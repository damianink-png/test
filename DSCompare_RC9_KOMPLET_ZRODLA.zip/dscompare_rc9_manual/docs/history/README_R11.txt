DS Compare V4.6 R11 FAST B-Rep

Zmiany: SHA-256 całego STEP -> jednokrotny import, pewne SAME bez powtórnych Booleans; porównanie różnych STEP stosuje serializację definicji B-Rep tylko jako dokładny dowód zgodności, nigdy nie uznaje samych gabarytów za dowód. Pamięć grup BOM reuse dla identycznych modeli; postęp dopasowania co 25 pozycji.

Ograniczenie: testy samych identycznych plików nie potwierdzają wydajności porównania rzeczywiście różnych rewizji ani importu do ZW3D 2019.
