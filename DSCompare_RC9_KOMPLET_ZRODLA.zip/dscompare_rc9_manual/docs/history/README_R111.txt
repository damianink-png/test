DS Compare V4.6 R11.1 — optymalizacja bez obniżenia dokładności

Zmiany:
1. Wspólny rejestr definicji kształtów STEP i pamięć sprawdzonych geometrii tylko w RAM
   podczas jednej analizy; te same dowody wykorzystują porównywanie i BOM.
2. Indeksowanie natywnych definicji TShape / powtarzających się wystąpień STEP:
   bez wielokrotnego skanowania utworzonych grup i serializowania tych samych definicji.
3. Kandydaci do kosztownych sprawdzeń B-Rep są filtrowani po objętości,
   polu powierzchni i momentach bezwładności; to tylko filtr, nie dowód zgodności.
   Odmienna niezależna geometria wciąż wymaga rzeczywistego testu B-Rep.

Nie zastosowano trwałego cache na dysku. Brak zmian w tolerancji B-Rep,
kolorystyce, regułach przesunięć i wymogu stuprocentowej zgodności.

Testy: python -m pytest -q tests
Kompilacja: .github/workflows/build-dscompare-v46-r111.yml na gałęzi
'dscompare-v46-r111-bom-fast' w repozytorium damianink-png/test.

Uwaga: uruchomienie DLL w rzeczywistym ZW3D 2019 wymaga weryfikacji.

R11.1 R2: Dodatkowe bezpieczne odroczenie serializacji B-Rep. Jeżeli filtr
cech nie wskazuje innej możliwej części w grupie, nie wykonuj kosztownego
zapisu B-Rep tej unikalnej bryły. Gdy pojawi się kandydat, nadal wykonuj
dokładną weryfikację geometrii.
