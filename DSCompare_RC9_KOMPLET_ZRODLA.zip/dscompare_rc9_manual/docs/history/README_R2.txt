DS Compare 4.6 R2 – poprawki stabilności

- Wybór plików wykorzystuje dialog Qt zamiast natywnego dialogu Windows.
- Wybierane pliki STEP/STP (również wielkie rozszerzenia); wpisanie ścieżki i drag-and-drop działa.
- Z3 można wybrać, ale jest to natywny format ZW3D, który wymaga eksportu do STEP przed analizą. Nie deklarujemy nieistniejącego importera Z3.
- Kliknięcie Porównaj uruchamia osobny proces. Błędy tego procesu są pokazywane zamiast wyłączenia GUI.
- Dodano diagnostykę wyjątków do %LOCALAPPDATA%\DSCompare\logs i automatyczny test gotowego EXE: kliknięcie wyboru pliku i Porównaj.
- Wyniki testu z GitHuba: WERYFIKACJA\UI_INTERACTIONS_PASS.json.

Zmiany dotyczą przede wszystkim stabilności Windows; oryginalny algorytm geometrii 4.6 R1 i podzłożenia STEP zachowano.
