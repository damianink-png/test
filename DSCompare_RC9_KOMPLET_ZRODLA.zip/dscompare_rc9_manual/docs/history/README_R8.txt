DS Compare V4.6 R8 — poprawki interfejsu i widoku złożenia

Naprawiono błąd „Internal C++ object (QPushButton) already deleted” podczas
zmiany zakładki i motywu. Przycisk starego panelu Ustawienia nie pozostaje
w słowniku aktywnej nawigacji.

Polskie nazwy produktów eksportowane do STEP. Dla przesuniętych: nowe
położenie B jest ciemnofioletowe, stare A jasnofioletowe (alfa).
Stare usunięte są pomarańczowe, nowe dodane niebieskie, bez zmian zielone.
W przypadku nakładania się brył ukryj grupę A_STARA lub B_NOWA
w drzewie złożenia. Nie przesuwaj geometrii tylko dla poprawy widoczności: 
w przeciwnym razie porównanie przestanie przedstawiać rzeczywiste pozycje.

Uwaga: plik STEP posiada przezroczystość per-powierzchnia (RGBA), ale
ZW3D 2019 może pomijać tę cechę podczas importu. Koloru/alpha nie da się
zagwarantować bez udokumentowanego API ZW3D 2019. Dwa odcienie fioletu
i ręczne ukrywanie podgrup działają jako niezależny sposób porównania.

ABSRn: kontroluj nazwy w surowym STEP (PRODUCT(...)). Jeżeli są tam
prawidłowe nazwy, a w drzewie ZW3D pojawia się ABSRn, nazwy generuje
importer ZW3D, a nie eksporter DS Compare. W takim przypadku potrzebne
są ustawienia importu ZW3D lub natywne API tej wersji — nie obiecujemy
niezweryfikowanego rozwiązania.

Filtr Zmiana nazwy działa dla świadomie nazwanych, geometrycznie
identycznych części; nie zgaduje zmian nazw z identyfikatorów technicznych.
Raport HTML ma listę statusów, wyszukiwarkę i licznik trafień.
Pliki robocze są przenoszone po udanym załadowaniu wyniku do
podfolderu DANE_TECHNICZNE; w przypadku awarii pozostają do diagnostyki.

DLL to eksperymentalny most ZW3D i nie została przetestowana w
procesie ZW3D 2019.
