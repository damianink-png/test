# DS Compare R10 — raport zmian i weryfikacji

## Wyniki
151 testów źródeł i Qt przeszło na Linux (Python 3.12). Dodano 10 przypadków R10.
Sprawdzono również rzeczywisty proces roboczy uruchamiany przyciskiem porównania,
eksport STEP na próbkach, dwa motywy i pusty start aplikacji. Obejrzano zrzuty UI.
Natywne okno wyboru plików Windows jest zastępowane atrapą w headless smoke test.
Windows EXE/DLL i importer ZW3D nie były uruchamiane lokalnie. Nie ma gwarancji
zgodności z każdym modelem bez testu na tych modelach. Workflow zawiera bramkę
testów rzeczywiście zbudowanego EXE/DLL, AP214/AP242 oraz przejścia GUI → worker.

## Szczególnie sprawdzone poprawki
- Symulowany wyjątek B-Rep nie staje się potwierdzonym usunięciem/dodaniem.
- Pozycje niepewne trafiają do grupy 06_DO_SPRAWDZENIA w rzeczywistym STEP.
- Tryb rewizji nie uruchamia odrzucanych obliczeń wspólnej objętości.
- Adwersarialne przypisanie 65 × 65: globalne minimum, którego dobór zachłanny nie znajduje.
- Przesunięte wystąpienia 10/65/120: kompletność, odległości, unikalne pary.
- Pełna i strukturalna kontrola eksportu na rzeczywistych plikach STEP.
- Import bryły razem z niezależną powierzchnią: poprawne ostrzeżenie i limit brył.
- Materiał Hardox pozostaje wybrany po restarcie mimo gęstości wspólnej ze stalą.
- Błąd eksportu pozostawia pasek STEP nieukończony przy gotowym raporcie.
- Zaktualizowano test starego zachowania, który wymagał kasowania niepewności.

## Pomiar czasu
Mediana 3 uruchomień na syntetycznych bryłach. Pomiar obejmuje wyłącznie
compare + classify_revisions; nie obejmuje importu, eksportu STEP, BOM ani startu
procesu. Nie jest prognozą czasu dla rzeczywistych złożeń.

| Scenariusz | R9 [s] | R10 [s] | Zgodność końcowych par i statusów |
|---|---:|---:|---|
| 100 zmienionych brył | 0.3958 | 0.0026 | Tak |
| 120 powtarzalnych przesuniętych brył | 0.9491 | 0.7279 | Tak |

## Ograniczenia i decyzje
- Duże grupy nadal mogą mieć kwadratową liczbę możliwych par; nie deklarujemy liniowej skalowalności.
  Ulepszono cache kandydatów i globalny dobór. Wykorzystanie hierarchii jako kryterium
  tożsamości pozostaje do sprawdzenia na rzeczywistych złożeniach, aby nie zmieniać par na ślepo.
- Dla grup ponad 60 elementów przypisanie jest optymalne kosztowo, ale jego jednoznaczność
  nie jest audytowana przez wielokrotne rozwiązywanie całego zadania. Raport to zaznacza.
- Import obejmuje bryły SOLID. Powierzchnie poza nimi są raportowane jako pominięte.
- Szybka kontrola STEP potwierdza obecność zapisów stylów; pełna sprawdza przypisania po imporcie.
- Limit brył jest konfigurowalny do 10000, lecz nie jest gwarancją szybkiej obsługi tylu części.
- Zmieniono aktywną aplikację gui46; starsze moduły zachowano dla zgodności i testów.
