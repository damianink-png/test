DS Compare 4.6 R4 — klasyfikacja rewizji i interfejs

Zmiany klasyfikacji w trybie porównania rewizji:
- BEZ ZMIAN = ta sama geometria i lokalizacja w układzie złożenia.
- PRZESUNIĘTE = ta sama geometria, zmieniona lokalizacja/obrót, taka sama liczba wystąpień tej samej definicji detalu (nazwa + geometria) w A i B. Kolor fioletowy dla obu pozycji, stara transparentna.
- Gdy ilość wystąpień tej definicji różni się: dopasowania co do położenia nadal zielone, niedopasowane sztuki STARE i NOWE, bez kategorii PRZESUNIĘTE dla tej definicji.
- Niepewne pary są rozdzielane na STARE/NOWE, nigdy do kategorii DO SPRAWDZENIA.
- ZMIENIONE wymagają tej samej nazwy i zmienionej geometrii; niejednoznaczności nadal mogą wymagać niezależnego przeglądu raportu.

Wygląd:
- Ciemny motyw: grafit/czerń zamiast fioletowego zabarwienia.
- Przełącznik sun/moon: wektorowy, jednoklikowy, bez emoji/fontowej ikony.
- Podświetlanie przy najechaniu kursorem: przyciski nawigacji, filtry, operacje, przełącznik motywu.
- Dopasowywanie okna do dostępnego rozmiaru ekranu, brak zewnętrznego przewijania; długie tabele obsługują przewijanie kółkiem bez widocznych pasków.
- Zwarty układ dla monitorów poniżej 1320x880.

UWAGA: widoczność i przezroczystość podzłożeń po imporcie do ZW3D 2019 nadal wymaga testu na stacji CAD.
