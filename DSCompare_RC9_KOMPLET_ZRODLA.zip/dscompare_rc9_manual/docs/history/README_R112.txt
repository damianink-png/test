DS Compare V4.6 R11.2 R1 — bezpieczne wspólne grupowanie BOM

Przy kompletnej bijekcji wyników SAME/RENAMED, prawidłowo zweryfikowane grupy BOM A
są przenoszone na rewizję B; przy zmianach/niepewności/niekompletnych parach B jest grupowane samodzielnie.
Jeżeli grupowanie A zawiodło, grupa awaryjna NIE jest wykorzystywana jako zweryfikowana.
Wszystkie testy obejmują również ten scenariusz.
Porównania B-Rep nie są zastępowane samymi parametrami objętości.
Plik EXE/DLL powstaje przez GitHub Actions. Działania DLL wewnątrz ZW3D 2019 nie przetestowano.
