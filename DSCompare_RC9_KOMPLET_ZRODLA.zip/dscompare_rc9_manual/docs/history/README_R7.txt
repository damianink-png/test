DS Compare 4.6 R7 - instrukcja

Uruchom DSCompareV3.exe z rozpakowanego katalogu.

POPRAWKI
- Wybor plikow: klasyczne systemowe okno Windows (PowerShell WinForms w procesie pomocniczym, aby nie powodowac awarii UI).
- Usunieto widoczna zakladke Ustawienia; parametry analizy sa w rozwijanej sekcji Porownanie, gestosc i folder zapisu w zakladce Masa czesci.
- Nowa wektorowa ikona motywu.
- Dopasowywanie przesunietych elementow bez ponawiania juz dowiedzionych testow B-Rep. Status postepu widoczny po etapie B-Rep.
- Przesuniete elementy tylko przy identycznej liczbie wystapien; w przeciwnym razie usuniete i dodane.

OGRANICZENIA
- Wczytywanie geometrii wymaga STEP / STP; wskazany plik Z3 zostanie odrzucony z instrukcja eksportu.
- Przy szczegolnie trudnym B-Rep eksport STEP moze trwac dlugo. Przy przerwaniu wyslij katalog wynikowy i _POSTEP_V37.jsonl.
- Nie testowano uruchomienia DLL w zainstalowanym ZW3D 2019.
