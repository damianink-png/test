DS COMPARE 4.6 R5 — POPRAWKI WYBORU PLIKÓW I POSTĘPU

1. Nienatywne okno Qt zachowuje mechanizm unikania awarii przy wyborze modelu.
2. Menu Szybki dostęp obok przycisku Wybierz plik: Pulpit, Dokumenty, Pobrane, katalog domowy i istniejące lokalizacje OneDrive.
3. Startowy katalog wyboru to Pulpit, jeśli istnieje; można też wkleić ścieżkę.
4. Po komunikacie końca testów B-Rep program wyraźnie pokazuje etap BOM A, BOM B, eksportu STEP i finalizacji.
5. Eksporter emituje postęp po każdych 50 elementach oraz przed dłuższym zapisem pliku.
6. BOM pomija kosztowny test sztywnej zgodności, gdy wstępne parametry nie pasują; nie zmienia tolerancji samego porównania.

UWAGA: Duże STEP ze znaczną liczbą unikalnych brył mogą wciąż eksportować się długo.
Pełna zgodność i czas w ZW3D 2019 zależą od importera i sprzętu.

Uruchamianie: rozpakuj cały ZIP Windows do nowego folderu i uruchom DSCompareV3.exe.
Nie usuwaj folderu _internal.
