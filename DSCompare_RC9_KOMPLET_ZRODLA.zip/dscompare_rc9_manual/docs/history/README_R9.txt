DS Compare V4.6 R9 FAST · Windows x64

NOWOŚCI:
- STEP udostępniany natychmiast po zapisie i automatycznej kontroli kolorów / struktury.
- HTML, CSV i BOM generowane dalej w osobnym procesie, bez blokowania przycisku STEP.
- Dwa wskaźniki: model STEP oraz raporty (etapy A, B, HTML).
- Przyspieszone grupowanie wystąpień tej samej natywnej bryły CAD, z dowodem geometrii dla odrębnych definicji.
- W masie: lista materiałów, ich gęstości i możliwość zapisania własnej pozycji.
- Panel wyniku poszerzony, przyciski w dwóch kolumnach.

UWAGA: przycisk otwiera STEP w domyślnej aplikacji przypisanej w Windows;
wybierz ZW3D jako aplikację domyślną lub wczytaj STEP w ZW3D.
Rozpoczęcie pracy z STEP nie wymaga ukończenia raportów.
Nie zamykaj programu, jeżeli nadal mają być tworzone raporty.
Biblioteka ZW3D 2019 DLL pozostaje rozwiązaniem eksperymentalnym.
