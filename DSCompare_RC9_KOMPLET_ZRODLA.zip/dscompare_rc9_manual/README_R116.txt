DSCompare — Windows x64 — R11.6
================================

URUCHOMIENIE
1. Rozpakuj ZIP do zwykłego folderu na dysku lokalnym (nie uruchamiaj z ZIP).
2. Uruchom DSCompare.exe. Nie przenoś samego EXE bez folderu _internal.
3. Wybierz A (stara) i B (nowa) jako STEP/STP, kliknij „Porównaj i utwórz STEP”.
4. Otwórz POROWNANIE_KOLORY.step w ZW3D; przy dużych złożeniach raporty mogą
   kończyć się kilka minut po zapisaniu STEP.
5. W parametrach można ustawić limit 1–50 000 brył na plik (domyślnie 20 000).
   Przy bardzo dużych złożeniach monitoruj RAM i wolne miejsce na dysku.

PLIKI PAKIETU
- DSCompare.exe — aplikacja z ikoną i wbudowanymi widokami GUI
- DSAssemblyCompare2019.dll — eksperymentalny most do ZW3D 2019 x64
- _internal/ — konieczne biblioteki PyInstaller, OCCT, Qt i VTK; nie usuwać
- README_R116.txt — instrukcja
- SHA256.txt — sumy kontrolne

STEP / STRUKTURA
Plik STEP ma grupy zmian i nazwy CAD przygotowane do importu w ZW3D,
bez technicznych nawiasów z metadanymi. Program nie usuwa SOLID w celu
uproszczenia drzewa. Importer ZW3D może jednak nadawać wybranym kształtom
lokalne, automatyczne nazwy (np. ABSR); sama zmiana zapisu PRODUCT
nie gwarantuje nadpisania takich nazw. Prosimy zachować problematyczny STEP
A/B do testów, jeśli w ZW3D nadal powstaną takie wpisy.

BOM
Dla niektórych oryginalnych STEP biblioteka OCCT może nie rozstrzygnąć
równoważności geometrycznej. Program zgłasza ostrzeżenie zamiast zgadywać.
Tryb bez pełnego BOM jest szybszy. Pełny BOM wymaga oddzielnych testów na dużych złożeniach; status R11.6
potwierdzają wyniki workflow Windows w repozytorium GitHub.

ZW3D 2019
Kompilacja i załadowanie DLL w Windows CI nie zastępują uruchomienia
w instalacji ZW3D 2019 — to trzeba sprawdzić na docelowym komputerze.
