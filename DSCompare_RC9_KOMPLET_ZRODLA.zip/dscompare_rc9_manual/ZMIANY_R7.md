# DS Compare 1.0 R7

- Weryfikacja dopasowania kotwic na całym złożeniu przez geometrię B-Rep; przy niskim poparciu ponowne szukanie translacji z części powtarzalnych.
- Wyszukiwanie sąsiadów według odległości zamiast równości zaokrąglonych komórek.
- Podgląd zachowuje wszystkie wystąpienia: cel 300000 trójkątów jest informacyjny. Bardzo duże pliki HTML mogą działać wolniej.
- Przycisk Usunięte A oraz opcja widoczności starej rewizji przez nową.
- Nie zmieniono eksportu STEP/ABSR ani kryteriów zgodności geometrii.

109 testów regresji: PASS lokalnie. Test syntetyczny 380 brył: 231 bez zmian, 2 przesunięte lokalnie, 147 usuniętych i 147 nowych. To nie jest weryfikacja plików użytkownika, których nie udostępniono. Zachowano próg poparcia wyrównania 60%; niejednoznaczne dopasowanie nadal może zostać odrzucone.
