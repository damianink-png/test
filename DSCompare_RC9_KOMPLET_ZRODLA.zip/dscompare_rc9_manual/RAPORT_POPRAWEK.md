# DSCompare RC9 — analiza i poprawki, 30.10.2026

Podstawa: załączone źródła z commitu `b1f735d8b043c414cf6299ba9a071975ef775965`, repozytorium [damianink-png/test](https://github.com/damianink-png/test), [ostatni przebieg 41002751992](https://github.com/damianink-png/test/actions/runs/41002751992).

## Ustalenia z GitHub

Przejrzano metadane przebiegu, log zadania Trident shift oraz pobrano i przeanalizowano cztery artefakty nieudanych scenariuszy:

| Scenariusz | ID artefaktu | Przyczyna zakończenia ostatniego CI |
| --- | --- | --- |
| Trident shift | 12954858313 | `Common`: niemożliwa ujemna objętość −292,955609 mm³ |
| Trident revision_shift | 12955830073 | taki sam błąd ujemnej objętości `Common` |
| V2 shift | 12955437108 | `Common`: przekroczenie 90 sekund |
| V2 revision_shift | 12955582466 | `Common`: przekroczenie 90 sekund |

Build i Trident revision zakończyły się powodzeniem. Awaria scenariuszy przesunięcia następuje już po wyrównaniu, podczas próby analizy wspólnego materiału dla par wcześniej odrzuconych przez kontrolę zgodności. Samo `exit=1` nie wskazywało przyczyny; ustalenia pochodzą z `DIAGNOSTYKA_BLEDU.txt`, zapisanego wyniku workera i B-Rep.

## Naprawione błędy

1. `dsac29/parametric_identity.py`: filtr obrysów używał `BRepBndLib.Add_s`, którego wynik zależy od zapisanych tolerancji krawędzi i zachowawczych oszacowań łuków. W rzeczywistym V2 ta sama krzywa po ponownym eksporcie miała inne granice. Zastosowano `AddOptimal_s(..., False, False)` przed dotychczasowym pełnym dowodem powierzchni i zorientowanych krawędzi.
2. `dsac29/step_reexport_tolerance.py`: różnicę końców konserwatywnych AABB błędnie traktowano jako dowód zmiany bryły. Nawet `AddOptimal` zwraca zachowawcze granice niektórych powierzchni przyciętych. W rzeczywistym Trident różnica wynosiła 0,292893 mm, mimo pozytywnego pełnego dowodu geometrii. Filtr odrzuca teraz rozłączne pudełka. Pudełka nakładające się dopuszczają parę do istniejącego pełnego dowodu; same nie potwierdzają zgodności.

Tolerancja użytkownika pozostaje 0,01 mm. Nie zmieniono operacji Boolean, reguł naprawy nieprawidłowego B-Rep, reguł SAME/MOVED ani eksportu. Fałszywy wynik pełnego dowodu nadal odrzuca parę. Testy obejmują przesunięcia ponad tolerancję, zmienioną geometrię i wymuszoną odmowę dowodu krawędzi.

## Weryfikacja

- 51 testów dotyczących porównania, wyrównania i nowych regresji: PASS.
- 9 testów funkcyjnych z aktualnych skryptów CI repozytorium: PASS; skrypty z kontrolami wykonywanymi przy imporcie również przeszły.
- Dodatkowo 18 skryptów CI uruchomiono jako osobne programy: PASS. To częściowo te same kontrole, nie dodatkowe 18 niezależnych testów pytest.
- Weryfikacja składni modułów Python: PASS.
- Skrypt nakładający poprawki sprawdzono na oryginalnych źródłach i przy powtórnym uruchomieniu: PASS.
- Główna weryfikacja na `cadquery-ocp==7.9.3.1.1`, zgodnie z diagnostyką CI; Linux/Python 3.12. GitHub używa Windows/Python 3.11.
- Dołączono niezmienione pary B-Rep dla V2 i Trident wraz z pochodzeniem, testy regresji, wyniki XML oraz odtworzenia lokalne w `diagnostics/`.

| Odtworzenia po obu poprawkach | Pozytywny pełny dowód | Po deduplikacji |
| --- | --- | --- |
| V2 shift | 18/20 zapisów | 10/11 różnych par |
| Trident shift | 14/16 zapisów | 7/8 różnych par |

W obu przypadkach niepotwierdzona para występuje w artefakcie dwukrotnie. Dodatkowy izolowany worker na niepotwierdzonej parze V2 również zwrócił `match=false`, po próbie naprawy kopii.

Wyniki odtworzeń dotyczą zapisanych par `world_negative_*`, a nie kompletnych złożeń. Powtarzające się pliki policzono osobno i po deduplikacji; zestawienie jest w `diagnostics/replay-summary.json`.

## Pozostały problem i granice wyniku

W obu złożeniach pozostaje para, w której źródłowe A nie przechodzi `BRepCheck_Analyzer`, natomiast B jest prawidłowe. Zapisane zestawy różnią się też liczbą powierzchni B-Spline o danej orientacji. Zmiany filtrów nie usuwają tej różnicy i nie są dowodem zgodności tej pary. Lokalny negatywny wynik dowodu oznacza brak certyfikacji, nie potwierdzenie zmiany materiału.

Przygotowane poprawki usuwają wykazane błędy rozpoznawania poprawnych par, w tym parę Trident, na której ostatnio kończyła się operacja Common. Nie stanowią potwierdzenia naprawy wszystkich dużych scenariuszy. Pełny build i testy Windows na Trident/V2 trzeba uruchomić ponownie; nie zostały uruchomione w tej sesji. Nie opublikowano zmian w repozytorium.

## Użycie paczki

W istniejącym repozytorium na gałęzi `feature/rc9-old-engine-proof-cache-20261029` rozpakować paczkę do katalogu głównego. Zachować istniejące archiwum bazowe i pozostałe skrypty repozytorium. Dołączony workflow nakłada nowy `ci/patch_rc9_wire_bounds.py` po dotychczasowym łańcuchu poprawek, a następnie uruchamia nowe testy z rzeczywistymi B-Rep przed budowaniem. Przekazane osobno pliki `dsac29/` zawierają już obie poprawki.

Skrypt można też zastosować bez workflow: `python ci/patch_rc9_wire_bounds.py SCIEZKA_DO_ZRODEL`.
