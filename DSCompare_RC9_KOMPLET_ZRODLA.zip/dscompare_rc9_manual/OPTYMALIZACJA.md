# DSCompare RC9 — optymalizacja i porównanie z rozwiązaniami open source

## Co zmierzono w obecnym programie

W artefakcie V2 shift z przebiegu GitHub 41002751992 suma czasów 1587 wywołań `verify_reexport_guarded` wynosi około 864,657 s. Dla Trident shift: 606 wywołań i około 624,029 s. Są to sumy czasów wskazanych wywołań z dziennika, nie niezależne benchmarki całych aplikacji.

Kod `deferred_alignment.propose` sprawdza najpierw próbkę do 24 par, a potem wszystkie dopasowania. Obie kontrole dostawały nowy rejestr geometrii i nowe pamięci dowodów, mimo identycznych położeń i tolerancji. Powtarzało to kosztowną serializację definicji i część pełnych dowodów B-Rep.

## Wdrożona zmiana

Dodano `FrameProofCache`, wspólny wyłącznie dla próbki i pełnej kontroli jednej hipotezy przesunięcia. Przechowuje rejestr definicji, potwierdzone kotwice i pozytywne wyniki konkretnych par. Osobny obiekt powstaje dla każdego przesunięcia.

Wyniki pozostają związane z kolejnością i tożsamością wystąpień, dokładnym położeniem i orientacją TopoDS oraz tolerancją. Zmiana wejść powoduje odrzucenie użycia pamięci. Wyniki negatywne, nierozstrzygnięte, awarie i timeouty nie są zapamiętywane jako dowody. Pełna kontrola nadal przechodzi wszystkie krawędzie grafu dopasowań potrzebne do ustalenia mapowania 1:1. Sama próbka nie zatwierdza całego złożenia.

Dodano liczniki `registration_proof_cache` do dziennika diagnostycznego: trafienia, próby dowodu i liczba zachowanych wyników. Dane pozwolą ocenić korzyść na pełnych złożeniach w Windows.

## Pomiar przed i po

Linux, Python 3.12, `cadquery-ocp==7.9.3.1.1`. Dwie niezmienione pary B-Rep z artefaktów V2 i Trident; próbka, a następnie pełna kontrola. Cztery pomiary każdego wariantu, naprzemienna kolejność. Wariant „przed” to kod sprzed tej optymalizacji, zawierający już poprzednie poprawki granic geometrycznych.

| Miara | Przed | Po |
| --- | --- | --- |
| Mediana czasu | 3,7168 s | 1,9538 s |
| Pełne kontrole B-Rep | 4 | 2 |
| Potwierdzone pary | 2 | 2 |

W tym pomiarze czas etapu skrócił się o około 47,4% — przyspieszenie 1,90×. Wynik nie uwzględnia importu STEP, startu izolowanych procesów, eksportu, GUI ani innych hipotez przesunięcia. Nie jest pomiarem przyspieszenia całego Trident/V2. Dane surowe: `diagnostics/frame-cache-benchmark.json`.

## Weryfikacja

- 75 testów porównania, wyrównania, poprzednich poprawek i nowej pamięci: PASS.
- 9 testów funkcyjnych aktualnych skryptów CI: PASS, wraz z kontrolami wykonywanymi przy imporcie tych skryptów.
- Osiem nowych testów obejmuje ponowne użycie pozytywnego dowodu, zmianę położenia/tolerancji/kolejności, podmianę TopoDS, brak współdzielenia różnych hipotez, ponowną próbę po błędzie natywnym oraz dwie rzeczywiste pary.
- Osobny istniejący test pełnego dowodu po próbce (`test_rc9_interleaved.py`): PASS.
- Instalator CI sprawdzono na źródłach sprzed optymalizacji, przy powtórnym zastosowaniu i na nieznanej wersji źródła, którą odrzuca.

## Przejrzane projekty i wykorzystane pomysły

| Projekt / źródło | Rozwiązanie | Wniosek dla DSCompare |
| --- | --- | --- |
| [CADdiff — geom_diff.py](https://github.com/angel291592/caddiff/blob/main/caddiff/geom_diff.py) i [README](https://github.com/angel291592/caddiff) | Oddzielenie szybkiej klasyfikacji od kosztownej różnicy Boolean; izolowane procesy z limitami czasu | Zachować etapy i izolację, które DSCompare już ma. Warto usuwać powtórzenia między etapami. Skrót „identical” oparty na objętości i wymiarach nie spełnia obecnych wymagań pełnej kontroli B-Rep DSCompare. |
| [FreeCAD — App/Link.h](https://github.com/FreeCAD/FreeCAD/blob/main/src/App/Link.h) | Definicja obiektu i odrębne położenia jego wystąpień | W DSCompare istnieje już `GeometryRegistry`. Wdrożona zmiana wydłuża jego życie na dwa przebiegi tej samej hipotezy. |
| [CadQuery — occ_impl/assembly.py](https://github.com/CadQuery/cadquery/blob/master/cadquery/occ_impl/assembly.py) | `unique_objs` i pamięć współdzielonych obiektów/siatek podczas eksportu złożenia | Nie przeliczać definicji dla każdego wystąpienia. DSCompare ma już `SharedMesh`; należy zachować tę współdzieloną reprezentację w kolejnych zmianach eksportu. |
| [Analysis Situs — BVH](https://github.com/CadQuery/AnalysisSitus/blob/master/src/asiAlgo/auxiliary/asiAlgo_BVHAlgo.h) oraz [BVHAttr](https://github.com/CadQuery/AnalysisSitus/blob/master/src/asiData/part/asiData_BVHAttr.h) | Indeks przestrzenny przechowywany wraz z danymi geometrii | Kolejny kandydat: indeks nakładających się pudełek dla `revision_overlap`, gdy wiele części naprawdę się zmienia. Obecny indeks środków w `compare` już istnieje. BVH byłby filtrem kandydatów, nie dowodem zgodności. |
| [OpenCascade — BRepAlgoAPI_BooleanOperation](https://github.com/Open-Cascade-SAS/OCCT/blob/V7_9_3/src/BRepAlgoAPI/BRepAlgoAPI_BooleanOperation.hxx) | Operacje na wcześniej obliczonych przecięciach (`BOPAlgo_PaveFiller`) | To podejście jest już użyte w `material_deltas`. Nie dokładano drugiej implementacji tego samego mechanizmu. |

Implementacja optymalizacji jest własna; do programu nie skopiowano kodu tych projektów.

## Kolejne obszary, według priorytetu

1. **Wiarygodna diagnoza nieprawidłowych brył.** Pozostały problem z niepotwierdzonymi B-Rep z poprzedniego raportu nadal występuje. Pamięć dowodów go nie naprawia. Warto zakończyć taki przypadek czytelną informacją o konkretnej części, zamiast dochodzić do kosztownej operacji materiałowej bez wystarczającego dowodu.
2. **Cache importu STEP.** Istniejący `import_cache.py` używa SHA-256 całego pliku, wersji OCCT i schematu, lecz domyślnie jest wyłączony. Do zmierzenia pozostają kolejne uruchomienia z `DSCOMPARE_IMPORT_CACHE=auto`, z uwzględnieniem miejsca na dysku. Nie zmieniono tutaj wartości domyślnej.
3. **Indeks przestrzenny analizy zmian materiału.** Obecny `revision_overlap` filtruje po osi X, a następnie ocenia pary. Drzewo AABB/BVH może ograniczyć liczbę kandydatów przy dużych, rzeczywiście zmienionych rewizjach. Przed wdrożeniem potrzebny pomiar takiego scenariusza.
4. **Koszt transportu B-Rep i sesji procesów.** `WorldSession` już ogranicza liczbę startów workerów. Następny pomiar powinien osobno pokazać serializację, start procesu, odczyt i właściwy dowód. Dopiero wtedy warto dobierać rozmiar partii lub liczbę procesów; większa równoległość zwiększa także szczytową pamięć.

## Pliki i uruchomienie CI

Nowa paczka zawiera wcześniejsze poprawki i nową optymalizację. Poprzednia paczka pozostaje dostępna osobno. Rozpakować nową do katalogu głównego dotychczasowego repozytorium. Workflow nakłada `ci/patch_rc9_frame_cache.py` po poprzednim łańcuchu poprawek i uruchamia nowe testy przed zbudowaniem EXE. Instalator kontroluje wersję obu modyfikowanych plików.

Pełny build/test Windows dużych złożeń nie został uruchomiony w tej sesji. Zmiany przygotowano lokalnie, bez publikacji w GitHub.
