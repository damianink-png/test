# DS Compare 1.0 R6 — HTML 3D

Dodano do produkcyjnego UI opcję generowania podglądu i przycisk Podgląd 3D.
Przyciski wyników są ułożone w dwóch kolumnach, aby mieściły się na mniejszych ekranach.
Opcja jest domyślnie włączona, zapamiętywana i może zostać wyłączona.

Samodzielny HTML zawiera geometrię i kod WebGL. Nie pobiera bibliotek ani
modelu z internetu. Obsługuje obrót, przesuwanie, zoom, widoki ortogonalne
kierunkowo (kamera pozostaje perspektywiczna), izometrię, dopasowanie oraz
widoczność kategorii zmian. Stare i nowe położenia części są pokazywane osobno.
Kolory odpowiadają palecie eksportu rewizji, a przezroczystość A ustawieniu aplikacji.
Przezroczyste wystąpienia są sortowane wg głębokości środka — w złożonych
nakładających się bryłach możliwe są artefakty typowe dla takiego renderowania.

Generowanie wykorzystuje bryły już obecne w pamięci po wyrównaniu B → A;
nie importuje ponownie STEP. Triangulacja kosztuje dodatkowy czas i pamięć.
Główny STEP i podstawowy raport są dostępne przed końcem generowania podglądu.
Błąd opcjonalnego podglądu jest zgłaszany w raporcie i nie unieważnia STEP.
Szablon HTML został dodany do pakowania PyInstaller.

Limit siatki: 300 000 trójkątów. Nie zapisuje się połowy bryły; wystąpienie
niemieszczące się w budżecie jest pomijane, a HTML podaje liczbę pominiętych.
Duże współrzędne są centrowane przed zapisem float32, by ograniczyć utratę precyzji.

Eksporter STEP i obsługa ABSR oraz reguły porównywania pozostają z R5.
W O programie pozostaje Wersja 1.0, rewizja techniczna R6.

Weryfikacja: 106 testów wybranej aktualnej bramki regresji PASS;
kontrola uruchomienia Qt — 3 strony, 2 motywy — PASS;
generowanie HTML z przykładowych RAMA_REV_03.step i RAMA_REV_04.step — PASS;
sprawdzenie składni JavaScript — PASS.
Nie wykonano lokalnej kompilacji Windows ani testu w natywnym ZW3D.
Workflow GitHub buduje Windows i sprawdza uruchomienie EXE.

Pełnego testu renderowania WebGL w przeglądarce nie wykonano: pobieranie
przeglądarki testowej zwracało uszkodzony pakiet. Wymagany test w przeglądarce użytkownika.
