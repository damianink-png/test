DS COMPARE 1.0 - PELNE ZRODLA PRZED KOMPILACJA
================================================
To jest kompletna migawka zrodel programu po zastosowaniu poprawek 1.0,
a przed uruchomieniem PyInstaller. Nie zawiera gotowego EXE.

ZAWARTOSC
- DSCompareV3.py              punkt startowy programu
- dsac29/                     caly silnik, eksport STEP, raporty i UI
- assets/                     ikony i grafiki programu
- tests/                      testy dostarczone ze zrodlami
- requirements.txt            zaleznosci projektu
- BUDUJ_WINDOWS.ps1            instalacja zaleznosci i kompilacja
- MANIFEST_SHA256.txt          kontrola integralnosci plikow

KOMPILACJA LOKALNA (Windows 64-bit):
1. Zainstaluj Python 3.11 x64.
2. Rozpakuj archiwum do katalogu bez polskich znakow w sciezce, np. C:\DSCompareR1132.
3. Otworz PowerShell w rozpakowanym katalogu.
4. Uruchom:
     powershell -ExecutionPolicy Bypass -File .\BUDUJ_WINDOWS.ps1
5. Uruchom dist\DSCompare\DSCompare.exe. Zawsze zachowaj caly folder DSCompare (w tym _internal).

Uruchomienie zrodel (po zainstalowaniu pakietow):
     python DSCompareV3.py

Zrodla interfejsu 1.0 korzystaja z silnika CAD i eksportu STEP R11.32.
Wymagane sa Windows x64 i biblioteki OCP oraz Qt.
Kompilacja PyInstaller moze wymagac dostepu do internetu do instalacji pakietow.

Uwaga: Pliki STEP z modeli firmowych NIE sa elementem tej paczki.
