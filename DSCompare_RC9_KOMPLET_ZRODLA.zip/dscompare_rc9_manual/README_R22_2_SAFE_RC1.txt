DS COMPARE R22.2 SAFE RC1 — DO KOMPILACJI WINDOWS X64
======================================================
1. Do GitHub w katalogu głównym wgraj:
   DSCompare_1_0_R22_2_SAFE_RC1_ZRODLA.zip
2. W repozytorium utwórz katalog .github/workflows i umieść osobny plik:
   build-dscompare-r22-2-safe.yml
3. Actions > DS Compare R22.2 SAFE RC1 > Run workflow.
4. Pobierz artefakt DSCompare-R22.2-SAFE-RC1-Windows-x64.
5. Przejrzyj wyniki i logi czterech testów w artefaktach evidence-*.

To jest wersja przedprodukcyjna. Nie została jeszcze skompilowana ani
przetestowana na Voron V2/Trident w konfiguracji Windows. Wymagany PASS testów.
W wariancie SAFE odizolowane natywne operacje Open CASCADE mają krótki limit.
Niepowodzenie oznacza nieukończoną analizę, nie dopasowanie brył. Wykrywanie
wspólnego przesunięcia i oznaczanie rzeczywistych zmian pozostało obowiązkowe.

Kompatybilność: Windows x64, Python 3.11 + Open CASCADE / cadquery-ocp.
