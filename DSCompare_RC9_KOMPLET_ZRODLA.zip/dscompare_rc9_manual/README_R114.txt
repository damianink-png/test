DS Compare V4.6 R11.4 — dokladne grupowanie BOM / odporne Boolean

Zmiana: Gdy Open CASCADE Common nie moze obliczyc przeciecia dwoch bryl, program podejmuje niezalezna probe obliczenia obustronnych roznic geometrycznych (Cut A-B i Cut B-A). Wynik uznaje za zgodny TYLKO gdy obie operacje powiodly sie i obie roznice zmiescily sie w oryginalnej tolerancji. Przy niepowodzeniu obu metod wynik pozostaje nierozstrzygniety, z ostrzezeniem w raporcie. Material, nazwa, masa i gabaryty nigdy nie sa dowodem identycznosci.

Dodano 4 testy regresyjne wymuszajace blad Common, potwierdzajace rygorystyczne Cut, brak falszywego grupowania roznych czesci i zachowanie ostrzezen przy dwoch bledach Boolean.

To nie jest gwarancja, ze kazdy niepoprawny model STEP lub zlozenie przejdzie pełny BOM. Warunek wydania Windows: 183 testy i pelny benchmark SO101/OLSK bez bledow.

Integracja DLL z zainstalowanym ZW3D 2019 wymaga osobnego testu uzytkownika.
