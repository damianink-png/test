"""Baked STEP re-export: either full proof or explicit unresolved, never guessed."""
import sys,time,json
from pathlib import Path
from OCP.BRepBuilderAPI import BRepBuilderAPI_Transform
from OCP.gp import gp_Trsf,gp_Vec
from dsac29.step_io import load_step,ColoredDocument
from dsac29.deferred_alignment import _step_reexport_fallback
source=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
a=load_step(str(source));tr=gp_Trsf();tr.SetTranslation(gp_Vec(1275,-395,210))
doc=ColoredDocument();target=out/'BAKED_COPY.step'
for p in a:doc.add(BRepBuilderAPI_Transform(p.shape,tr,True).Shape(),p.name,(.2,.8,.2))
doc.write(str(target));b=load_step(str(target));start=time.monotonic()
proposal=_step_reexport_fallback(a,b,0,.01,progress=lambda s:print(s,flush=True))
elapsed=time.monotonic()-start
print('RESULT',proposal,'SECONDS',elapsed,flush=True)
assert proposal is not None
if proposal['status']=='registered':assert len(proposal['full_pair_map'])==len(a)==len(b)
else:assert proposal['status']=='unresolved' and proposal['invalid_pairs']>0
(out/'DIAGNOSTYKA.json').write_text(json.dumps({'seconds':elapsed,'proposal':proposal},indent=2,ensure_ascii=False),encoding='utf8')
