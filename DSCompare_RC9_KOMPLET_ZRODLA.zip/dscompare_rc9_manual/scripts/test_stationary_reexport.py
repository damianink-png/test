import sys,time,numpy as np,json

from dsac29.step_io import load_step
from dsac29.alignment import _relocate
from dsac29.compare import compare
from dsac29 import deferred_alignment
from collections import Counter
from pathlib import Path
a=load_step(sys.argv[1]);b=load_step(sys.argv[2])
b=[_relocate(p,np.eye(3),np.array([-1275.,395.,-210.])) for p in b]
def forbidden(*a,**kw):raise AssertionError('Unnecessary translation search')
deferred_alignment.propose=forbidden
start=time.monotonic()
rec=compare(a,b,.01,revision_only=True,exact_serialization=True,stage1_check=lambda rec,fa,fb:deferred_alignment.propose_from_stage1(a,b,rec,fa,fb,.01))
c=Counter(r.status for r in rec);assert c['SAME']+c['RENAMED']==19,c
result={'statuses':dict(c),'seconds':time.monotonic()-start,'translation_search_calls':0}
Path(sys.argv[3]).write_text(json.dumps(result,indent=2))
print(result,flush=True)
