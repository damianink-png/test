DS COMPARE R11.9 — BAZA R11.8 (ZW3D 2019 / Windows x64)
=======================================================

NAJWAŻNIEJSZE POPRAWKI
1. Eksport STEP — nowy domyślny tryb "Bezpieczny STEP do ZW3D".
   Każde wystąpienie bryły ma niezależną definicję w STEP; nie jest ona
   współdzielona z innymi wystąpieniami. Ogranicza to niezgodności importerów
   CAD, mogące objawiać się dodatkowymi / błędnymi elementami w złożeniu.
   Zachowane podzłożenia wg zmian oraz kolory całych brył.
   Tryb może zwiększyć rozmiar pliku i czas eksportu na dużych złożeniach.
   Przy dokładnej weryfikacji sprawdzana jest też liczba brył SOLID po imporcie.
   Uwaga: bez konkretnego wadliwego STEP i testu ZW3D 2019 nie ma gwarancji,
   że wszystkie zgłaszane artefakty zniknęły. Nie usuwamy żadnych części.
2. BOM — od tej wersji domyślnie włączony, także po migracji ustawień.
   Przyciski "BOM A" i "BOM B" otwierają BOM_A.csv oraz BOM_B.csv.
   Zestawienia mają kolumny: nazwa, ilość, objętość/szt., masa/szt.,
   masa łączna, ścieżka w złożeniu. Oba BOM są w RAPORT.html.
3. Raporty — tylko jeden końcowy RAPORT.html, bez RAPORT_ZMIAN.html;
   niezależny ZMIANY.csv pozostaje, bo zawiera wiersze zmian.
4. Interfejs — trzy zakładki: Porównanie, Masa części, Ustawienia.
   Tolerancja, limit brył, kolory, format, BOM i weryfikacja w Ustawieniach.
   Bez przycisku "Parametry porównania" na stronie głównej.
   Nowe wektorowe ikony o jednym stylu, w tym "Anuluj", "Wybierz", BOM,
   odśwież, zamiana modeli, motyw, raporty i START.
   Bez miniatur modeli obok ścieżek i bez generowania MINIATURA_*.json.
5. Z3 — natywnego pliku ZW3D nie odczytuje Open CASCADE. Można jednak
   wskazać Z3; program AUTOMATYCZNIE wyszuka .step/.stp o tej samej nazwie
   obok niego. Wymaga uprzedniego eksportu aktualnego modelu w ZW3D:
   Plik -> Eksport -> STEP (AP214); np. rama.z3 -> rama.step.
   Stary plik STEP jest odrzucany, aby nie porównać wcześniejszej rewizji.
   Samodzielny import geometrii z natywnego Z3 NIE został zaimplementowany.
6. Równoległy import z R11.8 nadal działa. W dużych złożeniach zależnie od
   dostępnej pamięci i wielkości plików aplikacja wybiera import A+B naraz.

WYNIKI W FOLDERZE PORÓWNANIA
- POROWNANIE_KOLORY.step — złożenie wg statusów
- RAPORT.html — jeden końcowy raport, w tym zestawienie BOM A/B
- BOM_A.csv — pogrupowana stara rewizja, BOM_B.csv — pogrupowana nowa
- ZMIANY.csv — szczegóły zmian dla każdej pary / wystąpienia
- DANE_TECHNICZNE — logi diagnostyczne, pliki pomocnicze

JAK ZBUDOWAĆ WINDOWS x64
1. Rozpakuj DSCompare_R119_GITHUB.zip.
2. Prześlij DSCompare_R119_ZRODLA.zip do głównego katalogu repo GitHub.
3. Prześlij build-dscompare-r119.yml do .github/workflows/.
4. GitHub Actions > DS Compare R11.9 Windows > Run workflow.
5. Po udanym workflow pobierz Artifacts / DSCompare-R119-Windows-x64-EXE-DLL.
6. Rozpakuj cały wynikowy ZIP. Uruchom DSCompare.exe, zachowaj katalog _internal.

Uwaga: paczka źródeł NIE JEST skompilowanym programem Windows. Testy
algorytmiczne wykonano na Linux z OCP, testy UI/Windows i działanie
natywnego importera ZW3D 2019 wymagają uruchomienia na Windows.
