# DS Compare 1.0 R5 — porządkowanie i wydajność

Baza: dostarczona wersja R4. Zmiany R4 pozostają zachowane.

- Jeden indeks przestrzenny A dla wszystkich hipotez powtarzalnego przesunięcia.
- Podczas oceny hipotez przechowywane są wyniki i transformacje, a nie kilka
  pełnych złożeń B. Pełna lista wynikowa powstaje dla zwycięskiej transformacji.
- Zbiory zajętych indeksów zamiast wielokrotnego przeszukiwania list par baz.
- Równoległy importer otrzymuje skrót SHA-256 i rozmiar/czas modyfikacji
  sprawdzone przez rodzica. Gdy statystyki pliku nie pasują, cache oblicza skrót
  ponownie. Nadal zachowano istniejące reguły zgodności cache.
- Limit oczekiwania na procesy importu: domyślnie 1800 sekund. Po przekroczeniu
  oba procesy są kończone i sprzątane, bez automatycznego ponawiania importu.
  Zwykła awaria importera nadal pozwala na dotychczasowy powrót do importu
  sekwencyjnego. Limit nie obejmuje importu sekwencyjnego ani całej analizy.
- Dane masy przechodzą bezpośrednio w pamięci do raportu zbiorczego. Zachowano
  format liczb i zabezpieczenia nazw CSV, raporty modeli oraz raport zbiorczy.
- Sprzątanie znanych starych ostrzeżeń i opcjonalnego podglądu porównania
  przy ponownym użyciu folderu. Nie usuwa się innych plików użytkownika.
- Raport HTML jest publikowany wcześnie jak poprzednio. Jeśli późniejszy
  opcjonalny eksport różnic lub podgląd zawiedzie, raport zostaje atomowo
  uzupełniony o ostrzeżenie. Poprawny główny STEP pozostaje ważny.

Eksport STEP/ABSR, geometry.py, revision_rules.py i wszystkie trzy warstwy
obecnego interfejsu są identyczne z R4. W O programie pozostaje Wersja 1.0.
Starszych warstw GUI nie usunięto, bo obecny interfejs ich używa.

## Weryfikacja
103 testy aktualnej bramki TESTUJ.py: PASS. Zestaw zawiera 91 testów R4,
6 regresji R5 i 6 testów importu równoległego, w tym rzeczywiste procesy STEP.
Sprawdzono zgodność importu sekwencyjnego i równoległego, sprzątanie po limicie,
brak sekwencyjnego ponowienia po limicie, wykorzystanie skrótu rodzica,
zgodność CSV masy, jeden indeks wyrównania oraz ostrzeżenia w HTML.
Zachowano testy przesunięcia całego złożenia, obrotu i ruchów lokalnych.

Środowisko: Linux, Python 3.12, OCP 7.8.1.1.post1, PySide6 6.8.3.
To wybrana aktualna bramka regresji, nie wszystkie historyczne testy repozytorium.
Nie wykonano tutaj kompilacji Windows ani próby w natywnym ZW3D.
Workflow GitHub Actions uruchamia testy, kompiluje EXE i sprawdza jego UI.
Nie wykonano nowego pomiaru przyspieszenia całej analizy; wyniki w
benchmarks/wynik_R3_R4.json dotyczą wyłącznie poprzedniej zmiany R3 → R4.
