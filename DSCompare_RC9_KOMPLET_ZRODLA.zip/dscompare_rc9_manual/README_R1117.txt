DS Compare R11.17: poprawki rzeczywistego UI PySide6 i postępu

* Okno O programie: jeden przycisk zamknięcia w pasku Windows, logo bez kolizji.
* STEP można otworzyć natychmiast po zapisie i weryfikacji, przed BOM.
* Zamiast szybko skaczącej animacji BOM pokazuje rzeczywisty raport_percent.
* Nowe porównanie czyści wybrane pliki, tabelę, wyniki i paski postępu, pozostawia poprzednie wyniki na dysku.
* Bezpieczny STEP ma natywne warstwy AP242 nazwane według statusów. Warstwy nie są natywnymi podzłożeniami ZW3D.
* Brak pustych kontenerów ABSR; natywne podzłożenia wymagają weryfikacji komendy ZW3D 2019 API.
