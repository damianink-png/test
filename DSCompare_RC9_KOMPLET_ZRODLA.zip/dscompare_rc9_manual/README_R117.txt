DSCompare R11.7 — dopracowanie interfejsu i STEP do ZW3D

- DSCompare.exe, ikona programu w oknie i na pasku zadań.
- Limit brył do 50 000 na plik (domyślnie 20 000).
- Parametry zawierają edytor 9 niezależnych kolorów (bez zmian, nowe, usunięte, przesunięte A/B, zmienione A/B, nierozstrzygnięte A/B).
- Usunięte z interfejsu ustawienie przezroczystości: elementy STEP eksportowane nieprzezroczyście, bo importer ZW3D 2019 może ignorować alfa.
- Zbędny pasek logu jest ukryty, a tabela wyników dopasowuje szerokości kolumn bez poziomego przewijania. Szczegóły zapisywane są w folderze wyników.
- Domyślnie eksport STEP do ZW3D stosuje kolory na poziomie całych SOLID/definicji XCAF, a nie osobnych ścian; może ograniczyć automatycznie nazywane dodatkowe obiekty ABSR. Zachowuje kolor i strukturę złożeń CAD, choć działanie konkretnie w ZW3D 2019 wymaga weryfikacji użytkownika na przesłanym modelu.
- Wewnętrzna flaga --body-colors pozwala wybrać wariant kompatybilny ZW3D dla analiz wykonywanych z GUI. W bibliotece pozostawiono dotychczasowy tryb kolorowania powierzchni dla zgodności.

RÓWNOLEGŁY IMPORT
Jest technicznie możliwy z dwoma odrębnymi procesami, ale nie jest włączony w tej wersji. OCP TopoDS_Shape nie jest obiektem serializowalnym przez pickle, a przenoszenie B-Rep między procesami może spowolnić duże złożenia i pozbawić natywnych współdzielonych definicji. Nie łączymy dwóch importerów równocześnie w jednym procesie bez weryfikacji bezpieczeństwa OCCT. Gdy pliki A=B, program nadal wykorzystuje szybką ścieżkę importu jednej kopii.

ZAKRES WALIDACJI
Windows x64, PySide6, OCC: testy źródeł, uruchomienie EXE, eksport z kolorami, weryfikacja pakietu, publiczne modele SO101 i OLSK. Kompilacja biblioteki DLL nie oznacza potwierdzenia działania wewnątrz ZW3D 2019.
