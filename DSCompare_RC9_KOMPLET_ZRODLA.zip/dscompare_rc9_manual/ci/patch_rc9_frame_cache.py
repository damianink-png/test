"""Install the measured frame-proof optimization after the RC9 patch chain."""
from pathlib import Path
import hashlib
import sys

BASE = {'registration_gate.py': '56964e8f48fe6f6845dc1a917564c4538831e0b67e4412d6153df03669a186be', 'deferred_alignment.py': 'aff225709e8b24a5be7e37b01af7427719990852b2c6eedaef106efa182a9064'}
OPTIMIZED = {'registration_gate.py': '0d753a4bd6967a6a918460151c3f63f946885a85d5ec9d7ae86c59d7d5e2741d', 'deferred_alignment.py': '11b0545331a27347d7fbe21cb3e8684dd85b20fdc9bdd3f2a4d062bb7c8060d1'}
repository = Path(__file__).resolve().parents[1]
target = Path(sys.argv[1]) if len(sys.argv)>1 else repository/'dscompare_rc9_manual'
if not (target/'dsac29').is_dir():
    raise SystemExit('Missing extracted dsac29 source')
pending=[]
for name,expected in BASE.items():
    payload=(repository/'dsac29'/name).read_text(encoding='utf-8')
    if hashlib.sha256(payload.encode()).hexdigest()!=OPTIMIZED[name]:
        raise SystemExit('Unexpected optimization payload: '+name)
    destination=target/'dsac29'/name
    current=destination.read_text(encoding='utf-8')
    if hashlib.sha256(current.encode()).hexdigest() not in (expected,OPTIMIZED[name]):
        raise SystemExit('Unexpected source version; refusing to overwrite '+name)
    pending.append((destination,payload))
for destination,payload in pending:
    destination.write_text(payload,encoding='utf-8')
print('PASS: sample/full proof cache installed with verified source versions')
