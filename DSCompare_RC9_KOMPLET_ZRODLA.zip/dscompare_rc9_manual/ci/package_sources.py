"""Build a complete source ZIP with a checked file manifest."""
import argparse,hashlib,json,zipfile
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('output',type=Path);args=p.parse_args()
root=Path(__file__).resolve().parents[1]
files=[]
for path in root.iterdir():
    if path.is_file() and path.suffix.lower() in ('.py','.ps1','.cmd','.txt','.md','.json') and path.name!='SOURCE_MANIFEST.json':files.append(path)
for name in ('dsac29','ci','tests','samples','assets','benchmarks','bridge','scripts','docs'):
    for path in (root/name).rglob('*'):
        if path.is_file() and not any(x in path.parts for x in ('__pycache__','.pytest_cache')) and path.suffix.lower() not in ('.pyc','.pyo'):
            files.append(path)
workflow=root/'.github/workflows/rc9-corrected-real-cad.yml';files.append(workflow)
data={str(f.relative_to(root)).replace('\\','/'):f.read_bytes() for f in sorted(files)}
manifest={'release':'RC9 audit 2026-10-30','sha256':{k:hashlib.sha256(v).hexdigest() for k,v in data.items()}}
data['SOURCE_MANIFEST.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
args.output.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(args.output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,content in sorted(data.items()):
        info=zipfile.ZipInfo('dscompare_rc9_manual/'+name,date_time=(2026,10,30,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=0o100644<<16;z.writestr(info,content)
print(args.output,len(data),'files',args.output.stat().st_size,'bytes')
