"""A UI-only installer must use byte-identical tested engine sources."""
import json,sys,zipfile
from pathlib import Path
root=Path(sys.argv[1]);archive=Path(sys.argv[2])
current=json.loads((root/'SOURCE_MANIFEST.json').read_text(encoding='utf8'))['sha256']
with zipfile.ZipFile(archive) as z:
    baseline=json.loads(z.read('dscompare_rc9_manual/SOURCE_MANIFEST.json'))['sha256']
checked=0
for name,digest in baseline.items():
    if name.startswith(('desktop/','ci/','.github/')) or Path(name).suffix=='.md':continue
    assert current.get(name)==digest,'Engine source differs from tested 6c055339: '+name
    checked+=1
assert checked>200,checked
print('TESTED_ENGINE_SOURCE_MATCH_PASS',checked,'unchanged source/assets; pinned engine artifact 13007565110')
