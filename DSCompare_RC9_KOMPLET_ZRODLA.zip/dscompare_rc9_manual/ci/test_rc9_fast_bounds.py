"""Regression: faster conservative AABBs cannot establish SAME themselves."""
from pathlib import Path
_source_root=Path(__file__).resolve().parents[1]
if not (_source_root/'dsac29').is_dir():_source_root=_source_root/'dscompare_rc9_manual'
import sys
root = _source_root
sys.path.insert(0, str(root))
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.gp import gp_Pnt
from dsac29.geometry import describe
from dsac29.step_reexport_tolerance import reexport_equivalent_world
from dsac29.brep_safety import is_valid

box = BRepPrimAPI_MakeBox(10., 12., 15.).Shape()
identical = BRepPrimAPI_MakeBox(10., 12., 15.).Shape()
shifted = BRepPrimAPI_MakeBox(gp_Pnt(.02, 0, 0), 10., 12., 15.).Shape()
changed = BRepPrimAPI_MakeBox(10.2, 12., 15.).Shape()
assert all(is_valid(s) for s in (box, identical, shifted, changed))
a = describe(box, "a", "a")
assert reexport_equivalent_world(a, describe(identical, "b", "b"), .01, allow_boolean=False)
assert not reexport_equivalent_world(a, describe(shifted, "b", "b"), .01, allow_boolean=False)
assert not reexport_equivalent_world(a, describe(changed, "b", "b"), .01, allow_boolean=False)
source = (root / "dsac29" / "step_reexport_tolerance.py").read_text(encoding="utf-8")
# Optimal analytic bounds are allowed only for the three candidate-gating
# calculations installed by patch_rc9_optimal_analytic_bounds.py.
# Bounds are never sufficient to declare SAME: the strict proof anchors above
# and positive/negative geometry fixtures must continue to pass.
print("PASS: faster prefilters preserve strict geometric SAME proof")


# A candidate filter cannot establish SAME when the full proof is denied.
from unittest.mock import patch
with patch('dsac29.parametric_identity.prove',return_value=False):
    assert not reexport_equivalent_world(a,describe(identical,'no-proof','no-proof'),.01,allow_boolean=False)
