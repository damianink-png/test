"""Keep original fail-closed behavior until an independently verified recovery exists."""
from pathlib import Path
_source_root=Path(__file__).resolve().parents[1]
if not (_source_root/'dsac29').is_dir():_source_root=_source_root/'dscompare_rc9_manual'
import ast
root=_source_root/'dsac29'
a=(root/'compare.py').read_text(encoding='utf-8')
b=(root/'revision_overlap.py').read_text(encoding='utf-8')
ast.parse(a);ast.parse(b)
assert 'except NativeGeometryFailure:' in a
assert 'except NativeGeometryFailure:' in b
print('PASS: strict native failure propagation remains enabled')

