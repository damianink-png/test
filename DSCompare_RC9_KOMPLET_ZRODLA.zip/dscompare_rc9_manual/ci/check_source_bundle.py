"""Reject incomplete/mixed source packages before tests or EXE build."""
import hashlib,json,sys
from pathlib import Path

def check(root):
    root=Path(root).resolve()
    manifest=json.loads((root/'SOURCE_MANIFEST.json').read_text(encoding='utf-8'))
    for relative,expected in manifest['sha256'].items():
        path=root/relative
        if not path.is_relative_to(root) or not path.is_file():
            raise RuntimeError('Missing source: '+relative)
        if hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
            raise RuntimeError('Changed source: '+relative)
    required=['DSCompareV3.py','BUDUJ_WINDOWS.ps1','TESTUJ.py','requirements.txt',
              'dsac29/preview_template.html','ci/rc9_common_probe.py',
              'ci/rc9_failure_summary.py','tests/test_step_boundary_proof.py']
    for relative in required:
        if relative not in manifest['sha256']:raise RuntimeError('Incomplete manifest: '+relative)
    print('SOURCE_BUNDLE_PASS',len(manifest['sha256']),'files')

if __name__=='__main__':check(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parents[1])
