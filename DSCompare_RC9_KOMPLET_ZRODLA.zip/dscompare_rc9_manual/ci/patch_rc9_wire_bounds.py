"""Apply after the existing RC9 patch chain, before tests and packaging."""
from pathlib import Path
import sys

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
if (root / 'dscompare_rc9_manual' / 'dsac29').is_dir():
    root = root / 'dscompare_rc9_manual'
target = root / 'dsac29' / 'parametric_identity.py'
source = target.read_bytes()
old = b'bb=Bnd_Box();BRepBndLib.Add_s(w,bb,False)'
new = b'bb=Bnd_Box();BRepBndLib.AddOptimal_s(w,bb,False,False)'
if source.count(old) == 1 and new not in source:
    target.write_bytes(source.replace(old, new))
elif source.count(new) != 1 or old in source:
    raise SystemExit('Unexpected wire_bounds source; refusing an unverified patch')
print('PASS: wire lookup uses geometry bounds; full oriented edge proof retained')

target = root / 'dsac29' / 'step_reexport_tolerance.py'
source = target.read_bytes()
old = b'if np.max(np.abs(np.asarray(exact_a.Get())-np.asarray(exact_b.Get())))>tolerance:return False'
new = (b'box_a=np.asarray(exact_a.Get());box_b=np.asarray(exact_b.Get())' +
       (b'\r\n' if b'\r\n' in source else b'\n') + b'    ' +
       b'if np.any(np.maximum(box_a[:3],box_b[:3])-np.minimum(box_a[3:],box_b[3:])>tolerance):return False')
if source.count(old) == 1 and new not in source:
    target.write_bytes(source.replace(old, new))
elif source.count(new) != 1 or old in source:
    raise SystemExit('Unexpected solid bounds source; refusing an unverified patch')
print('PASS: disjoint solid bounds reject; overlapping bounds require full geometry proof')
