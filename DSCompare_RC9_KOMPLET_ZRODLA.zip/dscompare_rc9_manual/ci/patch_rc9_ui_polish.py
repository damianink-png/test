"""Apply the reviewed GUI/report/color update after all existing RC9 patches."""
from pathlib import Path
import hashlib,sys
BASE = {'gui46.py': 'fc57651d1c9fb23f14bf1c4e172da663367b89f961abd46081e9f01ed2b47944', 'gui_modern.py': 'a851e048ebeeec6386a25ca47cb5c961b163460841f90cc282747f476e8991a6', 'step_io.py': '45ab246acb9a9eb26d6612f41b702edd8abd3832df8260ee92836e42cbe6bd45', 'material_deltas.py': '7cc3312aa130970876ef917d93d732aa3f7c9d4ebdbb4cd76fc73ffd039c7950', 'report.py': 'e5600c4777ba8ca754fea69ecfb1dd81078cb14c96297d91d5072d2958b86f3a', 'icons_r119.py': '95fbf740883570ed3294692ab238926b24bb150712252c6aea256ec99978e666', 'single_mass.py': '7c78a4452d07ad9d8d079c1ed69f5d4eed0a4d2d3ae5e95fcf5bbc303703e611', 'mass_batch.py': 'd713c1e1111813b7a8a9c0477529232152ddc5b53bd32ddb4c0dcc7a7778d303', 'preview_template.html': 'd9d1a15d658e80ea009a7c78477924a1d838547ad020fd6b3e3caae23905f129', 'palette.py': None, 'report_view.py': None, 'alignment_notice.py': None}
UPDATED = {'gui46.py': '5f88289d8acee08ba6c12319c24e2ca1c622e76168c1660d3a8bee0b117ecf07', 'gui_modern.py': 'ac752b31ff3e881156bc197b216abdfe2a57943128e3573c8f6190a704b0541e', 'step_io.py': 'd7c15039de2cb36ec73a46fb8edb725497d03f967e616459a10b65a65d7671d9', 'material_deltas.py': '46441ef2f679e3977603ab4c1474f211ec60be8c9dfeec5c886a4fd668a96fde', 'report.py': '8dd8e573a0985904bb13fa0a0323144a7f6fa364aba70245b4a3fa909550fd17', 'icons_r119.py': 'c18b21d7fe315f1eb15dfd430cef27cbd99f8e7c85ec2d60fd4395c0c9535462', 'single_mass.py': '6de343125ecd2bcc584b5555e55839c178f83cd4e5478a8175ab526c2aed1a45', 'mass_batch.py': '3cb4a8b5e66458ab09e9c12f414c1d08d7633f2ba93ba432a712c9d95a762b07', 'preview_template.html': '5c14c7f95d171caf9627a9e1f723d4e5b45e287a8c8aede81c691846c55a9fbc', 'palette.py': 'f36624a63f3d7b8ee5f868e1ffb0fab1d18287c803572ec42408641799e2bead', 'report_view.py': 'e734bcc06c70d534b01d51ce9f73cb2b1cf7e1b4e681778fd5e75e4781a65731', 'alignment_notice.py': '5cdac87b6b2f8e067f94b2dd2be7b8e4b2bf9dd05fe860e62a295726b75c8dc7'}
repository=Path(__file__).resolve().parents[1]
target=Path(sys.argv[1]) if len(sys.argv)>1 else repository/'dscompare_rc9_manual'
if not (target/'dsac29').is_dir():raise SystemExit('Missing extracted dsac29 source')
pending=[]
for name,expected in BASE.items():
    payload=(repository/'dsac29'/name).read_text(encoding='utf8')
    if hashlib.sha256(payload.encode()).hexdigest()!=UPDATED[name]:
        raise SystemExit('Unexpected UI payload: '+name)
    destination=target/'dsac29'/name
    current=hashlib.sha256(destination.read_text(encoding='utf8').encode()).hexdigest() if destination.exists() else None
    if current not in (expected,UPDATED[name]):
        raise SystemExit('Unexpected source version; refusing to overwrite '+name)
    pending.append((destination,payload))
for destination,payload in pending:destination.write_text(payload,encoding='utf8')
print('PASS: coherent palette, transactional settings, desktop actions, reports and offline 3D installed')
