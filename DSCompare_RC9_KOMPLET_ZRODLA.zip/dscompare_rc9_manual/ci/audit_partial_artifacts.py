"""A partial report is accepted only for the explicit OpenArm review scenario."""
import json,sys
from pathlib import Path
from audit_preview import audit_preview
root=Path(sys.argv[1]);out=root/'comparison'
result=json.loads((root/'TEST_RESULT.json').read_text())
assert result['scenario']=='openarm_explicit_partial_review' and result['expected_partial']
assert result['result']=='PASS'
s=json.loads((out/'PODSUMOWANIE.json').read_text())
assert s['analysis_complete'] is False and s['material_analysis_complete'] is False
assert s['statuses'].get('UNCERTAIN') and not set(s['statuses'])-{'SAME','RENAMED','MOVED','UNCERTAIN'}
for role,key in [('A','a_index'),('B','b_index')]:
    ids=[r[key] for r in s['records'] if r.get(key) is not None]
    assert len(ids)==len(set(ids))==s['solids_'+role]
    assert (out/('BOM_'+role+'.csv')).is_file()
assert not s['material_regions'] and not s['material_errors']
step=out/'POROWNANIE_KOLORY.step';assert step.is_file() and step.stat().st_size>1000
assert step.open('rb').read(64).startswith(b'ISO-10303-21;')
assert (out/'ANALIZA_NIEKOMPLETNA.txt').is_file()
assert 'Raport częściowy' in (out/'RAPORT.html').read_text()
count=audit_preview((out/'PODGLAD_KOLOROW_3D.html').read_text(),s,allow_uncertain=True)
assert s['preview_3d']['pominiete']==0
print('PARTIAL_REVIEW_ARTIFACTS_PASS',count,'visual occurrences; all original inputs accounted for')
