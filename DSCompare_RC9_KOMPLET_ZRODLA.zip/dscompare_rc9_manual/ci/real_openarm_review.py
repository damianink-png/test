"""Frozen EXE: explicitly approved partial review of the public OpenArm pair."""
import hashlib,json,os,subprocess,sys,time,traceback,urllib.request
from pathlib import Path
from urllib.parse import quote

root=Path('evidence').resolve();root.mkdir(exist_ok=True);out=root/'comparison';out.mkdir(exist_ok=True)
exe=Path(sys.argv[1]).resolve()
report={'scenario':'openarm_explicit_partial_review','expected_partial':True,'sources':[],
        'exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()}
def save():(root/'TEST_RESULT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
try:
    inputs=[]
    for filename,expected in [('OpenArm_v1.0_follower.step','9cac80902edc3f5ebb9fd7050d687559a1a99324202add756c3f1278fcbdd441'),
                              ('OpenArm_v1.1_follower.STEP','71d11da9ceb0155fb4003206ae25f51eb2cfbfefa3f2097ea35c36a3d29389b0')]:
        source='https://raw.githubusercontent.com/Utsav92/openarm-3d-cad-assembly/0c0852bd76ee7026f97875d6eac789d189a0012a/'+quote('STEP (assembly)/'+filename)
        target=Path('models/openarm')/filename;target.parent.mkdir(parents=True,exist_ok=True)
        urllib.request.urlretrieve(source,target)
        digest=hashlib.sha256(target.read_bytes()).hexdigest();assert digest==expected,(filename,digest)
        inputs.append(target.resolve());report['sources'].append({'url':source,'sha256':digest});save()
    command=[str(exe),'--worker','compare','--a',str(inputs[0]),'--b',str(inputs[1]),
             '--output',str(out),'--align-auto','--allow-review-decision','--generate-step','--preview3d','--revision-style']
    report['command']=command;save();decisions=[];start=time.monotonic()
    with (root/'EXE_STDOUT.log').open('wb') as stdout,(root/'EXE_STDERR.log').open('wb') as stderr:
        proc=subprocess.Popen(command,stdout=stdout,stderr=stderr)
        while proc.poll() is None:
            request=out/'_WYROWNANIE_PYTANIE.json'
            if request.is_file():
                try:
                    question=json.loads(request.read_text());token=question['token']
                    if token not in [x['token'] for x in decisions]:
                        choice='review' if question.get('material_unverified') else 'original'
                        answer={'token':token,'decision':choice};decisions.append(answer)
                        (out/'_WYROWNANIE_ODPOWIEDZ.json').write_text(json.dumps(answer))
                except (OSError,ValueError,KeyError):pass
            if time.monotonic()-start>1500:
                subprocess.run(['taskkill','/F','/T','/PID',str(proc.pid)],capture_output=True)
                raise TimeoutError('OpenArm review exceeded 1500 seconds')
            time.sleep(.5)
    report.update(seconds=round(time.monotonic()-start,2),returncode=proc.returncode,decisions=decisions);save()
    assert proc.returncode==0,'OpenArm worker failed'
    summary=json.loads((out/'PODSUMOWANIE.json').read_text())
    assert summary['analysis_complete'] is False and summary['material_analysis_complete'] is False
    assert any(x['decision']=='review' for x in decisions),'Review was not explicitly approved'
    assert summary['solids_A']==summary['solids_B']==553
    assert summary['statuses'].get('UNCERTAIN',0)>0
    assert summary['step_ready'] and not summary['step_export_error']
    assert summary['preview_3d']['pominiete']==0
    for key in ('a_index','b_index'):
        indices=[r[key] for r in summary['records'] if r.get(key) is not None]
        assert len(indices)==len(set(indices))==553 and set(indices)==set(range(553)),key
    assert (out/'ANALIZA_NIEKOMPLETNA.txt').is_file()
    assert 'Raport częściowy' in (out/'RAPORT.html').read_text()
    for path,source in zip(inputs,report['sources']):assert hashlib.sha256(path.read_bytes()).hexdigest()==source['sha256']
    report.update(result='PASS',analysis_complete=False,statuses=summary['statuses'],solids_A=553,solids_B=553)
    save();print(json.dumps(report,ensure_ascii=False),flush=True)
except BaseException:
    report.update(result='FAIL',error=traceback.format_exc());save();raise
