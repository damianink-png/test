"""Replay captured B-Reps through the same isolated worker as the EXE."""
import argparse,hashlib,json,os,subprocess,sys,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('pair',type=Path);p.add_argument('output',type=Path);p.add_argument('--shift-x',type=float,default=0.);p.add_argument('--expected',choices=['true','false'],required=True)
args=p.parse_args();args.pair=args.pair.resolve();args.output=args.output.resolve();args.output.mkdir(parents=True,exist_ok=True)
source_b=args.pair/'B.brep'
if args.shift_x:
 from dsac29.native_guard import _load_brep
 from dsac29.geometry import transform
 from OCP.BRepTools import BRepTools
 import numpy as np
 source_b=args.output/'B_shifted.brep'
 with source_b.open('wb') as f:BRepTools.Write_s(transform(_load_brep(args.pair/'B.brep'),np.eye(3),np.array([args.shift_x,0.,0.])),f)
request=args.output/'request.json';reply=args.output/'reply.json';reply.unlink(missing_ok=True)
request.write_text(json.dumps({'operation':'world_reexport','a':str(args.pair/'A.brep'),'b':str(source_b),'tolerance':.01,'allow_boolean':False}))
started=time.monotonic();run=subprocess.run([sys.executable,'-m','dsac29.native_guard',str(request),str(reply)],capture_output=True,timeout=95)
data=json.loads(reply.read_text()) if reply.exists() else None
result={'seconds':round(time.monotonic()-started,3),'exit_code':run.returncode,'reply':data,'shift_x_mm':args.shift_x,'tolerance_mm':.01,'sha256':{name:hashlib.sha256((args.pair/(name+'.brep')).read_bytes()).hexdigest() for name in ('A','B')}}
(args.output/'replay.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
assert run.returncode==0 and data=={'ok':True,'match':args.expected=='true'},result
