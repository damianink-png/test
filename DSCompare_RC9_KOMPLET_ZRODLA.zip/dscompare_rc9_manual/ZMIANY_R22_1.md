# DS Compare 1.0 R22.1

- Powtórne użycie potwierdzonych par B-Rep po wyrównaniu, również w pamięci zgodności definicji i przy częściowym dopasowaniu.
- Weryfikacja powierzchni i kompletnych krawędzi CAD przed kosztownymi operacjami Boolean.
- Pomijanie równoważnych hipotez przesunięcia oraz kandydatów, których maksymalne możliwe poparcie nie może zmienić wyniku.
- Sztywne obroty i przesunięcia przez położenie TopLoc, bez przebudowy geometrii bryły.
- Obliczanie właściwości powtarzalnych definicji raz; obracanie tensora bezwładności i środka masy dla kolejnych wystąpień.
- Korekta odwróconej orientacji tylko wtedy, gdy wynikowa bryła jest poprawna. Niepoprawny B-Rep zatrzymuje import ze wskazaniem części; żadne części nie są pomijane.
- Dokładniejszy zapis postępu weryfikacji przesunięcia.

Brak przesunięcia nadal oznacza analizę w oryginalnym układzie. Mechanizm eksportu ABSR i interfejs pozostają takie jak w poprzedniej wersji.

## Weryfikacja

Bieżący log regresji: validation/R22_REGRESJE.log. Pierwsza wersja R22 przeszła kompilację i regresje, ale NIE przeszła dużych testów przesunięcia; R22.1 zawiera dalsze poprawki. Końcowy status dużych testów należy sprawdzić w GitHub Actions — sam sukces regresji nie potwierdza ich wyniku.

Switchwire ma rzeczywiście niepoprawną bryłę Main_Body. Zmiana znaku objętości nie naprawia geometrii; wymagany jest poprawny eksport tej części z CAD.
