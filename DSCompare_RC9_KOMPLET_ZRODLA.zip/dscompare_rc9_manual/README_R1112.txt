DS Compare R11.12 — ZW3D 2019 / Windows x64

POPRAWKI:
- Płaski STEP: każda rzeczywista bryła SOLID jest osobnym produktem STEP,
  bez pustych kontenerów ABSR, z kontrolą liczby produktów/ukrytych reprezentacji.
- Eksport bez pustych kontenerów jest domyślny także dla trybu worker/CLI.
  Stary sposób dostępny wyłącznie z --legacy-step-assemblies.
- Przeniesiono eksport wyników do niskiego paska pod tabelą,
  tabela wypełnia dostępną szerokość; responsywne pola i liczniki.
- Zwijane BOM A/B są pod tabelą zmian w RAPORT.html; CSV jest opcjonalny.
- Dokładny BOM zachowuje kosztowne dowody B-Rep; szybki BOM pomija
  niejednoznaczne pary (może rozdzielić identyczne części).
- Usunięto nieprawdziwe wskazówki o podzłożeniach statusu z raportu w trybie płaskim.
- 143 testy silnika i geometrii zaliczone lokalnie (Linux, bez testów PySide6).
- Testy GUI oraz kompilację Windows trzeba wykonać przez GitHub Actions.

UWAGA: nie potwierdzono jeszcze na rzeczywistym pliku 91007430_000.stp
w ZW3D 2019, że importer nie tworzy ABSR. Lokalnie testy sprawdzają
zgodność ilości produktów STEP, brył i położenia i brak pustych kontenerów.
