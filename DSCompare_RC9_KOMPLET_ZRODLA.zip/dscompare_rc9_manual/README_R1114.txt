DS Compare R11.14 - import cache B-Rep + minimalistyczne UI

1. Równoległy import A/B zachowany; wątek Qt nie wykonuje operacji CAD.
2. Trwały cache B-Rep z weryfikacją SHA-256 całego STEP i wersji geometrii.
3. Cache wspólny dla importu równoległego i sekwencyjnego; rozmiar 3 GB,
   tryb automatyczny pomija pliki poniżej 2 MB. Można wyłączyć i wyczyścić.
4. Nie odczytujemy zbędnej palety kolorów źródłowego STEP.
5. Komunikaty postępu rozdzielają dekodowanie STEP i charakterystyki brył.
6. Uproszczone palety jasna/ciemna i jednolite wektorowe ikony SVG w rozdzielczości HiDPI.
7. Zachowane: bezpieczny płaski STEP bez pustych ABSR, pełny BOM, identyczność części
   oparta na dowodzie B-Rep, zapis raportów i układ tabeli w całej szerokości.

Ograniczenia:
- Nie każdy STEP da się szybko odczytać za pierwszym razem: pierwszy import
  może być nawet trochę wolniejszy wskutek publikacji cache.
- Cache tworzy rzeczywiste pliki .brep, zużywa miejsce do 3 GB.
- Jeżeli plik STEP zmieni choć 1 bajt, nastąpi nowy import.
- Całość skompilowana dla Windows 64-bit; DLL ZW3D wymaga testu w rzeczywistym ZW3D 2019.
