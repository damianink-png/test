# DS Compare RC9 — poprawki i stan weryfikacji, 28.10.2026

**Źródła do kompilacji i dalszych testów. Nie jest to potwierdzenie stabilnego wydania Windows.**

Baza: `damianink-png/test`, gałąź `fix/integrated-proof-matching`, commit
`2ae6b4fbca084dcf0c98eec55f6e938c67f1598c` oraz przypięte źródła RC9 Stability.
Nakładki są już scalone. Kompilacja z tej paczki nie wymaga pobierania starego
artefaktu GitHub ani ponownego uruchamiania skryptów modyfikujących źródła.

Nie wysłano zmian do GitHuba, nie uruchomiono ani nie anulowano GitHub Actions.
Ostateczne pliki odtworzono po automatycznym usunięciu przestrzeni roboczej;
dołączone logi pochodzą z ponownych testów odtworzonych plików.

## Co poprawiono

1. **Obieg cache Common/Cut.** W bazie odbiorca wymagał `CommonEvidence` i
   `RegionEvidence`, lecz producent nadal przekazywał surowe wyniki. Powodowało
   to powtarzanie operacji. Wyniki są teraz wiązane z dokładną parą brył,
   położeniem/orientacją i tolerancją. Przejście między procesami sprawdza SHA-256
   dokładnych plików A, B i Common. Niepasujący lub uszkodzony wynik nie jest używany.
2. **Ponowne użycie gotowych regionów.** Eksport i raport korzystają z wyniku
   już wyznaczonego podczas dopasowania rewizji. Test całego obiegu zabrania
   drugiego wywołania podziału materiału.
3. **Wspólny PaveFiller.** Zachowano integrację przecięć dla Common i obu Cut.
   Test rzeczywistego procesu potomnego potwierdza: przy poprawnym cache wykonywany
   jest jeden PaveFiller i dwa Cut, bez ponownego Common.
4. **Walidacja cache.** Regiony są niemodyfikowalną strukturą danych, a bilans
   sprawdza objętości rzeczywistych kształtów, nie tylko zapisane liczby.
   NaN, nieskończoność i ujemne objętości są odrzucane, także w odpowiedzi IPC Common.
5. **Niekompletność nie jest wynikiem sukcesu.** Wyłączono nakładkę
   `patch_optional_revision.py`, która po błędach Common/Cut pozwalała kończyć
   analizę jako ADDED/REMOVED. Wymagany, niedokończony dowód propaguje błąd
   `NativeGeometryFailure`. Zachowano test oczekujący błędu, zamiast zmieniać go na PASS.
6. **Kandydaci materiałowi.** Usunięto ciche ograniczenie do pierwszych sześciu
   kandydatów. Dalszy kandydat może podważać jednoznaczność dopasowania. Tanie
   filtry przestrzenne i objętościowe pozostają. Wyczerpanie jawnego budżetu czasu
   lub liczby operacji nadal oznacza niekompletną analizę.
7. **Pamięć.** Cache kandydatów zatrzymuje najwyżej 64 wyniki Common; niewybrane
   i wykorzystane wyniki są zwalniane. To limit wpisów, nie limit RAM programu.
   Usunięty wpis może zostać bezpiecznie przeliczony.
8. **Pojedyncze wykonanie Boolean.** Pomocniczy `safe_boolean_worker` używa pustego
   konstruktora, ustawia argumenty, NonDestructive i OBB, a potem wywołuje Build
   raz. Wcześniej konstruktor wykonywał operację przed ustawieniem zabezpieczeń,
   po czym Build powtarzał pracę. Odczyt B-Rep uwzględnia wariant API zwracający None.
9. **Naprawa wyłącznie kopii.** Po naprawie mierzone są tolerancje wierzchołków,
   krawędzi i ścian. Wzrost maksimum kategorii albo przekroczenie tolerancji
   użytkownika odrzuca naprawę. Nadal wymagane są poprawna topologia i niezależny
   dowód zgodności granic. Test potwierdza odrzucenie zwiększonej tolerancji oraz
   brak zmiany oryginału.
10. **Diagnostyka procesów.** Włączono dziennik i faulthandler w workerach.
    Błędy napraw zawierają nazwę metody i przyczynę. Błąd Common zawiera końcówkę
    stderr. Pomiary PaveFiller/Common/Cut, czas i RSS są przenoszone do dziennika
    głównego przed skasowaniem katalogu tymczasowego, również przy sukcesie.
11. **Audyt plików HTML/BOM.** Audyt odczytuje rzeczywistą scenę HTML i sprawdza
    rekordy, role A/B, identyfikatory, siatki, transformacje, przezroczystość oraz
    obecność usuniętych części i materiału. Testy celowo usuwają te elementy i
    wymagają od audytu błędu. BOM A/B jest wymagany we wszystkich sześciu scenariuszach;
    usunięto sprzeczne `--no-bom` z obu skryptów dużych testów.
12. **Workflow ręczny.** Windows x64, regresje, kompilacja i opcjonalne sześć
    scenariuszy CAD. Wyłącznie workflow_dispatch, osobna grupa współbieżności,
    cancel-in-progress=false. Nie ma wyzwalacza push.

Tolerancja nominalna pozostaje **0,01 mm**. Nie zwiększono limitu 35 s pojedynczej
operacji Common/Cut. Limit 1800 s dotyczy całego zestawu regresji, nie operacji CAD.
Nie usuwano funkcji drzewa HTML, zaznaczania, kontroli nazw, BOM ani eksportu STEP.

## Testy

Dokładne wyniki znajdują się w `validation/TEST_RESULTS.json` oraz plikach JUnit
i logach w tym samym katalogu. Środowisko: Linux, Python 3.12, OCP 7.9.3.1.1.
Windows Job Object jest pomijany na Linux. Zestawy częściowo się pokrywają.

Test 600 wystąpień dotyczy kompletności podglądu; test 3000 kotwic dotyczy konsensusu
translacji. **Nie są to testy dużych złożeń na skompilowanym EXE.**
Regresje obejmują geometrię, wyrównanie, nazwy, materiał, STEP, HTML, BOM i cache.
Oczekiwanych liczb części i objętości nie zmieniono. Starszy test cache dostosowano
jedynie do opakowania `RegionEvidence`; wartości 2000/100/0 mm³ pozostają takie same.

Nie deklaruję procentowego przyspieszenia ani poprawy szczytowego RAM. Liczba
powtórnych operacji w sprawdzonym obiegu została zmniejszona, ale nie zmierzono
wpływu na porównywalne duże złożenia RC6/RC9. Pełny przegląd kandydatów może
zwiększyć pracę w gęstych złożeniach; jest wymagany dla wiarygodności dopasowania.

## Ocena listy mechanizmów

| Mechanizm | Stan |
|---|---|
| BRepCheck, Common/Cut, NonDestructive, OBB | Obecne, małe regresje |
| PaveFiller i cache wyników | Zintegrowane, sprawdzony obieg między procesami |
| ShapeFix_Shape i ShapeFix_Wire | Obecne na kopiach; uzupełniono tolerancje i diagnostykę |
| Niezależny dowód po naprawie | Wymagany; nieudowodniona naprawa odrzucana |
| ShapeAnalysis | Pełny raport krawędzi i pętli nadal do opracowania |
| Osobny BOPAlgo_Builder | Nie dodawano zbędnej warstwy: API Boolean korzysta już z przygotowanych przecięć |
| FreeCAD/CadQuery/OCP | Wzorce walidacji, bezpiecznych operacji i testów; bez kopiowania kodu tych projektów |
| SALOME GEOM, pythonOCC, Draw Harness | Narzędzia do dalszej reprodukcji problemów, bez nowych zależności w aplikacji |
| Sygnatury, indeksowanie, dopasowanie 1:1 | Zachowane z bazy i objęte małymi regresjami |
| SAME/MOVED, liczby wystąpień, nazwy | Regresje; duże rzeczywiste złożenia nadal do potwierdzenia |
| Kolory, STEP, HTML, BOM | Regresje i audyty; ZW3D 2019 nie sprawdzono |

## Co pozostaje

- **Duże rzeczywiste B-Rep:** wcześniejsze raporty integracji wskazują niepoprawne
  pętle i timeouty w V2/Trident. Te poprawki nie są dowodem rozwiązania wszystkich
  takich par. Należy odtworzyć dokładne FAILED_BREP i optymalizować dowód granic.
- **Sześć scenariuszy Windows:** żaden nowy wynik skompilowanego EXE nie został
  uzyskany w tym zadaniu. Wymagane są revision, shift i revision_shift dla V2
  oraz Trident. Liczby brył, czasy etapów i RAM tej paczki: nie zmierzono.
- **Pełna izolacja:** nie wszystkie wywołania OCCT są odizolowane. Odczyt/zapis
  B-Rep i część kontroli właściwości/cache nadal korzystają z OCCT w koordynatorze.
- **Granice cache:** evidence jest wewnętrzną kontrolą pochodzenia, nie dowodem
  SAME. Wymaga niezmieniania topologii po związaniu z wynikiem. Zamrożony dataclass
  nie zamraża natywnego obiektu OCCT. Kontrola tolerancji porównuje maksima
  kategorii, nie mapuje każdego nowego wierzchołka do starego.
- **Koszt procesów:** wiele różnych zmienionych par nadal uruchamia wiele procesów.
  Trwałe workery wymagają osobnej implementacji, odtwarzania po awarii i testów RAM.
- **Eksport:** nagłówek i bilans wystąpień STEP nie zastępują niezależnego dowodu
  geometrii każdej dużej rewizji. Potrzebne są rzeczywiste artefakty i otwarcie
  kolorów/struktury w ZW3D 2019.

## Źródła porównania i licencje

Nie kopiowano kodu FreeCAD, CadQuery, SALOME ani pythonOCC. Użyto własnej integracji
publicznego API już obecnego OCCT/OCP. Nie należy traktować wszystkich tych
projektów jako MIT. Przy dalszym kopiowaniu i dystrybucji zależności trzeba
zachować właściwe licencje, noty i wymagane atrybucje.

- OCCT API i nagłówek licencyjny: https://github.com/Open-Cascade-SAS/OCCT/blob/master/src/ModelingAlgorithms/TKBO/BRepAlgoAPI/BRepAlgoAPI_BooleanOperation.hxx
- CadQuery, Apache 2.0: https://github.com/CadQuery/cadquery
- OCP: https://github.com/CadQuery/OCP/blob/master/LICENSE
- FreeCAD: https://github.com/FreeCAD/FreeCAD/blob/main/LICENSE

Kryterium wydania pozostaje niezmienione: sześć poprawnych dużych scenariuszy
na Windows EXE, zgodność rzeczywistych artefaktów i brak pogorszenia regresji.
