# DS Compare 1.0 R21 — wyniki końcowe

## Co poprawiono
1. Kontrola eksportu STEP rozróżnia teraz definicje geometrii od wystąpień.
   Przykład: jedna definicja użyta trzy razy daje dwa produkty (część + złożenie)
   i trzy powiązania. Wcześniej taki poprawny plik był odrzucany.
   Zachowano kontrolę liczby brył, kolorów, kontenerów i nadmiarowych produktów.
2. Zgodność po reeksporcie STEP może zostać udowodniona bez problematycznych
   operacji Cut: porównywane są powierzchnie analityczne, pełne racjonalne płaty
   Béziera oraz wszystkie zorientowane krzywe brzegowe i obwody ścian.
   Dodatnie wagi i siatki kontrolne dają ograniczenie odchyłki całego płata,
   a nie tylko kilku próbek. Budżet tej ścieżki wynosi 1/8 tolerancji użytkownika.
   Same pola, objętości, nazwy lub obwiednie nadal nie wystarczają do SAME.
3. Ścieżka ta wymaga poprawnego B-Rep. Nieobsługiwane lub niepotwierdzone
   reprezentacje nadal trafiają do dwukierunkowej kontroli Boolean.
   Oba kierunki wykorzystują jeden zestaw przecięć; kolejność zwalniania
   obiektów natywnych utrzymuje poprawny czas życia współdzielonych danych.
4. Wstępna kontrola ważności brył odrzuca nieprawidłowe kandydatury przed
   kosztownymi operacjami. Silne podejrzenie przesunięcia bez dowodu geometrii
   nie znika już po cichu: wynik jest nierozstrzygnięty i wymaga decyzji użytkownika.
   Nie zatwierdza się automatycznie porównania w oryginalnym układzie.
5. Ponowny zapis STEP z drobnymi różnicami parametrów jest obsługiwany także
   przy porównaniu w miejscu. Nie wymaga to uruchamiania wyszukiwania przesunięcia.

## Wyniki
- 156 przypadków regresji, w tym tolerancja 0,001 mm, kontrola 231 części bez zmian,
  nierówne liczby wystąpień i przesunięcie okresowe, ponowne użycie geometrii,
  łuk dopełniający vs właściwy łuk, zmiana krzywizny między końcami krzywej,
  wagi racjonalne i prawidłowy eksport powtarzalnych definicji.
- SO-ARM100: 19/19 SAME po przesunięciu złożenia o (1275,-395,210) mm,
  niezależnym eksporcie i odczycie STEP. Analiza wraz z eksportem wyników 66,4 s;
  cały test wraz z przygotowaniem kopii 90,46 s. STEP i HTML kompletne (19 obiektów).
- SO-ARM100 w tym samym układzie: 19/19 SAME, 0 wywołań wyszukiwania translacji,
  samo porównanie 50,93 s. To trudny reeksport, nie szybkie porównanie identycznych plików.
- NIST/CAx-IF: 18/18 SAME, poprawne przesunięcie oraz kompletne STEP i HTML.

## Ważne rozróżnienie testów robota
Test zakończony wynikiem 19/19 zachowuje definicje części i zmienia ich położenia
w złożeniu (TopLoc_Location). Jest to przesunięcie wystąpień bez przeliczania
powierzchni każdego detalu.

Dawny test tworzył nowe powierzchnie przez BRepBuilderAPI_Transform(copy=True),
a następnie zapisywał je do STEP. Po ponownym odczycie tej wersji danych jeden
z 19 kandydatów ma niepoprawny B-Rep. R21 NIE oznacza takiego pliku jako 19 SAME.
Osobny test odtworzył ten przypadek: wykrycie nierozstrzygniętego przesunięcia
zajęło 4,56 s po imporcie, bez kosztownej serii Cut. Nie jest to automatyczna
naprawa uszkodzonego STEP. Użytkownik powinien sprawdzić/ponownie wyeksportować
plik albo świadomie wybrać porównanie w oryginalnym układzie.
Nie należy porównywać tych czasów jako jednego benchmarku przyspieszenia.

## Odtwarzanie i ograniczenia
Testy lokalne: Python 3.12, cadquery-ocp 7.8.1.1, Linux. Komenda: python TESTUJ.py.
Skrypty publicznych modeli: scripts/test_public_assembly.py oraz
scripts/test_reexport_invalid.py. Ich wejścia i wyniki opisano w validation/*.json.
W validation znajdują się również logi i rzeczywiste podglądy HTML.

Nie wykonano kompilacji Windows EXE ani testu w ZW3D. Workflow Windows instaluje
przypięty silnik 7.9.3.1.1 i musi zaliczyć testy przed kompilacją.
Nie testowano modeli użytkownika. Obsługa ABSR i interfejs pozostają bez przebudowy.
