"""Regression checks for R8 (renames, STEP identity, alpha and Qt lifetime)."""
import json,os
from pathlib import Path
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.TopLoc import TopLoc_Location
from OCP.gp import gp_Trsf,gp_Vec
from dsac29.geometry import describe
from dsac29.compare import Record
from dsac29.step_io import export_revision_step, REVISION_COLORS
from dsac29.revision_rules import classify_revisions
from dsac29.report import produce


def part(name,x=0):
    s=BRepPrimAPI_MakeBox(15,12,10).Shape()
    t=gp_Trsf();t.SetTranslation(gp_Vec(x,0,0))
    return describe(s.Located(TopLoc_Location(t)),name,name)


def test_renamed_visible_in_csv_html_and_filter(tmp_path):
    a=[part('STARY_NAPIS')];b=[part('NOWY_NAPIS')]
    r=classify_revisions(a,b,[Record(0,0,'RENAMED','Nazwa')])
    assert [x.status for x in r]==['RENAMED']
    produce(tmp_path,a,b,r,generate_step=False,diff_step=False,revision_style=True)
    html=(tmp_path/'RAPORT.html').read_text(encoding='utf8')
    assert 'data-status="RENAMED"' in html and 'value="RENAMED"' in html
    assert 'STARY_NAPIS' in html and 'NOWY_NAPIS' in html
    assert 'id="count"' in html


def test_moved_roles_different_purple_and_polish_products(tmp_path):
    a=[part('WSPORNIK',30)];b=[part('WSPORNIK',75)]
    output=tmp_path/'porownanie.step'
    d=export_revision_step(output,[Record(0,0,'MOVED','')],a,b,old_alpha=.4)
    raw=output.read_text(encoding='latin-1')
    assert d['roles']['OLD']==1 and d['roles']['NEW']==1
    assert d['rekordy_przezroczystosci_step']>0
    assert REVISION_COLORS['MOVED']!=REVISION_COLORS['MOVED_OLD']
    assert '__PRZESUNIETE__STARA__' in raw and '__PRZESUNIETE__NOWA__' in raw
    assert 'ABSR' not in raw


def test_qt_theme_and_tabs_do_not_touch_deleted_sidebar(tmp_path,monkeypatch):
    os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
    from PySide6.QtCore import QCoreApplication,QEvent
    from PySide6.QtWidgets import QApplication,QAbstractSpinBox
    from dsac29.gui46 import Window
    app=QApplication.instance() or QApplication([])
    w=Window();w.show();app.processEvents()
    QCoreApplication.sendPostedEvents(None,QEvent.DeferredDelete)
    app.processEvents()
    assert set(w.nav)=={'compare','mass','settings'}
    assert w.stack.indexOf(w.pages['settings'])>=0
    assert w.density.buttonSymbols()==QAbstractSpinBox.NoButtons
    w.navigate('mass');w.toggle_theme();w.navigate('compare');w.toggle_theme()
    app.processEvents()
    assert w.stack.currentWidget()==w.pages['compare']
    assert not w.only_changes.isVisible()
    assert 'RENAMED' in w.filter_buttons
    w.close()
