from collections import Counter
import json
import numpy as np
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.TopLoc import TopLoc_Location
from OCP.gp import gp_Trsf,gp_Vec
from dsac29.geometry import describe
from dsac29.alignment import align_assembly

def occurrence(shape,name,x,y,z=0):
    tr=gp_Trsf();tr.SetTranslation(gp_Vec(float(x),float(y),float(z)))
    return describe(shape.Located(TopLoc_Location(tr)),name,name)

def test_231_of_380_parts_override_two_misleading_anchors(tmp_path,monkeypatch):
    from dsac29 import cli
    shift=np.array([10000.,3000.,180.]);a=[];b=[]
    repeated=BRepPrimAPI_MakeBox(17,11,9).Shape()
    for i in range(380):
        x=i*41.;y=i*i*.37
        if i<231:sa=sb=repeated;name='REPEATED'
        elif i<233:sa=sb=BRepPrimAPI_MakeBox(50+i,13,19).Shape();name=f'ANCHOR{i}'
        else:
            sa=BRepPrimAPI_MakeBox(1000+i*3,5,7).Shape()
            sb=BRepPrimAPI_MakeBox(4000+i*3,6,8).Shape();name=f'CHANGED{i}'
        a.append(occurrence(sa,name,x,y))
        b.append(occurrence(sb,name,x+shift[0],y+shift[1]+(800 if 231<=i<233 else 0),shift[2]))
    pa=tmp_path/'a.step';pb=tmp_path/'b.step';pa.write_text('a');pb.write_text('b')
    monkeypatch.setattr(cli,'load_step',lambda path,**kw:a if path==pa else b)
    out=tmp_path/'out';out.mkdir();approvals=[]
    def approve(info):approvals.append(info);return 'align'
    cli.process(pa,pb,out,step=False,diff_step=False,full_bom=False,revision_style=True,auto_align=True,alignment_approval=approve,progress=None)
    summary=json.loads((out/'PODSUMOWANIE.json').read_text())
    # R14 automatically applies an unambiguous, B-Rep-verified 231/380 shift.
    assert not approvals
    assert np.allclose(summary['alignment']['translation_B_to_A_mm'],-shift)
    assert summary['alignment']['approved_by_user'] is False
    assert summary['statuses']['SAME']==231
    assert summary['statuses']['MOVED']==2
    assert summary['statuses']['REMOVED']==147
    assert summary['statuses']['ADDED']==147

def test_repeated_alignment_tolerates_rounding_cell_boundary():
    from dsac29.registration_gate import frame_support
    shape=BRepPrimAPI_MakeBox(17,11,9).Shape()
    a=[occurrence(shape,'P',i*43+.000625,i*i*13) for i in range(15)]
    b=[occurrence(shape,'P',i*43+.000625+500+(0 if i%2 else .0000001),i*i*13+100) for i in range(15)]
    aligned,info=align_assembly(a,b,.01)
    support=frame_support(a,aligned,.01,verify_all=True)
    assert support['count']==15

def test_removed_part_survives_tiny_preview_target(tmp_path):
    from dsac29.preview3d import create_preview
    from dsac29.compare import Record
    from test_r6_preview import scene
    shape=BRepPrimAPI_MakeBox(17,11,9).Shape()
    a=[occurrence(shape,'OLD',0,0)];b=[occurrence(shape,'NEW',100,0)]
    p=tmp_path/'view.html'
    info=create_preview(p,[Record(None,0,'ADDED',''),Record(0,None,'REMOVED','')],a,b,max_triangles=1)
    assert {c['status'] for c in scene(p)}=={'REMOVED','ADDED'}
    assert info['elementy']==2 and info['pominiete']==0
    assert 'id="removed"' in p.read_text() and 'id="xray" checked' in p.read_text()
