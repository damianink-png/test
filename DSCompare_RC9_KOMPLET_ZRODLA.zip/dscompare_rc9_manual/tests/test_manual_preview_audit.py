import json,re,sys
from pathlib import Path
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'ci'))
from audit_preview import audit_preview
from dsac29.preview3d import create_preview
from dsac29.compare import Record
from dsac29.geometry import describe
from dsac29.material_deltas import calculate
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox

def test_audit_detects_missing_removed_parts_and_material(tmp_path):
 a=[describe(BRepPrimAPI_MakeBox(n,10,10).Shape(),'A','A') for n in (25,10)]
 b=[describe(BRepPrimAPI_MakeBox(20,10,10).Shape(),'B','B')]
 records=[Record(0,0,'CHANGED',''),Record(1,None,'REMOVED','')]
 reg=calculate(a[0],b[0]);path=tmp_path/'preview.html'
 info=create_preview(path,records,a,b,material_regions={0:reg})
 summary=dict(records=[vars(r) for r in records],old_alpha=.4,preview_3d=info,
   material_regions=[dict(record_index=0,common_mm3=reg.common_mm3,added_mm3=reg.added_mm3,removed_mm3=reg.removed_mm3)])
 text=path.read_text();assert audit_preview(text,summary)==info['elementy']
 match=re.search(r'^const scene=(.*);$',text,re.M);scene=json.loads(match.group(1))
 for status in ('REMOVED','CHANGED_REMOVED'):
  changed=[x for x in scene if x['status']!=status]
  broken=text[:match.start(1)]+json.dumps(changed)+text[match.end(1):]
  with pytest.raises(AssertionError):audit_preview(broken,summary)
