"""R9 early STEP availability, atomic handoff, and safe BOM optimization."""
import json
from pathlib import Path


def test_stage_state_atomic(tmp_path):
    from dsac29.stage_fast import StageWriter
    stage=StageWriter(tmp_path)
    stage.update(step='eksport',reports='oczekuje',report_percent=0)
    assert json.loads((tmp_path/'_ETAPY.json').read_text())['step']=='eksport'
    step=tmp_path/'POROWNANIE_KOLORY.step'
    step.write_bytes(b'ISO-10303-21;' + b'X'*200)
    stage.update(step='gotowy',step_bytes=step.stat().st_size,reports='bom_a',report_percent=12)
    status=json.loads((tmp_path/'_ETAPY.json').read_text())
    assert status['step']=='gotowy' and status['reports']=='bom_a'
    assert status['step_bytes']==step.stat().st_size
    assert not (tmp_path/'_ETAPY.json.tmp').exists()


def test_repeated_native_component_does_not_require_geometry_retest(monkeypatch):
    from dsac29 import report,geometry
    from dsac29.step_io import load_step
    from pathlib import Path
    samples=Path(__file__).resolve().parents[1]/'samples/MODEL_A.step'
    one=load_step(str(samples))[0]
    def expensive(*args,**kwargs):raise AssertionError('Native repeated TShape should not execute rigid B-Rep test')
    monkeypatch.setattr(geometry,'equivalent_rigid',expensive)
    values=[one]*120
    calls=[]
    groups=report.geometry_groups(values,report_progress=lambda idx,tot:calls.append((idx,tot)))
    assert groups==[list(range(120))]
    assert calls[-1]==(120,120)


def test_step_marked_ready_before_bom_and_html(tmp_path,monkeypatch):
    from dsac29 import report
    from dsac29.step_io import load_step
    from dsac29.compare import compare
    sample=Path(__file__).resolve().parents[1]/'samples/MODEL_A.step'
    a=load_step(str(sample))
    records=compare(a,a)
    def verify_early(stage_records,*args,**kwargs):
        state=json.loads((tmp_path/'_ETAPY.json').read_text(encoding='utf-8'))
        assert state['step']=='gotowy'
        assert state['step_bytes']==(tmp_path/'POROWNANIE_KOLORY.step').stat().st_size
        assert state['reports'] in ('bom_a','bom_b')
        assert not (tmp_path/'RAPORT.html').exists()
        return [[i] for i in range(len(stage_records))]
    def fake_export(path,*args,**kwargs):
        Path(path).write_bytes(b'ISO-10303-21;' + b'COLOR'*60)
        return {'pokolorowane_etykiety':len(a),'weryfikacja':'OK'}
    monkeypatch.setattr(report,'export_revision_step',fake_export)
    monkeypatch.setattr(report,'geometry_groups',verify_early)
    _,error=report.produce(tmp_path,a,a,records,revision_style=True,diff_step=False)
    assert error is None
    state=json.loads((tmp_path/'_ETAPY.json').read_text(encoding='utf-8'))
    assert state['step']=='gotowy' and state['reports']=='gotowe' and state['report_percent']==100
    assert (tmp_path/'RAPORT.html').exists()
