import sys
import numpy as np
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from dsac29.geometry import describe
from dsac29.native_guard import guarded_common,guarded_rigid,NativeGeometryFailure
from dsac29.material_deltas import volume
from dsac29.compare import compare
from dsac29.alignment import _relocate


def box(dx=10,dy=20,dz=30):
    return describe(BRepPrimAPI_MakeBox(dx,dy,dz).Shape(),'part','part')


def test_isolated_rigid_proves_identical_shape():
    assert guarded_rigid(box(),box(),.01,timeout_s=15)[0]


def test_isolated_rigid_never_marks_changed_solid_identical():
    assert guarded_rigid(box(),box(11),.01,timeout_s=15)[0] is False


def test_isolated_rigid_rotation_and_shift():
    s=box(10,20,30)
    # Different placement, exact B-Rep definition. OCP transformation must be proven.
    t=_relocate(s,np.eye(3),np.array([120.,-60.,35.]))
    ok,r,vec=guarded_rigid(s,t,.01,timeout_s=15)
    assert ok
    assert r is not None


def test_isolated_common_preserves_exact_volume():
    s=box()
    shared=guarded_common(s.shape,box().shape,.01,timeout_s=15)
    assert volume(shared)==pytest.approx(6000,rel=1.e-8)


def test_native_process_crash_is_not_a_false_green():
    with pytest.raises(NativeGeometryFailure,match='błędem'):
        guarded_rigid(box(),box(),.01,process_args=[sys.executable,'-c','import os;os._exit(91)'])


def test_native_process_timeout_is_not_a_false_green():
    with pytest.raises(NativeGeometryFailure,match='limit'):
        guarded_rigid(box(),box(),.01,timeout_s=.05,
                      process_args=[sys.executable,'-c','import time;time.sleep(3)'])


def test_verified_pairs_never_conceal_real_add_remove_large_assembly():
    # Large enough to activate guard, but only native identity pairs are certified.
    shape=box(); a=[];b=[]
    for i in range(620):
        part=_relocate(shape,np.eye(3),np.array([i*50.,0.,0.]))
        a.append(part);b.append(part)
    b[-1]=_relocate(box(18,20,30),np.eye(3),np.array([619*50.,0.,0.]))
    records=compare(a,b,certified_pairs=[(i,i) for i in range(619)],revision_only=True)
    assert sum(r.status=='SAME' for r in records)==619
    assert sum(r.status=='REMOVED' for r in records)==1
    assert sum(r.status=='ADDED' for r in records)==1


def test_large_registered_frame_native_worker_crash_aborts_whole_comparison(monkeypatch):
    """Never silently convert a child failure into ADDED/REMOVED or SAME."""
    from dsac29 import native_guard
    shared=box();a=[];b=[]
    for i in range(601):
        part=_relocate(shared,np.eye(3),np.array([i*45.,0.,0.]))
        a.append(part);b.append(part)
    a[-1]=_relocate(box(12),np.eye(3),np.array([601*45.,0.,0.]))
    b[-1]=_relocate(box(12),np.eye(3),np.array([701*45.,0.,0.]))
    def crash(*_,**__):
        raise NativeGeometryFailure('symulowana awaria natywna')
    monkeypatch.setattr(native_guard,'guarded_rigid',crash)
    with pytest.raises(NativeGeometryFailure,match='symulowana awaria'):
        compare(a,b,certified_pairs=[(i,i) for i in range(600)],revision_only=True)


def test_verified_global_shift_does_not_hide_real_modified_piece():
    from dsac29.registration_gate import frame_support
    shared=box();a=[];b=[]
    global_shift=np.array([1275.,-395.,210.])
    for i in range(620):
        p=_relocate(shared,np.eye(3),np.array([i*40.,0.,0.]))
        a.append(p);b.append(_relocate(p,np.eye(3),global_shift))
    b[-1]=_relocate(box(14),np.eye(3),np.array([619*40.,0.,0.])+global_shift)
    aligned=[_relocate(part,np.eye(3),-global_shift) for part in b]
    proof=frame_support(a,aligned,.01,verify_all=True)
    assert proof['count']==619
    assert not any(i==619 for i,j in proof['pairs'])
    result=compare(a,aligned,certified_pairs=proof['pairs'],revision_only=True)
    assert sum(x.status=='SAME' for x in result)==619
    assert sum(x.status=='REMOVED' for x in result)==1
    assert sum(x.status=='ADDED' for x in result)==1


def test_large_registered_frame_isolated_rigid_matches_moved_solid():
    shared=box();a=[];b=[]
    for i in range(601):
        part=_relocate(shared,np.eye(3),np.array([i*45.,0.,0.]))
        a.append(part);b.append(part)
    a[-1]=_relocate(box(12),np.eye(3),np.array([601*45.,0.,0.]))
    b[-1]=_relocate(box(12),np.eye(3),np.array([701*45.,0.,0.]))
    records=compare(a,b,certified_pairs=[(i,i) for i in range(600)],revision_only=True)
    assert sum(r.status=='SAME' for r in records)==600
    assert sum(r.status=='MOVED' for r in records)==1
