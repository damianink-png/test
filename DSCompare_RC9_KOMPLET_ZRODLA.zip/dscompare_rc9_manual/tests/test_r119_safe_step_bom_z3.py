"""R11.9: native ZW3D safeguards, one report, visible grouped BOM, Z3 sidecars."""
import os,json
from pathlib import Path
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from dsac29.z3_support import resolve_model,NativeZW3DExportRequired
from dsac29.step_io import export_revision_step,inspect_step_colors,load_step
from dsac29.geometry import describe
from dsac29.compare import Record
from dsac29.report import produce
import pytest

def test_z3_requires_existing_fresh_real_step(tmp_path):
    z=tmp_path/'REV_A.z3'; z.write_bytes(b'not a step')
    with pytest.raises(NativeZW3DExportRequired,match='wymaga eksportu'):resolve_model(z)
    stp=tmp_path/'REV_A.step';stp.write_bytes(b'ISO-10303-21;'+b'x'*300)
    os.utime(stp,(z.stat().st_mtime+10,)*2)
    assert resolve_model(z)==stp
    os.utime(stp,(z.stat().st_mtime-20,)*2)
    with pytest.raises(NativeZW3DExportRequired,match='starszy'):resolve_model(z)

def test_safe_step_no_reuse_and_exact_solid_count(monkeypatch,tmp_path):
    monkeypatch.setenv('DSCOMPARE_BODY_COLORS','1')
    monkeypatch.setenv('DSCOMPARE_SAFE_EXPORT','1')
    monkeypatch.setenv('DSCOMPARE_STEP_VERIFY','full')
    box=BRepPrimAPI_MakeBox(20,30,40).Shape()
    parts=[describe(box,'part',f'part{i}') for i in range(2)]
    rec=[Record(0,0,'SAME',''),Record(1,1,'SAME','')]
    dest=tmp_path/'porownanie.step'
    diag=export_revision_step(dest,rec,parts,parts,old_alpha=1.0)
    reread=load_step(dest)
    assert len(reread)==2
    assert diag['bryly_wynikowe']==2
    assert diag['definicje_unikalne']==2 and diag['ponownie_uzyte_definicje']==0
    assert diag['tryb_zapisu']=='plaski_bez_pustych_absr'
    assert diag['produkty_step']==2 and diag['powiazania_zlozenia']==0 and diag['puste_reprezentacje_step']==0
    assert not any('ABSR' in p.name for p in reread)

def test_one_html_report_with_both_boms(tmp_path):
    a=[describe(BRepPrimAPI_MakeBox(12,13,14).Shape(),'A','A')]
    b=[describe(BRepPrimAPI_MakeBox(12,13,14).Shape(),'B','B')]
    produce(tmp_path,a,b,[Record(0,0,'SAME','')],generate_step=False,diff_step=False,full_bom=True)
    html=(tmp_path/'RAPORT.html').read_text()
    assert (tmp_path/'BOM_A.csv').is_file() and (tmp_path/'BOM_B.csv').is_file()
    assert 'BOM A' in html and 'BOM B' in html
    assert not (tmp_path/'RAPORT_ZMIAN.html').exists()
    assert not (tmp_path/'MINIATURA_A.json').exists()
    assert json.loads((tmp_path/'_ETAPY.json').read_text())['basic_report_ready']

def test_new_ui_settings_contract():
    pytest.importorskip('PySide6.QtWidgets')
    from PySide6.QtWidgets import QApplication
    from dsac29.gui46 import Window
    app=QApplication.instance() or QApplication([])
    w=Window();w.show();app.processEvents()
    try:
        assert list(w.nav)==['compare','mass','settings']
        assert not hasattr(w,'param_button')
        assert not hasattr(w.a,'thumbnail')
        assert not w.generate_thumbnails
        w.navigate('settings');app.processEvents()
        assert w.safe_export.isVisible() and w.full_bom.isVisible()
        assert w.cancel_compare.icon().isNull() is False
        assert all(not b.icon().isNull() for b in w.compare_open.values())
    finally:w.close()
