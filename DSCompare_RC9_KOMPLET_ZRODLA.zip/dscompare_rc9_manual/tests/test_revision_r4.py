"""Revision rules: confirmed changes and explicit unresolved geometry."""
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.gp import gp_Trsf, gp_Vec
from OCP.TopLoc import TopLoc_Location
from dsac29.geometry import describe
from dsac29.compare import compare,Record
from dsac29.revision_rules import classify_revisions
from dsac29.step_io import export_revision_step


def part(shape,x,name='RURA'):
    t=gp_Trsf();t.SetTranslation(gp_Vec(x,0,0))
    return describe(shape.Located(TopLoc_Location(t)),name,name)

def test_equal_count_relocation_is_purple_moved(tmp_path):
    shape=BRepPrimAPI_MakeBox(5,7,21).Shape()
    a=[part(shape,0),part(shape,50)]
    b=[part(shape,0),part(shape,80)]
    records=classify_revisions(a,b,compare(a,b))
    assert sorted(r.status for r in records)==['MOVED','SAME']
    dst=tmp_path/'moved.step'
    export_revision_step(dst,records,a,b)
    txt=dst.read_text(errors='replace')
    assert '03_PRZESUNIETE' in txt
    assert 'SURFACE_STYLE_TRANSPARENT' in txt
    assert '06_DO_SPRAWDZENIA' not in txt

def test_count_change_never_moved_and_keeps_unmodified():
    shape=BRepPrimAPI_MakeBox(7,8,23).Shape()
    a=[part(shape,0),part(shape,50)]
    b=[part(shape,0),part(shape,80),part(shape,120)]
    records=classify_revisions(a,b,compare(a,b))
    assert sorted(r.status for r in records)==['ADDED','ADDED','REMOVED','SAME']
    assert len([x for x in records if x.status=='SAME'])==1
    assert 'UNCERTAIN' not in [x.status for x in records]

def test_unproven_geometry_preserves_uncertainty():
    shape=BRepPrimAPI_MakeBox(5,8,9).Shape()
    a=[part(shape,0)];b=[part(shape,90)]
    # This legacy ambiguity has no proven rigid equivalence. No fabricated "change".
    result=classify_revisions(a,b,[Record(0,0,'UNCERTAIN','unresolved')])
    assert [r.status for r in result]==['UNCERTAIN']
    assert result[0].a_index==0 and result[0].b_index==0
