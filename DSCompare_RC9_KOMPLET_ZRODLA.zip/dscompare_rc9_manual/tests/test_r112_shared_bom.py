from dsac29.report import reuse_verified_bom_groups
from dsac29.compare import Record

def rec(a,b,status='SAME'):
    return Record(a,b,status,'')

def test_transfers_complete_verified_bijection():
    groups=[[0,2],[1,3]]
    assert reuse_verified_bom_groups(groups,[rec(0,3),rec(1,2),rec(2,1),rec(3,0)],4,4)==[[3,1],[2,0]]

def test_rejects_incomplete_or_duplicate_matches():
    assert reuse_verified_bom_groups([[0],[1]],[rec(0,0)],2,2) is None
    assert reuse_verified_bom_groups([[0],[1]],[rec(0,0),rec(1,0)],2,2) is None
    assert reuse_verified_bom_groups([[0],[1]],[rec(0,0),rec(0,1)],2,2) is None

def test_rejects_changes_and_movements():
    for status in ('MOVED','ADDED','REMOVED','CHANGED','UNCERTAIN'):
        assert reuse_verified_bom_groups([[0]],[rec(0,0,status)],1,1) is None

def test_renamed_is_safe():
    assert reuse_verified_bom_groups([[0]],[rec(0,0,'RENAMED')],1,1)==[[0]]

def test_invalid_grouping_not_reused():
    assert reuse_verified_bom_groups([[0],[0]],[rec(0,0),rec(1,1)],2,2) is None


def test_failed_a_bom_is_not_falsely_reused_for_b(monkeypatch, tmp_path):
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
    from dsac29.geometry import describe
    from dsac29 import report
    part=describe(BRepPrimAPI_MakeBox(2,3,4).Shape(), 'P', 'P')
    def fail(*args,**kwargs): raise RuntimeError('simulated geometry failure')
    monkeypatch.setattr(report,'geometry_groups',fail)
    traces=[]
    report.produce(tmp_path,[part],[part],[rec(0,0)],generate_step=False,diff_step=False,progress=traces.append)
    assert not any('ponowne użycie zweryfikowanych grup A' in text for text in traces)
    import json
    result=json.loads((tmp_path/'PODSUMOWANIE.json').read_text(encoding='utf8'))
    assert len(result['bom_warnings']) == 2
