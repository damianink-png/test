"""R11.5: sound geometric rejection before Boolean checks, trial-local recovery."""
import numpy as np
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.gp import gp_Pnt
from dsac29 import geometry
from dsac29.geometry import describe, equivalent_rigid


def cube(x, y=0, z=0):
    return BRepPrimAPI_MakeBox(gp_Pnt(x, y, z), 12, 8, 5).Shape()


def test_verified_equal_translated_shapes_remain_equal():
    a = describe(cube(0), 'A', 'A')
    b = describe(cube(100, 42, 5), 'B', 'B')
    assert equivalent_rigid(a, b)[0]


def test_bounds_condition_is_placement_sensitive_and_safe():
    a = describe(cube(0), 'A', 'A')
    b = describe(cube(100), 'B', 'B')
    ra = geometry._precise_world_bounds(a.shape)
    rb = geometry._precise_world_bounds(b.shape)
    assert not geometry._bounds_compatible(ra, rb, .01)
    assert np.allclose(ra, geometry._precise_world_bounds(geometry.transform(
        b.shape, np.eye(3), a.center-b.center)))


def test_failed_first_orientation_can_recover_when_a_later_boolean_proves_match(monkeypatch):
    a = describe(cube(0), 'A', 'A')
    b = describe(cube(0), 'B', 'B')
    # Override only a single Boolean attempt and force a later valid trial.
    original = geometry._is_common_equal
    first = [True]
    def flaky(*args):
        if first[0]:
            first[0] = False
            raise RuntimeError('OCCT temporary invalid intersection')
        return original(*args)
    monkeypatch.setattr(geometry, '_is_common_equal', flaky)
    assert equivalent_rigid(a, b)[0]
    assert first == [False]


def test_all_plausible_failed_boolean_checks_still_warn(monkeypatch):
    a = describe(cube(0), 'A', 'A')
    b = describe(cube(0), 'B', 'B')
    def err(*args):
        raise RuntimeError('OCCT boolean failed')
    monkeypatch.setattr(geometry, '_is_common_equal', err)
    import dsac29.surface_witness as sw
    monkeypatch.setattr(sw, 'independent_surface_identity', lambda *args: False)
    with pytest.raises(RuntimeError, match='brak rozstrzygnięcia'):
        equivalent_rigid(a, b)


def test_bbox_rejection_does_not_claim_a_positive_match(monkeypatch):
    a = describe(cube(0), 'A', 'A')
    b = describe(BRepPrimAPI_MakeBox(13., 8., 5.).Shape(), 'B', 'B')
    # Simulate a numerically permissive preselection. Impossible bounding
    # boxes must never be sent to the OCCT expensive Boolean engine.
    monkeypatch.setattr(geometry, 'candidate', lambda *args: True)
    def fail(*args):
        raise AssertionError('AABB should reject this proposed placement')
    monkeypatch.setattr(geometry, '_is_common_equal', fail)
    assert not equivalent_rigid(a, b)[0]
