"""Same colors in STEP, report and HTML; custom choices remain effective."""
import json,re
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from dsac29.geometry import describe
from dsac29.compare import Record
from dsac29.step_io import export_revision_step,inspect_step_colors,COLORS,REVISION_COLORS
from dsac29.material_deltas import COLORS as MATERIAL_COLORS
from dsac29.palette import HEX
from dsac29.preview3d import create_preview
from dsac29.report_view import enhance_report

def test_shared_palette_semantics():
    assert COLORS['SAME']==REVISION_COLORS['SAME']==MATERIAL_COLORS['CHANGED_COMMON']
    assert COLORS['ADDED']==MATERIAL_COLORS['CHANGED_ADDED']
    assert COLORS['REMOVED']==MATERIAL_COLORS['CHANGED_REMOVED']
    assert len({HEX[k] for k in ('SAME','ADDED','REMOVED','MOVED','CHANGED','UNCERTAIN')})==6

def test_actual_step_reimport_and_preview_use_same_custom_colors(tmp_path):
    part=describe(BRepPrimAPI_MakeBox(10,12,14).Shape(),'Nowa część','Nowa część')
    records=[Record(None,0,'ADDED','')];custom={'ADDED':(.2,.4,.6)}
    output=tmp_path/'colored.step';export_revision_step(str(output),records,[],[part],colors=custom)
    result=inspect_step_colors(str(output))
    assert result['bryly_bez_koloru']==0
    assert [.2,.4,.6] in [list(c) for c in result['kolory_wczytane_rgb']]
    preview=tmp_path/'preview.html';create_preview(preview,records,[],[part],colors=custom)
    scene=json.loads(re.search(r'^const scene=(.*);$',preview.read_text(),re.M).group(1))
    assert scene[0]['rgb']==[.2,.4,.6]

def test_report_adds_pair_links_only_when_preview_ready():
    page='<html><head></head><body><h1>Raport</h1><div class="panel filters"></div><table id="table"><tr data-status="ADDED"><td>Nowy</td></tr></table></body></html>'
    assert 'PODGLAD_KOLOROW_3D.html#pair=PAIR_000000' in enhance_report(page,REVISION_COLORS,{'ADDED':1},True,[])
    assert 'PODGLAD_KOLOROW_3D.html#pair=' not in enhance_report(page,REVISION_COLORS,{'ADDED':1},False,[])

def test_custom_material_color_is_reported_and_exported(tmp_path):
    from dsac29.report import produce
    a=[describe(BRepPrimAPI_MakeBox(10,12,14).Shape(),'A','A')]
    b=[describe(BRepPrimAPI_MakeBox(12,12,14).Shape(),'B','B')]
    colors={'CHANGED_ADDED':(18/255,52/255,86/255)}
    folder,error=produce(tmp_path,a,b,[Record(0,0,'CHANGED','')],revision_style=True,
                        colors=colors,preview3d=True,full_bom=False,diff_step=False)
    assert error is None
    report=(tmp_path/'RAPORT.html').read_text()
    assert 'background:#123456"></i>Dodany materiał' in report
    summary=json.loads((tmp_path/'PODSUMOWANIE.json').read_text())
    assert summary['colors_hex']['CHANGED_ADDED']=='#123456'
    scene=json.loads(re.search(r'^const scene=(.*);$',(tmp_path/'PODGLAD_KOLOROW_3D.html').read_text(),re.M).group(1))
    assert next(p for p in scene if p['status']=='CHANGED_ADDED')['rgb']==list(colors['CHANGED_ADDED'])
