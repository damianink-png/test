"""No cached geometry may be reused when STEP bytes or limits change."""
import os
import json
from pathlib import Path
import pytest
from OCP.TopoDS import TopoDS_Shape
from dsac29.import_cache import load_step_persistent, cache_key, try_load, root_dir

ROOT=Path(__file__).resolve().parents[1]

def test_cache_identity_and_limit(tmp_path,monkeypatch):
    monkeypatch.setenv('DSCOMPARE_IMPORT_CACHE','on')
    monkeypatch.setenv('DSCOMPARE_CACHE_DIR',str(tmp_path/'cache'))
    original=ROOT/'samples'/'RAMA_REV_03.step'
    first=tmp_path/'input.step';first.write_bytes(original.read_bytes())
    meta={};cold=load_step_persistent(first,max_solids=500,diagnostics=meta)
    assert len(cold)>=1 and meta.get('persistent_cache')=='MISS'
    meta={};warm=load_step_persistent(first,max_solids=500,diagnostics=meta)
    assert meta.get('persistent_cache')=='HIT'
    assert len(warm)==len(cold)
    assert [(s.name,s.volume,s.area,s.bbox,s.path) for s in warm]==[(s.name,s.volume,s.area,s.bbox,s.path) for s in cold]
    for before,after in zip(cold,warm):
        assert before.shape.IsNull()==after.shape.IsNull()==False
        assert (before.center==after.center).all()
    with pytest.raises(ValueError,match='Limit bezpieczenstwa'):
        load_step_persistent(first,max_solids=1)
    # Whitespace/comment change must invalidate cached file, even if CAD geometry is the same.
    before_key=cache_key(first)
    first.write_bytes(first.read_bytes().replace(b'ISO-10303-21;',b'ISO-10303-21;\n/* changed source */',1))
    assert cache_key(first)!=before_key
    meta={};changed=load_step_persistent(first,max_solids=500,diagnostics=meta)
    assert meta.get('persistent_cache')=='MISS' and len(changed)==len(cold)


def test_disable_cache_is_safe(tmp_path,monkeypatch):
    monkeypatch.setenv('DSCOMPARE_IMPORT_CACHE','off')
    assert cache_key(ROOT/'samples'/'RAMA_REV_04.step') is None
    a=load_step_persistent(ROOT/'samples'/'RAMA_REV_04.step')
    assert a
