"""Proof reuse must preserve results, placements and native error semantics."""
from pathlib import Path
import numpy as np
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from dsac29.geometry import describe
from dsac29.alignment import _relocate
from dsac29.native_guard import _load_brep, NativeGeometryFailure
from dsac29.geometry_registry import GeometryRegistry
from dsac29.registration_gate import frame_support, FrameProofCache
from dsac29 import step_reexport_tolerance as step, native_guard


def independent_parts():
    return ([describe(BRepPrimAPI_MakeBox(10,12,14).Shape(),'A','A')],
            [describe(BRepPrimAPI_MakeBox(10,12,14).Shape(),'B','B')])


def force_proof(monkeypatch):
    monkeypatch.setattr(GeometryRegistry,'same_definition',lambda *args:False)


def test_sample_then_full_reuses_completed_proof(monkeypatch):
    a,b=independent_parts();force_proof(monkeypatch);calls=[]
    original=step.reexport_equivalent_world
    def proof(*args,**kwargs):
        calls.append(1);return original(*args,**kwargs)
    monkeypatch.setattr(step,'reexport_equivalent_world',proof)
    cache=FrameProofCache()
    sample=frame_support(a,b,.01,proof_cache=cache)
    full=frame_support(a,b,.01,verify_all=True,proof_cache=cache)
    assert sample['proofs']==full['count']==1
    assert full['pairs']==[(0,0)] and len(calls)==1 and cache.hits==1


def test_reused_proof_is_bound_to_placement_and_tolerance():
    a,b=independent_parts();cache=FrameProofCache()
    frame_support(a,b,.01,proof_cache=cache)
    with pytest.raises(ValueError):frame_support(a,b,.001,proof_cache=cache)
    moved=[_relocate(b[0],np.eye(3),np.array([1.,0,0]))]
    with pytest.raises(ValueError):frame_support(a,moved,.01,proof_cache=cache)
    b[0].shape=moved[0].shape
    with pytest.raises(ValueError):frame_support(a,b,.01,proof_cache=cache)


def test_new_cache_does_not_reuse_another_hypothesis():
    a,b=independent_parts();cache=FrameProofCache()
    assert frame_support(a,b,.01,verify_all=True,proof_cache=cache)['count']==1
    moved=[_relocate(b[0],np.eye(3),np.array([1.,0,0]))]
    assert frame_support(a,moved,.01,verify_all=True,proof_cache=FrameProofCache())['count']==0


def test_negative_proof_is_not_promoted_to_match(monkeypatch):
    a,b=independent_parts();force_proof(monkeypatch)
    monkeypatch.setattr(step,'reexport_equivalent_world',lambda *args,**kwargs:False)
    import dsac29.registration_gate as gate
    monkeypatch.setattr(gate,'equivalent_world',lambda *args:False)
    cache=FrameProofCache()
    assert frame_support(a,b,.01,proof_cache=cache)['proofs']==0
    assert frame_support(a,b,.01,verify_all=True,proof_cache=cache)['count']==0
    assert cache.results=={}  # Inconclusive proofs remain retryable.


def test_native_failure_is_retried_and_not_cached(monkeypatch):
    a0,b0=independent_parts();a=[];b=[]
    for i in range(600):
        offset=np.array([i*50.,0,0])
        a.append(_relocate(a0[0],np.eye(3),offset))
        b.append(_relocate(b0[0],np.eye(3),offset))
    force_proof(monkeypatch)
    monkeypatch.setattr(GeometryRegistry,'definition',lambda self,p:id(p))
    calls=[]
    def flaky(left,right,*args,**kwargs):
        calls.append(left)
        if left is a[0] and calls.count(left)==1:
            raise NativeGeometryFailure('simulated timeout')
        return True
    monkeypatch.setattr(native_guard,'guarded_world_reexport',flaky)
    cache=FrameProofCache()
    sample=frame_support(a,b,.01,proofs=2,proof_cache=cache)
    assert sample['proofs']==1 and (0,0) not in cache.results
    full=frame_support(a,b,.01,verify_all=True,proof_cache=cache)
    assert full['count']==600 and calls.count(a[0])==2
    assert cache.results[0,0] is True


@pytest.mark.parametrize('fixture',['wire_roundtrip','solid_bounds_roundtrip'])
def test_real_pair_matches_uncached_result(fixture):
    folder=Path(__file__).parent/'fixtures'/fixture
    a,b=[[describe(_load_brep(folder/(role+'.brep')),role,role)] for role in ('A','B')]
    expected=frame_support(a,b,.01,verify_all=True)
    cache=FrameProofCache()
    frame_support(a,b,.01,proof_cache=cache)
    actual=frame_support(a,b,.01,verify_all=True,proof_cache=cache)
    assert actual==expected and actual['count']==1


def test_cache_rejects_reordered_occurrences():
    a,b=independent_parts()
    a.append(_relocate(a[0],np.eye(3),np.array([30.,0,0])))
    b.append(_relocate(b[0],np.eye(3),np.array([30.,0,0])))
    cache=FrameProofCache();frame_support(a,b,.01,proof_cache=cache)
    with pytest.raises(ValueError):frame_support(a,b[::-1],.01,proof_cache=cache)
