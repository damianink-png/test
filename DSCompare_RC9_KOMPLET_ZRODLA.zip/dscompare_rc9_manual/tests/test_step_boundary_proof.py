"""Exact point bookkeeping and whole-patch bounds, not sampled equality."""
from pathlib import Path
from types import SimpleNamespace
import pytest
from OCP.TopoDS import TopoDS
from dsac29.native_guard import _load_brep
from dsac29 import parametric_identity as proof
from dsac29.step_reexport_tolerance import _faces

FIXTURES=Path(__file__).parent/'fixtures'

def pair(name):
    return [TopoDS.Face_s(_load_brep(FIXTURES/name/(role+'.brep'))) for role in ('A','B')]

def prove_faces(a,b,**kwargs):
    return proof.prove(a,b,{0:0},_faces(SimpleNamespace(shape=a)),.005,
                       strict_repair=False,**kwargs)

def test_captured_nurbs_strip_needs_a_uniform_bound_and_full_curve_proof(monkeypatch):
    a,b=pair('orientation_strip')
    assert proof.collapsed_strip_orientation(a,b,.005)
    assert not proof.collapsed_strip_orientation(a,b,.001)
    assert not prove_faces(a,b)
    assert prove_faces(a,b,allow_strip_orientation=True)
    monkeypatch.setattr(proof,'edge_equal',lambda *args:False)
    assert not prove_faces(a,b,allow_strip_orientation=True)

def test_two_captured_point_seams_preserve_every_real_curve(monkeypatch):
    a,b=pair('point_seams')
    assert not prove_faces(a,b)
    assert prove_faces(a,b,allow_original_micro_degenerate=True)
    monkeypatch.setattr(proof,'edge_equal',lambda *args:False)
    assert not prove_faces(a,b,allow_original_micro_degenerate=True)

def nurbs_face(width,length=.08):
    from OCP.TColgp import TColgp_Array2OfPnt
    from OCP.TColStd import TColStd_Array1OfReal,TColStd_Array1OfInteger
    from OCP.Geom import Geom_BSplineSurface
    from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeFace
    from OCP.gp import gp_Pnt
    poles=TColgp_Array2OfPnt(1,2,1,2)
    for i in (1,2):
        for j in (1,2):poles.SetValue(i,j,gp_Pnt((i-1)*width,(j-1)*length,0))
    knots=TColStd_Array1OfReal(1,2);knots.SetValue(1,0.);knots.SetValue(2,1.)
    mult=TColStd_Array1OfInteger(1,2);mult.SetValue(1,2);mult.SetValue(2,2)
    return BRepBuilderAPI_MakeFace(Geom_BSplineSurface(poles,knots,knots,mult,mult,1,1),1e-9).Face()

def test_reversed_regular_surface_cannot_use_strip_exception():
    face=nurbs_face(.1)
    assert not proof.collapsed_strip_orientation(face,TopoDS.Face_s(face.Reversed()),.01)
    assert not proof.collapsed_strip_orientation(face,face,.01)

def test_thin_patch_has_an_explicit_tolerance_threshold():
    face=nurbs_face(.001)
    reverse=TopoDS.Face_s(face.Reversed())
    assert proof.collapsed_strip_orientation(face,reverse,.01)
    assert not proof.collapsed_strip_orientation(face,reverse,.001)

def test_nonzero_curve_cannot_be_discarded_as_a_point():
    from OCP.BRep import BRep_Builder,BRep_Tool
    from OCP.Geom import Geom_Line
    from OCP.gp import gp_Pnt,gp_Dir
    a,b=pair('point_seams')
    for edge in proof.items(b,proof.TopAbs_EDGE,TopoDS.Edge_s):
        if BRep_Tool.Degenerated_s(edge):
            BRep_Builder().UpdateEdge(edge,Geom_Line(gp_Pnt(0,0,0),gp_Dir(1,0,0)),1e-7)
            break
    assert not prove_faces(a,b,allow_original_micro_degenerate=True)
