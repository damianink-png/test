"""R9 regression for original placement and global translation on large assemblies."""
import time
import numpy as np
from collections import Counter
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.TopLoc import TopLoc_Location
from OCP.gp import gp_Trsf,gp_Vec
from dsac29.geometry import describe
from dsac29.alignment import align_assembly
from dsac29.registration_gate import frame_support
from dsac29.compare import compare


def _two_assemblies(global_shift=0.0):
    primitive=BRepPrimAPI_MakeBox(5,7,9).Shape()
    def part(i,shift=0.0):
        tr=gp_Trsf();tr.SetTranslation(gp_Vec(i*27+shift,(i%15)*60,(i//15)*12))
        return describe(primitive.Located(TopLoc_Location(tr)),'identyczny_profil','identyczny_profil')
    a=[part(i) for i in range(380)]
    b=[part(i,global_shift+(0 if i<231 else 14)) for i in range(380)]
    return a,b


def test_no_global_offset_380_with_partial_changes():
    a,b=_two_assemblies(0.0)
    start=time.perf_counter()
    aligned,meta=align_assembly(a,b,.01)
    assert meta['status']=='already_aligned'
    assert meta['translation_B_to_A_mm']==[0.0,0.0,0.0]
    assert aligned is b  # native shapes not recopied or rebuilt
    assert frame_support(a,aligned,.01)['count']==231
    assert time.perf_counter()-start<15  # safety regression, not timing guarantee
    records=compare(a,aligned,.01,revision_only=True,exact_serialization=True)
    assert Counter(x.status for x in records)['SAME']==231


def test_global_offset_380_has_231_identical_after_alignment():
    a,b=_two_assemblies(1000.0)
    aligned,meta=align_assembly(a,b,.01)
    assert meta['status']=='registered'
    assert np.allclose(meta['translation_B_to_A_mm'],[-1000,0,0])
    assert frame_support(a,aligned,.01,verify_all=True)['count']==231
    records=compare(a,aligned,.01,revision_only=True,exact_serialization=True)
    assert Counter(x.status for x in records)['SAME']==231
