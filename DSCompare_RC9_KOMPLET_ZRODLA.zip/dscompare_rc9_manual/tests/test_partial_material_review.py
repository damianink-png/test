"""Explicit review never turns incomplete material proof into ADDED/REMOVED."""
import json
from pathlib import Path
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from dsac29 import native_guard,revision_overlap
from dsac29.compare import Record
from dsac29.geometry import describe
from dsac29.report import produce
from dsac29.brep_safety import validated_copy,UnprovenRepair,topology_tolerances

def inputs():
    stable=describe(BRepPrimAPI_MakeBox(20.,15.,10.).Shape(),'stable','stable')
    old=describe(BRepPrimAPI_MakeBox(10.,10.,10.).Shape(),'old','old')
    new=describe(BRepPrimAPI_MakeBox(11.,10.,10.).Shape(),'new','new')
    return [stable,old],[stable,new],[Record(0,0,'SAME','proven'),Record(1,None,'REMOVED',''),Record(None,1,'ADDED','')]

def fail(*args,**kwargs):
    raise native_guard.NativeGeometryFailure('source tolerance budget 0.17 mm > 0.01 mm')

def test_strict_mode_and_declining_review_still_stop(monkeypatch):
    a,b,records=inputs();monkeypatch.setattr(native_guard,'guarded_common',fail)
    with pytest.raises(native_guard.NativeGeometryFailure,match='source tolerance'):
        revision_overlap.merge_material_revisions(a,b,records)
    with pytest.raises(InterruptedError,match='raportu częściowego'):
        revision_overlap.merge_material_revisions(a,b,records,review_approval=lambda p:'cancel')
    assert [r.status for r in records]==['SAME','REMOVED','ADDED']

def test_explicit_review_preserves_all_inputs_and_exports_no_fake_material(tmp_path,monkeypatch):
    a,b,records=inputs();monkeypatch.setattr(native_guard,'guarded_common',fail)
    proposals=[]
    def approve(p):proposals.append(p);return 'review'
    result,cache,stat=revision_overlap.merge_material_revisions(a,b,records,review_approval=approve)
    assert len(proposals)==1 and proposals[0]['status']=='material_unverified'
    assert proposals[0]['unverified_A']==proposals[0]['unverified_B']==1
    assert [r.status for r in result]==['SAME','UNCERTAIN','UNCERTAIN']
    assert {r.a_index for r in result if r.a_index is not None}=={0,1}
    assert {r.b_index for r in result if r.b_index is not None}=={0,1}
    assert not cache and stat['incomplete']
    out,error=produce(tmp_path,a,b,result,7850.,generate_step=True,preview3d=True,
                      revision_style=True,full_bom=False,diff_step=False,
                      report_context={'revision_overlap':stat})
    assert not error
    s=json.loads((out/'PODSUMOWANIE.json').read_text())
    assert not s['analysis_complete'] and not s['material_analysis_complete']
    assert s['statuses']=={'SAME':1,'UNCERTAIN':2}
    assert not s['material_regions'] and not s['material_errors']
    assert s['step_ready'] and s['preview_3d']['pominiete']==0
    assert 'Raport częściowy' in (out/'RAPORT.html').read_text()
    assert (out/'ANALIZA_NIEKOMPLETNA.txt').is_file()

def test_actual_openarm_tolerance_is_reported_without_changing_source():
    root=Path(__file__).parent/'fixtures/openarm_source_tolerance'
    shape=native_guard._load_brep(root/'A.brep');before=topology_tolerances(shape)
    assert before['vertex']>.17 and before['edge']>.07
    with pytest.raises(UnprovenRepair,match='wierzchołki: 0.170017583 mm') as error:
        validated_copy(shape,.01)
    assert 'limit: 0.01 mm' in str(error.value)
    assert topology_tolerances(shape)==before
