"""Actual STEP imports: distinguish frame shifts from individual part moves."""
import json
import numpy as np
import pytest
from OCP.BRep import BRep_Builder
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.STEPControl import STEPControl_Writer,STEPControl_AsIs
from OCP.TopoDS import TopoDS_Compound
from OCP.gp import gp_Trsf,gp_Vec
from OCP.TopLoc import TopLoc_Location
from dsac29.cli import process
from dsac29.alignment_notice import alignment_notice

def write(path,count,offset,local=False):
    compound=TopoDS_Compound();builder=BRep_Builder();builder.MakeCompound(compound)
    for i in range(count):
        delta=np.asarray(offset) if not local or i==count-1 else np.zeros(3)
        tr=gp_Trsf();tr.SetTranslation(gp_Vec(*(np.array([i*60.,i*i*10.,0.])+delta)))
        builder.Add(compound,BRepPrimAPI_MakeBox(10.+i,12.+i*2,8.+i).Shape().Located(TopLoc_Location(tr)))
    writer=STEPControl_Writer();writer.Transfer(compound,STEPControl_AsIs);writer.Write(str(path))

@pytest.mark.parametrize('count',[2,6,20])
@pytest.mark.parametrize('shift',[[1000.,-300.,50.],[507.4569,-249.1752,524.]])
def test_global_shift_is_proven_and_visible_in_report(tmp_path,count,shift):
    a=tmp_path/'A.step';b=tmp_path/'B.step'
    write(a,count,[0.,0.,0.]);write(b,count,shift)
    out=tmp_path/'out';out.mkdir()
    process(a,b,out,step=False,diff_step=False,full_bom=False,auto_align=True,
            revision_style=True,alignment_approval=lambda p:'align',progress=None)
    summary=json.loads((out/'PODSUMOWANIE.json').read_text())
    assert summary['alignment']['applied']
    assert np.allclose(summary['alignment']['translation_B_to_A_mm'],-np.asarray(shift),atol=1e-6)
    assert summary['statuses'].get('SAME',0)==count
    notice=alignment_notice(summary['alignment'])
    assert 'globalne przesunięcie' in notice and f'ΔX = {-shift[0]:+.4f} mm' in notice
    assert 'globalne przesunięcie' in (out/'RAPORT.html').read_text()

def test_one_moved_part_is_not_normalized_as_a_whole_assembly_shift(tmp_path):
    a=tmp_path/'A.step';b=tmp_path/'B.step'
    write(a,6,[0.,0.,0.]);write(b,6,[25.,-5.,0.],local=True)
    out=tmp_path/'out';out.mkdir()
    process(a,b,out,step=False,diff_step=False,full_bom=False,auto_align=True,
            revision_style=True,alignment_approval=lambda p:'align',progress=None)
    s=json.loads((out/'PODSUMOWANIE.json').read_text())
    assert not s['alignment'].get('applied')
    assert s['statuses'].get('MOVED')==1 and s['statuses'].get('SAME')==5

def test_unknown_shift_is_never_described_as_no_displacement():
    assert 'Nie udało' in alignment_notice({'status':'unresolved_no_hypothesis'})
    assert alignment_notice({'applied':True,'translation_B_to_A_mm':[float('nan'),0,0]})==''
