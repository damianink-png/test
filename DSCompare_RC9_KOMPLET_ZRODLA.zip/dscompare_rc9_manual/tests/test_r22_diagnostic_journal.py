"""Instrumentation must not turn native failures into false geometric matches."""
import json, pytest
from pathlib import Path
from dsac29 import trace_r22 as trace

def test_crash_safe_journal_and_pair(tmp_path,monkeypatch):
 monkeypatch.setenv('DSCOMPARE_TRACE_BREP','1')
 trace.setup(tmp_path)
 with trace.phase('import',n=2):
  assert trace.brep_call('geometry',5,11,lambda x: x==2,2)
 events=[json.loads(x) for x in (tmp_path/'_ETAPY_DIAGNOSTYKA.jsonl').read_text(encoding='utf-8').splitlines()]
 assert events[0]['stage']=='worker'
 assert [(e['stage'],e['event']) for e in events if e['stage']=='geometry']== [('geometry','PAIR_BEGIN'),('geometry','PAIR_END')]
 assert all('rss_mib' in e and 'peak_rss_mib' in e for e in events)
 assert all('utc' in e and 'elapsed_s' in e for e in events)


def test_exception_propagates_and_journal_persists(tmp_path):
 trace.setup(tmp_path)
 def fail():raise RuntimeError('geometry failed')
 with pytest.raises(RuntimeError,match='geometry failed'):
  with trace.phase('matching'):
   trace.brep_call('native',3,7,fail)
 events=[json.loads(x) for x in (tmp_path/'_ETAPY_DIAGNOSTYKA.jsonl').read_text(encoding='utf-8').splitlines()]
 assert ('matching','ERROR') in {(e['stage'],e['event']) for e in events}
 assert ('native','PAIR_ERROR') in {(e['stage'],e['event']) for e in events}
