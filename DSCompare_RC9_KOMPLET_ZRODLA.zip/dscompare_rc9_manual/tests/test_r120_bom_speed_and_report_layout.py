"""R11.10: optional proven-duplicates-only grouping, collapsible HTML and optional CSV."""
import json
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from dsac29 import report
from dsac29.geometry import describe
from dsac29.compare import Record
from dsac29.geometry_registry import GeometryRegistry


def _part(name):
    return describe(BRepPrimAPI_MakeBox(10, 20, 30).Shape(), name, name)


def test_fast_bom_skips_expensive_cad_bool_when_independent_digests_differ(monkeypatch):
    a,b=_part('A'),_part('B')
    ctx=GeometryRegistry()
    monkeypatch.setattr(ctx, 'exact_digest', lambda part: b'one' if part is a else b'two')
    monkeypatch.setattr(ctx, 'rigid_equivalent', lambda *args: (_ for _ in ()).throw(AssertionError('expensive check')))
    groups=report.geometry_groups([a,b],context=ctx,fast_proven_only=True)
    assert groups==[[0],[1]]
    assert ctx.stats['bom_inconclusive_fast_pairs']==1


def test_fast_bom_can_join_identical_digest_without_cad_bool(monkeypatch):
    a,b=_part('A'),_part('B')
    ctx=GeometryRegistry()
    monkeypatch.setattr(ctx, 'exact_digest', lambda part: b'confirmed-brep')
    monkeypatch.setattr(ctx, 'rigid_equivalent', lambda *args: (_ for _ in ()).throw(AssertionError('unnecessary CAD bool')))
    assert report.geometry_groups([a,b],context=ctx,fast_proven_only=True)==[[0,1]]


def test_html_bom_collapsed_after_changes_no_csv(tmp_path):
    a,b=[_part('A')],[_part('B')]
    report.produce(tmp_path,a,b,[Record(0,0,'SAME','same')],generate_step=False,diff_step=False,bom_fast=True,bom_csv=False)
    page=(tmp_path/'RAPORT.html').read_text(encoding='utf8')
    assert '<details class="panel bom-panel"><summary>BOM A' in page
    assert '<details class="panel bom-panel"><summary>BOM B' in page
    assert '<details class="panel bom-panel" open' not in page
    assert page.index('<table id="table">') < page.index('<details class="panel bom-panel">')
    assert page.index('BOM A')<page.index('BOM B')
    assert not (tmp_path/'BOM_A.csv').exists() and not (tmp_path/'BOM_B.csv').exists()
    assert (tmp_path/'ZMIANY.csv').exists()
    data=json.loads((tmp_path/'PODSUMOWANIE.json').read_text(encoding='utf8'))
    assert data['bom_mode']=='szybki' and not data['bom_csv'] and data['full_bom']
    assert data['bom_grouping_complete']


def test_html_bom_can_keep_csv_and_full_mode(tmp_path):
    a,b=[_part('A')],[_part('B')]
    report.produce(tmp_path,a,b,[Record(0,0,'SAME','same')],generate_step=False,diff_step=False,bom_fast=False,bom_csv=True)
    assert (tmp_path/'BOM_A.csv').is_file() and (tmp_path/'BOM_B.csv').is_file()
    assert json.loads((tmp_path/'PODSUMOWANIE.json').read_text())['bom_mode']=='dokladny'
