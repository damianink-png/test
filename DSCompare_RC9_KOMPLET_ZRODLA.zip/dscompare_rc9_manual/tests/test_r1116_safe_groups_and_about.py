"""R11.16 regression: flat STEP must remain body-only, grouping is metadata.
Qt UI is smoke tested separately on Windows with a real PySide6 runtime.
"""
import json,os,re
from pathlib import Path
import pytest
from dsac29.step_io import export_revision_step
from dsac29.geometry import describe
from dsac29.compare import compare
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.TopLoc import TopLoc_Location
from OCP.gp import gp_Trsf,gp_Vec


def _box(dx=0):
    s=BRepPrimAPI_MakeBox(20,12,9).Shape()
    t=gp_Trsf();t.SetTranslation(gp_Vec(dx,0,0))
    return describe(s.Located(TopLoc_Location(t)),'Rama 1','Rama 1')


def test_group_manifest_and_absr_safe_flat_step(tmp_path,monkeypatch):
    a=[_box(0),_box(100)]
    b=[_box(0),_box(150),_box(250)]
    records=compare(a,b,revision_only=True)
    monkeypatch.setenv('DSCOMPARE_SAFE_EXPORT','1')
    monkeypatch.setenv('DSCOMPARE_STEP_VERIFY','fast')
    output=tmp_path/'POROWNANIE_KOLORY.step'
    d=export_revision_step(str(output),records,a,b)
    groups=json.loads((tmp_path/'GRUPY_ZW3D.json').read_text('utf8'))
    assert groups['status']=='wymaga_zweryfikowanego_grupowania_przez_api_zw3d'
    assert groups['liczba_bryl']==len(groups['grupy'])
    assert groups['liczba_bryl']==d['produkty_step']
    data=output.read_bytes()
    products=len(re.findall(rb'(?m)^#\d+\s*=\s*PRODUCT\(',data))
    assert products==groups['liczba_bryl']
    assert not re.search(rb'(?m)^#\d+\s*=\s*NEXT_ASSEMBLY_USAGE_OCCURRENCE\(',data)
    assert not re.search(rb'(?m)^#\d+\s*=\s*SHAPE_REPRESENTATION\(',data)
    assert all(x['podzlozenie'] for x in groups['grupy'])


def test_native_ui_and_animated_about(tmp_path,monkeypatch):
    qt=pytest.importorskip('PySide6')
    monkeypatch.setenv('QT_QPA_PLATFORM','offscreen')
    from PySide6.QtWidgets import QApplication
    from dsac29.gui46 import Window
    from dsac29.gui_modern import AboutWindow,build_version
    app=QApplication.instance() or QApplication([])
    w=Window();w.show();app.processEvents()
    try:
        assert w.safe_export.isChecked()
        assert w.safe_export.isHidden()
        assert len(w.nav)==3
        assert w.about_button.isVisible()
        assert w._success.isHidden()
        assert w._details.isHidden()
        for x in ['Ciemny','Jasny','Ciemny','Jasny']:
            w.theme.setCurrentText(x);app.processEvents()
        for key in ('compare','mass','settings'):
            w.navigate(key);app.processEvents()
            assert w.pages[key].isVisible()
        w.navigate('compare')
        ab=AboutWindow(w);ab.show();app.processEvents()
        assert ab.logo._ticker.isActive()
        ab.logo.tick();ab.close();app.processEvents()
        assert not ab.logo._ticker.isActive()
        assert build_version()
        w.a.path.setText(str(tmp_path/'A.step'))
        w.b.path.setText(str(tmp_path/'B.step'))
        w.swap()
        assert w.a.path.text().endswith('B.step')
        assert w.b.path.text().endswith('A.step')
        for width,height in ((1024,768),(800,600),(1460,900)):
            w.resize(width,height);app.processEvents()
            assert w.width()>=740
    finally:w.close()
