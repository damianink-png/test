from pathlib import Path
import pytest
import numpy as np
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.gp import gp_Trsf,gp_Vec
from OCP.TopLoc import TopLoc_Location
from dsac29.geometry import describe
from dsac29.compare import Record,compare,ShiftDetected
from dsac29.deferred_alignment import propose_from_stage1,_step_reexport_fallback
from dsac29.step_reexport_tolerance import reexport_equivalent_world
from dsac29.step_io import ColoredDocument,load_step

def part(shape,x=0,y=0):
 t=gp_Trsf();t.SetTranslation(gp_Vec(x,y,0));return describe(shape.Located(TopLoc_Location(t)),'P','P')

def test_rejects_dimension_change():
 assert not reexport_equivalent_world(part(BRepPrimAPI_MakeBox(100,10,10).Shape()),part(BRepPrimAPI_MakeBox(100.005,10,10).Shape(),-.0025),.001)

def changed_case():
 sa=BRepPrimAPI_MakeBox(100,10,10).Shape();sb=BRepPrimAPI_MakeBox(100.005,10,10).Shape()
 return [part(sa,i*300.,i*i*100.) for i in range(8)],[part(sb,i*300.+1000-.0025,i*i*100.+2000) for i in range(8)]

def test_changed_parts_cannot_certify_frame():
 a,b=changed_case();proposal=_step_reexport_fallback(a,b,0,.001)
 assert proposal is None or proposal['status']=='unresolved'

def test_face_descriptors_are_not_identity_proof(monkeypatch):
 from dsac29 import step_reexport_tolerance as module
 a=part(BRepPrimAPI_MakeBox(20,10,10).Shape());calls=[]
 def proof(*args):calls.append(args);return False
 from dsac29 import parametric_identity
 monkeypatch.setattr(parametric_identity,'prove',lambda *args:False)
 monkeypatch.setattr(module,'_verified_difference_empty',proof)
 assert not reexport_equivalent_world(a,a,.01)
 assert len(calls)==1

def test_periodic_shift_with_added_occurrence():
 s=BRepPrimAPI_MakeBox(17,11,9).Shape();pos=list(range(29))+[40]
 a=[part(s,x*40) for x in pos];b=[part(s,(x+1)*40) for x in pos]+[part(s,4040)]
 hook=lambda rec,fa,fb:propose_from_stage1(a,b,rec,fa,fb,.01)
 with pytest.raises(ShiftDetected) as caught:compare(a,b,revision_only=True,exact_serialization=True,stage1_check=hook)
 assert caught.value.proposal['votes']==30
 assert caught.value.proposal['translation_B_to_A_mm']==[-40.,0.,0.]

def test_step_roundtrip(tmp_path):
 from OCP.BRepPrimAPI import BRepPrimAPI_MakeCylinder
 for idx,s in enumerate([BRepPrimAPI_MakeBox(20,10,10).Shape(),BRepPrimAPI_MakeCylinder(5,20).Shape()]):
  path=tmp_path/f'{idx}.step';doc=ColoredDocument();doc.add(s,'Roundtrip',(.2,.8,.2));doc.write(str(path))
  imported=load_step(str(path));assert len(imported)==1
  assert reexport_equivalent_world(part(s),imported[0],.001)

def test_material_common_reuse(monkeypatch):
 from dsac29 import revision_overlap,material_deltas
 a=[part(BRepPrimAPI_MakeBox(20,10,10).Shape())];b=[part(BRepPrimAPI_MakeBox(21,10,10).Shape())]
 from dsac29 import native_guard
 calls=[];original_common=native_guard.guarded_common;original_calculate=revision_overlap.calculate
 def tracked_common(*args,**kwargs):
  calls.append('Common');return original_common(*args,**kwargs)
 def tracked_calculate(*args,**kwargs):
  assert kwargs.get('common_shape') is not None
  calls.append('ReuseCommon');return original_calculate(*args,**kwargs)
 monkeypatch.setattr(native_guard,'guarded_common',tracked_common)
 monkeypatch.setattr(revision_overlap,'calculate',tracked_calculate)
 rec,regions,_=revision_overlap.merge_material_revisions(a,b,[Record(0,None,'REMOVED',''),Record(None,0,'ADDED','')])
 assert [r.status for r in rec]==['CHANGED']
 assert calls==['Common','ReuseCommon']
 assert regions[0].regions.common_mm3==pytest.approx(2000)
 assert regions[0].regions.added_mm3==pytest.approx(100)
 assert regions[0].regions.removed_mm3==pytest.approx(0,abs=1e-6)

def test_mesh_cache_preserves_rotation_translation():
 from OCP.gp import gp_Ax1,gp_Pnt,gp_Dir
 from dsac29.preview3d import _MeshCache,_faces_meshed
 s=BRepPrimAPI_MakeBox(20,10,7).Shape();cache=_MeshCache();original=cache.world_points(s,.15)
 tr=gp_Trsf();tr.SetRotation(gp_Ax1(gp_Pnt(0,0,0),gp_Dir(0,0,1)),.7);tr.SetTranslationPart(gp_Vec(100,-50,10))
 moved=s.Located(TopLoc_Location(tr));actual=cache.world_points(moved,.15)
 expected=np.asarray(list(_faces_meshed(moved,.15))).reshape(-1,3)
 assert cache.hits==1 and np.allclose(actual,expected,rtol=0,atol=1e-10)
 assert not np.allclose(original,actual)

def test_within_tolerance_is_accepted():
 assert reexport_equivalent_world(part(BRepPrimAPI_MakeBox(100,10,10).Shape()),part(BRepPrimAPI_MakeBox(100.0002,10,10).Shape(),-.0001),.001)

def test_full_cli_never_marks_changed_geometry_same(tmp_path,monkeypatch):
 import json
 from dsac29 import cli
 a,b=changed_case();pa=tmp_path/'a.step';pb=tmp_path/'b.step';pa.write_text('A');pb.write_text('B')
 monkeypatch.setattr(cli,'load_step',lambda path,**kw:a if Path(path)==pa else b)
 out=tmp_path/'out';out.mkdir()
 cli.process(pa,pb,out,tolerance=.001,step=False,diff_step=False,full_bom=False,revision_style=True,auto_align=True,progress=None,alignment_approval=lambda _: 'original')
 assert json.loads((out/'PODSUMOWANIE.json').read_text())['statuses'].get('SAME',0)==0
