"""Regression: no empty ABSR products by default in the frozen Windows worker."""
from dsac29.worker_v37 import main
from dsac29.step_io import export_revision_step, load_step
from dsac29.compare import Record
from dsac29.geometry import describe
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
import json

def test_worker_export_is_flat_without_explicit_safe_flag(tmp_path,monkeypatch):
    monkeypatch.setenv('DSCOMPARE_SAFE_EXPORT','0')  # worker overrides this only during its isolated process
    a=tmp_path/'A.step';b=tmp_path/'B.step';out=tmp_path/'output'
    base=[describe(BRepPrimAPI_MakeBox(3,4,5).Shape(),'sample','sample')]
    export_revision_step(a,[Record(0,0,'SAME','')],base,base)
    export_revision_step(b,[Record(0,0,'SAME','')],base,base)
    rc=main(['--worker','compare','--a',str(a),'--b',str(b),'--output',str(out),'--generate-step','--revision-style','--no-bom'])
    assert rc==0,json.loads((out/'_WYNIK_V37.json').read_text(encoding='utf8'))
    assert len(load_step(out/'POROWNANIE_KOLORY.step'))==1
    raw=(out/'POROWNANIE_KOLORY.step').read_bytes()
    assert b'NEXT_ASSEMBLY_USAGE_OCCURRENCE' not in raw
    assert 'plaski STEP' in (out/'RAPORT.html').read_text(encoding='utf8')
