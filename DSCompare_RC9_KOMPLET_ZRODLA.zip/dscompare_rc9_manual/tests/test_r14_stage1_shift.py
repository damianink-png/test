"""Performance and safety contract: stage 1 makes placement decision."""
import json
from pathlib import Path
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
import pytest
from test_r7_alignment_preview import occurrence
from dsac29 import cli,compare as compare_module
from dsac29.compare import compare,ShiftDetected
from dsac29.deferred_alignment import propose_from_stage1
from dsac29.similarity_gate import ModelsUnrelated,check_related
from test_r14_sparse_shift import case


def parts(n=40,stable=40,offset=0):
 s=BRepPrimAPI_MakeBox(15,9,7).Shape()
 t=BRepPrimAPI_MakeBox(15,10,7).Shape()
 a=[occurrence(s,'Name',i*57.,i*i*3.) for i in range(n)]
 b=[occurrence(s if i<stable else t,'Name',i*57.+offset,i*i*3.) for i in range(n)]
 return a,b


def test_unshifted_stage1_does_not_raise_or_check_translations(monkeypatch):
 from dsac29 import deferred_alignment
 a,b=parts(stable=39)
 monkeypatch.setattr(deferred_alignment,'propose',lambda *a,**k: (_ for _ in ()).throw(AssertionError('unnecessary histogram')))
 hook=lambda records,fa,fb:propose_from_stage1(a,b,records,fa,fb,.01)
 records=compare(a,b,revision_only=True,exact_serialization=True,stage1_check=hook)
 assert sum(r.status=='SAME' for r in records)==39


def test_global_shift_interrupts_before_rigid(monkeypatch):
 a,b=parts(offset=1000)
 def no_rigid(*args,**kwargs):raise AssertionError('rigid B-Rep before shift')
 import dsac29.compare as compare_pkg
 monkeypatch.setattr(compare_pkg,'equivalent_rigid',no_rigid)
 hook=lambda records,fa,fb:propose_from_stage1(a,b,records,fa,fb,.01)
 with pytest.raises(ShiftDetected) as caught:
  compare(a,b,revision_only=True,exact_serialization=True,stage1_check=hook)
 assert caught.value.proposal['translation_B_to_A_mm']==[-1000.,0.,0.]
 assert caught.value.proposal['votes']==40


def test_sparse_global_shift_requires_user_confirm(tmp_path,monkeypatch):
 a,b,_=case()
 pa=tmp_path/'a.step';pb=tmp_path/'b.step';pa.write_text('x');pb.write_text('y')
 monkeypatch.setattr(cli,'load_step',lambda path,**k:a if path==pa else b)
 requests=[]
 def prompt(p):requests.append(p);return 'align'
 out=tmp_path/'out';out.mkdir()
 cli.process(pa,pb,out,step=False,diff_step=False,full_bom=False,revision_style=True,
             auto_align=True,alignment_approval=prompt,progress=None)
 data=json.loads((out/'PODSUMOWANIE.json').read_text(encoding='utf8'))
 assert len(requests)==1,requests
 assert requests[0]['votes']==8
 assert data['alignment']['translation_B_to_A_mm']==[-1500.,200.,0.]
 assert data['statuses'].get('SAME')==8


def test_periodic_pitch_shift_not_hidden_by_90_percent():
 s=BRepPrimAPI_MakeBox(11,9,7).Shape()
 a=[occurrence(s,'Beam',i*50.,0.) for i in range(35)]
 b=[occurrence(s,'Beam',(i+1)*50.,0.) for i in range(35)]
 hook=lambda rec,fa,fb:propose_from_stage1(a,b,rec,fa,fb,.01)
 with pytest.raises(ShiftDetected) as caught:
  compare(a,b,revision_only=True,exact_serialization=True,stage1_check=hook)
 assert caught.value.proposal['translation_B_to_A_mm']==[-50.,0.,0.]


def test_unrelated_gate_can_be_overridden(tmp_path,monkeypatch):
 s=BRepPrimAPI_MakeBox(30,30,30).Shape()
 t=BRepPrimAPI_MakeBox(3,3,3).Shape()
 a=[occurrence(s,'A',0,0)];b=[occurrence(t,'B',0,0)]
 with pytest.raises(ModelsUnrelated):check_related(a,b)
 pa=tmp_path/'a.step';pb=tmp_path/'b.step';pa.write_text('old');pb.write_text('new')
 monkeypatch.setattr(cli,'load_step',lambda path,**kw:a if path==pa else b)
 out=tmp_path/'out';out.mkdir()
 calls=[]
 def confirm(p):calls.append(p);return 'original'
 cli.process(pa,pb,out,step=False,diff_step=False,full_bom=False,revision_style=True,
             auto_align=True,alignment_approval=confirm,progress=None)
 assert len(calls)==1 and calls[0]['status']=='unrelated'
 assert (out/'PODSUMOWANIE.json').is_file()
