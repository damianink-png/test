"""R11.6: true large assembly import and third-party CAD-friendly labels."""
from pathlib import Path
import os
import pytest
from dsac29.names import display_csv_label
from dsac29.step_io import cad_product_name,ColoredDocument,load_step


def test_ui_shows_plain_part_number_not_excel_formula():
    assert display_csv_label('="04244002"') == '04244002'
    assert display_csv_label('="04001"') == '04001'
    assert display_csv_label('Rama 001') == 'Rama 001'


def test_step_product_names_ascii_and_stable():
    a=cad_product_name('0412456 [aluminium] / ŚRUBA',7,'NOWE','NOWA')
    assert a.startswith('0412456_aluminium_SRUBA')
    assert a.endswith('__NOWE__NOWA__P000007')
    assert '[' not in a and ' ' not in a
    assert a != cad_product_name('0412456 [aluminium] / ŚRUBA',8,'NOWE','NOWA')


def test_import_limit_above_1000_is_supported(tmp_path,monkeypatch):
    """Regression: former hard safety limit of 1000 blocks real customer files."""
    from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
    monkeypatch.setenv('DSCOMPARE_STEP_VERIFY','fast')
    shp=BRepPrimAPI_MakeBox(1.0,1.0,1.0).Shape()
    file=tmp_path/'over_1000.stp'
    doc=ColoredDocument(group_by_status=True)
    for number in range(1005):
        doc.add(shp,cad_product_name('AB-001',number,'SAME','B'),(.0,.7,.2),group='SAME',revision='B')
    assert doc.count==1005
    diag=doc.write(file)
    assert diag['pokolorowane_etykiety']==1005
    parts=load_step(str(file),max_solids=20000)
    assert len(parts)==1005
    assert all(not part.name.startswith('ABSR') for part in parts)
    with pytest.raises(ValueError,match='Limit'):
        load_step(str(file),max_solids=1000)


def test_max_limit_50k_and_reject_invalid(tmp_path):
    sample=Path(__file__).resolve().parents[1]/'samples'/'MODEL_A.step'
    assert load_step(str(sample),max_solids=50000)
    with pytest.raises(ValueError,match='Limit'):
        load_step(str(sample),max_solids=50001)


def test_gui_panel_does_not_overlay_results():
    # No qtbot dependency; Windows CI provides PySide6.
    os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
    from PySide6.QtWidgets import QApplication
    from dsac29.gui46 import Window
    app=QApplication.instance() or QApplication([])
    win=Window();win.show();app.processEvents()
    try:
        assert win.legend.isHidden() and win.grouping_hint.isHidden() and win.visibility_hint.isHidden()
        assert not hasattr(win,'legend_button')
        assert win.solid_limit.maximum()==50000
        assert win.solid_limit.value()>1000
        assert win.run_compare.icon().isNull() is False
        assert win.compare_open['POROWNANIE_KOLORY.step'].icon().isNull() is False
        assert win.theme_button.icon().isNull() is False
        assert not hasattr(win,'param_frame')
        for selector in (win.filter_selector,win.verify_mode,win.materials,win.schema):
            assert 'QComboBox' in win.styleSheet() and selector.count()>0
        win.navigate('settings');app.processEvents()
        assert win.safe_export.isVisible() and win.full_bom.isVisible()
        win.navigate('compare');app.processEvents()
    finally:win.close()
