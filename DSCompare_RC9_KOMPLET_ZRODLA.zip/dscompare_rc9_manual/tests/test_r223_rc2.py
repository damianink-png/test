import importlib
import sys
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from dsac29.geometry import describe
from dsac29.native_guard import guarded_world_reexport, NativeGeometryFailure
from dsac29.native_session import world_session, current

def solid(n=10):
    return describe(BRepPrimAPI_MakeBox(n,12,14).Shape(),'part','part')

def test_session_reuses_process_and_recycles():
    with world_session() as session:
        session.max_requests=2
        assert guarded_world_reexport(solid(),solid(),.01)
        pid=session.process.pid
        assert not guarded_world_reexport(solid(),solid(11),.01)
        assert session.process.pid==pid and session.starts==1
        assert guarded_world_reexport(solid(),solid(),.01)
        assert session.starts==2
        process=session.process
    assert process.poll() is not None and current() is None

def test_failed_session_is_not_a_negative_match(tmp_path):
    from dsac29.native_session import WorldSession
    request=tmp_path/'invalid.json';request.write_text('{}')
    session=WorldSession()
    try:
        with pytest.raises(NativeGeometryFailure):
            session.execute(request,tmp_path/'result.json',5)
        assert session.process is None
    finally:session.close()

def test_session_timeout_reaps_child(tmp_path):
    from dsac29.native_session import WorldSession
    import subprocess
    session=WorldSession()
    session.directory=__import__('tempfile').TemporaryDirectory()
    session.process=subprocess.Popen([sys.executable,'-c','import time;time.sleep(20)'])
    process=session.process
    with pytest.raises(NativeGeometryFailure,match='Timeout'):
        session.execute(tmp_path/'request',tmp_path/'reply',.1)
    assert process.poll() is not None and session.directory is None

def test_world_failure_aborts_compare(monkeypatch):
    module=importlib.import_module('dsac29.compare')
    def failed(*args,**kwargs):raise NativeGeometryFailure('test timeout')
    monkeypatch.setattr(importlib.import_module('dsac29.step_reexport_tolerance'),'reexport_equivalent_world',failed)
    with pytest.raises(NativeGeometryFailure,match='test timeout'):
        module.compare([solid()],[solid()],.01,step_reexport_tolerance=True)

def test_large_fallback_uses_isolated_verifier(monkeypatch):
    from dsac29 import deferred_alignment as align
    from dsac29.alignment import _relocate
    import numpy as np
    base=solid()
    a=[_relocate(base,np.eye(3),np.array([i*30.,i*i*.2,0])) for i in range(600)]
    b=[_relocate(p,np.eye(3),np.array([100.,-200.,300.])) for p in a]
    def forbidden(*args,**kwargs):raise AssertionError('Unisolated validation')
    monkeypatch.setattr(importlib.import_module('dsac29.step_reexport_tolerance'),'shape_valid',forbidden)
    calls=[]
    def verified(left,right,tolerance,**kwargs):
        calls.append(1)
        assert kwargs['verify_all'] and len(left)==600
        assert np.allclose(left[0].center,right[0].center)
        return {'count':600,'pairs':[(i,i) for i in range(600)]}
    monkeypatch.setattr(align,'frame_support',verified)
    result=align._step_reexport_fallback(a,b,0,.01)
    assert result['status']=='registered' and len(result['certified_pairs'])==600 and calls

@pytest.mark.parametrize('tol',[.001,.01,.1])
def test_spatial_edges_preserve_all_exact_candidates(tol):
    from dsac29.parametric_identity import edge_options,edge_equal
    import numpy as np
    rng=np.random.default_rng(7)
    edges=[]
    for i in range(35):
        p=rng.normal(size=3)*tol*2;q=p+np.array([tol,0,0])
        edges.extend([('point',p),('line',p,q),
            ('circle',p,q,p,1.,np.array([0.,0,1.]),2*np.pi),
            ('bezier',[(np.array([p,q]),np.ones(2))])])
    right=list(reversed(edges))
    right.extend([('point',np.array([tol,0,0])),('point',np.zeros(3))])
    left=edges+[('point',np.zeros(3))]
    expected=[[j for j,b in enumerate(right) if edge_equal(a,b,tol)] for a in left]
    assert edge_options(left,right,tol)==expected

def test_long_wire_uses_linear_number_of_exact_checks(monkeypatch):
    import numpy as np
    from dsac29 import parametric_identity as module
    edges=[('line',np.array([float(i),0,0]),np.array([float(i)+.2,0,0])) for i in range(2000)]
    calls=[];original=module.edge_equal
    def counted(*args):calls.append(1);return original(*args)
    monkeypatch.setattr(module,'edge_equal',counted)
    assert module.perfect(module.edge_options(edges,list(reversed(edges)),.01))
    assert len(calls)==2000  # exhaustive search would perform 4,000,000 checks

def test_iterative_matching_handles_long_augmenting_path():
    from dsac29.parametric_identity import perfect
    # Force a path longer than Python's ordinary recursion limit.
    n=2000
    options=[[i,i+1] for i in range(n)]+[[0,1]]
    assert perfect(options)
    assert not perfect([[0],[0]])
