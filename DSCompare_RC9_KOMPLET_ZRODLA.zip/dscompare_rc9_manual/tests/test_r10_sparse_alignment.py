from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.TopLoc import TopLoc_Location
from OCP.gp import gp_Trsf,gp_Vec
from dsac29.geometry import describe
from dsac29.alignment import align_assembly,AlignmentUnavailable
from dsac29.registration_gate import frame_support
import numpy as np

def make(shape,p,ident):
 t=gp_Trsf();t.SetTranslation(gp_Vec(*map(float,p)))
 return describe(shape.Located(TopLoc_Location(t)),f'Model{ident}',f'Model{ident}')

def test_changed_assembly_30_of_80_global_translation():
 rng=np.random.default_rng(821)
 stable=[BRepPrimAPI_MakeBox(4+q,7+q,12+q).Shape() for q in range(3)]
 altered=BRepPrimAPI_MakeBox(9,15,27).Shape()
 pos=rng.integers(100,8000,size=(80,3))
 a=[make(stable[i%3] if i<30 else altered,pos[i],i) for i in range(80)]
 b=[make(stable[i%3] if i<30 else BRepPrimAPI_MakeBox(9,16,27).Shape(),
         pos[i]+np.array([1100.,-2000.,300.]),i) for i in range(80)]
 aligned,info=align_assembly(a,b,.01)
 assert info['status']=='registered',info
 assert info['method']=='partial_world_brep_consensus',info
 assert np.allclose(info['translation_B_to_A_mm'],[-1100.,2000.,-300.]),info
 evidence=frame_support(a,aligned,.01,proofs=12)
 assert evidence['count']>=30 and evidence['proofs']==12,evidence

def test_no_common_components_fails_safely():
 a=[make(BRepPrimAPI_MakeBox(4,5,6).Shape(),(i*43,i%7*49,0),i) for i in range(50)]
 b=[make(BRepPrimAPI_MakeBox(13,17,19).Shape(),(i*43+1000,i%7*49,0),i) for i in range(50)]
 try:align_assembly(a,b,.01)
 except AlignmentUnavailable:return
 raise AssertionError('Must not guess a transform with no shared geometry')
