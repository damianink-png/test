import json
from pathlib import Path
from dataclasses import replace,FrozenInstanceError
from types import SimpleNamespace
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from dsac29.geometry import describe
from dsac29 import material_deltas as md,material_guard as guard

def parts():return [describe(BRepPrimAPI_MakeBox(n,10,10).Shape(),'plate','root') for n in (20,25)]

def test_complete_cache_pipeline(monkeypatch):
 from dsac29.revision_overlap import merge_material_revisions
 from dsac29.compare import Record
 a,b=parts();records,cache,stats=merge_material_revisions([a],[b],[Record(0,None,'REMOVED',''),Record(None,0,'ADDED','')])
 assert stats['accepted']==1 and isinstance(cache[0],md.RegionEvidence)
 def forbidden(*a,**k):raise AssertionError('Duplicate material work')
 monkeypatch.setattr(guard,'calculate_isolated',forbidden)
 out,errors=md.all_changes(records,[a],[b],precomputed=cache)
 assert not errors and out[0].added_mm3==pytest.approx(500)

def test_native_reuse_and_diagnostics(tmp_path,monkeypatch):
 from dsac29 import trace_r22 as trace
 monkeypatch.setenv('DSCOMPARE_TRACE_BREP','1')
 a,b=parts();common=md.operate(BRepAlgoAPI_Common,a.shape,b.shape,.01)
 trace.setup(tmp_path)
 result=guard.calculate_isolated(a,b,common_shape=md.bind_common(common,a.shape,b.shape,.01))
 assert result.common_mm3==pytest.approx(2000)
 rows=[json.loads(line) for line in (tmp_path/'_ETAPY_DIAGNOSTYKA.jsonl').read_text().splitlines()]
 row=next(x for x in rows if x['stage']=='material_regions_isolated' and x['event']=='END')
 assert [x['stage'] for x in row['native_operations'] if x['event']=='PAIR_END']==['occt_pave_filler','occt_BRepAlgoAPI_Cut','occt_BRepAlgoAPI_Cut']

def test_transport_tamper_rejected(monkeypatch):
 a,b=parts();common=md.operate(BRepAlgoAPI_Common,a.shape,b.shape,.01)
 def inline(argv,**kw):
  req=json.loads(Path(argv[-2]).read_text());req['common_evidence']['hashes']['a']='wrong'
  guard.worker(req,argv[-1])
 monkeypatch.setattr(guard.subprocess,'run',inline)
 with pytest.raises(guard.NativeGeometryFailure,match='provenance mismatch'):
  guard.calculate_isolated(a,b,common_shape=md.bind_common(common,a.shape,b.shape,.01))

def test_volume_scalars_do_not_hide_wrong_regions():
 a,b=parts();regions=md.calculate(a,b)
 with pytest.raises(FrozenInstanceError):regions.added_mm3=0
 with pytest.raises(ValueError):md.bind_regions(replace(regions,added=BRepPrimAPI_MakeBox(100,100,100).Shape()),a,b,.01)

def test_unexpected_material_error_is_incomplete(monkeypatch):
 from dsac29.compare import Record
 a,b=parts()
 def failure(*args,**kwargs):raise RuntimeError('serialization failed')
 monkeypatch.setattr(guard,'calculate_isolated',failure)
 with pytest.raises(guard.NativeGeometryFailure,match='serialization failed'):
  md.all_changes([Record(0,0,'CHANGED','')],[a],[b])

@pytest.mark.parametrize('value',[float('nan'),float('inf'),-1])
def test_invalid_source_volume(value):
 a,b=parts()
 with pytest.raises(ValueError):md.calculate(SimpleNamespace(shape=a.shape,volume=value),b)

def test_seventh_candidate_not_hidden(monkeypatch):
 from dsac29 import revision_overlap as ro,native_guard as ng
 from dsac29.compare import Record
 a,b=parts();calls=[];common=md.operate(BRepAlgoAPI_Common,a.shape,b.shape,.01)
 def common_call(*args,**kw):calls.append(1);return common
 monkeypatch.setattr(ng,'guarded_common',common_call)
 records=[Record(0,None,'REMOVED','')]+[Record(None,i,'ADDED','') for i in range(7)]
 out,regions,stats=ro.merge_material_revisions([a],[b]*7,records)
 assert len(calls)==7 and stats['accepted']==0 and len(out)==8

def test_boolean_configured_before_single_build(tmp_path,monkeypatch):
 import OCP.BRepAlgoAPI as api
 from OCP.BRepTools import BRepTools
 from dsac29.safe_boolean_worker import _worker
 a,b=parts();events=[];original=api.BRepAlgoAPI_Common
 class Observed:
  def __init__(self,*args):assert not args;self.op=original()
  def __getattr__(self,name):
   def call(*args):events.append(name);return getattr(self.op,name)(*args)
   return call
 monkeypatch.setattr(api,'BRepAlgoAPI_Common',Observed)
 for name,part in [('a',a),('b',b)]:BRepTools.Write_s(part.shape,str(tmp_path/(name+'.brep')))
 _worker(str(tmp_path/'a.brep'),str(tmp_path/'b.brep'),str(tmp_path/'out.brep'),'common')
 assert events.count('Build')==1 and events.index('SetNonDestructive')<events.index('Build')

@pytest.mark.parametrize('value',[float('nan'),float('inf'),-1.])
def test_common_invalid_reply_volume(monkeypatch,value):
 from dsac29 import native_guard as ng
 from OCP.BRepTools import BRepTools
 a,b=parts()
 def fake(argv,**kw):
  req=json.loads(Path(argv[-2]).read_text())
  with open(req['common_shape'],'wb') as f:BRepTools.Write_s(a.shape,f)
  Path(argv[-1]).write_text(json.dumps(dict(ok=True,common_volume=value)))
  return SimpleNamespace(returncode=0,stderr=b'')
 monkeypatch.setattr(ng.subprocess,'run',fake)
 with pytest.raises(ng.NativeGeometryFailure):ng.guarded_common(a.shape,b.shape,.01)

def test_repair_tolerance_growth_rejected_on_copy(monkeypatch):
 from dsac29 import brep_safety as safety
 from OCP.BRep import BRep_Builder
 from OCP.TopAbs import TopAbs_EDGE
 from OCP.TopExp import TopExp_Explorer
 from OCP.TopoDS import TopoDS
 a,_=parts();before=safety.topology_tolerances(a.shape)
 monkeypatch.setattr(safety,'is_valid',lambda shape:not shape.IsSame(a.shape))
 def inflated(shape,tol):
  edge=TopoDS.Edge_s(TopExp_Explorer(shape,TopAbs_EDGE).Current())
  BRep_Builder().UpdateEdge(edge,.001);return shape
 monkeypatch.setattr(safety,'_shape_fix',inflated)
 monkeypatch.setattr(safety,'_wire_fix',inflated)
 def forbidden(*args):raise AssertionError('Tolerance guard bypassed')
 monkeypatch.setattr(safety,'_strict_original_boundary_proof',forbidden)
 with pytest.raises(safety.UnprovenRepair,match='increases stored edge'):
  safety.validated_copy(a.shape,.01)
 assert safety.topology_tolerances(a.shape)==before
