"""R11.4: Common failures must not corrupt BOM and can use exact dual Cut."""
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.gp import gp_Pnt
from dsac29 import geometry
from dsac29.geometry import describe
from dsac29.report import geometry_groups
from dsac29.geometry_registry import GeometryRegistry


def box(x=0):
    return BRepPrimAPI_MakeBox(gp_Pnt(float(x), 0, 0), 12, 8, 5).Shape()


def test_common_failure_recovers_identical_solids_via_both_exact_cuts(monkeypatch):
    a, b = box(), box()
    def common_unavailable(*args):
        raise RuntimeError('Open CASCADE: Common failed')
    monkeypatch.setattr(geometry, '_common_volume', common_unavailable)
    calls = []
    real_cut = geometry._cut_volume
    def cut_logged(*args):
        calls.append(1)
        return real_cut(*args)
    monkeypatch.setattr(geometry, '_cut_volume', cut_logged)
    assert geometry._is_common_equal(a, b, 480, 480, .01)
    assert len(calls) == 2


def test_common_failure_must_not_match_different_solids(monkeypatch):
    monkeypatch.setattr(geometry, '_common_volume', lambda *args: (_ for _ in ()).throw(RuntimeError('Common failed')))
    assert not geometry._is_common_equal(box(), box(2), 480, 480, .01)


def test_two_failed_boolean_methods_remain_explicitly_unresolved(monkeypatch):
    monkeypatch.setattr(geometry, '_common_volume', lambda *args: (_ for _ in ()).throw(RuntimeError('Common failed')))
    monkeypatch.setattr(geometry, '_cut_volume', lambda *args: (_ for _ in ()).throw(RuntimeError('Cut failed')))
    with pytest.raises(RuntimeError, match='independent Cut fallback also failed'):
        geometry._is_common_equal(box(), box(), 480, 480, .01)


def test_no_unsafe_grouping_on_second_cut_failure(monkeypatch):
    monkeypatch.setattr(geometry, '_common_volume', lambda *args: (_ for _ in ()).throw(RuntimeError('Common failed')))
    def cut_always_fail(*args):
        raise RuntimeError('Cut B-A failed')
    monkeypatch.setattr(geometry, '_cut_volume', cut_always_fail)
    parts = [describe(box(), 'part1', 'a'), describe(box(), 'part2', 'b')]
    context = GeometryRegistry()
    # These separately constructed boxes may be recognized as equal by their
    # serialized B-Rep and bypass Boolean verification entirely. Force it.
    monkeypatch.setattr(context, 'same_definition', lambda *args: False)
    import dsac29.surface_witness as sw
    monkeypatch.setattr(sw, 'independent_surface_identity', lambda *args: False)
    result = geometry_groups(parts, context=context)
    assert result == [[0], [1]]
    assert context.bom_errors and 'fallback' in context.bom_errors[0]['error']
