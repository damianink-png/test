"""Desktop actions and settings tested on real Qt widgets in offscreen mode."""
import os
from pathlib import Path
import pytest
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from PySide6.QtCore import QSettings,QTimer
from PySide6.QtGui import QColor
from PySide6.QtWidgets import QApplication,QColorDialog,QDialogButtonBox,QMessageBox,QPushButton
from dsac29.gui46 import Window

@pytest.fixture
def win(tmp_path,monkeypatch):
    app=QApplication.instance() or QApplication([])
    import dsac29.gui45 as base
    monkeypatch.setattr(base,'QSettings',lambda *a:QSettings(str(tmp_path/'settings.ini'),QSettings.IniFormat))
    w=Window();w.resize(1240,850);w.show();app.processEvents()
    yield w
    w.process=None;w._settings_revert();w.close();app.processEvents()

def test_all_export_settings_save_and_revert(win):
    w=win;old=w._settings_snapshot();stored=w.store.value('preview_html')
    w.preview_html.setChecked(not old['preview_html']);w.opacity.setValue(25)
    assert w._settings_dirty() and w.store.value('preview_html')==stored
    w._settings_cancel_button.click();assert w._settings_snapshot()==old
    w.preview_html.setChecked(not old['preview_html']);w.opacity.setValue(25)
    w._settings_save_button.click()
    assert not w._settings_dirty()
    assert str(w.store.value('preview_html')).lower()==str(not old['preview_html']).lower()
    assert int(w.store.value('transparency'))==25
    w._settings_revert();assert w.opacity.value()==25

def test_color_dialog_is_transactional(win,monkeypatch):
    w=win;old=w.export_colors['SAME'];stored=w.store.value('export_color_SAME')
    monkeypatch.setattr(QColorDialog,'getColor',lambda *a,**k:QColor('#123456'))
    def edit():
        dlg=QApplication.activeModalWidget()
        next(b for b in dlg.findChildren(QPushButton) if b.accessibleName().startswith('Zmień:')).click()
        dlg.findChild(QDialogButtonBox).button(QDialogButtonBox.Ok).click()
    QTimer.singleShot(0,edit);w.color_editor.click()
    assert w.export_colors['SAME']=='#123456' and w._settings_dirty()
    assert w.store.value('export_color_SAME')==stored
    w._settings_cancel_button.click();assert w.export_colors['SAME']==old
    QTimer.singleShot(0,edit);w.color_editor.click();w._settings_save_button.click()
    assert w.store.value('export_color_SAME')=='#123456'

def test_numeric_controls_are_readable_and_bom_controls_follow_switch(win):
    w=win;w.navigate('settings');QApplication.processEvents()
    for spin in (w.tolerance,w.solid_limit,w.opacity):
        assert spin.lineEdit().isVisible() and spin.lineEdit().width()>50
        assert spin.lineEdit().text()
    w.full_bom.setChecked(False)
    assert not w.bom_mode.isEnabled() and not w.bom_csv.isEnabled()
    w.full_bom.setChecked(True)
    assert w.bom_mode.isEnabled() and w.bom_csv.isEnabled()

def test_explicit_numeric_buttons_limits_typing_and_disabled_state(win):
    from dsac29.gui_modern import NumberControl
    from PySide6.QtWidgets import QAbstractSpinBox
    w=win;w.navigate('settings');QApplication.processEvents()
    for spin in (w.tolerance,w.solid_limit,w.opacity,w.density):
        control=spin.parentWidget()
        assert isinstance(control,NumberControl)
        assert spin.buttonSymbols()==QAbstractSpinBox.NoButtons
        spin.setValue(spin.minimum());assert not control.minus.isEnabled()
        control.plus.click();assert spin.value()>spin.minimum()
        spin.setValue(spin.maximum());assert not control.plus.isEnabled()
        control.minus.click();assert spin.value()<spin.maximum()
        spin.setDisabled(True)
        assert not control.minus.isEnabled() and not control.plus.isEnabled()
        spin.setEnabled(True)
    w.opacity.lineEdit().setText('25 %');w.opacity.interpretText()
    assert w.opacity.value()==25

def test_navigation_stays_on_settings_when_save_fails(win,monkeypatch):
    w=win;w.navigate('settings');w.opacity.setValue(10)
    monkeypatch.setattr(w,'_save_settings_explicit',lambda:None)
    def choose_save():
        prompt=QApplication.activeModalWidget()
        next(b for b in prompt.buttons() if b.text()=='Zapisz').click()
    QTimer.singleShot(0,choose_save);w.navigate('compare')
    assert w.stack.currentWidget() is w.pages['settings'] and w._settings_dirty()

def test_model_swap_reset_theme_and_mass_queue(win,tmp_path):
    w=win
    a=tmp_path/'a.step';b=tmp_path/'b.stp';a.write_text('demo');b.write_text('demo')
    w.a.path.setText(str(a));w.b.path.setText(str(b));w.swap_button.click()
    assert w.a.path.text()==str(b) and w.b.path.text()==str(a)
    theme=w.theme.currentText();w.theme_button.click();assert w.theme.currentText()!=theme
    w.theme_button.click();assert w.theme.currentText()==theme
    w._mass_add([a,b,a]);assert len(w.mass_inputs)==2
    w.mass_input_list.item(0).setSelected(True);w.mass_remove_selected.click()
    assert len(w.mass_inputs)==1
    w.new_comparison();assert not w.a.path.text() and not w.b.path.text()
    assert len(w.mass_inputs)==1
    w.mass_reset.click();assert not w.mass_inputs

def test_busy_state_protects_inputs_but_keeps_navigation(win):
    w=win;w.task='compare';w.process=object();w._set_busy_ui(True)
    assert not w.run_compare.isEnabled() and not w.swap_button.isEnabled()
    assert not w.color_editor.isEnabled() and not w.mass_add_files.isEnabled()
    assert all(b.isEnabled() for b in w.nav.values()) and w.theme_button.isEnabled()
    w.process=None;w._set_busy_ui(False)
    assert w.run_compare.isEnabled() and w.color_editor.isEnabled()

def test_lazy_details_and_changed_filter(win,tmp_path):
    import csv,json
    w=win
    with (tmp_path/'ZMIANY.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f,delimiter=';');writer.writerow(['Status','Nazwy','A','B','Ścieżka'])
        writer.writerow(['Bez zmian','','Rama','Rama','złożenie/stałe'])
        writer.writerow(['Zmieniona geometria','','Płyta A','Płyta B','złożenie/nowa'])
    (tmp_path/'PODSUMOWANIE.json').write_text(json.dumps({'records':[{'status':'SAME'},{'status':'CHANGED'}]}))
    w.results['compare']=tmp_path;w._set_compare_result_state(True)
    assert w.compare_table.rowCount()==0
    assert w._details_toggle.isVisible()
    w._details_toggle.click();assert w.compare_table.rowCount()==2 and w._details.isVisible()
    w.filter_selector.setCurrentIndex(w.filter_selector.findData('CHANGED'))
    assert w.compare_table.isRowHidden(0) and not w.compare_table.isRowHidden(1)
    w.select_filter('ALL');w.search.setText('nowa')
    assert w.compare_table.isRowHidden(0) and not w.compare_table.isRowHidden(1)
    w._refresh_outputs();assert w.compare_open['ZMIANY.csv'].isEnabled()
    assert not w.compare_open['BOM_A.csv'].isEnabled()

def test_cancel_button_ends_worker_with_cancel_message(win,tmp_path):
    import sys,time
    from PySide6.QtCore import QProcess
    w=win;w.task='compare';w.was_cancelled=False;w.current_folder=tmp_path
    w.active_progress=w.progress;w.active_log=w.log;w.worker_output=''
    w.process=QProcess(w);w.process.finished.connect(w.finished)
    w.process.start(sys.executable,['-c','import time;time.sleep(20)'])
    assert w.process.waitForStarted(3000)
    w._set_busy_ui(True);w.cancel_compare.setEnabled(True);w.cancel_compare.click()
    deadline=time.monotonic()+5
    while w.process is not None and time.monotonic()<deadline:
        QApplication.processEvents();time.sleep(.01)
    assert w.process is None and w.was_cancelled
    assert 'anulowane' in w.compare_summary.text().lower()
    assert w.run_compare.isEnabled()

def test_material_selector_and_cache_clear_do_not_touch_sources(win,tmp_path,monkeypatch):
    from PySide6.QtWidgets import QInputDialog
    from dsac29 import import_cache
    w=win
    w.materials.setCurrentIndex(w.materials.findData(2700))
    assert w.density.value()==2700
    monkeypatch.setattr(QInputDialog,'getText',lambda *a:('Testowy materiał',True))
    monkeypatch.setattr(QInputDialog,'getDouble',lambda *a:(1234.5,True))
    w.add_material();assert w.density.value()==1234.5
    assert w.custom_materials['Testowy materiał']==1234.5
    cache=tmp_path/'cache';cache.mkdir();(cache/'buffer.brep').write_text('temporary')
    source=tmp_path/'source.step';source.write_text('source')
    monkeypatch.setattr(import_cache,'root_dir',lambda:cache)
    monkeypatch.setattr(QMessageBox,'question',lambda *a:QMessageBox.Yes)
    monkeypatch.setattr(QMessageBox,'information',lambda *a:QMessageBox.Ok)
    w.clear_import_cache_button.click()
    assert not cache.exists() and source.read_text()=='source'
