from collections import Counter
import numpy as np
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.gp import gp_Trsf,gp_Vec
from OCP.TopLoc import TopLoc_Location
from dsac29.geometry import describe
from dsac29.alignment import align_assembly,AlignmentUnavailable
from dsac29.compare import compare
from dsac29.revision_rules import classify_revisions

def part(i,shift=(0,0,0),repeated=False,moved=0,linear=False):
    shape=BRepPrimAPI_MakeBox(17 if repeated else 17+i*3,11,9).Shape()
    t=gp_Trsf();t.SetTranslation(gp_Vec(i*40+shift[0],(0 if linear else i*i*3)+shift[1]+moved,shift[2]))
    return describe(shape.Located(TopLoc_Location(t)),'P' if repeated else f'P{i}',f'P{i}')

@pytest.mark.parametrize('repeated',[False,True])
@pytest.mark.parametrize('changes',[False,True])
def test_whole_translation_keeps_only_actual_changes(repeated,changes):
    a=[part(i,repeated=repeated) for i in range(8)]
    b=[part(i,(400,-250,80),repeated,moved=23 if changes and i==6 else 0) for i in range(8)]
    if changes:a.append(part(12));b.append(part(13,(400,-250,80)))
    shifted,info=align_assembly(a,b,.01)
    assert np.allclose(info['translation_B_to_A_mm'],[-400,250,-80])
    rows=classify_revisions(a,shifted,compare(a,shifted,revision_only=True,exact_serialization=True),.01)
    expected={'SAME':7,'MOVED':1,'REMOVED':1,'ADDED':1} if changes else {'SAME':8}
    assert Counter(r.status for r in rows)==expected

def test_periodic_pitch_through_auto_alignment_pipeline(tmp_path):
    from dsac29 import cli
    from dsac29.step_io import ColoredDocument
    import json
    def write(path,offset):
        doc=ColoredDocument(flat_zw3d=True)
        for i in range(30):
            p=part(i,(offset,0,0),True,linear=True);doc.add(p.shape,'PART',(.2,.6,.3))
        doc.write(path)
    a=tmp_path/'a.step';b=tmp_path/'b.step';write(a,0);write(b,40)
    approvals=[]
    def approve(info):approvals.append(info);return 'align'
    output=tmp_path/'out';output.mkdir()
    cli.process(a,b,output,auto_align=True,alignment_approval=approve,revision_style=True,
                step=False,full_bom=False,progress=None)
    summary=json.loads((output/'PODSUMOWANIE.json').read_text())
    assert len(approvals)==1
    assert np.allclose(approvals[0]['translation_B_to_A_mm'],[-40,0,0])
    assert summary['statuses'].get('SAME')==30
    assert sum(v for k,v in summary['statuses'].items() if k!='SAME')==0

def test_ambiguous_periodic_endpoint_is_not_guessed():
    def row(n,shift):return [part(i,(shift,0,0),True,linear=True) for i in range(n)]
    with pytest.raises(AlignmentUnavailable):align_assembly(row(30,0),row(29,100),.01)

def load_reference(name):
    import importlib.util,sys
    from pathlib import Path
    path=Path(__file__).resolve().parents[1]/'benchmarks/reference_10'/f'{name}.py'
    spec=importlib.util.spec_from_file_location('dsac29._reference_'+name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    return module

def test_assignment_exactly_matches_previous_implementation():
    from dsac29.assignment import assign
    old=load_reference('assignment').assign;rng=np.random.default_rng(618)
    for n,m in ((1,1),(4,8),(8,4),(20,20),(65,65)):
        edges={(i,j):float(rng.random()) for i in range(n) for j in range(m) if rng.random()<.35}
        assert assign(edges)==old(edges)

def test_optimized_matching_preserves_pairs_and_transforms():
    old=load_reference('compare').compare
    from OCP.gp import gp_Ax1,gp_Pnt,gp_Dir
    from dataclasses import asdict
    rng=np.random.default_rng(27)
    for run in range(6):
        base=BRepPrimAPI_MakeBox(17,11,9).Shape()
        a=[];b=[]
        for i in range(7):
            tr=gp_Trsf();tr.SetTranslation(gp_Vec(i*50,i*i*3,0))
            a.append(describe(base.Located(TopLoc_Location(tr)),f'P{i}',f'P{i}'))
            r=gp_Trsf();r.SetRotation(gp_Ax1(gp_Pnt(0,0,0),gp_Dir(0,0,1)),float(rng.choice([0,.2,.7])))
            r.SetTranslationPart(gp_Vec(i*50+run*100,i*i*3+30,12))
            b.append(describe(base.Located(TopLoc_Location(r)),f'P{i}',f'P{i}'))
        before=old(a,b,revision_only=True,exact_serialization=True)
        after=compare(a,b,revision_only=True,exact_serialization=True)
        assert [(x.a_index,x.b_index,x.status,x.confidence) for x in before]==[(x.a_index,x.b_index,x.status,x.confidence) for x in after]
        for x,y in zip(before,after):
            for key in ('distance_mm','delta_x','delta_y','delta_z','rotation_deg'):
                assert getattr(x,key)==pytest.approx(getattr(y,key),abs=1e-6)

def test_declining_whole_shift_does_not_publish_results(tmp_path,monkeypatch):
    from dsac29 import cli
    a=[part(i) for i in range(4)];b=[part(i,(200,40,0)) for i in range(4)]
    pa=tmp_path/'a.step';pb=tmp_path/'b.step';pa.write_text('a');pb.write_text('b')
    monkeypatch.setattr(cli,'load_step',lambda path,**kw:a if path==pa else b)
    out=tmp_path/'out';out.mkdir()
    with pytest.raises(InterruptedError):
        cli.process(pa,pb,out,auto_align=True,alignment_approval=lambda _:'cancel',revision_style=True,step=False,full_bom=False,progress=None)
    assert not (out/'PODSUMOWANIE.json').exists()

def test_mass_uses_persistent_import_cache(tmp_path,monkeypatch):
    from dsac29.single_mass import analyze_single
    from dsac29.step_io import ColoredDocument
    from dsac29 import step_io
    monkeypatch.setenv('DSCOMPARE_IMPORT_CACHE','on');monkeypatch.setenv('DSCOMPARE_CACHE_DIR',str(tmp_path/'cache'))
    path=tmp_path/'part.step';doc=ColoredDocument(flat_zw3d=True);p=part(1);doc.add(p.shape,'P',(.1,.2,.3));doc.write(path)
    _,first=analyze_single(path,tmp_path/'first',preview=False)
    monkeypatch.setattr(step_io,'load_step',lambda *a,**k:pytest.fail('Cache hit must skip STEP parsing'))
    _,second=analyze_single(path,tmp_path/'second',preview=False)
    assert first['masa_calosci_kg']==second['masa_calosci_kg']
    assert second['import_diagnostics']['persistent_cache']=='HIT'

def test_modern_mass_keeps_warnings_without_building_hidden_rows(tmp_path,monkeypatch):
    import json
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import QSettings
    from dsac29.gui46 import Window
    store=QSettings(str(tmp_path/'settings.ini'),QSettings.IniFormat)
    monkeypatch.setattr('dsac29.gui45.QSettings',lambda *a:store)
    app=QApplication.instance() or QApplication([]);w=Window()
    s=dict(plik='model.step',liczba_bryl=20000,liczba_pozycji=20000,masa_calosci_kg=12,gestosc_kg_m3=7850,import_diagnostics={'faces_outside_solids':3})
    (tmp_path/'PODSUMOWANIE_MASY.json').write_text(json.dumps(s))
    try:
        w.load_result('mass',tmp_path)
        assert w.mass_table.rowCount()==0
        assert 'pominięto 3' in w.mass_summary.text()
    finally:w.close()

def test_assembly_rotation_and_translation_preserve_local_movement():
    from dsac29.geometry import transform
    angle=.37
    R=np.array([[np.cos(angle),-np.sin(angle),0],[np.sin(angle),np.cos(angle),0],[0,0,1]])
    t=np.array([250.,-170.,80.])
    a=[part(i) for i in range(8)]
    b=[]
    for i in range(8):
        p=part(i,moved=23 if i==6 else 0)
        b.append(describe(transform(p.shape,R,t),p.name,p.path))
    aligned,info=align_assembly(a,b,.01)
    records=classify_revisions(a,aligned,compare(a,aligned,revision_only=True,exact_serialization=True),.01)
    assert Counter(r.status for r in records)=={'SAME':7,'MOVED':1}
    assert np.allclose(info['rotation_B_to_A'],R.T)
    assert np.allclose(info['translation_B_to_A_mm'],-R.T@t)

def test_translation_preserves_1000_occurrences_and_native_geometry():
    from dsac29.alignment import _relocate
    from dsac29.geometry import equivalent_world
    source=part(3)
    delta=np.array([420.,-330.,170.])
    originals=[_relocate(source,np.eye(3),np.array([i*40.,0,0])) for i in range(1000)]
    shifted=[_relocate(p,np.eye(3),delta) for p in originals]
    assert len(shifted)==len(originals)==1000
    for before,after in zip(originals,shifted):
        assert before.shape.IsPartner(after.shape)
        assert np.allclose(after.center-before.center,delta)
        assert after.path==before.path and after.volume==before.volume
    for i in (0,499,999):
        actual=describe(shifted[i].shape,'check','check')
        assert np.allclose(actual.center,shifted[i].center)
        assert equivalent_world(originals[i],_relocate(shifted[i],np.eye(3),-delta),.01)
