"""GUI clipping/overlap regressions reproducing user screenshots."""
from PySide6.QtWidgets import QApplication,QPushButton
from PySide6.QtCore import Qt,QPoint,QRect
from dsac29.gui46 import Window


def test_results_card_no_overlapping_text_and_buttons(monkeypatch):
    monkeypatch.setenv('QT_QPA_PLATFORM','offscreen')
    app=QApplication.instance() or QApplication([])
    win=Window();win.resize(1120,735);win.show();app.processEvents()
    try:
        assert win.legend.isHidden(), 'long legend must be displayed only on demand'
        assert win.visibility_hint.isHidden(), 'long ZW3D explanation must be in help dialog'
        assert win.grouping_hint.isHidden()
        assert not hasattr(win,'legend_button')
        assert win.compare_open['POROWNANIE_KOLORY.step'].isVisible()
        # No visible widget can be placed on top of another in export result card.
        widgets=[item for item in (win.export_name,*win.compare_open.values()) if item.isVisible()]
        rectangles=[]
        for obj in widgets:
            pt=obj.mapTo(win.export_box,QPoint(0,0));r=QRect(pt,obj.size())
            assert win.export_box.rect().contains(r), (obj.objectName(),r)
            for other in rectangles:
                assert not r.intersects(other),(obj.text() if isinstance(obj,QPushButton) else obj.objectName(),r,other)
            rectangles.append(r)
        assert win.theme_button.icon().isNull() is False
        assert win.run_compare.icon().isNull() is False
        assert all(not b.icon().isNull() for b in win.compare_open.values())
    finally:win.close()


def test_dropdowns_style_and_solid_limit_settings(monkeypatch):
    monkeypatch.setenv('QT_QPA_PLATFORM','offscreen')
    app=QApplication.instance() or QApplication([])
    win=Window();win.show();app.processEvents()
    try:
        for combo in (win.old_color,win.schema,win.verify_mode,win.materials,win.filter_selector):
            assert combo.count()>0
            assert combo.height()>20
        assert win.solid_limit.maximum()==50000
        assert win.solid_limit.value()>1000
        win.navigate('settings');app.processEvents()
        assert win.safe_export.isVisible() and win.full_bom.isVisible()
        assert not hasattr(win,'param_frame')
    finally:win.close()
