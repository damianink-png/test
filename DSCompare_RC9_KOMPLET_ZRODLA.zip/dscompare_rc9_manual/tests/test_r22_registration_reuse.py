import numpy as np
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from dsac29.geometry import describe
from dsac29.alignment import _relocate
from dsac29.registration_gate import frame_support
from dsac29.compare import compare

def parts():return [describe(BRepPrimAPI_MakeBox(10+i,20,30).Shape(),str(i),str(i)) for i in range(4)]
def test_parametric_proof_precedes_boolean(monkeypatch):
 import dsac29.registration_gate as gate
 def forbidden(*args):raise AssertionError('Unnecessary Common')
 monkeypatch.setattr(gate,'equivalent_world',forbidden)
 s=frame_support(parts(),parts(),.01,verify_all=True)
 assert s['count']==4 and len(set(map(tuple,s['pairs'])))==4

def test_partial_reuse_keeps_real_changes():
 a=parts();b=parts();b[3]=describe(BRepPrimAPI_MakeBox(100,20,30).Shape(),'new','new')
 result=compare(a,b,.01,certified_pairs=[(0,0),(1,1),(2,2)],revision_only=True)
 assert sum(r.status=='SAME' for r in result)==3
 assert any(r.status=='ADDED' for r in result) and any(r.status=='REMOVED' for r in result)

@pytest.mark.parametrize('pairs',[[(0,0),(0,1)],[(0,0),(1,0)],[(5,0)]])
def test_invalid_map_rejected(pairs):
 with pytest.raises(ValueError):compare(parts(),parts(),.01,certified_pairs=pairs)

def test_wrong_frame_rejected():
 b=[_relocate(p,np.eye(3),np.array([50.,0,0])) for p in parts()]
 with pytest.raises(ValueError):compare(parts(),b,.01,certified_pairs=[(0,0)])

def test_changed_shape_not_certified():
 a=parts();b=parts();b[0]=describe(BRepPrimAPI_MakeBox(9,20,30).Shape(),'changed','changed')
 s=frame_support(a,b,.01,verify_all=True)
 assert s['count']==3 and (0,0) not in s['pairs']

def test_reversed_valid_solid_is_oriented_without_changing_shape():
 from dsac29.import_validation import orient_positive_solid
 s=BRepPrimAPI_MakeBox(10,20,30).Shape();fixed=orient_positive_solid(s.Reversed(),'part')
 assert fixed.IsSame(s) and fixed.Orientation()==s.Orientation()
 assert describe(fixed,'part','part').volume==pytest.approx(6000)

def test_invalid_negative_solid_is_not_silently_repaired():
 from dsac29.import_validation import orient_positive_solid,InvalidStepSolid
 from OCP.BRep import BRep_Builder
 from OCP.TopoDS import TopoDS_Shell,TopoDS_Solid
 from OCP.TopExp import TopExp_Explorer
 from OCP.TopAbs import TopAbs_FACE
 s=BRepPrimAPI_MakeBox(10,20,30).Shape();builder=BRep_Builder()
 shell=TopoDS_Shell();builder.MakeShell(shell);ex=TopExp_Explorer(s,TopAbs_FACE);ex.Next()
 while ex.More():builder.Add(shell,ex.Current());ex.Next()
 solid=TopoDS_Solid();builder.MakeSolid(solid);builder.Add(solid,shell)
 with pytest.raises(InvalidStepSolid,match='Napraw tę część'):orient_positive_solid(solid.Reversed(),'damaged')

@pytest.mark.parametrize('angle',[0.3,1.2,2.8])
def test_cached_rotated_properties_equal_direct_integration(angle):
 from dsac29.geometry import DescriptionCache
 from OCP.gp import gp_Trsf,gp_Ax1,gp_Pnt,gp_Dir,gp_Vec
 from OCP.TopLoc import TopLoc_Location
 s=BRepPrimAPI_MakeBox(11,23,37).Shape();cache=DescriptionCache();cache.describe(s,'base','base')
 tr=gp_Trsf();tr.SetRotation(gp_Ax1(gp_Pnt(0,0,0),gp_Dir(1,2,3)),angle);tr.SetTranslationPart(gp_Vec(400,-700,200))
 moved=s.Moved(TopLoc_Location(tr));actual=cache.describe(moved,'part','part');expected=describe(moved,'part','part')
 assert cache.hits==1
 for field in ['volume','area','center','inertia','eigenvalues','bbox']:
  assert np.allclose(getattr(actual,field),getattr(expected,field),rtol=1e-8,atol=1e-6),field
 assert actual.shape.IsSame(moved)

def test_partial_proofs_seed_rigid_definition_cache(monkeypatch):
 import importlib
 module=importlib.import_module('dsac29.compare')
 s=BRepPrimAPI_MakeBox(10,20,30).Shape();t=BRepPrimAPI_MakeBox(10,20,30).Shape()
 a0=describe(s,'p','p');b0=describe(t,'p','p')
 a=[a0,_relocate(a0,np.eye(3),np.array([100.,0,0]))]
 b=[b0,_relocate(b0,np.eye(3),np.array([200.,0,0]))]
 def forbidden(*args,**kwargs):raise AssertionError('Repeated rigorous proof')
 monkeypatch.setattr(module,'equivalent_rigid',forbidden)
 result=compare(a,b,.01,certified_pairs=[(0,0)])
 assert sorted(r.status for r in result)==['MOVED','SAME']

def test_rigid_transform_preserves_native_definition_and_world_position():
 from dsac29.geometry import transform
 s=BRepPrimAPI_MakeBox(10,20,30).Shape()
 rot=np.array([[0.,-1.,0.],[1.,0.,0.],[0.,0.,1.]])
 out=transform(s,rot,np.array([100.,200.,300.]))
 assert out.IsPartner(s) and not out.IsSame(s)
 assert np.allclose(describe(out,'p','p').center,[90.,205.,315.])
 assert np.allclose(describe(s,'p','p').center,[5.,10.,15.])
