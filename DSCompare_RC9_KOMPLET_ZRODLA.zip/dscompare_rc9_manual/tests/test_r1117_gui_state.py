"""R11.17 UI regressions; no imported/constructed benchmark CAD models."""
import pytest


def test_modern_ui_dedicated_action_state():
    pytest.importorskip('PySide6')
    from PySide6.QtWidgets import QApplication
    from dsac29.gui46 import Window as ModernWindow
    from dsac29.gui_modern import AboutWindow
    app=QApplication.instance() or QApplication([])
    w=ModernWindow()
    try:
        assert w.reset_button.text()=='Nowe porównanie'
        assert not w._actions.isVisible()
        w.a.path.setText('test_old.step')
        w.b.path.setText('test_new.step')
        w.new_comparison()
        assert not w.a.path.text() and not w.b.path.text()
        assert not w._actions.isVisible()
        for theme in ('Jasny','Ciemny','Jasny'):
            w.theme.setCurrentText(theme)
            about=AboutWindow(w)
            try:
                assert not any(b.text()=='×' for b in about.findChildren(__import__('PySide6').QtWidgets.QPushButton))
                assert about.logo.minimumHeight()>=250
            finally:about.close()
    finally:w.close()


def test_safe_step_layers_contract():
    from pathlib import Path
    source=(Path(__file__).resolve().parents[1]/'dsac29'/'step_io.py').read_text('utf8')
    assert 'self.layers.SetLayer(label,TCollection_ExtendedString(layer))' in source
    assert 'self.flat_zw3d' in source
