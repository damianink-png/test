import re
import numpy as np
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.TopLoc import TopLoc_Location
from OCP.gp import gp_Trsf,gp_Vec
from dsac29.step_reexport_tolerance import _verified_difference_empty,shape_valid
from dsac29.step_io import ColoredDocument,load_step
from dsac29.geometry import describe
from dsac29.deferred_alignment import _step_reexport_fallback

@pytest.mark.parametrize('reverse',[False,True])
def test_shared_intersections_reject_added_material(reverse):
 a=BRepPrimAPI_MakeBox(20,10,10).Shape();b=BRepPrimAPI_MakeBox(21,10,10).Shape()
 if reverse:a,b=b,a
 assert not _verified_difference_empty(a,b,.001)

def test_intersections_built_once(monkeypatch):
 import OCP.BOPAlgo as bop
 original=bop.BOPAlgo_PaveFiller;calls=[]
 def Tracked(*args):calls.append(1);return original(*args)
 monkeypatch.setattr(bop,'BOPAlgo_PaveFiller',Tracked)
 assert _verified_difference_empty(BRepPrimAPI_MakeBox(20,10,10).Shape(),BRepPrimAPI_MakeBox(20,10,10).Shape(),.001)
 assert calls==[1]

def test_shared_definitions_are_valid_step(tmp_path):
 s=BRepPrimAPI_MakeBox(20,10,10).Shape();doc=ColoredDocument()
 for i in range(3):
  tr=gp_Trsf();tr.SetTranslation(gp_Vec(i*50,0,0))
  doc.add(s.Moved(TopLoc_Location(tr)),'Part',(.2,.8,.2))
 assert doc.definitions_created==1 and doc.count==3
 p=tmp_path/'shared.step';doc.write(str(p));data=p.read_bytes()
 assert len(re.findall(rb'(?m)^#\d+\s*=\s*PRODUCT\(',data))==2
 assert len(re.findall(rb'NEXT_ASSEMBLY_USAGE_OCCURRENCE\(',data))==3
 assert len(load_step(str(p)))==3

def test_invalid_assembly_yields_explicit_unresolved_without_booleans(monkeypatch):
 from OCP.BRep import BRep_Builder
 from OCP.TopoDS import TopoDS_Shell,TopoDS_Solid
 from OCP.TopExp import TopExp_Explorer
 from OCP.TopAbs import TopAbs_FACE
 from dsac29 import step_reexport_tolerance as rt
 s=BRepPrimAPI_MakeBox(20,10,10).Shape();builder=BRep_Builder();shell=TopoDS_Shell();builder.MakeShell(shell)
 ex=TopExp_Explorer(s,TopAbs_FACE);ex.Next()
 while ex.More():builder.Add(shell,ex.Current());ex.Next()
 solid=TopoDS_Solid();builder.MakeSolid(solid);builder.Add(solid,shell)
 assert not shape_valid(solid)
 def parts(offset):
  out=[]
  for i in range(8):
   tr=gp_Trsf();tr.SetTranslation(gp_Vec(i*100+offset,i*i*50,0))
   out.append(describe(solid.Moved(TopLoc_Location(tr)),'P','P'))
  return out
 def forbidden(*args):raise AssertionError('Invalid solids reached expensive Boolean')
 monkeypatch.setattr(rt,'reexport_equivalent_world',forbidden)
 result=_step_reexport_fallback(parts(0),parts(1000),0,.01)
 assert result['status']=='unresolved' and result['invalid_pairs']==8
 assert result['candidate_pairs']==8

def test_bezier_bound_rejects_change_between_endpoints():
 from dsac29.parametric_identity import pole_bound
 p=np.array([[0.,0,0],[1,2,0],[2,0,0]]);q=p.copy();q[1,1]+=.1
 assert pole_bound((p,np.ones(3)),(q,np.ones(3)))>.01

def test_bezier_bound_accepts_proportional_rational_weights():
 from dsac29.parametric_identity import pole_bound
 p=np.array([[0.,0,0],[1,2,0],[2,0,0]]);w=np.array([1.,.5,1.])
 assert pole_bound((p,w),(p,w*7))<1e-8

def test_arc_complement_is_not_the_same_curve():
 from dsac29.parametric_identity import edge_equal
 a=('circle',np.array([1.,0,0]),np.array([0.,1,0]),np.zeros(3),1.,np.array([0.,0,1]),np.pi/2)
 b=(*a[:-1],3*np.pi/2)
 assert not edge_equal(a,b,.01)

def test_changed_curve_poles_do_not_hide_behind_same_endpoints():
 from dsac29.parametric_identity import edge_equal
 p=np.array([[0.,0,0],[1,2,0],[2,0,0]]);q=p.copy();q[1,2]=.2
 assert not edge_equal(('bezier',[(p,np.ones(3))]),('bezier',[(q,np.ones(3))]),.01)
