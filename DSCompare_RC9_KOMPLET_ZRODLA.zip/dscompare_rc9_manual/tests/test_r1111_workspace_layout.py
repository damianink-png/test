"""R11.11 UI layout: no large empty export card and no overlapping widgets."""
import pytest

@pytest.mark.parametrize('width,height,expected_columns',[(1366,850,6),(1120,735,6),(940,720,3)])
def test_compare_layout_reflow_no_overlap(monkeypatch,width,height,expected_columns):
    monkeypatch.setenv('QT_QPA_PLATFORM','offscreen')
    from PySide6.QtWidgets import QApplication,QScrollArea
    from PySide6.QtCore import QPoint
    from dsac29.gui46 import Window
    app=QApplication.instance() or QApplication([])
    w=Window();w.resize(width,height);w.show();app.processEvents()
    try:
        w.navigate('compare');app.processEvents()
        assert not w.centralWidget().findChildren(QScrollArea)
        assert w._metric_columns==expected_columns
        assert w.compare_table.isVisible()
        assert w.compare_table.width()>=w.export_box.width()-6, 'result table must occupy full width'
        assert w.export_box.height()<=66, 'file actions must be a compact toolbar'
        assert len([b for b in w.compare_open.values() if b.isVisible()])==3
        assert w.compare_open['RAPORT.html'].geometry().intersects(w.compare_open[''].geometry()) is False
        for obj in (w.a,w.b,w.run_compare,w.cancel_compare,w.compare_table,w.export_box,w.progress,w.report_progress,w.reset_button):
            assert obj.geometry().width()>0 and obj.geometry().height()>0, obj.objectName()
        # QWidget geometry is relative to its parent; map all main sections to the page.
        page=w.pages['compare']
        rects=[]
        for item in (w.a,w.b,w.compare_table,w.export_box):
            p=item.mapTo(page,QPoint(0,0))
            rects.append((item,p.x(),p.y(),item.width(),item.height()))
        for i,(obj,x,y,ww,hh) in enumerate(rects):
            assert x>=0 and y>=0 and x+ww<=page.width()+2 and y+hh<=page.height()+2, (obj,x,y,ww,hh,page.size())
            for other,xx,yy,ow,oh in rects[:i]:
                assert not (x<xx+ow and xx<x+ww and y<yy+oh and yy<y+hh),(obj,other)
    finally:
        w.close()
