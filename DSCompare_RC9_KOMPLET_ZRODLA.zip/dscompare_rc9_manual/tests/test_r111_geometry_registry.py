"""R11.1: verified B-Rep grouping must not trade speed for correctness."""
import json
from collections import Counter

import numpy as np
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.TopLoc import TopLoc_Location
from OCP.gp import gp_Trsf, gp_Vec

from dsac29.geometry import describe
from dsac29.geometry_registry import GeometryRegistry
from dsac29.report import geometry_groups
from dsac29.compare import compare
from dsac29.cli import process
from pathlib import Path


def item(size=(20, 8, 5), x=0, y=0):
    shape = BRepPrimAPI_MakeBox(*size).Shape()
    tr = gp_Trsf()
    tr.SetTranslation(gp_Vec(float(x), float(y), 0))
    return describe(shape.Located(TopLoc_Location(tr)), 'DETAL', 'DETAL')


def test_reused_step_native_definition_groups_rapidly():
    initial = item()
    # True reuse of native TShape: 250 separate assembly occurrences.
    things = []
    for i in range(250):
        tr = gp_Trsf(); tr.SetTranslation(gp_Vec(float(i * 40), 0, 0))
        things.append(describe(initial.shape.Located(TopLoc_Location(tr)), 'x', 'x'))
    reg = GeometryRegistry()
    groups = geometry_groups(things, context=reg)
    assert len(groups) == 1 and len(groups[0]) == 250
    assert reg.stats['serializations'] == 0  # exact TShape references prove identity
    assert reg.stats['rigid_brep_checks'] == 0


def test_unique_geometry_not_serialized_without_compatible_candidate():
    parts=[item(size=(20+i*3, 8+i, 5+i%2), x=i*40) for i in range(90)]
    registry=GeometryRegistry()
    groups=geometry_groups(parts, context=registry)
    assert len(groups)==90
    assert registry.stats['serializations']==0
    assert registry.stats['rigid_brep_checks']==0


def test_separately_created_same_shape_merges_only_after_proof():
    parts = [item(x=i*40) for i in range(12)]
    reg = GeometryRegistry()
    groups = geometry_groups(parts, context=reg)
    assert len(groups) == 1 and len(groups[0]) == 12
    assert reg.stats['serializations'] >= 1


def test_geometrically_different_parts_do_not_merge():
    parts = [item(size=(20, 8, 5)), item(size=(20, 10, 4)), item(size=(20,8,5), x=30)]
    groups = geometry_groups(parts, context=GeometryRegistry())
    assert sorted(map(len, groups)) == [1, 2]


def test_matching_and_bom_share_single_in_memory_registry():
    a = [item(x=0), item(x=100)]
    b = [item(x=0), item(x=100)]
    context = GeometryRegistry()
    records = compare(a, b, exact_serialization=True, revision_only=True, geometry_context=context)
    assert all(r.status == 'SAME' for r in records)
    first = context.stats['serializations']
    group_a = geometry_groups(a, context=context)
    group_b = geometry_groups(b, context=context)
    assert len(group_a) == len(group_b) == 1
    # Import/compare does not serialize these same definitions again for BOM.
    assert context.stats['serializations'] == first


def test_no_persistent_cache_entries_on_disk(tmp_path, monkeypatch):
    from dsac29.geometry import signature
    one=GeometryRegistry()
    assert geometry_groups([item()], context=one)==[[0]]
    two=GeometryRegistry()
    assert not two._digests and not two._definitions
    assert list(tmp_path.iterdir())==[]


def test_r111_full_different_revisions(tmp_path):
    samples = Path(__file__).resolve().parents[1] / 'samples'
    folder, rows, error = process(str(samples/'MODEL_A.step'), str(samples/'MODEL_B.step'),
                                 str(tmp_path/'report'), step=True, revision_style=True,
                                 progress=None)
    assert error is None
    summary = json.loads((folder / 'PODSUMOWANIE.json').read_text('utf8'))
    assert len(rows) and sum(summary['statuses'].values()) == len(rows)
    assert (folder / 'RAPORT.html').is_file()
    assert (folder / 'BOM_A.csv').is_file() and (folder / 'BOM_B.csv').is_file()
    assert (folder / 'POROWNANIE_KOLORY.step').is_file()
