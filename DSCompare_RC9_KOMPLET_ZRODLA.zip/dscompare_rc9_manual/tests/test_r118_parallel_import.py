"""R11.8 — independent OCCT processes, lossless BRep IPC and safe fallback."""
from pathlib import Path
import json
import numpy as np

from dsac29 import parallel_import as parallel
from dsac29.cli import process
from dsac29.geometry import describe
from dsac29.step_io import load_step

HERE=Path(__file__).resolve().parents[1]
A=HERE/'samples'/'RAMA_REV_03.step'
B=HERE/'samples'/'RAMA_REV_04.step'


def test_automatic_mode_defaults_to_serial_for_small_models(monkeypatch):
    monkeypatch.delenv('DSCOMPARE_PARALLEL_IMPORT', raising=False)
    assert not parallel.should_parallel(A, B)[0]
    monkeypatch.setenv('DSCOMPARE_PARALLEL_IMPORT', 'on')
    assert parallel.should_parallel(A, B)[0]
    monkeypatch.setenv('DSCOMPARE_PARALLEL_IMPORT', 'off')
    assert not parallel.should_parallel(A, B)[0]


def test_exact_brep_transfer_preserves_names_and_placements(tmp_path):
    original=load_step(str(A))
    parallel.write_cache(tmp_path, original, {'solids': len(original)})
    rebuilt, stats=parallel.read_cache(tmp_path)
    assert stats['solids']==len(original)
    assert len(rebuilt)==len(original)
    for x, y in zip(original, rebuilt):
        assert (x.name, x.path, x.source, x.name_origin)==(y.name, y.path, y.source, y.name_origin)
        assert x.volume==y.volume and x.area==y.area
        np.testing.assert_allclose(x.center,y.center,rtol=0,atol=0)
        np.testing.assert_allclose(x.inertia,y.inertia,rtol=0,atol=0)
        np.testing.assert_allclose(x.axes,y.axes,rtol=0,atol=0)
        assert x.bbox==y.bbox
        # Native OCC roundtrip, not just JSON metadata, preserves real geometry.
        new=describe(y.shape,y.name,y.path)
        assert np.isclose(new.volume,x.volume,rtol=1e-10,atol=1e-7)
        np.testing.assert_allclose(new.center,x.center,rtol=0,atol=1e-8)


def test_parallel_worker_two_step_models(tmp_path, monkeypatch):
    monkeypatch.setenv('DSCOMPARE_PARALLEL_IMPORT', 'on')
    a,b,stats,times,wall=parallel.load_pair(A,B,tmp_path,max_solids=100)
    assert len(a)==len(load_step(str(A)))==13
    assert len(b)==len(load_step(str(B)))==13
    assert stats['A']['solids']==stats['B']['solids']==13
    assert times['A']>0 and times['B']>0 and wall>0
    assert not list(tmp_path.glob('DSCompare_import_*'))  # temporary native BREP is cleaned


def test_compare_gives_same_classification_after_isolated_import(tmp_path, monkeypatch):
    monkeypatch.setenv('DSCOMPARE_PARALLEL_IMPORT', 'off')
    serial=tmp_path/'serial'
    parallel_dir=tmp_path/'parallel'
    process(str(A),str(B),str(serial),step=False,diff_step=False,revision_style=True,full_bom=False,progress=None)
    monkeypatch.setenv('DSCOMPARE_PARALLEL_IMPORT', 'on')
    process(str(A),str(B),str(parallel_dir),step=False,diff_step=False,revision_style=True,full_bom=False,progress=None)
    for name in ('ZMIANY.csv','_ETAPY.json'):
        assert (serial/name).read_bytes()==(parallel_dir/name).read_bytes()
    sx=json.loads((serial/'PODSUMOWANIE.json').read_text(encoding='utf-8'))
    px=json.loads((parallel_dir/'PODSUMOWANIE.json').read_text(encoding='utf-8'))
    for name in ('statuses','solids_A','solids_B','records','mass_A_kg','mass_B_kg'):
        assert sx[name]==px[name]
    assert json.loads((parallel_dir/'CZASY_ANALIZY.json').read_text())['import_mode']=='rownolegly_dwa_procesy'


def test_parallel_import_failure_retries_sequential(tmp_path, monkeypatch):
    monkeypatch.setenv('DSCOMPARE_PARALLEL_IMPORT', 'on')
    def fail(*args,**kwargs):
        raise RuntimeError('symulowana awaria importera')
    monkeypatch.setattr(parallel,'load_pair',fail)
    out=tmp_path/'fallback'
    process(str(A),str(B),str(out),step=False,diff_step=False,revision_style=True,full_bom=False,progress=None)
    t=json.loads((out/'CZASY_ANALIZY.json').read_text())
    assert t['import_mode']=='sekwencyjny_fallback'
    assert json.loads((out/'PODSUMOWANIE.json').read_text())['solids_A']==13


def test_identical_file_optimization_remains(tmp_path, monkeypatch):
    monkeypatch.setenv('DSCOMPARE_PARALLEL_IMPORT', 'on')
    out=tmp_path/'same'
    process(str(A),str(A),str(out),step=False,diff_step=False,revision_style=True,full_bom=False,progress=None)
    timings=json.loads((out/'CZASY_ANALIZY.json').read_text())
    assert timings['import_mode']=='sekwencyjny'
    assert json.loads((out/'PODSUMOWANIE.json').read_text())['statuses']['SAME']==13
