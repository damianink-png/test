from dataclasses import replace
import numpy as np
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from dsac29.geometry import describe
from dsac29.registration_gate import frame_support
from dsac29.step_reexport_tolerance import reexport_equivalent_world

def box(x=10):return describe(BRepPrimAPI_MakeBox(x,20,30).Shape(),'piece','piece')

def test_integrated_descriptors_do_not_override_full_geometric_proof():
    a=box();b=box()
    b=replace(b,volume=b.volume*.997,area=b.area*.999,center=b.center+np.array([.036,0,0]))
    assert reexport_equivalent_world(a,b,.01,allow_boolean=False)
    proof=frame_support([a],[b],.01,verify_all=True)
    assert proof['pairs']==[(0,0)]

def test_equal_descriptors_do_not_hide_changed_geometry():
    a=box();b=box(10.04)
    b=replace(b,volume=a.volume,area=a.area,center=a.center,eigenvalues=a.eigenvalues)
    assert not reexport_equivalent_world(a,b,.01,allow_boolean=False)

def test_no_search_margin_leaks_into_geometric_tolerance():
    from dsac29.alignment import _relocate
    a=box();b=_relocate(box(),np.eye(3),np.array([.03,0,0]))
    assert not reexport_equivalent_world(a,b,.01,allow_boolean=False)
