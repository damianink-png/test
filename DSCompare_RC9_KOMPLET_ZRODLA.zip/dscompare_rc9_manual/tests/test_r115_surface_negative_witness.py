"""Failure-safe surface witness: never upgrades geometry into an assumed match."""
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.gp import gp_Pnt
from dsac29.surface_witness import definitely_different_surfaces
from dsac29 import geometry
from dsac29.geometry import describe


def box(length=12., x=0.):
    return BRepPrimAPI_MakeBox(gp_Pnt(x,0.,0.),length,8.,5.).Shape()


def test_surface_witness_same_solids_not_proved_different():
    assert not definitely_different_surfaces(box(),box(),.01)


def test_surface_witness_proves_far_surface_variation():
    assert definitely_different_surfaces(box(12.),box(12.03),.01)


def test_surface_witness_respects_cad_tolerance():
    assert not definitely_different_surfaces(box(12.),box(12.005),.01)


def test_boolean_failure_and_surface_witness_is_only_negative(monkeypatch):
    # Candidate bypass deliberately probes rejection path. An error from
    # Boolean must not be treated as a positive geometry match.
    monkeypatch.setattr(geometry,'candidate',lambda *args: True)
    monkeypatch.setattr(geometry,'_is_common_equal',lambda *args: (_ for _ in ()).throw(RuntimeError('Boolean failed')))
    a=describe(box(12.),'A','A')
    b=describe(box(12.03),'B','B')
    assert not geometry.equivalent_rigid(a,b)[0]


def test_uncertain_boolean_cannot_be_silently_discarded(monkeypatch):
    monkeypatch.setattr(geometry,'_is_common_equal',lambda *args: (_ for _ in ()).throw(RuntimeError('Boolean failed')))
    a=describe(box(),'A','A');b=describe(box(),'B','B')
    import dsac29.surface_witness as sw
    monkeypatch.setattr(sw,'independent_surface_identity',lambda *args: False)
    with pytest.raises(RuntimeError,match='brak rozstrzygnięcia'):
        geometry.equivalent_rigid(a,b)


def test_strict_independent_faces_prove_identical_boxes():
    from dsac29.surface_witness import independent_surface_identity
    assert independent_surface_identity(box(),box())


def test_strict_independent_faces_reject_even_tiny_real_modifications():
    from dsac29.surface_witness import independent_surface_identity
    assert not independent_surface_identity(box(12.),box(12.0002))


def test_boolean_failure_recovers_only_independent_identical_faces(monkeypatch):
    monkeypatch.setattr(geometry,'_is_common_equal',lambda *args: (_ for _ in ()).throw(RuntimeError('Boolean failed')))
    a=describe(box(),'A','A');b=describe(box(),'B','B')
    assert geometry.equivalent_rigid(a,b)[0]
