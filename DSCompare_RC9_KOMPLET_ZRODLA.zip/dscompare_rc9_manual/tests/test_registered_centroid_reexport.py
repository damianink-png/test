"""Captured CI pair: integrated centers must not block the full world proof."""
from pathlib import Path
import numpy as np
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from dsac29.native_guard import _load_brep,guarded_world_reexport,NativeGeometryFailure
from dsac29.geometry import describe
from dsac29.alignment import _relocate
from dsac29.compare import compare
from dsac29.brep_safety import is_valid

def pair():
    root=Path(__file__).parent/'fixtures/centroid_reexport'
    return [describe(_load_brep(root/(r+'.brep')),r,r) for r in ('A','B')]

@pytest.mark.parametrize('registered',[False,True])
def test_registered_large_frame_does_not_send_equivalent_originals_to_common(registered):
    a,b=pair()
    assert np.linalg.norm(a.center-b.center)>.19
    assert not is_valid(a.shape) and not is_valid(b.shape)
    shared=describe(BRepPrimAPI_MakeBox(10.,12.,14.).Shape(),'same','same')
    old=[shared]*600+[a];new=[shared]*600+[b]
    records=compare(old,new,.01,revision_only=True,exact_serialization=True,
                    certified_pairs=[(i,i) for i in range(600)] if registered else [])
    assert len(records)==601 and all(r.status in ('SAME','RENAMED') for r in records)

def test_lookup_radius_cannot_accept_a_real_shift_beyond_tolerance():
    a,b=pair()
    moved=_relocate(b,np.eye(3),np.array([.02,0.,0.]))
    # This source is invalid and cannot be independently repaired. The offset
    # defeats its original-boundary proof: an explicit incomplete proof is
    # required, never SAME or a fabricated empty material difference.
    with pytest.raises(NativeGeometryFailure):
        guarded_world_reexport(a,moved,.01,timeout_s=20)
