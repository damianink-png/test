"""Windows-native B-Rep mailbox regression tests."""
from pathlib import Path
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from dsac29.geometry import describe
from dsac29.native_guard import guarded_world_reexport, NativeGeometryFailure
from dsac29.native_session import world_session, WorldSession, current

def solid(x=8):
    return describe(BRepPrimAPI_MakeBox(x,11,17).Shape(),'x','x')

def test_many_requests_immutable_mailbox_and_recycle():
    a=solid();b=solid();different=solid(9)
    with world_session() as session:
        session.max_requests=22
        for i in range(52):
            assert guarded_world_reexport(a, b if i%3 else different,.01) is (i%3!=0)
        assert session.starts==3
        root=Path(session.directory.name)
        assert (root/'command_00000008.json').exists()
        assert not (root/'command.json').exists()
        child=session.process
    assert child.poll() is not None and current() is None

def test_no_overwrite_of_previous_commands(monkeypatch):
    original=Path.replace
    def reject_existing(self,target):
        if Path(target).exists():
            raise PermissionError('sharing violation')
        return original(self,target)
    monkeypatch.setattr(Path,'replace',reject_existing)
    with world_session() as session:
        a=solid()
        for _ in range(4):assert guarded_world_reexport(a,a,.01)
        assert (Path(session.directory.name)/'command_00000004.json').exists()

def test_bad_request_aborts_without_false_match(tmp_path):
    req=tmp_path/'request.json';req.write_text('{}',encoding='utf8')
    session=WorldSession()
    try:
        with pytest.raises(NativeGeometryFailure):
            session.execute(req,tmp_path/'reply.json',3)
        assert session.process is None
    finally:session.close()
