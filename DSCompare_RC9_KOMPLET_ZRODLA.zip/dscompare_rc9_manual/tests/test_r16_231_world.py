import sys, tempfile, json
from pathlib import Path
from collections import Counter
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.gp import gp_Trsf,gp_Vec
from OCP.TopLoc import TopLoc_Location
from dsac29.geometry import DescriptionCache
from dsac29.alignment import _relocate
from dsac29.compare import compare
from dsac29.revision_rules import classify_revisions
from dsac29.report import produce
from dsac29.registration_gate import frame_support
ca=DescriptionCache();cb=DescriptionCache()
base=[BRepPrimAPI_MakeBox(7+k*4,10+k*3,13+k*2).Shape() for k in range(4)]
mod=[BRepPrimAPI_MakeBox(14+k*5,9+k*3,16+k*2).Shape() for k in range(4)]
shift=np.array([975.,-426.,100.]);a=[];b=[]
for i in range(380):
 center=np.asarray([(i%20)*39.,(i//20)*55.,(i%7)*65.])
 t=gp_Trsf();t.SetTranslation(gp_Vec(*center));t2=gp_Trsf();t2.SetTranslation(gp_Vec(*(center+shift)))
 a.append(ca.describe(base[i%4].Moved(TopLoc_Location(t)),f'N{i:05}',f'A/{i}'))
 b.append(cb.describe((base[i%4] if i<231 else mod[i%4]).Moved(TopLoc_Location(t2)),f'N{i:05}'+('' if i<3 else '_prt'),f'B/{i}'))
b=[_relocate(p,np.eye(3),-shift) for p in b]
truth=frame_support(a,b,.01,verify_all=True)
assert truth['count']==truth['proofs']==231,truth
raw=compare(a,b,.01,revision_only=True,exact_serialization=True)
assert Counter(r.status for r in raw)['SAME']==3
assert Counter(r.status for r in raw)['RENAMED']==228
rec=classify_revisions(a,b,raw,.01,geometry_first=True)
c=Counter(r.status for r in rec)
assert c['SAME']==231 and c['RENAMED']==0,c
assert sum(r.name_changed for r in rec)==228
assert c['REMOVED']==149 and c['ADDED']==149,c
assert not [r for r in rec if r.status=='SAME' and r.a_index is not None and r.a_index>=231]
print('PASS: 380 models, exactly 231 SAME (228 supplier name differences), 149 revisions',flush=True)
with tempfile.TemporaryDirectory() as td:
 folder,err=produce(td,a,b,rec,7850,generate_step=False,diff_step=False,full_bom=False,preview3d=False,revision_style=True)
 summary=json.loads((folder/'PODSUMOWANIE.json').read_text('utf8'))
 assert summary['statuses']['SAME']==231,summary['statuses']
 assert summary['same_geometry_count']==231
 assert summary['renamed_geometry_count']==228
 audit=json.loads((folder/'DIAGNOSTYKA_DOPASOWANIA.json').read_text('utf8'))
 assert audit['bez_zmian_geometrii']==231
 assert audit['nazwy_rozne_geometria_ta_sama']==228
 lines=(folder/'NAZWY_TE_SAME_GEOMETRIE.csv').read_text('utf-8-sig').splitlines()
 assert len(lines)==229,len(lines)
 html=(folder/'RAPORT.html').read_text('utf8')
 assert 'Bez zmian geometrycznych: 231' in html
 assert 'różne zapisy nazw: 228' in html
 assert 'data-renamed="1"' in html
 assert 'status===\'RENAMED\'&&row.dataset.renamed===\'1\'' in html
 print('PASS: HTML and JSON report, separate supplier-naming CSV and audited counts')
