"""R11 regression: exact-file shortcut, no false geometry identity, fast STEP."""
import json, shutil
from pathlib import Path
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.gp import gp_Trsf, gp_Vec
from OCP.TopLoc import TopLoc_Location
from dsac29.compare import compare
from dsac29.geometry import describe
from dsac29.cli import process

HERE=Path(__file__).resolve().parents[1]


def item(x=0, length=12, name='PROFIL'):
    sh=BRepPrimAPI_MakeBox(length,8,5).Shape()
    tr=gp_Trsf();tr.SetTranslation(gp_Vec(x,0,0))
    return describe(sh.Located(TopLoc_Location(tr)),name,name)


def test_same_object_requires_no_brep():
    same=[item(0),item(25)]
    rec=compare(same,same)
    assert [r.status for r in rec]==['SAME','SAME']
    assert all(r.confidence=='Identyczna zawartość STEP' for r in rec)


def test_distinct_parts_still_proven_by_brep():
    rec=compare([item(length=12)],[item(length=14)])
    assert set(r.status for r in rec)=={'CHANGED'}


def test_exact_brep_hash_proves_same_world():
    rec=compare([item(0)],[item(0)],exact_serialization=True)
    assert len(rec)==1 and rec[0].status=='SAME'


def test_exact_brep_hash_proves_moved():
    rec=compare([item(0)],[item(25)],exact_serialization=True,revision_only=True)
    assert len(rec)==1 and rec[0].status=='MOVED'


def test_distinct_geometry_not_equal_even_optimized():
    rec=compare([item(0,12)],[item(0,14)],exact_serialization=True,revision_only=True)
    assert len(rec)==2 and set(x.status for x in rec)=={'REMOVED','ADDED'}


def test_identical_step_full_workflow(tmp_path):
    source=HERE/'samples'/'MODEL_A.step'
    dup=tmp_path/'COPY_B.step'
    shutil.copyfile(source,dup)
    events=[]
    folder,recs,err=process(str(source),str(dup),str(tmp_path/'results'),
         step=True,revision_style=True,progress=events.append)
    assert err is None
    assert len(recs)==4 and all(r.status=='SAME' for r in recs)
    assert any('identyczna zawartość STEP' in x for x in events)
    assert any('ponownie wykorzystuje zweryfikowane grupy' in x for x in events)
    summary=json.loads((folder/'PODSUMOWANIE.json').read_text(encoding='utf8'))
    assert summary['statuses']=={'SAME':4}
    assert summary['source_fingerprints']['A']==summary['source_fingerprints']['B']
    assert (folder/'POROWNANIE_KOLORY.step').is_file()
    state=json.loads((folder/'_ETAPY.json').read_text(encoding='utf8'))
    assert state['step']=='gotowy' and state['reports']=='gotowe'


def test_genuinely_different_files_use_full_comparison(tmp_path):
    a=HERE/'samples'/'MODEL_A.step'
    b=HERE/'samples'/'MODEL_B.step'
    folder,recs,err=process(str(a),str(b),str(tmp_path/'results'),
        step=False,revision_style=True,progress=None)
    assert len(recs)>0
    summary=json.loads((folder/'PODSUMOWANIE.json').read_text(encoding='utf8'))
    assert summary['source_fingerprints']['A']!=summary['source_fingerprints']['B']
    assert not all(r.status=='SAME' for r in recs)
