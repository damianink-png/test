"""The normal CAD frame must be the default; whole-assembly registration is a fallback."""
import json
import numpy as np
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.gp import gp_Trsf,gp_Vec
from OCP.TopLoc import TopLoc_Location
from dsac29.geometry import describe
from dsac29.registration_gate import frame_support,original_frame_fastpath

def make(shape,coords,num):
    tr=gp_Trsf();tr.SetTranslation(gp_Vec(*map(float,coords)))
    return describe(shape.Located(TopLoc_Location(tr)),f'P{num}',f'P{num}')

def test_partial_world_revision_skips_alignment():
    rng=np.random.default_rng(777)
    positions=rng.integers(100,9000,size=(80,3))
    unchanged=BRepPrimAPI_MakeBox(20,11,9).Shape()
    before=BRepPrimAPI_MakeBox(13,14,15).Shape()
    after=BRepPrimAPI_MakeBox(13,14,16).Shape()
    a=[make(unchanged if i<30 else before,positions[i],i) for i in range(80)]
    b=[make(unchanged if i<30 else after,positions[i],i) for i in range(80)]
    support=frame_support(a,b,.01,proofs=8)
    assert support['count']==30 and support['proofs']==8,support
    allowed,_=original_frame_fastpath(a,b,.01,support)
    assert allowed,'Strong original CAD-frame evidence should bypass alignment'

def test_periodic_shift_not_misclassified_as_already_aligned():
    base=BRepPrimAPI_MakeBox(17,11,9).Shape()
    a=[make(base,(i*40,0,0),i) for i in range(30)]
    b=[make(base,(i*40+40,0,0),i) for i in range(30)]
    evidence=frame_support(a,b,.01,proofs=8)
    assert evidence['count']==29,evidence
    allowed,reason=original_frame_fastpath(a,b,.01,evidence)
    assert not allowed,reason

def test_translated_revision_triggers_fallback():
    base=BRepPrimAPI_MakeBox(17,11,9).Shape()
    a=[make(base,(i*40,i*i*3,0),i) for i in range(20)]
    b=[make(base,(i*40+500,i*i*3+100,0),i) for i in range(20)]
    initial=frame_support(a,b,.01)
    assert not original_frame_fastpath(a,b,.01,initial)[0]

def test_no_global_search_during_unshifted_cli_process(tmp_path,monkeypatch):
    from dsac29 import cli,alignment
    unchanged=BRepPrimAPI_MakeBox(20,11,9).Shape()
    old=BRepPrimAPI_MakeBox(13,14,15).Shape()
    new=BRepPrimAPI_MakeBox(13,14,16).Shape()
    a=[make(unchanged if i<20 else old,(i*41,i*i*2,0),i) for i in range(40)]
    b=[make(unchanged if i<20 else new,(i*41,i*i*2,0),i) for i in range(40)]
    pa=tmp_path/'old.step';pb=tmp_path/'new.step'
    pa.write_text('old');pb.write_text('new')
    monkeypatch.setattr(cli,'load_step',lambda path,**kwargs:a if path==pa else b)
    def unexpected(*args,**kwargs):raise AssertionError('Unnecessary alignment executed')
    monkeypatch.setattr(alignment,'align_assembly',unexpected)
    out=tmp_path/'results';out.mkdir()
    cli.process(pa,pb,out,step=False,diff_step=False,full_bom=False,
                auto_align=True,alignment_approval=lambda _:unexpected(),
                revision_style=True,progress=None)
    results=json.loads((out/'PODSUMOWANIE.json').read_text(encoding='utf8'))
    assert results['statuses']['SAME']==20
    assert results['alignment']['status']=='original_coordinates'
