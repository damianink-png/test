"""Replay an actual failed V2 pair; altered trims must still be rejected."""
from pathlib import Path
import numpy as np
from OCP.BRepBuilderAPI import BRepBuilderAPI_Transform
from OCP.gp import gp_Trsf, gp_Vec
from dsac29.native_guard import _load_brep
from dsac29.geometry import describe
from dsac29.step_reexport_tolerance import reexport_equivalent_world
from dsac29 import parametric_identity

FIXTURE = Path(__file__).parent / 'fixtures' / 'wire_roundtrip'

def parts(folder=FIXTURE):
    return [describe(_load_brep(folder / (name + '.brep')), name, name)
            for name in ('A', 'B')]

def test_step_roundtrip_passes_original_surface_and_trim_proof():
    assert reexport_equivalent_world(*parts(), .01, allow_boolean=False)

def test_original_conservative_wire_bounds_reproduce_false_negative():
    # Compare the two APIs directly on the source cylindrical trimming wire.
    from OCP.Bnd import Bnd_Box
    from OCP.BRepBndLib import BRepBndLib
    from OCP.TopAbs import TopAbs_FACE, TopAbs_WIRE
    from OCP.TopoDS import TopoDS
    a, b = parts()
    wires = []
    for part in (a, b):
        face = parametric_identity.items(part.shape, TopAbs_FACE, TopoDS.Face_s)[26]
        wires.append(parametric_identity.items(face, TopAbs_WIRE, TopoDS.Wire_s)[0])
    def bounds(wire, optimal):
        box = Bnd_Box()
        if optimal: BRepBndLib.AddOptimal_s(wire, box, False, False)
        else: BRepBndLib.Add_s(wire, box, False)
        return np.array(box.Get())
    assert np.max(np.abs(bounds(wires[0], False) - bounds(wires[1], False))) > .005
    assert np.max(np.abs(bounds(wires[0], True) - bounds(wires[1], True))) < 1e-6

def test_displaced_roundtrip_is_not_same():
    a, b = parts()
    tr = gp_Trsf(); tr.SetTranslation(gp_Vec(.02, 0, 0))
    b = describe(BRepBuilderAPI_Transform(b.shape, tr, True).Shape(), 'B', 'B')
    assert not reexport_equivalent_world(a, b, .01, allow_boolean=False)

def test_no_identity_when_full_curve_proof_fails(monkeypatch):
    monkeypatch.setattr(parametric_identity, 'edge_equal', lambda *args: False)
    assert not reexport_equivalent_world(*parts(), .01, allow_boolean=False)

SOLID_FIXTURE = FIXTURE.parent / 'solid_bounds_roundtrip'

def test_solid_bounds_roundtrip_passes_full_surface_and_trim_proof():
    from dsac29.geometry import _precise_world_bounds
    a, b = parts(SOLID_FIXTURE)
    # Real Trident capture: 0.293 mm of conservative AABB disagreement.
    assert np.max(np.abs(_precise_world_bounds(a.shape) - _precise_world_bounds(b.shape))) > .29
    assert reexport_equivalent_world(a, b, .01, allow_boolean=False)

def test_solid_bounds_do_not_replace_oriented_curve_proof(monkeypatch):
    monkeypatch.setattr(parametric_identity, 'edge_equal', lambda *args: False)
    assert not reexport_equivalent_world(*parts(SOLID_FIXTURE), .01, allow_boolean=False)

def test_displaced_solid_bounds_fixture_is_not_same():
    a, b = parts(SOLID_FIXTURE)
    tr = gp_Trsf(); tr.SetTranslation(gp_Vec(.02, 0, 0))
    b = describe(BRepBuilderAPI_Transform(b.shape, tr, True).Shape(), 'B', 'B')
    assert not reexport_equivalent_world(a, b, .01, allow_boolean=False)
