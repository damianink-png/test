"""R11.7: configurable status colors and ZW3D-style body-only STEP without subshape clutter."""
import os
from types import SimpleNamespace
from pathlib import Path
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.TDF import TDF_LabelSequence
from dsac29.geometry import describe
from dsac29.step_io import ColoredDocument, export_revision_step, inspect_step_colors

def test_body_color_assembly_single_free_root(monkeypatch, tmp_path):
    monkeypatch.setenv("DSCOMPARE_BODY_COLORS", "1")
    monkeypatch.setenv("DSCOMPARE_STEP_VERIFY","full")
    d=ColoredDocument(group_by_status=True)
    shape=BRepPrimAPI_MakeBox(10,12,14).Shape()
    d.add(shape,"TEST_PART",(0.12,0.8,0.22),1.0,group="SAME",revision="B")
    roots=TDF_LabelSequence()
    d.tool.GetFreeShapes(roots)
    assert roots.Length()==1
    assert d.count==1 and d.transparent_faces==0 and d.body_colors
    out=tmp_path/"body_only.step"
    report=d.write(str(out))
    inspect=inspect_step_colors(str(out))
    assert out.is_file()
    assert report["pokolorowane_etykiety"]==1
    assert inspect["bryly_bez_koloru"]==0
    assert inspect["pokolorowane_powierzchnie"]==0
    assert inspect["rekordy_kolorow_step"]>0
    assert report["kolory_na_poziomie_bryl"] is True

def test_all_independent_status_colors_for_revision_output(monkeypatch,tmp_path):
    monkeypatch.setenv("DSCOMPARE_BODY_COLORS", "1")
    monkeypatch.setenv("DSCOMPARE_STEP_VERIFY","fast")
    a=[describe(BRepPrimAPI_MakeBox(7,8,9).Shape(),"old","old")]
    b=[describe(BRepPrimAPI_MakeBox(7,8,9).Shape(),"new","new")]
    rec=[SimpleNamespace(status="CHANGED",a_index=0,b_index=0)]
    colors={"CHANGED_OLD":(0.7,0.1,0.5),"CHANGED_NEW":(0.1,0.8,0.7)}
    target=tmp_path/"changed.step"
    result=export_revision_step(str(target),rec,a,b,colors=colors,old_alpha=1.0)
    assert target.exists() and target.stat().st_size>100
    assert result["roles"]["OLD"]==1 and result["roles"]["NEW"]==1
    diag=inspect_step_colors(str(target))
    found=set(diag["kolory_wczytane_rgb"])
    assert (0.7,0.1,0.5) in found
    assert (0.1,0.8,0.7) in found

def test_ui_model_keeps_all_colors_and_no_opacity():
    qt=pytest.importorskip("PySide6.QtWidgets")
    from PySide6.QtGui import QGuiApplication
    from dsac29.gui46 import Window, EXPORT_COLOR_CHOICES
    app=qt.QApplication.instance() or qt.QApplication([])
    w=Window()
    try:
        w.show()
        app.processEvents()
        assert w.windowIcon() and not w.windowIcon().isNull()
        assert len(EXPORT_COLOR_CHOICES)==9
        assert not w.opacity.isVisible()
        assert not w.log.isVisible()
        assert w.zw3d_body_colors
        from PySide6.QtCore import Qt
        assert w.compare_table.horizontalScrollBarPolicy()==Qt.ScrollBarAlwaysOff
        assert w.mass_table.horizontalScrollBarPolicy()==Qt.ScrollBarAlwaysOff
        w.navigate('settings')
        app.processEvents()
        assert w.color_editor.isVisible()
        assert w.safe_export.isChecked()
        assert not hasattr(w,'param_frame')
        assert set(w.color_overrides()) == {x[0] for x in EXPORT_COLOR_CHOICES}
    finally:
        w.close()
