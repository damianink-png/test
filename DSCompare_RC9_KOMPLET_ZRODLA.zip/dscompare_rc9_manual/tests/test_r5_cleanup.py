import csv,json
from pathlib import Path
import pytest
from test_optimization_10 import part


def test_repeated_alignment_builds_reference_index_once(monkeypatch):
    from dsac29 import compare as matching
    from dsac29.alignment import align_assembly
    calls=[];original=matching._spatial_index
    def index(*args):calls.append(1);return original(*args)
    monkeypatch.setattr(matching,'_spatial_index',index)
    a=[part(i,repeated=True,linear=True) for i in range(30)]
    b=[part(i,(40,0,0),repeated=True,linear=True) for i in range(30)]
    shifted,info=align_assembly(a,b)
    assert len(calls)==1 and len(shifted)==30
    assert info['translation_B_to_A_mm']==pytest.approx([-40,0,0])


def test_timeout_terminates_both_workers_and_cleans_temp(monkeypatch,tmp_path):
    from dsac29 import parallel_import as pi
    a=tmp_path/'a.step';a.write_text('STEP')
    workers=[]
    class Hung:
        def __init__(self,*args,**kwargs):self.returncode=None;workers.append(self)
        def poll(self):return self.returncode
        def terminate(self):self.returncode=-15
        def wait(self,timeout=None):return self.returncode
        def kill(self):self.returncode=-9
    monkeypatch.setattr(pi.subprocess,'Popen',Hung)
    clock=iter([0,2]);monkeypatch.setattr(pi,'perf_counter',lambda:next(clock))
    with pytest.raises(TimeoutError):pi.load_pair(a,a,tmp_path/'out',timeout_s=1)
    assert len(workers)==2 and all(p.returncode is not None for p in workers)
    assert not list((tmp_path/'out').iterdir())


def test_timeout_is_not_retried_serially(monkeypatch,tmp_path):
    from dsac29 import cli,parallel_import
    a=tmp_path/'a.step';b=tmp_path/'b.step';a.write_text('a');b.write_text('b')
    monkeypatch.setattr(parallel_import,'should_parallel',lambda *a:(True,''))
    def timeout(*a,**k):raise TimeoutError('deadline')
    monkeypatch.setattr(parallel_import,'load_pair',timeout)
    monkeypatch.setattr(cli,'load_step',lambda *a,**k:pytest.fail('Must not retry hung importer'))
    with pytest.raises(TimeoutError):cli.process(a,b,tmp_path/'out')


def test_parallel_worker_reuses_valid_digest(monkeypatch,tmp_path):
    from dsac29 import parallel_import as pi,import_cache,step_io
    path=tmp_path/'a.step';path.write_text('example')
    monkeypatch.setenv('DSCOMPARE_IMPORT_CACHE','on')
    proof={'sha256':'a'*64,'stat':[path.stat().st_size,path.stat().st_mtime_ns]}
    key=import_cache.cache_key(path,source_sha256=proof['sha256'],source_stat=proof['stat'])
    keys=[]
    def hit(*a,**kw):keys.append(kw['precomputed']);return [part(0)]
    monkeypatch.setattr(import_cache,'try_load',hit)
    monkeypatch.setattr(pi,'write_cache',lambda *a:None)
    # Valid parent proof means STEP bytes are not re-read here.
    original=Path.open
    def guarded(self,*a,**kw):
        if self==path:pytest.fail('Redundant source read')
        return original(self,*a,**kw)
    monkeypatch.setattr(Path,'open',guarded)
    pi.import_worker(path,tmp_path,20000,source_proof=proof)
    assert keys==[key]


def test_batch_mass_uses_memory_rows_with_identical_csv(monkeypatch,tmp_path):
    from dsac29 import single_mass,mass_batch
    from dsac29.report import write_csv
    rows=[['00123',2,10.123456789,1.2,2.4,'assembly/part'],['=formula',1,3.,4.,4.,'x']]
    inputs=[tmp_path/'a.step',tmp_path/'b.step']
    for p in inputs:p.write_text('STEP')
    def analyze(path,folder,*args,rows_out=None,**kwargs):
        folder.mkdir(parents=True);write_csv(folder/'MASY_CZESCI.csv',single_mass.CSV_HEADERS,rows)
        rows_out.extend(rows)
        return folder,dict(liczba_bryl=3,liczba_pozycji=2,masa_calosci_kg=6.4)
    monkeypatch.setattr(single_mass,'analyze_single',analyze)
    original=Path.open
    def guarded(self,mode='r',*a,**kw):
        if self.name=='MASY_CZESCI.csv' and 'r' in mode:pytest.fail('Redundant CSV read')
        return original(self,mode,*a,**kw)
    monkeypatch.setattr(Path,'open',guarded)
    out,summary=mass_batch.analyze_many([str(p) for p in inputs],tmp_path/'out')
    with original(out/'MASY_CZESCI.csv',encoding='utf-8-sig',newline='') as f:combined=list(csv.reader(f,delimiter=';'))[1:]
    with original(out/'MODELE/001_a/MASY_CZESCI.csv',encoding='utf-8-sig',newline='') as f:single=list(csv.reader(f,delimiter=';'))[1:]
    assert combined[:2]==[[f'a.step / {v[0]}']+v[1:] for v in single]
    assert summary['masa_calosci_kg']==12.8


def test_report_cleans_stale_optional_files_and_reports_late_failure(monkeypatch,tmp_path):
    from dsac29 import report
    from dsac29.compare import Record
    stale=('ZAKRES_IMPORTU.txt','PODGLAD_KOLOROW_3D.html','UWAGI_PODGLAD_3D.txt')
    for name in stale:(tmp_path/name).write_text('old')
    (tmp_path/'user-note.txt').write_text('keep')
    def fail(*a,**kw):raise RuntimeError('optional <failure>')
    monkeypatch.setattr(report,'export_differences_step',fail)
    a=[part(0)]
    report.produce(tmp_path,a,a,[Record(0,0,'SAME','')],generate_step=False,full_bom=False,diff_step=True)
    assert not any((tmp_path/name).exists() for name in stale)
    assert (tmp_path/'user-note.txt').read_text()=='keep'
    assert 'optional &lt;failure&gt;' in (tmp_path/'RAPORT.html').read_text()
    summary=json.loads((tmp_path/'PODSUMOWANIE.json').read_text())
    assert summary['step_export_error'] is None
    assert summary['optional_diff_errors']==['optional <failure>']
