"""A valid/invalid pair must receive the same full original-boundary proof."""
from pathlib import Path
from OCP.BRepBuilderAPI import BRepBuilderAPI_Transform
from OCP.gp import gp_Trsf,gp_Vec
from dsac29.native_guard import _load_brep,guarded_world_reexport
from dsac29.brep_safety import is_valid
from dsac29.geometry import describe
from dsac29.step_reexport_tolerance import reexport_equivalent_world

ROOT=Path(__file__).parent/'fixtures/mixed_validity_molex'
def test_captured_mixed_validity_pair_passes_full_original_boundary_guard():
    a,b=[_load_brep(ROOT/(r+'.brep')) for r in ('A','B')]
    assert is_valid(a) and not is_valid(b)
    left,right=describe(a,'A','molex-A'),describe(b,'B','molex-B')
    assert guarded_world_reexport(left,right,.01,timeout_s=30)
    assert is_valid(a) and not is_valid(b)  # original topology unchanged

def test_real_displacement_is_not_accepted_by_original_boundary_proof():
    a,b=[_load_brep(ROOT/(r+'.brep')) for r in ('A','B')]
    shift=gp_Trsf();shift.SetTranslation(gp_Vec(.03,0.,0.))
    b=BRepBuilderAPI_Transform(b,shift,True).Shape()
    assert not reexport_equivalent_world(describe(a,'A','A'),describe(b,'B','B'),.01,allow_boolean=False,_original_boundary_only=True)
