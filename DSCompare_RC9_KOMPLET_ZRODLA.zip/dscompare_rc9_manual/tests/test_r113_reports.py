import json
from pathlib import Path
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from dsac29.geometry import describe
from dsac29.compare import Record
from dsac29 import report
from dsac29.geometry_registry import GeometryRegistry

def part(x=2):
    return describe(BRepPrimAPI_MakeBox(x,3,4).Shape(),'P','P')

def test_no_bom_preserves_report_mass_and_removes_stale_files(tmp_path,monkeypatch):
    a=[part()];b=[part(5)]
    for name in ('BOM_A.csv','BOM_B.csv','RAPORT.html'):
        (tmp_path/name).write_text('STALE')
    def forbidden(*args,**kwargs):raise AssertionError('BOM requested in fast mode')
    monkeypatch.setattr(report,'geometry_groups',forbidden)
    report.produce(tmp_path,a,b,[Record(0,None,'REMOVED',''),Record(None,0,'ADDED','')],generate_step=False,diff_step=False,full_bom=False)
    data=json.loads((tmp_path/'PODSUMOWANIE.json').read_text())
    assert data['full_bom'] is False and not data['bom_warnings']
    assert len(data['records'])==2
    assert not (tmp_path/'BOM_A.csv').exists()
    assert 'STALE' not in (tmp_path/'RAPORT.html').read_text()
    assert not (tmp_path/'RAPORT_ZMIAN.html').exists()
    assert (tmp_path/'RAPORT.html').is_file()

def test_report_available_before_bom_even_after_step_error(tmp_path,monkeypatch):
    def fail(*args,**kwargs):raise RuntimeError('simulated export failure')
    monkeypatch.setattr(report,'export_colored_step',fail)
    calls=[]
    def groups(parts,*args,**kwargs):
        assert not (tmp_path/'RAPORT_ZMIAN.html').exists()
        assert not json.loads((tmp_path/'_ETAPY.json').read_text())['basic_report_ready']
        calls.append(1)
        return [[0]]
    monkeypatch.setattr(report,'geometry_groups',groups)
    report.produce(tmp_path,[part()],[part()],[Record(0,0,'SAME','')],diff_step=False)
    assert calls
    assert 'simulated export failure' in (tmp_path/'PODSUMOWANIE.json').read_text()
    assert (tmp_path/'RAPORT.html').exists()
    assert 'BOM A' in (tmp_path/'RAPORT.html').read_text()

def test_partial_groups_match_independent_grouping():
    records=[Record(0,0,'SAME',''),Record(1,1,'MOVED',''),Record(2,None,'REMOVED',''),Record(None,2,'ADDED','')]
    seeds=report.partial_verified_bom_groups([[0,1],[2]],records,3,3)
    assert seeds==[[0,1]]
    b=[part(),part(),part(7)]
    expected=report.geometry_groups(b)
    actual=report.geometry_groups(b,known_groups=seeds)
    assert sorted(map(sorted,actual))==sorted(map(sorted,expected))
    assert sorted(i for g in actual for i in g)==[0,1,2]

def test_uncertain_pairs_do_not_seed():
    assert report.partial_verified_bom_groups([[0]],[Record(0,0,'UNCERTAIN','')],1,1)==[]

def test_shared_proof_avoids_serialization(monkeypatch):
    a,b=part(),part();context=GeometryRegistry()
    context.remember_equivalence(a,b,.01,True)
    def forbidden(*args):raise AssertionError('Repeated serialization')
    monkeypatch.setattr(context,'same_definition',forbidden)
    assert context.rigid_equivalent(a,b,.01)
    assert context.stats['rigid_cache_hits']==1

def test_internal_bom_failure_warns_and_disables_reuse(tmp_path,monkeypatch):
    context=GeometryRegistry()
    monkeypatch.setattr(context,'same_definition',lambda *args:False)
    def fail(*args):raise RuntimeError('simulated BRep error')
    monkeypatch.setattr(context,'rigid_equivalent',fail)
    a=[part(),part()];b=[part(),part()]
    report.produce(tmp_path,a,b,[Record(0,0,'SAME',''),Record(1,1,'SAME','')],generate_step=False,diff_step=False,geometry_context=context)
    data=json.loads((tmp_path/'PODSUMOWANIE.json').read_text())
    assert not data['bom_grouping_complete']
    assert len(data['bom_warnings'])==2
    assert (tmp_path/'UWAGI_BOM.txt').is_file()

def test_population_failure_stays_uncertain(monkeypatch):
    from dsac29.revision_rules import classify_revisions
    a=[part(),part()];b=[part(),part()];context=GeometryRegistry()
    def fail(*args):raise RuntimeError('population failure')
    monkeypatch.setattr(context,'rigid_equivalent',fail)
    result=classify_revisions(a,b,[Record(0,0,'MOVED',''),Record(1,1,'SAME','')],geometry_context=context)
    assert [r.status for r in result]==['UNCERTAIN','SAME']
    assert 'population failure' in result[0].note

def test_full_and_fast_modes_have_identical_change_results(tmp_path):
    from dsac29.cli import process
    samples=Path(__file__).resolve().parents[1]/'samples'
    outputs=[]
    for full in (False,True):
        folder,records,error=process(str(samples/'MODEL_A.step'),str(samples/'MODEL_B.step'),str(tmp_path/str(full)),step=True,revision_style=True,full_bom=full)
        assert error is None
        assert (folder/'POROWNANIE_KOLORY.step').exists()
        assert (folder/'BOM_A.csv').exists()==full
        assert 'bom_grouping_s' in json.loads((folder/'CZASY_ANALIZY.json').read_text())
        outputs.append([vars(r) for r in records])
    assert outputs[0]==outputs[1]
