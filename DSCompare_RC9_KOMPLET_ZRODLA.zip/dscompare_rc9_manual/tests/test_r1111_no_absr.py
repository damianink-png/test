"""Prevent zero-volume ABSR products in ZW3D by exporting only real solids."""
from pathlib import Path
import re
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeFace
from OCP.gp import gp_Trsf,gp_Vec,gp_Pln,gp_Pnt,gp_Dir
from OCP.TopLoc import TopLoc_Location
from OCP.TDF import TDF_LabelSequence
from dsac29.geometry import describe
from dsac29.compare import Record
from dsac29.step_io import export_revision_step,load_step,inspect_step_colors,ColoredDocument


def _part(x,name):
    s=BRepPrimAPI_MakeBox(12,23,34).Shape()
    t=gp_Trsf();t.SetTranslation(gp_Vec(x,0,0))
    return describe(s.Located(TopLoc_Location(t)),name,name)

@pytest.mark.parametrize('schema',['AP214IS','AP242DIS'])
def test_flat_safe_export_has_one_product_per_positive_volume_solid(monkeypatch,tmp_path,schema):
    monkeypatch.setenv('DSCOMPARE_FLAT_FALLBACK','1')
    monkeypatch.setenv('DSCOMPARE_STEP_VERIFY','full')
    monkeypatch.setenv('DSCOMPARE_BODY_COLORS','1')
    monkeypatch.setenv('DSCOMPARE_STEP_SCHEMA',schema)
    a=[_part(0,'Bez zmian'),_part(50,'Przesunieta'),_part(100,'Usunieta')]
    b=[_part(0,'Bez zmian'),_part(80,'Przesunieta'),_part(150,'Nowa')]
    records=[Record(0,0,'SAME',''),Record(1,1,'MOVED',''),Record(2,None,'REMOVED',''),Record(None,2,'ADDED','')]
    output=tmp_path/'revision.step'
    diag=export_revision_step(output,records,a,b,old_alpha=.4)
    raw=output.read_bytes()
    assert diag['eksport_plaski_bez_absr'] and not diag['grupowanie_zlozenia']
    assert diag['produkty_step']==5 and diag['powiazania_zlozenia']==0 and diag['puste_reprezentacje_step']==0
    assert len(re.findall(rb'(?m)^#\d+\s*=\s*PRODUCT\(',raw))==5
    assert b'NEXT_ASSEMBLY_USAGE_OCCURRENCE' not in raw
    assert not re.search(rb'(?m)^#\d+\s*=\s*SHAPE_REPRESENTATION\(',raw)
    # Statuses are allowed as STEP LAYER names; flat mode has no
    # assembly PRODUCT nodes regardless of layer names.
    assert not re.search(rb"(?m)^#\d+\s*=\s*PRODUCT\('(?:01_|02_)",raw)
    assert diag['rekordy_przezroczystosci_step']>0
    reread=load_step(output)
    assert len(reread)==5
    assert all(part.volume>0 and not part.name.upper().startswith('ABSR') for part in reread)
    assert sorted(round(part.center[0],4) for part in reread)==[6.,56.,86.,106.,156.]
    assert diag['bryly_wynikowe']==5 and diag['elementy_bez_bryly']==0


def test_repeated_parts_have_distinct_step_products(monkeypatch,tmp_path):
    monkeypatch.setenv('DSCOMPARE_FLAT_FALLBACK','1')
    monkeypatch.setenv('DSCOMPARE_STEP_VERIFY','fast')
    box=BRepPrimAPI_MakeBox(12,13,14).Shape()
    # Same shape / placement but separate occurrences (do not silently dedupe).
    parts=[describe(box,'part','part') for _ in range(12)]
    records=[Record(i,i,'SAME','') for i in range(12)]
    p=tmp_path/'repeat.step'
    result=export_revision_step(p,records,parts,parts)
    assert result['produkty_step']==result['definicje_unikalne']==12
    assert result['ponownie_uzyte_definicje']==0
    assert len(load_step(p))==12


def test_bad_zero_volume_shape_rejected_before_step_write(tmp_path):
    face=BRepBuilderAPI_MakeFace(gp_Pln(gp_Pnt(0,0,0),gp_Dir(0,0,1)),0,10,0,10).Face()
    doc=ColoredDocument(flat_zw3d=True)
    with pytest.raises(ValueError,match='SOLID'):
        doc.add(face,'no_solid',(.5,.6,.7))
    assert not (tmp_path/'invalid.step').exists()


def test_legacy_assembly_mode_is_opt_in_and_is_not_safe_for_zw3d(monkeypatch,tmp_path):
    monkeypatch.setenv('DSCOMPARE_FLAT_FALLBACK','0')
    a=[_part(0,'Old')]
    path=tmp_path/'old.step'
    result=export_revision_step(path,[Record(0,None,'REMOVED','')],a,[])
    assert result['grupowanie_zlozenia']
    assert not result['tryb_bez_pustych_kontenerow']
    assert b'NEXT_ASSEMBLY_USAGE_OCCURRENCE' in path.read_bytes()
