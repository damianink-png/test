"""An unusable optional Common must trigger a full independent region proof."""
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.TopoDS import TopoDS_Shape
from dsac29.geometry import describe
from dsac29.compare import Record
from dsac29 import native_guard,revision_overlap as revision
from dsac29.material_deltas import _matching_regions,MaterialRegions

def inputs():
    a=[describe(BRepPrimAPI_MakeBox(10.,10.,10.).Shape(),'old','old')]
    b=[describe(BRepPrimAPI_MakeBox(11.,10.,10.).Shape(),'new','new')]
    return a,b,[Record(0,None,'REMOVED',''),Record(None,0,'ADDED','')]

def test_unusable_transferred_common_is_recomputed_and_all_regions_verified(monkeypatch):
    a,b,records=inputs()
    monkeypatch.setattr(native_guard,'guarded_common',lambda *args:TopoDS_Shape())
    result,precomputed,stat=revision.merge_material_revisions(a,b,records,.01)
    assert [r.status for r in result]==['CHANGED']
    assert stat['invalid_boolean']==1
    assert _matching_regions(precomputed[0],a[0],b[0],.01)
    reg=precomputed[0].regions
    assert reg.common_mm3==pytest.approx(1000)
    assert reg.added_mm3==pytest.approx(100)
    assert reg.removed_mm3==pytest.approx(0)

def test_failed_recomputation_never_becomes_a_revision_verdict(monkeypatch):
    a,b,records=inputs()
    monkeypatch.setattr(native_guard,'guarded_common',lambda *args:TopoDS_Shape())
    def fail(*args,**kwargs):raise native_guard.NativeGeometryFailure('failed independent proof')
    monkeypatch.setattr(revision,'calculate',fail)
    with pytest.raises(native_guard.NativeGeometryFailure,match='independent proof'):
        revision.merge_material_revisions(a,b,records,.01)

def test_plausible_volumes_cannot_validate_invalid_recomputed_regions(monkeypatch):
    a,b,records=inputs()
    monkeypatch.setattr(native_guard,'guarded_common',lambda *args:TopoDS_Shape())
    bad=MaterialRegions(TopoDS_Shape(),TopoDS_Shape(),TopoDS_Shape(),1000.,100.,0.)
    monkeypatch.setattr(revision,'calculate',lambda *args,**kwargs:bad)
    with pytest.raises(native_guard.NativeGeometryFailure,match='invalid or null topology'):
        revision.merge_material_revisions(a,b,records,.01)
