DS COMPARE R11.11 - KOREKTA PUSTYCH CZESCI ABSR
================================================

PROBLEM
W STEP zapisanym przez R11.10 znajdowaly sie dodatkowe produkty
reprezentujace PUSTE kontenery zlozen (TopoDS_Compound). ZW3D 2019
moze importowac te produkty jako niewidoczne czesci ABSR1, ABSR2
(0 mm3, 0 kg). Tryb "bez wspoldzielenia" R11.9 nie usuwal
kontenerow, dlatego problem wystepowal nadal.

ROZWIAZANIE (domyslnie zaznaczona opcja w Ustawieniach):
"Bez pustych ABSR - plaski STEP do ZW3D".
Kazda rzeczywista bryla SOLID jest zapisywana jako osobny STEP PRODUCT,
bez pustych kontenerow, SHAPE_REPRESENTATION i
NEXT_ASSEMBLY_USAGE_OCCURRENCE. Zachowane sa geometria, pozycje,
nazwy zawierajace status rewizji oraz kolory (z przezroczystoscia
starzej wersji zaleznia od importera).

UWAGA: w nowym STEP nie ma hierarchii grup 01_BEZ_ZMIAN, itd.
Rodzaj zmiany jest czescia nazwy produktu (__NOWE__, __USUNIETE__,
__PRZESUNIETE__, ...). Aby przywrocic stare podzlozenia,
mozna ODZNACZYC checkbox "Bez pustych ABSR", ale wtedy importer ZW3D
moze znow pokazac dodatkowe puste elementy.

KONTROLA PRZED PRZEKAZANIEM STEP
- Produktow STEP musi byc tyle, ile faktycznych bryl eksportu.
- Brak NEXT_ASSEMBLY_USAGE_OCCURRENCE.
- Brak pustych SHAPE_REPRESENTATION.
- Kazdy eksportowany komponent musi zawierac jedna bryle SOLID o
  dodatniej objetosci.
- Dla malych modeli eksport jest ponownie otwierany i liczona jest
  rzeczywista liczba bryl oraz kolory i przezroczystosc.

OGRANICZENIE
Testy wykonano na silniku Open CASCADE/Windows. Nie wykonywano
importu w zainstalowanym ZW3D 2019, wiec ostateczne potwierdzenie
znikniecia ABSR wymaga testu uzytkownika na problematycznym modelu.

Wersja bazowa: DS Compare R11.10; zachowane ulepszenia BOM, interfejsu,
raportu i rownoleglego importu.
