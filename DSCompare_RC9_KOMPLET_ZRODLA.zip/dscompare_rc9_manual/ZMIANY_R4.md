# DS Compare 1.0 R4

Baza: pełne źródła DS Compare 1.0 R3, commit bazowy zapisany w build_info.json.

## Wyrównanie całych złożeń
- Naprawiono pomijanie wyrównania przy częściowym nakładaniu modeli. Szereg
  30 identycznych części przesunięty o jeden rozstaw nie kończy się już
  błędnym uznaniem 29 dopasowań za poprawny układ odniesienia.
- Usunięto limit 20 potwierdzeń, który ukrywał różnicę między hipotezami.
- Rzeczywista poprawa o jedno dopasowanie nie jest odrzucana arbitralnym progiem.
- Do obrotu złożenia dodano hipotezy z trójek baz, weryfikowane przez większość
  wspólnych części i geometrię B-Rep. Ruch pojedynczej części nie psuje całego dopasowania.
- Nie zmienia się położenia części osobno. Akceptacja dotyczy jednej transformacji B → A.
- Niejednoznaczność jest zgłaszana. Nie gwarantuje się automatycznego wyrównania
  wszystkich symetrycznych złożeń, dużych zmian rewizji ani modeli pozbawionych wspólnych baz.

## Wydajność
- Translacja zachowuje współdzieloną geometrię natywną i nie przelicza ponownie
  objętości, powierzchni i bezwładności każdej części.
- Buforowanie macierzy położenia, wektorowe odległości oraz tworzenie szczegółów
  tylko dla wybranych par; zachowano kandydatów i reguły dowodzenia geometrii.
- Sprawniejsze przechodzenie składowych przypisania, mniej obliczeń sygnatur.
- Współdzielony odczyt stanu postępu, ograniczony log oraz brak tworzenia
  tysięcy niewidocznych wierszy tabeli masy. Ostrzeżenia pozostają widoczne.

## Interfejs i eksport
Zachowano układ R3, wyśrodkowane opisy i responsywne okno O programie:
Wersja 1.0. Doprecyzowano przycisk i opis nałożenia całego złożenia.
Pliki step_io.py, geometry.py i revision_rules.py są identyczne z R3.
Eksport STEP oraz obsługa ABSR pozostają bez zmian.

## Weryfikacja
91 testów wybranej aktualnej bramki regresji: PASS (TESTUJ.py).
Testy obejmują rzeczywisty import dwóch plików STEP z 30 powtarzalnymi częściami,
translację z dodaniem/usunięciem i ruchem lokalnym, obrót z ruchem lokalnym,
niejednoznaczność, anulowanie, zgodność par i statusów z R3, cache masy,
oraz zachowanie geometrii i położeń 1000 wystąpień podczas translacji.
Test uruchomienia UI: 3 strony, 2 motywy, PASS. To nie jest pełny zestaw
historycznych testów, z których część dotyczy usuniętych kontrolek/trybów.

Środowisko lokalne: Linux, Python 3.12, OCP 7.8.1.1.post1, PySide6 6.8.3.
Nie wykonano tutaj kompilacji Windows ani testu w natywnym ZW3D.
Workflow powtarza bramkę na Windows/Python 3.11, buduje EXE i sprawdza jego UI.
Zależności Windows OCP 7.9.3.1.1 i VTK 9.6 zachowano ze skryptu R3.

Benchmark syntetyczny R3 → R4, mediana 3 pomiarów:
- dopasowanie 180 wystąpień: 4.338 s → 0.117 s;
- przypisanie 10 000 niezależnych par: 0.851 s → 0.054 s.
Wyniki par/statusów były identyczne. Pomiar nie obejmuje importu STEP,
wyrównania, eksportu ani raportów; nie oznacza takiego przyspieszenia całej analizy.
Skrypt i surowe wyniki dołączono. Wynik zależy od sprzętu i modelu.
