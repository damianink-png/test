# DS Compare Desktop 04 — Svelte 5 / Tauri 2

Nowy interfejs desktopowy. Silnik geometrii pozostaje oddzielnym procesem DSCompare/OCCT; nie jest zastępowany heurystykami przeglądarki. Instalator Windows zawiera cały pakiet silnika, nie tylko EXE.

Funkcje: porównanie STEP, postęp i anulowanie całego drzewa procesów, decyzje wyrównania i raportu częściowego, filtrowana tabela, raport/3D w izolowanej ramce, eksporty STEP/CSV/BOM, otwieranie wcześniejszych wyników, masy wielu plików, diagnostyka, zapis ustawień, dokładne pola liczbowe, paleta i jasny/ciemny motyw. Raport niepełny pozostaje niepełny w nowym GUI.

## Uruchomienie i budowanie

Node 22+, Rust stable oraz systemowe wymagania Tauri 2. Windows: Visual Studio Build Tools (C++), WebView2. Linux: GTK3/WebKitGTK 4.1 development libraries. Interfejs WWW jest wyłącznie podglądem; nie udaje działających obliczeń CAD.

```
npm ci
npm run check
npm test
npm run dev
```

Natywny tryb deweloperski (zmienna obsługiwana wyłącznie w debug):

```
# DSCOMPARE_ENGINE_COMMAND = JSON array, e.g.
# ["C:/Python311/python.exe","C:/DSCompare/DSCompareV3.py"]
npm run tauri dev
```

Produkcja: skopiuj komplet zbudowanego DSCompare/ do src-tauri/engine/DSCompare/, następnie `npm run tauri build`. Workflow Windows wykonuje te kroki automatycznie. Samo `npm run build` sprawdza frontend i nie potwierdza działania natywnej aplikacji.

`cargo test --manifest-path src-tauri/Cargo.toml --lib` sprawdza granicę procesu bez zależności GUI. Kompilacja `desktop` wymaga pełnych zależności Tauri i weryfikacji na docelowym Windows.

Otwieranie artefaktów ograniczono do zarejestrowanych folderów i nazw wyników; interfejs WWW nie dostaje ogólnej komendy powłoki. Anulowanie nie usuwa wcześniejszych raportów. Dzienniki stdout/stderr silnika są zapisywane w folderze każdej operacji.

## Projekty referencyjne

CADdiff (Apache-2.0) uruchomiono bez modyfikowania kodu na OpenArm: 0 kandydatów geometrii, 177 różnic nazw BOM. Kontrola negatywna wykazała fałszywe `identical` dla otworu okrągłego i kwadratowego o równej objętości, rzeczywista różnica 22.756684 mm³. Nie przejęto silnika ani tej reguły.

Kwantflow (GPL-3.0-only): przejrzano organizację Svelte/Tauri i podglądu CAD. Nie skopiowano kodu ani pakietów GPL do tej warstwy; interfejs napisano niezależnie. occt-import-js używany do podglądu nie stanowi silnika porównywania brył. FreeCAD posłużył do niezależnego uruchomienia CADdiff i kontrolnych operacji geometrycznych.
