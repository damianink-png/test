<script lang="ts">
 let {value=$bindable(0),step=1,min=0,max=1e9,label,unit='',disabled=false}:{value?:number;step?:number;min?:number;max?:number;label:string;unit?:string;disabled?:boolean}=$props();
 function change(d:number){value=Math.min(max,Math.max(min,Number((value+d*step).toFixed(8))));}
</script>
<div class="numeric"><button type="button" aria-label={`Zmniejsz: ${label}`} disabled={disabled||value<=min} onclick={()=>change(-1)}>−</button><input aria-label={label} type="number" bind:value {min} {max} {step} {disabled}/>{#if unit}<span>{unit}</span>{/if}<button type="button" aria-label={`Zwiększ: ${label}`} disabled={disabled||value>=max} onclick={()=>change(1)}>+</button></div>
