# DS Compare 1.0 R13

Porównanie zaczyna się w oryginalnych współrzędnych. Usunięto osobny etap automatycznego wyrównywania przed porównaniem. Zwykłe dopasowania są wykorzystywane do wskazania podejrzanych translacji; dopiero kandydat poprawiający liczbę zgodnych pozycji uruchamia pełne potwierdzenie B-Rep. Zmienna liczba powtarzalnych części jest uwzględniona.

Użytkownik może przyjąć zaproponowaną transformację, zachować oryginalne współrzędne lub anulować. Niejednoznaczna propozycja umożliwia dodatkowe wyszukiwanie wyrównania. Nie zmienia się położenia bez zgody. Gdy nie znaleziono kandydata, analiza pozostaje w aktualnych współrzędnych; nie jest to dowód braku przesunięcia.

Import i rejestr definicji geometrii są współdzielone. Przy zaakceptowanym przesunięciu dopasowania przestrzenne są liczone ponownie, ponieważ zmienił się układ. Przy braku przesunięcia zwykłe porównanie wykonywane jest raz.

Ograniczenia: automatyczny etap dotyczy translacji, a ograniczone próbkowanie może nie znaleźć nietypowego przesunięcia. Rozbudowane szukanie transformacji zachowano jako opcję przy niejednoznacznej propozycji. Nie testowano oryginalnych modeli użytkownika. Nie zmieniono STEP/ABSR, kolorów ani podglądu HTML. Drzewo HTML nie należy do tego etapu.

Workflow GitHub buduje źródła z katalogu głównego repozytorium. Ta paczka nie zawiera skompilowanego EXE.
