# DS Compare 1.0 R22.3 RC2

Baza: R22.3 RC1, commit a8ca5e59a339276393ce41b6d44893e376af0387 repozytorium damianink-png/test. Odtworzono dokładny ZIP bazowy i nakładkę używane w jego workflow; nie cofnięto kodu do R22.1/R22.2.

## Zakończone testy R22.3 RC1

Przebieg: https://github.com/damianink-png/test/actions/runs/40200756650

- Windows: kompilacja i UI PASS; 182 regresje PASS, dodatkowy zestaw 28 PASS (częściowo pokrywa regresje).
- Trident przesunięty: FAIL, timeout 35 s, para 639/639, operacja 233.
- Trident rewizja + przesunięcie: FAIL, timeout 35 s, para 639/639, operacja 233.
- Voron V2 przesunięty: FAIL, timeout 35 s, para 1062/1062, operacja 887.
- Voron V2 rewizja + przesunięcie: FAIL, timeout 35 s, para 1054/1062, operacja 877.

To były kontrolowane przerwania; żaden z czterech dużych testów nie zakończył się PASS.

## Poprawki RC2

1. Porównanie obrysów: przestrzenny indeks kandydatów krawędzi zamiast każdej pary z każdą. Indeks opiera się wyłącznie na warunku koniecznym istniejącego dokładnego testu. Nadal sprawdzane są wszystkie krawędzie, powierzchnie, orientacje i poprawność brył. Nie zwiększono tolerancji.
2. Dopasowanie jeden do jednego obrysów ma iteracyjne wyszukiwanie ścieżek; nie zależy od limitu rekurencji Pythona.
3. Duża weryfikacja przesunięcia ponownie używa izolowanego procesu, z restartem co 32 żądania. Każda para jest ponownie odczytywana i sprawdzana. Timeout pozostaje 35 s; proces jest kończony przy awarii lub zamknięciu sesji.
4. NativeGeometryFailure w etapie 1 przerywa całe porównanie. Nie jest pochłaniany jako zwykłe niedopasowanie.
5. Awaryjna ścieżka STEP dla 600+ brył korzysta z izolowanego weryfikatora; przekazuje też częściową listę potwierdzonych par do dalszego porównania.
6. Diagnostyka timeoutu zawiera ostatni etap operacji i (dla sesji) ścieżki obu części.
7. Zaktualizowano metadane wydania i główny zestaw testów. Widoczna wersja UI pozostaje 1.0. Nie zmieniano eksportera ABSR ani podglądu HTML.

## Pomiary lokalne

Python 3.12, OCP 7.8.1.1, Linux. Czasy nie stanowią gwarancji czasu na Windows.

- Trident: rzeczywisty element indeks 639, A_Belt:1. Źródło: https://github.com/VoronDesign/Voron-Trident/blob/1a49bdc2c524cd6f4491a01e8fd566d0bd6acd0a/CAD/trident_assembly.step.zip
- Próba kontrolna tego paska, dwa odczyty tej samej B-Rep: sam dowód powierzchni/obrysu przed zmianą 56.511 s, po zmianie 1.640 s, wynik zgodny.
- Pasek wyeksportowany ponownie do STEP po przesunięciu (+1275,-395,+210) mm, następnie nałożony: izolowana pełna weryfikacja PASS w 15.086 s, limit 35 s. Jest to test wyodrębnionego elementu, nie całego Tridenta.
- 16 prostych par: osobny proces dla każdej 17.148 s; wspólna sesja 0.948 s, jedno uruchomienie procesu.
- 182 istniejące testy regresji PASS po poprawkach; 14 testów R22.3/RC2 PASS. Pełny połączony zestaw: 196 PASS w 33.87 s (TESTUJ.py).
- Nowe testy sprawdzają zgodność przestrzennego indeksu z pełnym przeglądem, 2000 krawędzi (2000 zamiast 4 mln dokładnych kontroli), długie ścieżki dopasowania, restart/zamknięcie procesu, awarie, timeouty oraz izolację dużej ścieżki awaryjnej.

## Granice potwierdzenia

W momencie przygotowania paczki Windows RC2 i cztery pełne duże porównania są jeszcze do wykonania. Test jednego paska nie dowodzi poprawnej klasyfikacji wszystkich 1595/1715 brył. Nie potwierdzono naprawy wszystkich problemów ponownego zapisu STEP, wadliwych brył ani integracji DLL z ZW3D 2019.

Workflow build-r223-rc2.yml buduje program Windows i uruchamia cztery duże przypadki. Nie zmienia limitu 2400 sekund porównania, liczby wymaganych brył ani warunków zaliczenia eksportu STEP/HTML.
