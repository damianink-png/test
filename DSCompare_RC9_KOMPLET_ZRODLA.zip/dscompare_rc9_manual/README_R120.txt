DS Compare R11.10 — BOM i uproszczone wyniki

Zmiany:
- Wyniki: mniejszy panel, bez napisów „Wynik porównania” oraz „STEP gotowy do otwarcia”.
- Raport RAPORT.html: BOM A i B jako domyślnie zamknięte sekcje HTML (<details>), pod tabelą zmian.
- Ustawienia: BOM dokładny (domyślnie) i opcjonalny szybki bez kosztownych porównań B-Rep dla różnych definicji STEP.
- Szybki BOM scala WYŁĄCZNIE pewne duplikaty, ale może pozostawić równoważne części w osobnych pozycjach. Nie należy traktować liczby unikalnych grup jako wyczerpującej. Ostrzeżenie wyświetlane w raporcie.
- CSV BOM A/B opcjonalny i domyślnie niewłączony w interfejsie (do obliczeń nadal konieczne jest grupowanie).
- Klasyfikacja rewizji i eksport STEP bez zmian względem R11.9.

Analiza przesłanych danych: „Nowsza wersja.zip” zawiera wyłącznie JSON wyników, NIE zawiera rzeczywistych 91002674_000.stp i 91007430_000.stp. Nie wykonano benchmarku poprawionej wersji na tych dwóch dużych modelach.
Czasy zmierzone w R11.9: import równoległy ok. 73 s, porównanie 328 s, BOM 238 s. 5 sprawdzeń Ringoese ok. 236 s.
Zapis CSV nie odpowiada za te 238 s.
