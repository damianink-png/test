import sys,json,time,statistics
from collections import Counter
sys.path.insert(0,sys.argv[1])
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.TopLoc import TopLoc_Location
from OCP.gp import gp_Trsf,gp_Vec
from dsac29.geometry import describe
from dsac29.compare import compare
from dsac29.revision_rules import classify_revisions
fast='revision_only' in compare.__code__.co_varnames

def part(shape,x,name):
 t=gp_Trsf();t.SetTranslation(gp_Vec(x,0,0));return describe(shape.Located(TopLoc_Location(t)),name,name)
results={}
for scenario in ('changed_100','moved_120'):
 n=100 if scenario=='changed_100' else 120
 shape=BRepPrimAPI_MakeBox(10,7,9).Shape()
 other=BRepPrimAPI_MakeBox(10.1,7,9).Shape() if scenario=='changed_100' else shape
 a=[part(shape,i*30,'OLD' if scenario=='changed_100' else 'P') for i in range(n)]
 b=[part(other,i*30+(4 if scenario=='moved_120' else 0),'NEW' if scenario=='changed_100' else 'P') for i in range(n)]
 durations=[]
 for _ in range(3):
  start=time.perf_counter();records=compare(a,b,**({'revision_only':True} if fast else {}));records=classify_revisions(a,b,records);durations.append(time.perf_counter()-start)
 results[scenario]={'median_seconds':statistics.median(durations),'runs':durations,'statuses':dict(Counter(r.status for r in records)),'pairs':[(r.a_index,r.b_index,r.status) for r in records]}
print(json.dumps(results))
