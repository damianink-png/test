"""Reproducible synthetic before/after benchmark. Run from the source root."""
import sys,json,time,statistics,importlib.util,platform
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from dsac29 import assignment,compare
from dsac29.geometry import describe
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.gp import gp_Trsf,gp_Vec
from OCP.TopLoc import TopLoc_Location

def reference(name):
    spec=importlib.util.spec_from_file_location('dsac29._bench_'+name,ROOT/'benchmarks/reference_10'/f'{name}.py')
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module);return module

def main():
    old=reference('compare');old_assign=reference('assignment').assign;new_assign=assignment.assign
    shape=BRepPrimAPI_MakeBox(17,11,9).Shape()
    def parts(y):
        out=[]
        for i in range(180):
            t=gp_Trsf();t.SetTranslation(gp_Vec(i*40,y,0));out.append(describe(shape.Located(TopLoc_Location(t)),'P','P'))
        return out
    a,b=parts(0),parts(100);results={};snapshots={}
    for label,fn,solver in [('before',old.compare,old_assign),('after',compare.compare,new_assign)]:
        timings=[];assignment_times=[]
        assignment.assign=solver
        try:
            for run in range(3):
                start=time.perf_counter();rows=fn(a,b,revision_only=True,exact_serialization=True);timings.append(time.perf_counter()-start)
                snapshots[label]=[(r.a_index,r.b_index,r.status,r.rotation_deg) for r in rows]
                edges={(i,i):.1 for i in range(10000)}
                start=time.perf_counter();solver(edges);assignment_times.append(time.perf_counter()-start)
        finally:assignment.assign=new_assign
        results[label]={'matching_180_s':statistics.median(timings),'assignment_10000_s':statistics.median(assignment_times),'matching_runs_s':timings,'assignment_runs_s':assignment_times}
    assert snapshots['before']==snapshots['after'],'Pairing/status regression'
    results.update(equal_results=True,python=platform.python_version(),platform=platform.platform(),repeats=3,
        scope='Synthetic matching and assignment only, excludes STEP parsing, alignment, export and reports')
    print(json.dumps(results,indent=2))
if __name__=='__main__':main()
