"""Static isometric edge thumbnails; never used as evidence in comparison."""
import json,math
from pathlib import Path
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_EDGE
from OCP.TopoDS import TopoDS
from OCP.BRepAdaptor import BRepAdaptor_Curve
from OCP.GeomAbs import GeomAbs_Line

def make_thumbnail(parts,path,max_edges=6000):
    lines=[];truncated=False;errors=0;seen=set()
    for part in parts:
        ex=TopExp_Explorer(part.shape,TopAbs_EDGE)
        while ex.More():
            edge=TopoDS.Edge_s(ex.Current());ex.Next()
            # Hash is only for drawing deduplication; no comparison depends on this image.
            key=hash(edge)
            if key in seen:continue
            seen.add(key)
            if len(lines)>=max_edges:truncated=True;break
            try:
                curve=BRepAdaptor_Curve(edge);a,b=curve.FirstParameter(),curve.LastParameter()
                if not all(math.isfinite(v) for v in (a,b)):continue
                n=2 if curve.GetType()==GeomAbs_Line else 14
                line=[]
                for i in range(n):
                    p=curve.Value(a+(b-a)*i/(n-1))
                    line.append([round((p.X()-p.Y())*.70710678,5),round((p.X()+p.Y())*.40824829-p.Z()*.81649658,5)])
                lines.append(line)
            except Exception:errors+=1
        if truncated:break
    data={'lines':lines,'truncated':truncated,'edge_errors':errors,'parts':len(parts)}
    Path(path).write_text(json.dumps(data,separators=(',',':')),encoding='utf-8')
    return data
