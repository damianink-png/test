"""Minimal high-contrast 24x24 vector icons, shared between light and dark UI.

All controls use one geometric language: rounded 1.75px strokes, a 24px
viewbox, equal optical scale, and crisp HiDPI output. No external font files.
"""
from PySide6.QtGui import QIcon, QPainter, QPixmap
from PySide6.QtCore import Qt, QSize
from PySide6.QtSvg import QSvgRenderer

_PATHS = {
 'info': '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7v1"/>',
 'compare': '<rect x="3" y="4" width="8" height="8" rx="2"/><rect x="13" y="12" width="8" height="8" rx="2"/><path d="M11 8h4l-2-2m2 2-2 2M13 16H9l2-2m-2 2 2 2"/>',
 'mass': '<path d="M5 7h14l2 13H3L5 7Z"/><path d="M9 7V5a3 3 0 0 1 6 0v2"/><path d="M10 15h4"/>',
 'settings': '<path d="M4 7h16M4 12h16M4 17h16"/><circle cx="9" cy="7" r="2" fill="currentColor" stroke="none"/><circle cx="16" cy="12" r="2" fill="currentColor" stroke="none"/><circle cx="11" cy="17" r="2" fill="currentColor" stroke="none"/>',
 'run': '<path d="m9 5 10 7-10 7V5Z"/>',
 'cancel': '<circle cx="12" cy="12" r="9"/><path d="m9 9 6 6m0-6-6 6"/>',
 'file': '<path d="M7 3h7l5 5v12a1 1 0 0 1-1 1H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z"/><path d="M14 3v6h5"/>',
 'folder': '<path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10H3V7Z"/>',
 'report': '<path d="M6 3h9l4 4v14H6zM15 3v5h4M9 12h6m-6 4h7"/>',
 'csv': '<path d="M6 3h9l4 4v14H6zM15 3v5h4M9 13h6m-6 4h6"/>',
 'bom': '<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M4 10h16M11 10v10"/>',
 'swap': '<path d="M4 8h16m-4-4 4 4-4 4M20 16H4m4-4-4 4 4 4"/>',
 'refresh': '<path d="M20 11a8 8 0 0 0-14-5L4 8m0-5v5h5M4 13a8 8 0 0 0 14 5l2-2m0 5v-5h-5"/>',
 'colors': '<path d="M12 3a9 9 0 1 0 0 18h2a2 2 0 0 0 1-4 2 2 0 0 1 1-3h1a4 4 0 0 0 4-4A9 9 0 0 0 12 3Z"/><circle cx="8" cy="11" r=".7" fill="currentColor" stroke="none"/><circle cx="11" cy="7" r=".7" fill="currentColor" stroke="none"/><circle cx="16" cy="9" r=".7" fill="currentColor" stroke="none"/>',
 'cache': '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
 'trash': '<path d="M4 7h16M9 7V4h6v3m3 0-1 13H7L6 7M10 11v6m4-6v6"/>',
}

def vector_icon(kind, ink='#2563eb'):
    path=_PATHS.get(kind,_PATHS['file'])
    xml=(f'<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" '
         f'fill="none" color="{ink}" stroke="{ink}" stroke-width="1.75" stroke-linecap="round" '
         f'stroke-linejoin="round">{path}</svg>')
    pix=QPixmap(72,72);pix.fill(Qt.transparent)
    painter=QPainter(pix);painter.setRenderHint(QPainter.Antialiasing)
    QSvgRenderer(xml.encode('utf-8')).render(painter);painter.end()
    pix.setDevicePixelRatio(3)
    return QIcon(pix)

def set_action(button,kind,color='#2563eb',size=20):
    button.setIcon(vector_icon(kind,color))
    button.setIconSize(QSize(size,size))
    button.setProperty('ds_icon_role',kind)
    return button
