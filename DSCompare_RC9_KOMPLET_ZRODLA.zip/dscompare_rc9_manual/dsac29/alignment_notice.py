"""Explain frame normalization separately from actual component movement."""
import math

def alignment_notice(info):
    vector=info.get('translation_B_to_A_mm')
    valid=isinstance(vector,(list,tuple)) and len(vector)==3
    if valid:
        try:valid=all(math.isfinite(float(v)) for v in vector)
        except (TypeError,ValueError):valid=False
    if valid and any(abs(float(v))>1e-8 for v in vector):
        axes='; '.join(f'Δ{axis} = {float(v):+.4f} mm' for axis,v in zip('XYZ',vector))
        if info.get('applied'):
            return ('Wykryto globalne przesunięcie. Wyrównanie B → A: '+axes+
                    '. Statusy części opisują różnice po wyrównaniu.')
        if info.get('status')=='original_by_user':
            return ('Wykryto możliwe przesunięcie B → A: '+axes+
                    '. Zachowano oryginalne położenie zgodnie z Twoją decyzją.')
    if str(info.get('status','')).startswith('unresolved'):
        return str(info.get('reason') or 'Nie udało się jednoznacznie potwierdzić przesunięcia. Zachowano oryginalne położenie.')
    return ''
