"""Real Open CASCADE B-Rep comparison; NO calls to the ZW3D process/API."""
from __future__ import annotations
from dataclasses import dataclass
from itertools import permutations, product
import math
import numpy as np
from OCP.TopoDS import TopoDS_Shape
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut, BRepAlgoAPI_Common
from OCP.BRepBuilderAPI import BRepBuilderAPI_Transform
from OCP.BRepBndLib import BRepBndLib
from OCP.Bnd import Bnd_Box
from OCP.gp import gp_Trsf


@dataclass
class SolidInfo:
    shape: TopoDS_Shape
    name: str
    path: str
    volume: float
    area: float
    center: np.ndarray
    inertia: np.ndarray
    eigenvalues: np.ndarray
    axes: np.ndarray
    bbox: tuple[float, float, float]
    source: str = ''
    name_origin: str = 'explicit'


def describe(shape: TopoDS_Shape, name: str, path: str, source: str = '') -> SolidInfo:
    if shape.IsNull():
        raise ValueError('Null B-Rep')
    v = GProp_GProps(); BRepGProp.VolumeProperties_s(shape, v)
    a = GProp_GProps(); BRepGProp.SurfaceProperties_s(shape, a)
    c = v.CentreOfMass(); center = np.array([c.X(), c.Y(), c.Z()], dtype=float)
    m = v.MatrixOfInertia()
    mat = np.array([[m.Value(i, j) for j in range(1, 4)] for i in range(1, 4)], dtype=float)
    eig, axes = np.linalg.eigh(mat)
    ix = np.argsort(eig)
    eig, axes = eig[ix], axes[:, ix]
    bb = Bnd_Box(); BRepBndLib.Add_s(shape, bb)
    x0, y0, z0, x1, y1, z1 = bb.Get()
    bbox = (x1-x0, y1-y0, z1-z0)
    if v.Mass() <= 0:
        raise ValueError(f'Bryla {path} ma zerowa/ujemna objetosc')
    return SolidInfo(shape, name, path, float(v.Mass()), float(a.Mass()), center,
                     mat, eig, axes, bbox, source)


def close(a: float, b: float, abs_tol: float, relative: float = 1e-7) -> bool:
    return abs(a-b) <= max(abs_tol, relative * max(abs(a), abs(b)))


def candidate(a: SolidInfo, b: SolidInfo, tolerance: float = 0.01) -> bool:
    # Pre-filter independent of placement and orientation.
    return (close(a.volume, b.volume, max(tolerance**3, 1e-5))
            and close(a.area, b.area, max(tolerance*tolerance, 1e-4))
            and np.allclose(a.eigenvalues, b.eigenvalues, rtol=1e-6,
                            atol=max(1e-3, tolerance**5)))


def _gp_transformation(rotation: np.ndarray, offset: np.ndarray) -> gp_Trsf:
    R = rotation; t = offset
    tr = gp_Trsf()
    tr.SetValues(float(R[0,0]),float(R[0,1]),float(R[0,2]),float(t[0]),
                 float(R[1,0]),float(R[1,1]),float(R[1,2]),float(t[1]),
                 float(R[2,0]),float(R[2,1]),float(R[2,2]),float(t[2]))
    return tr


def transform(shape: TopoDS_Shape, rotation: np.ndarray, offset: np.ndarray) -> TopoDS_Shape:
    tr=_gp_transformation(rotation,offset)
    if np.allclose(rotation.T@rotation,np.eye(3),rtol=0,atol=1e-12) and np.linalg.det(rotation)>0:
        # Rigid transforms are placements, not new trimmed CAD surfaces.
        from OCP.TopLoc import TopLoc_Location
        return shape.Moved(TopLoc_Location(tr))
    return BRepBuilderAPI_Transform(shape,tr,True).Shape()


def _cut_volume(a: TopoDS_Shape, b: TopoDS_Shape, tolerance: float) -> float:
    from .boolean_ops import configured
    cutter = configured(BRepAlgoAPI_Cut,a,b,tolerance)
    cutter.Build()
    if not cutter.IsDone():
        raise RuntimeError('Open CASCADE: operacja BRepAlgoAPI_Cut nie powiodla sie')
    g = GProp_GProps()
    BRepGProp.VolumeProperties_s(cutter.Shape(), g)
    return max(0.0, float(g.Mass()))


def difference(a: TopoDS_Shape, b: TopoDS_Shape, tolerance: float = 0.01) -> tuple[float, float]:
    """Volumes A minus B, B minus A in mm^3. Caller handles tolerance/geometry caveats."""
    return _cut_volume(a, b, tolerance), _cut_volume(b, a, tolerance)


def _common_volume(a: TopoDS_Shape, b: TopoDS_Shape, tolerance: float) -> float:
    """One Boolean intersection replaces two expensive cuts in equality checks.

    For two valid solid volumes, |A ∩ B| ~= |A| ~= |B| implies volume equivalence.
    True topology/feature identity is NOT inferred from volume alone.
    """
    from .boolean_ops import configured
    common = configured(BRepAlgoAPI_Common,a,b,tolerance)
    common.Build()
    if not common.IsDone():
        raise RuntimeError('Open CASCADE: Common failed')
    props = GProp_GProps()
    BRepGProp.VolumeProperties_s(common.Shape(), props)
    return max(0., float(props.Mass()))


def _is_common_equal(a: TopoDS_Shape, b: TopoDS_Shape, volume_a: float,
                     volume_b: float, tolerance: float) -> bool:
    if a.IsSame(b):
        return True
    vtol = max(tolerance**3, 1e-4, min(volume_a, volume_b) * 1e-7)
    try:
        c = _common_volume(a, b, tolerance)
    except RuntimeError as common_error:
        # Some imported STEP solids fail OCCT's Common although two directional
        # Cuts can still be computed reliably. These are independent Boolean
        # checks, not a volume/area/name heuristic: both A\B and B\A must
        # be below the same tolerance before a match is ever accepted.
        try:
            ab = _cut_volume(a, b, tolerance)
            if ab > vtol:
                return False
            ba = _cut_volume(b, a, tolerance)
            return ba <= vtol
        except Exception as cut_error:
            raise RuntimeError(
                f'Open CASCADE: Common failed; independent Cut fallback also failed '
                f'({cut_error})') from common_error
    return max(abs(volume_a - c), abs(volume_b - c)) <= vtol


def equivalent_world(a: SolidInfo, b: SolidInfo, tolerance: float = 0.01) -> bool:
    if not candidate(a,b,tolerance): return False
    if np.linalg.norm(a.center-b.center)>tolerance: return False
    return _is_common_equal(a.shape, b.shape, a.volume, b.volume, tolerance)


def _basis_rotations(a: SolidInfo, b: SolidInfo):
    # Proper sign/permutation matrices cover the 24 eigenframe orientation choices.
    # Permutations of distinct eigenvalues must not be used (they would swap unequal moments).
    for perm in permutations(range(3)):
        if any(not close(a.eigenvalues[i], b.eigenvalues[perm[i]], 1e-3, 1e-6)
               for i in range(3)):
            continue
        for signs in product((-1.0,1.0), repeat=3):
            p = np.zeros((3,3))
            for i,j in enumerate(perm): p[i,j]=signs[i]
            R = a.axes @ p @ b.axes.T
            if np.linalg.det(R)<0.99: continue
            yield R


def _precise_world_bounds(shape: TopoDS_Shape) -> np.ndarray:
    """Conservative exact-geometry axis-aligned bounds, independent of faces/vertices.

    Unlike native topology, the *solid's* world-space AABB is necessary for
    equality even if two STEP files split the same surface into different faces.
    Disjoint bounds after a proposed rigid transform PROVE that transform cannot
    align the solids. Numerical slack is applied by _bounds_compatible.
    """
    bounds = Bnd_Box()
    BRepBndLib.AddOptimal_s(shape, bounds, False, False)
    return np.asarray(bounds.Get(), dtype=float)


def _bounds_compatible(reference: np.ndarray, candidate_bounds: np.ndarray,
                       tolerance: float) -> bool:
    # A small safety margin beyond the CAD tolerance avoids false negatives
    # from floating-point transforms and geometric trim precision.
    slack = max(2.0 * tolerance, 1e-5)
    return bool(np.all(np.abs(reference-candidate_bounds) <= slack))


def equivalent_rigid(a: SolidInfo, b: SolidInfo, tolerance: float = 0.01,
                     max_trials: int = 24) -> tuple[bool, np.ndarray | None, np.ndarray | None]:
    """Test proper rigid congruence without letting one failed Boolean end the search.

    AABB rejection is a necessary *geometrical* condition, not a topological or
    name-based shortcut. For compatible placements, only the original precise
    OCCT Boolean tests can establish a positive match. Failed Boolean trials
    remain inconclusive, and are reported if no conclusive outcome exists.
    """
    if not candidate(a, b, tolerance): return False, None, None
    bounds = _precise_world_bounds(a.shape)
    attempts_with_failed_brep = []
    checked_rotations = set()

    def try_transform(R):
        # Multiple eigenframe choices can yield the same placement. Avoid
        # repeated native B-Rep work for numerically identical candidates.
        key = tuple(np.round(R.ravel(), 9))
        if key in checked_rotations: return None
        checked_rotations.add(key)
        t = a.center - R @ b.center
        moved = transform(b.shape, R, t)
        if not _bounds_compatible(bounds, _precise_world_bounds(moved), tolerance):
            return None
        try:
            if _is_common_equal(a.shape, moved, a.volume, b.volume, tolerance):
                return (True, R, t)
        except Exception as exc:
            # OCCT Common/Cut can fail for coplanar imported surfaces. Before
            # flagging this as unresolved, seek a *negative-only* CAD surface
            # witness. It NEVER establishes equality; successful comparisons
            # still require the original exact Boolean proof above.
            try:
                from .surface_witness import definitely_different_surfaces
                if definitely_different_surfaces(a.shape, moved, tolerance):
                    return None  # definitively not equal in this orientation
                from .surface_witness import independent_surface_identity
                if independent_surface_identity(a.shape, moved):
                    return (True, R, t)  # 100-nm surface + exact CAD face proof
            except Exception:
                pass  # an inconclusive mesh must remain an explicit warning
            attempts_with_failed_brep.append(str(exc))
        return None

    for R in [np.eye(3), *_basis_rotations(a, b)]:
        result = try_transform(R)
        if result is not None: return result
    # Repeated inertia eigenvalues yield underdetermined principal axes.
    # Retain vertex frame search rather than introducing false negatives.
    for trial, R in enumerate(_vertex_rotations(a, b, tolerance)):
        result = try_transform(R)
        if result is not None: return result
        if trial >= max_trials*4: break
    if attempts_with_failed_brep:
        # Never turn a plausible failed B-Rep comparison into a guessed match
        # or a silently false negative. The caller marks BOM incomplete.
        raise RuntimeError('Open CASCADE: brak rozstrzygnięcia po sprawdzeniu '
                           f'{len(attempts_with_failed_brep)} zgodnych obwiedni; '
                           + attempts_with_failed_brep[0])
    return False, None, None


def _vertex_rotations(a,b,tolerance):
    from OCP.TopAbs import TopAbs_VERTEX
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopoDS import TopoDS
    from OCP.BRep import BRep_Tool
    def points(part):
        vals=[];seen=set();ex=TopExp_Explorer(part.shape,TopAbs_VERTEX)
        while ex.More():
            p=BRep_Tool.Pnt_s(TopoDS.Vertex_s(ex.Current()))
            v=np.array([p.X(),p.Y(),p.Z()])-part.center
            key=tuple(np.round(v,7))
            if key not in seen:seen.add(key);vals.append(v)
            ex.Next()
        return sorted(vals,key=lambda x:-np.linalg.norm(x))[:128]
    aa,bb=points(a),points(b)
    if len(aa)<2 or len(bb)<2:return
    u=aa[0];nu=np.linalg.norm(u)
    if nu<1e-9:return
    v=max(aa,key=lambda x:np.linalg.norm(np.cross(u,x)))
    nv=np.linalg.norm(v)
    if np.linalg.norm(np.cross(u,v))<1e-8:return
    def frame(x,y):
        e=x/np.linalg.norm(x);f=y-e*np.dot(e,y);f/=np.linalg.norm(f)
        return np.column_stack((e,f,np.cross(e,f)))
    basis=frame(u,v)
    for x in bb:
        if abs(np.linalg.norm(x)-nu)>max(1e-5,tolerance):continue
        for y in bb:
            if abs(np.linalg.norm(y)-nv)>max(1e-5,tolerance):continue
            if abs(np.dot(x,y)-np.dot(u,v))>max(1e-4,tolerance*(nu+nv)):continue
            if np.linalg.norm(np.cross(x,y))<1e-8:continue
            yield basis@frame(x,y).T


def signature(s: SolidInfo) -> tuple:
    # Only a candidate index; this is NOT proof of equal geometry.
    return (round(s.volume,3),round(s.area,3),
            *[round(float(v),2) for v in s.eigenvalues])


def dist(a: SolidInfo,b: SolidInfo) -> float:
    return float(np.linalg.norm(a.center-b.center))

class DescriptionCache:
    """Reuse exact native geometry properties under rigid occurrence placements."""
    def __init__(self):
        self.entries={};self.hits=0
    def describe(self,shape,name,path,source=''):
        from OCP.TopLoc import TopLoc_Location
        tr=shape.Location().Transformation()
        rotation=np.array([[tr.Value(i,j) for j in range(1,4)] for i in range(1,4)])
        # Scale and reflection retain the ordinary full description path.
        if not np.allclose(rotation.T@rotation,np.eye(3),rtol=0,atol=1e-12) or np.linalg.det(rotation)<0:
            return describe(shape,name,path,source)
        local=shape.Located(TopLoc_Location());key=(hash(local),int(local.Orientation()))
        base=None
        for stored,info in self.entries.get(key,()):
            if local.IsSame(stored):base=info;self.hits+=1;break
        if base is None:
            base=describe(local,name,path,source)
            self.entries.setdefault(key,[]).append((local,base))
        delta=np.array([tr.Value(i,4) for i in range(1,4)])
        if np.array_equal(rotation,np.eye(3)):bbox=base.bbox
        else:
            bound=Bnd_Box();BRepBndLib.Add_s(shape,bound)
            x0,y0,z0,x1,y1,z1=bound.Get();bbox=(x1-x0,y1-y0,z1-z0)
        return SolidInfo(shape,name,path,base.volume,base.area,rotation@base.center+delta,
                         rotation@base.inertia@rotation.T,base.eigenvalues.copy(),
                         rotation@base.axes,bbox,source)
