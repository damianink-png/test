"""Atomic, complete change report independent of optional BOM grouping."""
import html
from collections import Counter
from pathlib import Path


def write_quick_report(path,headers,rows,a,b,records,density,full_bom,step_error,context=None):
    from .report import STATUS_PL
    counts=Counter(r.status for r in records)
    status=' · '.join(f'{STATUS_PL[k]}: {v}' for k,v in sorted(counts.items()))
    mass_a=sum(p.volume for p in a)*density*1e-9;mass_b=sum(p.volume for p in b)*density*1e-9
    headings=''.join('<th>'+html.escape(h)+'</th>' for h in headers)
    body=''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in row)+'</tr>' for row in rows)
    source_a=Path(a[0].source).name if a and a[0].source else 'A'
    source_b=Path(b[0].source).name if b and b[0].source else 'B'
    context=context or {}
    source_a=context.get('A',source_a);source_b=context.get('B',source_b)
    omitted=sum(v.get('faces_outside_solids',0) for v in context.get('import',{}).values())
    scope=f' Pominięto {omitted} powierzchni poza bryłami (A+B).' if omitted else ''
    alignment=context.get('alignment',{}).get('warning','')
    notice='Pełny BOM jest przygotowywany osobno; ten raport zmian jest już kompletny.' if full_bom else 'Pełny BOM wyłączony. Raport obejmuje wszystkie wyniki porównania.'
    error='<p role="alert">Błąd STEP: '+html.escape(step_error)+'</p>' if step_error else ''
    page=f'''<!doctype html><html lang="pl"><meta charset="utf-8"><title>DS Compare — raport zmian</title>
<style>body{{font:15px system-ui;margin:24px;color:#172539;background:#f4f7fc}}table{{border-collapse:collapse;background:white}}td,th{{border:1px solid #cad3df;padding:8px;text-align:left}}th{{background:#e7edf7}}input{{padding:10px;min-width:300px}}</style>
<h1>Porównanie rewizji — raport zmian</h1><p>A: {html.escape(source_a)} → B: {html.escape(source_b)}</p>
<p>{html.escape(status)}</p><p>Bryły A: {len(a)} · B: {len(b)}</p>
<p>Masa A: {mass_a:.3f} kg · B: {mass_b:.3f} kg · Różnica: {mass_b-mass_a:+.3f} kg</p>
<p>Gęstość wspólna: {density:g} kg/m³. Analiza obejmuje bryły SOLID.{scope}</p><p>{html.escape(alignment)}</p>
<p>{notice}</p>{error}<input id="search" placeholder="Szukaj części lub rodzaju zmiany…"><p id="count"></p>
<div style="overflow:auto"><table><thead><tr>{headings}</tr></thead><tbody>{body}</tbody></table></div>
<script>const q=document.getElementById('search'),rows=[...document.querySelectorAll('tbody tr')];function filter(){{let n=0;for(const r of rows){{r.hidden=!r.textContent.toLocaleLowerCase('pl').includes(q.value.toLocaleLowerCase('pl'));if(!r.hidden)n++;}}document.getElementById('count').textContent='Pozycji: '+n+' / '+rows.length;}}q.addEventListener('input',filter);filter();</script></html>'''
    tmp=path.with_suffix('.html.tmp');tmp.write_text(page,encoding='utf-8');tmp.replace(path)
