"""Conservative, validated rigid whole-assembly registration.

Only an explicitly requested alignment transforms B into A coordinates.
Pure translations can be established from two anchors or from a single
unique solid in a single-solid assembly; ambiguous multi-part transformations
raise AlignmentUnavailable. All hypotheses require B-Rep world verification.
"""
from collections import defaultdict
import numpy as np
from .geometry import equivalent_rigid,equivalent_world,transform,describe,signature

class AlignmentUnavailable(ValueError):
    """Not enough consistent, geometrically verified assembly anchors."""

def _relocate(part, rotation, offset):
    """Apply ONE assembly transform; pure translation preserves native shape sharing.

    Volume, area, inertia about COM, eigenvectors and AABB dimensions are
    translation-invariant. Only placement and center change. Rotations retain
    the existing full geometric description path.
    """
    if np.array_equal(rotation,np.eye(3)):
        from dataclasses import replace
        from OCP.gp import gp_Trsf,gp_Vec
        from OCP.TopLoc import TopLoc_Location
        tr=gp_Trsf();tr.SetTranslation(gp_Vec(*map(float,offset)))
        return replace(part,shape=part.shape.Moved(TopLoc_Location(tr)),center=part.center+offset)
    result=describe(transform(part.shape,rotation,offset),part.name,part.path,part.source)
    result.name_origin=part.name_origin
    return result

def align_assembly(a,b,tolerance=0.01,progress=None):
    """Anchors propose a frame; the whole assembly must support that frame."""
    from .registration_gate import frame_support
    # When the existing frame has a B-Rep-confirmed majority, inspect
    # translations FIRST. Unique-anchor rigid checks can otherwise spend a
    # very long time solving a transform that is not needed at all.
    initial=frame_support(a,b,tolerance,proofs=12)
    if (initial['ratio']>=.60 and initial['checked']>=min(2,min(len(a),len(b)))
            and initial['proofs']==initial['checked']):
        try:
            aligned,info=_align_repeated_translation(a,b,tolerance,progress,
                                                     already_aligned=initial)
            if info.get('status')=='already_aligned':
                return b,info
            support=frame_support(a,aligned,tolerance,proofs=12)
            if (support['count']>initial['count'] and support['ratio']>=.60
                    and support['proofs']==support['checked']):
                info['whole_assembly_support']=support
                return aligned,info
        except AlignmentUnavailable:
            # A real, proven world-frame majority is not a failure just because
            # multiple candidate translations are ambiguous.
            if progress:progress('Wyrównanie: zachowano potwierdzony aktualny układ CAD.')
            return b,{'requested':True,'enabled':True,'status':'already_aligned',
                      'method':'world_brep_consensus','votes':initial['count'],
                      'rotation_B_to_A':np.eye(3).tolist(),
                      'translation_B_to_A_mm':[0.,0.,0.]}
    # A fast partial B-Rep consensus is preferable to thousands of rigid
    # anchor trials when most components changed between large revisions.
    if initial['ratio']<.60 and min(len(a),len(b))>=40:
        try:
            return _align_sparse_translation(a,b,tolerance,progress)
        except AlignmentUnavailable:
            pass
    try:
        aligned,info=_align_anchors(a,b,tolerance,progress)
    except AlignmentUnavailable:
        try:
            return _align_repeated_translation(a,b,tolerance,progress)
        except AlignmentUnavailable as exc:
            # A large assembly can share a small but independently verifiable
            # subset of its components. Requiring 60% for registration makes
            # such revisions impossible to align, although their frame is real.
            return _align_sparse_translation(a,b,tolerance,progress,previous=exc)
    support=frame_support(a,aligned,tolerance,verify_all=True)
    if support['ratio']>=.60 and support['count']>=min(2,min(len(a),len(b))):
        info['whole_assembly_support']=support
        return aligned,info
    if progress:progress(f"Bazy nie reprezentują całego złożenia ({support['count']}/{min(len(a),len(b))}). Szukanie wspólnego przesunięcia wszystkich części…")
    try:
        return _align_repeated_translation(a,b,tolerance,progress)
    except AlignmentUnavailable as exc:
        return _align_sparse_translation(a,b,tolerance,progress,previous=exc)

def _align_anchors(a,b,tolerance=0.01,progress=None):
    names_a=defaultdict(list);names_b=defaultdict(list)
    for i,part in enumerate(a):names_a[part.name].append(i)
    for j,part in enumerate(b):names_b[part.name].append(j)
    pairs=[(items[0],names_b[name][0]) for name,items in names_a.items()
           if len(items)==1 and len(names_b.get(name,()))==1]
    signatures_a=defaultdict(list);signatures_b=defaultdict(list)
    for i,p in enumerate(a):signatures_a[signature(p)].append(i)
    for j,p in enumerate(b):signatures_b[signature(p)].append(j)
    used_a={i for i,j in pairs};used_b={j for i,j in pairs}
    for key,ids in signatures_a.items():
        if len(ids)!=1 or len(signatures_b.get(key,()))!=1:continue
        pair=(ids[0],signatures_b[key][0])
        if pair[0] not in used_a and pair[1] not in used_b:
            pairs.append(pair);used_a.add(pair[0]);used_b.add(pair[1])
    verified=[];rigid_proofs={}
    for i,j in pairs:
        if progress:progress(f'Wyrównanie: weryfikacja wspólnych baz {len(verified)+1}/{len(pairs)}')
        proof=equivalent_rigid(a[i],b[j],tolerance)
        if proof[0]:
            verified.append((i,j));rigid_proofs[i,j]=proof
    pairs=sorted(verified,key=lambda ij:-a[ij[0]].volume)
    if not pairs or (len(pairs)==1 and (len(a)!=1 or len(b)!=1)):
        # ZW3D can supply many identical, anonymously named occurrences.
        # Use majority registration, with physical B-Rep proof.
        raise AlignmentUnavailable('Brak wystarczających unikalnych baz; wymagany konsensus złożenia.')
    def score(R,t):
        supporting=[]
        for i,j in pairs:
            if np.linalg.norm(a[i].center-(R@b[j].center+t))>max(0.0001,tolerance):
                continue
            aligned=_relocate(b[j],R,t)
            if equivalent_world(a[i],aligned,tolerance):
                supporting.append((i,j))
        return supporting

    identity=np.eye(3)
    identity_votes=sum(equivalent_world(a[i],b[j],tolerance) for i,j in pairs)
    min_votes=1 if len(a)==len(b)==len(pairs)==1 else 2
    if identity_votes>=min_votes and identity_votes/len(pairs)>=0.6:
        if progress:progress('Wyrównanie: bazowy układ współrzędnych jest już zgodny.')
        return b,{'requested':True,'enabled':True,'status':'already_aligned',
                  'anchors':len(pairs),'votes':identity_votes,
                  'rotation_B_to_A':identity.tolist(),'translation_B_to_A_mm':[0.0,0.0,0.0]}

    candidates=[]
    # Pure translation needs neither three anchors nor non-collinear centroids.
    # A single anchor is accepted ONLY when each input contains one solid.
    for i,j in pairs[:16]:
        offset=np.asarray(a[i].center-b[j].center,dtype=float)
        candidates.append(('translation',identity,offset,i,j))
    if len(pairs)>=3:
        pa=np.array([a[i].center for i,j in pairs],dtype=float)
        pb=np.array([b[j].center for i,j in pairs],dtype=float)
        ca=pa.mean(axis=0);cb=pb.mean(axis=0)
        if np.linalg.matrix_rank(pb-cb,tol=max(tolerance,1.e-6))>=2:
            U,_,Vt=np.linalg.svd((pb-cb).T@(pa-ca))
            D=np.eye(3);D[-1,-1]=np.linalg.det(Vt.T@U.T)
            rotation=Vt.T@D@U.T;offset=ca-rotation@cb
            candidates.append(('rigid_kabsch',rotation,offset,pairs[0][0],pairs[0][1]))
        # Robust hypotheses: a genuinely moved part must not bias the global
        # least-squares fit. Each non-collinear triple proposes ONE transform;
        # the same majority and world B-Rep checks below decide acceptance.
        from itertools import combinations
        anchor_sample=pairs if len(pairs)<=12 else [pairs[round(k*(len(pairs)-1)/11)] for k in range(12)]
        for triple in combinations(anchor_sample,3):
            pa3=np.array([a[i].center for i,j in triple])
            pb3=np.array([b[j].center for i,j in triple])
            ca3=pa3.mean(axis=0);cb3=pb3.mean(axis=0)
            if np.linalg.matrix_rank(pb3-cb3,tol=max(tolerance,1.e-6))<2:continue
            U3,_,V3=np.linalg.svd((pb3-cb3).T@(pa3-ca3))
            D3=np.eye(3);D3[-1,-1]=np.linalg.det(V3.T@U3.T)
            R3=V3.T@D3@U3.T;t3=ca3-R3@cb3
            candidates.append(('rigid_consensus',R3,t3,*triple[0]))
        for i,j in pairs[:12]:
            same,rotation,offset=rigid_proofs[i,j]
            if same:candidates.append(('rigid_anchor',rotation,offset,i,j))
    if not candidates:
        raise AlignmentUnavailable('Nie uzyskano zgodnej transformacji B do A.')

    ranked=[]
    unique=[]
    extent=max((np.linalg.norm(p.center) for p in b),default=0.)
    for method,R,t,i,j in candidates:
        # Skip numerically equivalent poses only with a whole-assembly displacement bound.
        if any(np.linalg.norm(R-Q,ord=2)*extent+np.linalg.norm(t-u)<max(1e-10,tolerance*1e-6) for Q,u in unique):continue
        unique.append((R,t))
        coarse=sum(np.linalg.norm(a[ai].center-(R@b[bj].center+t))<=max(.0001,tolerance) for ai,bj in pairs)
        if coarse<min_votes or coarse/len(pairs)<.6:continue
        supported=score(R,t)
        if len(supported)>=min_votes and len(supported)/len(pairs)>=0.6:
            ranked.append((len(supported),method,R,t,i,j))
    if not ranked:
        raise AlignmentUnavailable('Brak transformacji potwierdzonej przez większość wspólnych części.')
    ranked.sort(key=lambda value:(-value[0],0 if value[1]=='translation' else 1))
    votes,method,R,t,i,j=ranked[0]
    # Equal-score transforms affecting entire assembly differently are
    # dangerous. Do not quietly pick an arbitrary symmetric registration.
    for other_votes,_,Q,u,_,_ in ranked[1:]:
        if other_votes!=votes:break
        if not np.allclose(R,Q,atol=1e-6) or np.linalg.norm(t-u)>max(tolerance,1e-4):
            raise AlignmentUnavailable('Równorzędne sprzeczne transformacje; wyrównanie jest niejednoznaczne.')
    aligned=[]
    for original in b:
        p=_relocate(original,R,t)
        p.name_origin=original.name_origin
        aligned.append(p)
    # Verify original parts did not lose shape/count after applying transform.
    if len(aligned)!=len(b):
        raise RuntimeError('Niespójna liczba części po wyrównaniu.')
    info={'requested':True,'enabled':True,'status':'registered',
          'method':method,'votes':votes,'anchors':len(pairs),
          'rotation_B_to_A':R.tolist(),'translation_B_to_A_mm':t.tolist(),
          'coordinate_system':'B transformed into A coordinates before comparison and STEP export'}
    if progress:progress(f'Wyrównano B do A: {votes}/{len(pairs)} sprawdzonych baz; translacja [mm]: {np.round(t,3).tolist()}')
    return aligned,info


def _align_repeated_translation(a,b,tolerance,progress=None,already_aligned=None):
    """Conservative world-BRep translation consensus for repeated shapes.

    Hypotheses from descriptors/positions are only candidates; every accepted
    hypothesis must be backed by OCC B-Rep world equality after relocation.
    """
    from collections import Counter,defaultdict
    from math import ceil
    from .geometry import candidate
    if min(len(a),len(b))<2:
        raise AlignmentUnavailable('Za mało niezależnych elementów.')
    sig_a=defaultdict(list);sig_b=defaultdict(list)
    for i,p in enumerate(a):sig_a[signature(p)].append(i)
    for j,p in enumerate(b):sig_b[signature(p)].append(j)
    common=set(sig_a).intersection(sig_b)
    if not common:
        raise AlignmentUnavailable('Brak wspólnych charakterystyk brył.')
    def sample(ids,max_count=7):
        if len(ids)<=max_count:return ids
        return [ids[round(k*(len(ids)-1)/(max_count-1))] for k in range(max_count)]
    proposals={}
    # Anchor hypotheses preferentially on uncommon signature groups; one
    # rare feature is usually more informative than hundreds of identical bolts.
    # Bound the number of frames: the old unbounded ~900 x all-parts ranking
    # could look frozen on large imported CAD assemblies.
    limit=192
    for key in sorted(common,key=lambda k:(len(sig_a[k])*len(sig_b[k]),str(k))):
        for i in sample(sig_a[key]):
            for j in sample(sig_b[key]):
                if not candidate(a[i],b[j],tolerance):continue
                shift=np.asarray(a[i].center-b[j].center,dtype=float)
                proposals[tuple(np.round(shift,4))]=shift
                if len(proposals)>=limit:break
            if len(proposals)>=limit:break
        if len(proposals)>=limit:break
    # Equal-size revisions often share a clear global centroid delta. This
    # is ONLY a proposed offset and must still win the same B-Rep gate.
    if len(a)==len(b):
        mean_delta=np.mean([p.center for p in a],axis=0)-np.mean([p.center for p in b],axis=0)
        proposals[tuple(np.round(mean_delta,4))]=mean_delta
    # Always score the original CAD frame for a safe 'no shift' answer.
    proposals[(0.,0.,0.)]=np.zeros(3)
    if not proposals:
        raise AlignmentUnavailable('Nie uzyskano hipotez przemieszczenia.')
    # Rank by tolerance-aware spatial proximity, not equality of rounded cells.
    # Rounded-cell equality discarded valid matches close to a cell boundary.
    from .compare import _spatial_index,_nearby
    from types import SimpleNamespace
    cell_size=max(tolerance,1.e-6)
    cells=_spatial_index(a,range(len(a)),cell_size)
    ranked=[]
    from time import perf_counter
    ranked_start=perf_counter()
    for proposal_index,translation in enumerate(proposals.values()):
        seen=set();votes=0
        for part in b:
            center=part.center+translation
            for i in _nearby(cells,SimpleNamespace(center=center),cell_size):
                if i in seen or np.linalg.norm(a[i].center-center)>tolerance:continue
                if not candidate(a[i],part,tolerance):continue
                seen.add(i);votes+=1;break
        ranked.append((votes,tuple(float(x) for x in translation)))
        if progress and proposal_index and proposal_index%48==0:
            progress(f'Wyrównanie: sprawdzono {proposal_index+1}/{len(proposals)} ustawień w {perf_counter()-ranked_start:.1f} s')
    ranked.sort(key=lambda x:(-x[0],x[1]))
    if already_aligned is not None:
        # If no candidate improves on the independently B-Rep-confirmed
        # original pose, there is no reason to run hundreds of native Booleans.
        baseline=int(already_aligned['count'])
        best_raw=ranked[0][0]
        if best_raw<=baseline:
            if progress:progress(f'Wyrównanie: już zgodne ({baseline} brył w układzie CAD), brak lepszego przesunięcia.')
            return b,{'requested':True,'enabled':True,'status':'already_aligned',
                      'method':'world_brep_consensus','votes':baseline,
                      'rotation_B_to_A':np.eye(3).tolist(),
                      'translation_B_to_A_mm':[0.,0.,0.]}
    candidates=[]
    for rawvotes,offset in ranked:
        if len(candidates)>=5:break
        if rawvotes<max(2,ceil(.6*min(len(a),len(b)))):break
        if any(np.linalg.norm(np.asarray(offset)-np.asarray(old[1]))<=tolerance/10 for old in candidates):continue
        candidates.append((rawvotes,offset))
    if not candidates:
        raise AlignmentUnavailable('Powtarzalne części nie tworzą większości zgodnej z jednym przesunięciem.')
    identity=np.eye(3)
    winners=[]
    for votes,offset in candidates:
        t=np.asarray(offset,dtype=float)
        accepted=0;seen=set()
        for p in b:
            new=_relocate(p,identity,t)
            indices=_nearby(cells,new,max(tolerance,1.e-6))
            for i in indices:
                if i in seen:continue
                if np.linalg.norm(a[i].center-new.center)>tolerance:continue
                if not candidate(a[i],new,tolerance):continue
                if equivalent_world(a[i],new,tolerance):
                    accepted+=1;seen.add(i);break

        required=max(2,ceil(.60*min(len(a),len(b))))
        if accepted>=required:winners.append((accepted,tuple(offset)))
    if not winners:
        raise AlignmentUnavailable('Hipotezy przesunięcia nie przeszły potwierdzenia B-Rep.')
    if len(a)==len(b):
        centroid_shift=(np.mean([p.center for p in a],axis=0)
                        -np.mean([p.center for p in b],axis=0))
        winners.sort(key=lambda x:(-x[0],np.linalg.norm(np.asarray(x[1])-centroid_shift)))
    else:
        centroid_shift=None
        winners.sort(key=lambda x:-x[0])
    best_score,offset=winners[0]
    for score,other in winners[1:]:
        if score!=best_score:break
        if np.linalg.norm(np.asarray(offset)-np.asarray(other))>tolerance:
            best_delta=(np.linalg.norm(np.asarray(offset)-centroid_shift)
                        if centroid_shift is not None else float('inf'))
            other_delta=(np.linalg.norm(np.asarray(other)-centroid_shift)
                         if centroid_shift is not None else float('inf'))
            if centroid_shift is None or best_delta>other_delta*.5 or other_delta-best_delta<max(10*tolerance,0.5):
                raise AlignmentUnavailable('Wiele równorzędnych przesunięć; nie można bezpiecznie wybrać jednego.')
    if progress:
        progress(f'Wyrównanie powtarzalnych brył: {best_score} potwierdzonych dopasowań, przesunięcie {list(np.round(offset,3))} mm')
    aligned=[_relocate(p,identity,np.asarray(offset,dtype=float)) for p in b]
    return aligned,{'requested':True,'enabled':True,'status':'registered',
                    'method':'repeated_translation_consensus','votes':best_score,
                    'rotation_B_to_A':np.eye(3).tolist(),
                    'translation_B_to_A_mm':list(offset),
                    'coordinate_system':'B transformed into A before geometry matching and STEP export'}


def _align_sparse_translation(a,b,tolerance,progress=None,previous=None):
    """Conservative *partial* global translation consensus for large revisions.

    Never infers equality or frame from a CAD name, volume, or centroid alone.
    A repeated-shape candidate is accepted only with many independent WORLD
    B-Rep matches, a genuinely better frame, and no near-equal alternative.
    A weak/ambiguous result retains AlignmentUnavailable, not guessed colors.
    """
    from collections import defaultdict
    from math import ceil
    from .geometry import candidate
    from .compare import _spatial_index,_nearby
    from .registration_gate import frame_support
    from types import SimpleNamespace
    pop=min(len(a),len(b))
    required=max(8,ceil(.15*pop))
    if pop<40:
        raise AlignmentUnavailable(str(previous or 'Za mało brył do częściowego konsensusu.'))
    sa=defaultdict(list);sb=defaultdict(list)
    for i,p in enumerate(a):sa[signature(p)].append(i)
    for j,p in enumerate(b):sb[signature(p)].append(j)
    common=sa.keys() & sb.keys()
    if not common:
        raise AlignmentUnavailable(str(previous or 'Nie znaleziono wspólnych brył.'))

    # Each shape family votes for translations. Balanced sampling includes
    # first and last occurrences, not merely the first occurrences of a
    # periodically repeated profile. Quantized offsets are proposals ONLY.
    histogram=defaultdict(lambda:[0,None])
    def sample(ids,maxcount=13):
        if len(ids)<=maxcount:return ids
        return list(dict.fromkeys(ids[round(k*(len(ids)-1)/(maxcount-1))]
                                  for k in range(maxcount)))
    for key in sorted(common,key=lambda k:(len(sa[k])*len(sb[k]),str(k))):
        for i in sample(sa[key]):
            for j in sample(sb[key]):
                if not candidate(a[i],b[j],tolerance):continue
                t=np.asarray(a[i].center-b[j].center,dtype=float)
                quant=tuple(int(round(float(v)/max(tolerance*.1,1.e-4))) for v in t)
                pair=histogram[quant]
                pair[0]+=1
                if pair[1] is None:pair[1]=t
    if not histogram:
        raise AlignmentUnavailable(str(previous or 'Brak hipotez przesunięcia.'))
    hints=sorted(histogram.values(),key=lambda val:-val[0])[:min(48,len(histogram))]
    # RC9 robust consensus: prioritize translation candidates supported by
    # independent rare signature families; do NOT infer SAME from this vote.
    try:
        from .robust_translation import Anchor, propose_translation
        aa=[Anchor(i,signature(p),tuple(float(v) for v in p.center))
            for i,p in enumerate(a)]
        bb=[Anchor(j,signature(p),tuple(float(v) for v in p.center))
            for j,p in enumerate(b)]
        proposal=propose_translation(
            aa,bb,tolerance=tolerance,
            min_support=max(3,min(12,required)),
            max_signature_multiplicity=4)
        if proposal is not None:
            t=np.asarray(proposal.shift,dtype=float)
            hints=[[proposal.support,t]] + [
                h for h in hints
                if np.linalg.norm(h[1]-t)>tolerance]
            hints=hints[:48]
            if progress: progress(
                f'Wyrównanie: odporny konsensus {proposal.support} par; '
                'weryfikacja B-Rep pozostaje obowiązkowa.')
    except (ValueError,TypeError,KeyError) as exc:
        if progress:progress(f'Wyrównanie: pominięto konsensus sygnatur ({exc}).')

    original=frame_support(a,b,tolerance,proofs=12)
    cell_size=max(tolerance,1.e-6)
    cells=_spatial_index(a,range(len(a)),cell_size)
    ranked=[]
    for _,translation in hints:
        visited=set();matches=[]
        for j,part in enumerate(b):
            center=part.center+translation
            for i in _nearby(cells,SimpleNamespace(center=center),cell_size):
                if i in visited or np.linalg.norm(a[i].center-center)>tolerance:continue
                if not candidate(a[i],part,tolerance):continue
                visited.add(i);matches.append((i,j));break
        if len(matches)>=required:
            ranked.append((len(matches),translation,matches))
    if not ranked:
        raise AlignmentUnavailable(str(previous or 'Zbyt mało powtarzalnych wspólnych detali.'))
    ranked.sort(key=lambda v:-v[0])
    if progress:
        progress(f'Wyrównanie częściowych rewizji: najlepszy kandydat '
                 f'{ranked[0][0]}/{pop} pozycji, wymagane {required}.')
    # A dominant candidate must pass native B-Rep. Check alternative frames
    # when their coarse support could rival the winner; never rely on names.
    winners=[]
    for coarse,offset,matches in ranked[:12]:
        if len(winners)>=3 and coarse<winners[0][0]*.75:break
        verified=0;seen=[]
        for i,j in matches:
            moved=_relocate(b[j],np.eye(3),offset)
            if equivalent_world(a[i],moved,tolerance):
                verified+=1;seen.append((i,j))
        if verified>=required:
            winners.append((verified,offset,seen))
    if not winners:
        raise AlignmentUnavailable('Kandydaty przesunięcia nie przeszły kontroli B-Rep.')
    winners.sort(key=lambda val:-val[0])
    best,offset,proofs=winners[0]
    # If two plausible placements match similarly many elements, the whole
    # assembly cannot be safely placed by local repetition (pitch ambiguity).
    for other_score,other_offset,_ in winners[1:]:
        if np.linalg.norm(offset-other_offset)<=tolerance:continue
        if other_score>=best-max(4,ceil(.08*best)):
            raise AlignmentUnavailable('Dwa przesunięcia mają porównywalne potwierdzenie B-Rep.')
    aligned=[_relocate(p,np.eye(3),offset) for p in b]
    final=frame_support(a,aligned,tolerance,proofs=12)
    required_gain=max(3,ceil(.04*pop))
    if (final['count']<required or final['count']<original['count']+required_gain
            or final['checked']<2 or final['proofs']!=final['checked']):
        raise AlignmentUnavailable('Nie potwierdzono poprawy wyrównania całego złożenia.')
    info={'requested':True,'enabled':True,'status':'registered',
          'method':'partial_world_brep_consensus', 'votes':best,
          'verified_world_matches':final['count'],
          'previous_world_matches':original['count'],
          'rotation_B_to_A':np.eye(3).tolist(),
          'translation_B_to_A_mm':[float(v) for v in offset],
          'coordinate_system':'B transformed into A before geometry matching and STEP export'}
    if progress:
        progress(f'Potwierdzono częściowe przesunięcie: {best} dopasowań B-Rep, '
                 f'{original["count"]} → {final["count"]} brył, '
                 f'translacja {np.round(offset,3).tolist()} mm.')
    return aligned,info
