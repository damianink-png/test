"""R11.16 native PySide6 UI. No changes to the CAD comparison algorithms.

Visual controls are re-parented from the established GUI46 widget contract so
QProcess, polling, settings, reports, mass and file handling remain operational.
"""
from __future__ import annotations
import json, os, sys, math, time
from pathlib import Path
from PySide6.QtCore import Qt, QTimer, QSize, QRectF, QPointF, QEvent
from PySide6.QtGui import QColor, QPainter, QPen, QBrush, QFont, QGuiApplication
from PySide6.QtWidgets import (QWidget,QDialog,QVBoxLayout,QHBoxLayout,QGridLayout,QFormLayout,
    QFrame,QLabel,QPushButton,QSizePolicy,QTableWidget,QTableWidgetItem,QProgressBar,QCheckBox,QComboBox,
    QAbstractItemView,QMessageBox,QScrollArea,QHeaderView,QToolButton,QAbstractSpinBox)
from .icons_r119 import vector_icon,set_action
from .gui46 import Window as PreviousWindow

ACCENT='#1677F7'
DARK={'bg':'#0B1119','surface':'#151D28','field':'#202B39','hover':'#283A50','line':'#344353','ink':'#F5F7FC','muted':'#ACB9CB','accent':'#1677F7','soft':'#183459'}
LIGHT={'bg':'#E5ECF4','surface':'#FFFFFF','field':'#E9F0FA','hover':'#DDEAFB','line':'#ABBED3','ink':'#15243A','muted':'#4C6079','accent':'#1268D8','soft':'#D8E8FA'}

def skin(dark):
 p=DARK if dark else LIGHT
 return '''
 QWidget{background:BG;color:INK;font-family:"Segoe UI";font-size:13px;}
 QWidget#page{background:BG;}
 QLabel{background:transparent;}
 QLabel#brand{font-size:21px;font-weight:650;letter-spacing:2px;}
 QLabel#hero{font-size:19px;font-weight:600;}
 QLabel#muted,QLabel#sub{color:MUTED;}
 QLabel#section{font-size:15px;font-weight:600;}
 QLabel#large-stat{font-size:23px;font-weight:700;}
 QFrame#topbar{border:0;border-bottom:1px solid LINE;background:SURFACE;border-radius:0;}
 QFrame#navigation-row{border:0;border-bottom:1px solid LINE;background:SURFACE;border-radius:0;}
 QFrame#topbar QLabel{background:transparent;}
 QFrame#settings-card QLabel{background:transparent;}
 QFrame#settings-card,QFrame#file-card,QFrame#surface,QFrame#success{border:1px solid LINE;background:SURFACE;border-radius:15px;}
 QFrame#file-card,QFrame#surface,QFrame#settings-card,QFrame#success{background:SURFACE;border:1px solid LINE;border-radius:17px;}
 QFrame#file-card:hover{border:1px solid ACCENT;background:FIELD;}
 QFrame#file-card[hasFile="true"]{border:1px solid ACCENT;background:SURFACE;}
 QFrame#mass-drop[hasFiles="true"]{border:1px solid ACCENT;background:SURFACE;}
 QFrame#success{border:1px solid LINE;background:SURFACE;}
 QLabel#chosen-file{font-size:14px;font-weight:650;color:INK;}
 QLabel#result-figure{font-size:16px;font-weight:650;color:INK;}
 QLabel#global-activity{color:ACCENT;font-size:12px;font-weight:600;min-height:25px;padding:2px 8px;background:SOFT;border-radius:8px;}
 QProgressBar#global-activity-progress{max-height:4px;min-height:4px;border-radius:2px;background:LINE;}
 QProgressBar#global-activity-progress::chunk{background:ACCENT;border-radius:2px;}
 QWidget#mass-queue-actions{background:transparent;border:0;}
 QWidget#mass-file-row{background:FIELD;border:1px solid LINE;border-radius:8px;}
 QWidget#mass-file-row:hover{background:HOVER;border-color:LINE;}
 QWidget#mass-file-row[selected="true"]{background:ACCENT;border:1px solid ACCENT;border-radius:8px;}
 QLabel#mass-row-label{background:transparent;color:INK;}
 QLabel#mass-row-label[massSelected="true"]{background:transparent;color:#FFFFFF;font-weight:650;}
 QPushButton#delete-one[massSelected="true"]{background:transparent;color:#FFFFFF;border:0;}
 QPushButton#delete-one[massSelected="true"]:hover{background:#FFFFFF;color:#1268D8;border-radius:7px;}
 QListWidget#mass-input-list{padding:3px;border:1px solid LINE;border-radius:11px;background:SURFACE;outline:0;}
 QListWidget#mass-input-list::item{border:0;padding:0;margin:0;background:transparent;}
 QListWidget#mass-input-list::item:selected{background:transparent;border:0;outline:0;}
 QListWidget#mass-input-list QScrollBar:vertical{background:SURFACE;border:0;width:7px;margin:3px 0;}
 QListWidget#mass-input-list QScrollBar::handle:vertical{background:LINE;border-radius:3px;min-height:24px;}
 QListWidget#mass-input-list QScrollBar::add-line:vertical,QListWidget#mass-input-list QScrollBar::sub-line:vertical{height:0;}
 QListWidget#mass-input-list QScrollBar::add-page:vertical,QListWidget#mass-input-list QScrollBar::sub-page:vertical{background:transparent;}
 QPushButton#delete-one{background:transparent;border:0;border-radius:7px;color:MUTED;min-width:30px;max-width:30px;min-height:30px;max-height:30px;padding:0;font-size:20px;}
 QPushButton#delete-one:hover{background:HOVER;color:ACCENT;}
 QFrame#details{background:transparent;border:0;}
 QPushButton{background:FIELD;border:1px solid LINE;border-radius:9px;min-height:29px;padding:7px 13px;}
 QPushButton:hover{background:HOVER;border-color:ACCENT;}
 QPushButton:pressed{background:SOFT;}
 QPushButton:disabled{background:FIELD;color:MUTED;border-color:LINE;}
 QPushButton#primary{background:ACCENT;color:#FFFFFF;border:1px solid ACCENT;font-size:14px;font-weight:650;border-radius:10px;min-height:36px;padding:7px 24px;}
 QPushButton#primary:hover{background:#2D8AFF;border-color:#2D8AFF;}
 QPushButton#primary:disabled{background:SOFT;color:MUTED;border-color:LINE;}
 QPushButton#nav{background:FIELD;border:1px solid LINE;border-radius:11px;padding:10px 17px;min-height:27px;}
 QPushButton#nav:hover{background:HOVER;border:1px solid ACCENT;}
 QPushButton#nav:checked{color:ACCENT;border:1px solid ACCENT;border-radius:11px;background:SOFT;font-weight:650;}
 QPushButton#theme-toggle,QPushButton#info-btn{background:transparent;border:1px solid LINE;border-radius:18px;max-width:34px;min-width:34px;min-height:34px;max-height:34px;padding:0;}
 QPushButton#theme-toggle:hover,QPushButton#info-btn:hover{background:HOVER;border-color:ACCENT;}
 QPushButton#text-button{background:transparent;border:0;color:MUTED;padding:5px 8px;min-height:24px;}
 QPushButton#text-button:hover{color:ACCENT;background:HOVER;}
 QPushButton#mass-clear{background:FIELD;color:INK;border:1px solid LINE;border-radius:9px;}
 QPushButton#mass-clear:hover{background:ACCENT;color:#FFFFFF;border:1px solid ACCENT;font-weight:700;}
 QPushButton#mass-clear:pressed{background:SOFT;color:INK;border-color:ACCENT;}
 QLineEdit,QDoubleSpinBox,QSpinBox,QComboBox{border:1px solid LINE;border-radius:8px;background:FIELD;color:INK;padding:6px 9px;min-height:26px;selection-background-color:ACCENT;}
 QLineEdit:focus,QComboBox:focus,QDoubleSpinBox:focus{border-color:ACCENT;}
 QFrame#numeric-control{border:1px solid LINE;border-radius:8px;background:FIELD;}
 QToolButton#numeric-step{border:0;border-radius:6px;background:transparent;color:INK;font-size:19px;font-weight:600;padding:0;}
 QToolButton#numeric-step:hover{background:HOVER;color:ACCENT;}
 QToolButton#numeric-step:pressed{background:SOFT;}
 QToolButton#numeric-step:disabled{color:MUTED;}
 QComboBox QAbstractItemView{background:SURFACE;color:INK;border:1px solid LINE;outline:0;selection-background-color:SOFT;selection-color:INK;}
 QComboBox::drop-down{border:0;background:transparent;min-width:21px;}
 QComboBox QAbstractItemView::item{min-height:27px;padding:5px 8px;}
 QScrollArea#page-scroll{background:BG;border:0;}
 QFrame#mass-drop{background:SURFACE;border:2px dashed LINE;border-radius:15px;}
 QFrame#mass-drop[dragActive="true"]{background:SOFT;border:2px dashed ACCENT;}
 QListWidget{background:FIELD;color:INK;border:1px solid LINE;border-radius:8px;}
 QTableWidget{background:SURFACE;alternate-background-color:FIELD;border:1px solid LINE;border-radius:10px;gridline-color:transparent;selection-background-color:SOFT;selection-color:INK;}
 QHeaderView::section{background:FIELD;color:MUTED;border:0;border-bottom:1px solid LINE;font-weight:600;padding:8px;}
 QProgressBar{background:LINE;border:0;border-radius:4px;max-height:7px;min-height:7px;}
 QProgressBar::chunk{background:ACCENT;border-radius:4px;}
 QCheckBox,QRadioButton{spacing:9px;padding:4px 2px;background:transparent;color:INK;}
 QCheckBox:hover,QRadioButton:hover{background:transparent;}
 QCheckBox::indicator,QRadioButton::indicator{width:17px;height:17px;border:2px solid MUTED;border-radius:5px;background:FIELD;}
 QRadioButton::indicator{border-radius:10px;}
 QCheckBox::indicator:checked,QRadioButton::indicator:checked{background:ACCENT;border:2px solid ACCENT;}
 QCheckBox::indicator:hover,QRadioButton::indicator:hover{border:2px solid ACCENT;}
 QCheckBox::indicator:disabled,QRadioButton::indicator:disabled{border:2px solid LINE;background:FIELD;}
 QCheckBox:checked,QCheckBox:disabled,QRadioButton:checked{background:transparent;}
 QToolTip{background:SURFACE;color:INK;border:1px solid LINE;}
 QDialog{background:BG;}
 '''.replace('BG',p['bg']).replace('SURFACE',p['surface']).replace('FIELD',p['field']).replace('HOVER',p['hover']).replace('LINE',p['line']).replace('INK',p['ink']).replace('MUTED',p['muted']).replace('ACCENT',p['accent']).replace('SOFT',p['soft'])

def build_version():
 """Version is produced by packaging workflow, not encoded in Qt layouts."""
 root=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parents[1]))
 for candidate in (root/'build_info.json',root/'dsac29'/'build_info.json'):
  try:
   info=json.loads(candidate.read_text(encoding='utf8'))
   return str(info.get('version') or 'wersja deweloperska')
  except (OSError,ValueError):pass
 return 'wersja deweloperska'

class CompareLogo(QWidget):
 """Tiny paint-only nonblocking DS + overlapping cubes animation, 30 fps."""
 def __init__(self,parent=None):
  super().__init__(parent);self._frame=0;self.setMinimumSize(270,256)
  self._ticker=QTimer(self);self._ticker.setInterval(33);self._ticker.timeout.connect(self.tick)
 def start(self):
  self._frame=0;self._ticker.start()
 def stop(self):self._ticker.stop()
 def tick(self):
  self._frame=min(102,self._frame+1);self.update()
  if self._frame>=102:self._ticker.stop()
 def paintEvent(self,event):
  p=QPainter(self);p.setRenderHint(QPainter.Antialiasing)
  dark=self.window().property('ds_dark') is True
  color=QColor('#EFF5FF' if dark else '#172338');muted=QColor('#A7B7C9' if dark else '#72839C')
  blue=QColor('#2686FF');w=self.width();scale=min(max(0.1,(w-16)/380.0),max(0.1,(self.height()-12)/322.0));p.translate(w/2,max(6,(self.height()-322*scale)/2));p.scale(scale,scale)
  p.setPen(color)
  ds=QFont('Segoe UI Light',76);ds.setWeight(QFont.Light);p.setFont(ds)
  a=min(1,self._frame/24);p.setOpacity(a);p.drawText(QRectF(-165,2,330,112),Qt.AlignCenter,'DS');p.setOpacity(1)
  p.setPen(muted);font=QFont('Segoe UI',14);font.setLetterSpacing(QFont.AbsoluteSpacing,7);p.setFont(font)
  p.setOpacity(max(0,min(1,(self._frame-20)/22)));p.drawText(QRectF(-170,123,340,29),Qt.AlignCenter,'COMPARE');p.setOpacity(1)
  p.translate(0,238)
  def cube(x,y,c):
   p.setPen(QPen(c,2.1))
   points=[QPointF(x-37,y-15),QPointF(x,y-37),QPointF(x+37,y-15),QPointF(x+37,y+30),QPointF(x,y+52),QPointF(x-37,y+30)]
   for ids in ((0,1,2,3,4,5,0),(0,3),(1,4),(2,5)):
    for j in range(len(ids)-1):p.drawLine(points[ids[j]],points[ids[j+1]])
  pos=min(1,max(0,(self._frame-30)/65));ease=pos*pos*(3-2*pos)
  p.setOpacity(min(1,max(0,(self._frame-25)/18)))
  # Overlapping, zooming wireframe cubes, no final blue circle.
  for index,(start,c) in enumerate(((-83,muted),(83,blue))):
   p.save();p.translate(start*(1-ease),0);p.scale(1+.22*ease,1+.22*ease)
   p.setOpacity(.7 if index==0 else .9)
   cube(0,-1,c);p.restore()
  p.setOpacity(1)
  p.end()

class AboutWindow(QDialog):
 def __init__(self,parent):
  super().__init__(parent);self.setModal(True);self.setProperty('ds_dark',parent.theme.currentText()=='Ciemny')
  self.setWindowTitle('O programie — DS Compare 1.0');self.setObjectName('about-window')
  self.setStyleSheet(skin(bool(self.property('ds_dark'))))
  self.setMinimumSize(340,360)
  screen=parent.screen() or QGuiApplication.primaryScreen()
  area=screen.availableGeometry() if screen else None
  self.resize(min(540,area.width()-32) if area else 540,
              min(700,area.height()-48) if area else 700)
  layout=QVBoxLayout(self);layout.setContentsMargins(0,0,0,0)
  scroll=QScrollArea(self);scroll.setWidgetResizable(True);scroll.setFrameShape(QFrame.NoFrame)
  scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  body=QWidget();content=QVBoxLayout(body)
  content.setContentsMargins(28,20,28,24);content.setSpacing(12)
  heading=QLabel('O programie');heading.setObjectName('section');heading.setAlignment(Qt.AlignCenter)
  content.addWidget(heading)
  self.logo=CompareLogo(self);content.addWidget(self.logo)
  caption=QLabel('Porównywanie geometrii CAD');caption.setAlignment(Qt.AlignCenter)
  caption.setWordWrap(True);caption.setObjectName('section');content.addWidget(caption)
  self.version_label=QLabel('Wersja 1.0');self.version_label.setAlignment(Qt.AlignCenter)
  self.version_label.setObjectName('muted');content.addWidget(self.version_label)
  details=QFrame();details.setObjectName('surface');grid=QVBoxLayout(details)
  grid.setContentsMargins(18,16,18,16);grid.setSpacing(7)
  for key,value in (('Autor','Damian Szymczyk'),('Technologia','Python · PySide6 · Open CASCADE (OCP)'),('Formaty','STEP / STP · eksport z ZW3D 2019')):
   lhs=QLabel(key);lhs.setObjectName('muted');lhs.setAlignment(Qt.AlignCenter)
   rhs=QLabel(value);rhs.setAlignment(Qt.AlignCenter);rhs.setWordWrap(True)
   grid.addWidget(lhs);grid.addWidget(rhs)
   if key!='Formaty':grid.addSpacing(8)
  content.addWidget(details)
  cr=QLabel('© 2026 Damian Szymczyk');cr.setObjectName('muted')
  cr.setAlignment(Qt.AlignCenter);content.addWidget(cr)
  content.addStretch(1);scroll.setWidget(body);layout.addWidget(scroll)
 def showEvent(self,event):
  super().showEvent(event);self.logo.start()
 def closeEvent(self,event):self.logo.stop();super().closeEvent(event)
 def accept(self):self.logo.stop();super().accept()

class MassRowWidget(QWidget):
 """Clickable mass-list row with explicit, theme-safe selected background."""
 def __init__(self,owner,item):
  super().__init__()
  self._owner=owner
  self._item=item
  self.setAttribute(Qt.WA_StyledBackground,True)
 def paintEvent(self,event):
  # QWidget item-widget QSS selection does not paint reliably on Windows.
  # Paint the entire row ourselves; labels/buttons paint above this layer.
  dark=self._owner.theme.currentText()=='Ciemny'
  palette=DARK if dark else LIGHT
  selected=bool(self._item.isSelected())
  hover=self.underMouse() and not selected
  fill=QColor(palette['accent'] if selected else
              (palette['hover'] if hover else palette['field']))
  border=QColor(palette['accent'] if selected else palette['line'])
  painter=QPainter(self)
  painter.setRenderHint(QPainter.Antialiasing)
  painter.setPen(QPen(border,1.2))
  painter.setBrush(QBrush(fill))
  painter.drawRoundedRect(QRectF(self.rect()).adjusted(1,1,-1,-1),7.5,7.5)
  painter.end()
 def enterEvent(self,event):
  self.update();super().enterEvent(event)
 def leaveEvent(self,event):
  self.update();super().leaveEvent(event)
 def mousePressEvent(self,event):
  if event.button()==Qt.LeftButton:
   self._owner._mass_toggle_row(self._item,event.modifiers())
   event.accept()
  else:super().mousePressEvent(event)

class NumberControl(QFrame):
 """Explicit +/- buttons avoid native spin subcontrol painting on Windows."""
 def __init__(self,spin,label):
  super().__init__();self.setObjectName('numeric-control');self.spin=spin
  row=QHBoxLayout(self);row.setContentsMargins(5,3,5,3);row.setSpacing(4)
  self.minus=QToolButton(self);self.plus=QToolButton(self)
  for button,text,verb,slot in ((self.minus,'−','Zmniejsz',spin.stepDown),(self.plus,'+','Zwiększ',spin.stepUp)):
   button.setObjectName('numeric-step');button.setText(text);button.setFixedSize(30,30)
   button.setAccessibleName(verb+': '+label);button.setToolTip(verb+' wartość')
   button.setAutoRepeat(True);button.clicked.connect(slot)
  spin.setButtonSymbols(QAbstractSpinBox.NoButtons);spin.setMinimumWidth(70)
  spin.setStyleSheet('QAbstractSpinBox{border:0;background:transparent;padding:0;min-height:26px;} QLineEdit{border:0;background:transparent;padding:0;min-width:50px;}')
  spin.setAccessibleName(label);spin.setAlignment(Qt.AlignCenter)
  row.addWidget(self.minus);row.addWidget(spin,1);row.addWidget(self.plus)
  self.setFocusProxy(spin);spin.valueChanged.connect(self._sync)
  spin.installEventFilter(self);self._sync()
 def _sync(self,*args):
  enabled=self.spin.isEnabled() and not self.spin.isReadOnly()
  self.minus.setEnabled(enabled and self.spin.value()>self.spin.minimum())
  self.plus.setEnabled(enabled and self.spin.value()<self.spin.maximum())
 def eventFilter(self,obj,event):
  if event.type() in (QEvent.EnabledChange,QEvent.ReadOnlyChange):self._sync()
  return super().eventFilter(obj,event)

class ModernWindow(PreviousWindow):
 populate_legacy_mass_table=False
 def __init__(self,a='',b=''):
  super().__init__(a,b)
  self.setWindowTitle('DS Compare — porównywanie geometrii CAD')
  self.setMinimumSize(740,540)
  self._install_deferred_settings_signals()
  self._modern_topbar();self._modern_compare();self._modern_mass();self._modern_settings()
  self._center_form_fields()
  self._scroll_page('compare')
  self._init_adaptive_window()
  self.theme.setCurrentText(str(self.store.value('theme46','Ciemny')) if str(self.store.value('theme46','Ciemny')) in ('Ciemny','Jasny') else 'Ciemny')
  self.apply_theme(self.theme.currentText())
  self._install_settings_transactions()
  self.navigate('compare')
  self._refresh_outputs()
 def resizeEvent(self,event):
  super().resizeEvent(event)
  if hasattr(self,'_settings_grid'):
   self._reflow_settings(event.size().width())

 def _reflow_settings(self,width):
  if not hasattr(self,'_settings_grid'):return
  narrow=width<1050
  if self._settings_stacked==narrow:return
  grid=self._settings_grid
  compare=self._settings_compare_card
  report=self._settings_report_card
  grid.removeWidget(compare)
  grid.removeWidget(report)
  if narrow:
   grid.addWidget(compare,0,0,1,1)
   grid.addWidget(report,1,0,1,1)
   grid.setColumnStretch(0,1);grid.setColumnStretch(1,0)
  else:
   grid.addWidget(compare,0,0,1,1)
   grid.addWidget(report,0,1,1,1)
   grid.setColumnStretch(0,1);grid.setColumnStretch(1,1)
  self._settings_stacked=narrow
  grid.invalidate()

 def _init_adaptive_window(self):
  from PySide6.QtGui import QGuiApplication
  screen=self.screen() or QGuiApplication.primaryScreen()
  if screen is None:
   self.setMinimumSize(740,520);self.resize(1120,730);return
  area=screen.availableGeometry()
  # Work with Qt's logical pixels (also on Windows display scaling).
  min_w=min(980,max(560,area.width()-48))
  min_h=min(740,max(480,area.height()-54))
  self.setMinimumSize(min_w,min_h)
  width=max(min_w,min(1240,int(area.width()*.89)))
  height=max(min_h,min(870,int(area.height()*.92)))
  self.resize(width,height)
  rect=self.frameGeometry()
  rect.moveCenter(area.center())
  self.move(rect.topLeft())
  self._reflow_settings(self.width())

 def _new_page(self,key):
  old=self.pages[key]
  self.stack.removeWidget(old);old.hide();self._legacy_pages=getattr(self,'_legacy_pages',{});self._legacy_pages[key]=old
  page=QWidget();page.setObjectName('page');page.setMinimumSize(0,0)
  pos={'compare':0,'mass':1,'settings':2}[key]
  self.stack.insertWidget(pos,page);self.pages[key]=page
  layout=QVBoxLayout(page);layout.setContentsMargins(24,20,24,16);layout.setSpacing(13)
  return page,layout
 def _modern_topbar(self):
  bar=self.centralWidget().findChild(QFrame,'topbar')
  if bar is None:return
  layout=bar.layout()
  labels=bar.findChildren(QLabel)
  for label in labels:label.hide()
  self.brand_modern=QLabel('DS  C O M P A R E');self.brand_modern.setObjectName('brand')
  layout.insertWidget(0,self.brand_modern)
  self._global_status=QLabel('');self._global_status.setObjectName('global-activity')
  self._global_status.setMinimumWidth(100);self._global_status.setMaximumWidth(220)
  self._global_status.setAlignment(Qt.AlignCenter);self._global_status.hide()
  layout.insertWidget(1,self._global_status)
  self._global_progress=QProgressBar();self._global_progress.setObjectName('global-activity-progress')
  self._global_progress.setTextVisible(False);self._global_progress.setRange(0,0)
  self._global_progress.setFixedWidth(64);self._global_progress.hide()
  layout.insertWidget(2,self._global_progress)
  self.about_button=QPushButton();self.about_button.setObjectName('info-btn');self.about_button.setToolTip('O programie');self.about_button.setAccessibleName('O programie')
  self.about_button.clicked.connect(self.show_about)
  layout.addWidget(self.about_button)
  self._topbar=bar
  # Prevent first tab clipping at 125-200% DPI: navigation gets its own row.
  navhost=QFrame(self.centralWidget());navhost.setObjectName('navigation-row')
  navlayout=QHBoxLayout(navhost);navlayout.setContentsMargins(18,6,18,8);navlayout.setSpacing(9)
  for key in ('compare','mass','settings'):
   b=self.nav[key]
   layout.removeWidget(b);b.setParent(navhost)
   b.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
   b.setMinimumWidth(max(145,b.fontMetrics().horizontalAdvance(b.text())+75))
   b.setMinimumHeight(44)
   navlayout.addWidget(b,1)
  self.centralWidget().layout().insertWidget(1,navhost)
  self._navigation_host=navhost
  self._analysis_busy_banner=QLabel(
   'Trwa analiza — poczekaj na zakończenie. Przełączanie zakładek i zmiana ustawień są chwilowo zablokowane. Możesz użyć „Anuluj”.')
  self._analysis_busy_banner.setObjectName('muted')
  self._analysis_busy_banner.setWordWrap(True)
  self._analysis_busy_banner.setAlignment(Qt.AlignCenter)
  self.centralWidget().layout().insertWidget(2,self._analysis_busy_banner)
  self._analysis_busy_banner.hide()
 def show_about(self):
  dlg=AboutWindow(self);self._about_dialog=dlg;dlg.exec()
 def _tile(self,tile,number):
  # Keep the original FileCard and choose button, but replace its giant tile
  # with a concise, visually distinct selected/empty state.
  from PySide6.QtCore import QSize
  tile.setObjectName('file-card')
  tile.setMinimumHeight(104)
  tile.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
  choose=getattr(tile,'choose_button',None)
  if choose is None:
   choose=next((b for b in tile.findChildren(QPushButton) if 'Wybierz' in b.text()),None)
  if choose is None:raise RuntimeError('Missing CAD file picker')
  tile.choose_button=choose
  layout=tile.layout()
  while layout.count():
   it=layout.takeAt(0)
   if it.layout():
    nested=it.layout()
    while nested.count():
     sub=nested.takeAt(0)
     if sub.widget():sub.widget().setParent(tile)
   elif it.widget():it.widget().hide()
  layout.setContentsMargins(17,13,17,13);layout.setSpacing(5)
  row=QHBoxLayout();row.setSpacing(12)
  emblem=QLabel();emblem.setPixmap(vector_icon('file','#8DA6C9').pixmap(28,28))
  emblem.setFixedSize(32,34);row.addWidget(emblem)
  textcol=QVBoxLayout();textcol.setSpacing(4)
  heading=QLabel('Model '+str(number));heading.setObjectName('section');textcol.addWidget(heading)
  filename=QLabel('Nie wybrano pliku');filename.setObjectName('muted')
  filename.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
  filename.setToolTip('Przeciągnij plik STEP / STP / Z3')
  textcol.addWidget(filename);row.addLayout(textcol,1)
  choose.setText('Wybierz');choose.setAccessibleName('Wybierz model '+str(number))
  choose.setMinimumWidth(88);choose.setMaximumWidth(112)
  choose.setObjectName('text-button')
  row.addWidget(choose,0,Qt.AlignVCenter)
  clear=QPushButton('×');clear.setObjectName('delete-one')
  clear.setToolTip('Usuń wybrany model z porównania')
  clear.setAccessibleName('Usuń model '+str(number))
  clear.clicked.connect(lambda:tile.path.clear() if self.process is None else None)
  row.addWidget(clear,0,Qt.AlignVCenter)
  layout.addLayout(row)
  def refresh(path):
   present=bool(path)
   filename.setText(Path(path).name if present else 'Nie wybrano pliku · STEP / STP / Z3')
   filename.setObjectName('chosen-file' if present else 'muted')
   filename.setToolTip(path or 'Przeciągnij plik STEP / STP / Z3')
   choose.setText('Zmień' if present else 'Wybierz')
   choose.setAccessibleName(('Zmień model ' if present else 'Wybierz model ')+str(number))
   clear.setVisible(present)
   tile.setProperty('hasFile',present)
   tile.style().unpolish(tile);tile.style().polish(tile)
   filename.style().unpolish(filename);filename.style().polish(filename)
  tile.path.textChanged.connect(refresh)
  tile._remove_model_button=clear
  tile._chosen_file_label=filename
  tile._file_refresh=refresh
  tile.path.hide()
  refresh(tile.path.text())

 def _install_deferred_settings_signals(self):
  # All currently visible settings persist only via the new Save button.
  # A few GUI46 controls were connected to QSettings via inline lambdas.
  for widget,signal in (
    (self.solid_limit,'valueChanged'),
    (self.full_bom,'toggled'),
    (self.bom_mode,'currentIndexChanged'),
    (self.bom_csv,'toggled'),
    (self.cache_import,'toggled'),
  ):
   try:getattr(widget,signal).disconnect()
   except (TypeError,RuntimeError):pass
  # Base GUI45 callbacks now call our no-op save_settings while editing.
  # Import cache is a runtime performance control and can be inspected;
  # its application will follow the explicit Save button.

 def _refresh_global_activity(self):
  if not hasattr(self,'_global_status') or self.process is None:return
  kind='Porównywanie' if self.task=='compare' else 'Obliczanie masy'
  elapsed=int(max(0,time.monotonic()-getattr(self,'_activity_started',time.monotonic())))
  self._global_status.setText(f'{kind} · {elapsed//60}:{elapsed%60:02d}')
  source=self.log if self.task=='compare' else self.mass_log
  stage=source.document().lastBlock().text().strip()
  self._global_status.setToolTip((stage or 'Przetwarzanie modeli')[-220:])

 def _set_busy_ui(self,busy):
  # Navigation and cosmetic actions remain available while worker computes.
  # Only operations that change or submit analysis inputs are disabled.
  self._analysis_busy_banner.setVisible(bool(busy))
  self._global_status.setVisible(bool(busy))
  self._global_progress.setVisible(bool(busy))
  if busy:
   self._activity_started=time.monotonic()
   self._refresh_global_activity()
  self._analysis_busy_banner.setText(
   'Trwa analiza — możesz przełączać zakładki i zmieniać motyw. '
   'Zapis ustawień oraz nowe obliczenia są dostępne po zakończeniu.'
   if busy else '')
  for button in self.nav.values():
   button.setEnabled(True)
   button.setToolTip('')
  self.theme_button.setEnabled(True)
  self.about_button.setEnabled(True)
  self._settings_save_button.setEnabled(not busy and self._settings_dirty())
  if hasattr(self,'_settings_cancel_button'):self._settings_cancel_button.setEnabled(self._settings_dirty())
  self._settings_save_button.setToolTip(
   'Zapis ustawień jest wstrzymany do końca analizy.' if busy else
   'Zapisz ustawienia dla kolejnych analiz.')
  for control in (self.run_compare,self.run_mass,self.swap_button,
                  self.a.choose_button,self.b.choose_button):
   control.setEnabled(not busy)
  for card in (self.a,self.b):
   if hasattr(card,'_remove_model_button'):
    card._remove_model_button.setEnabled(not busy)
  # The mass page can remain accessible while another tab is analysing.
  if hasattr(self,'mass_drop'):self._mass_running_controls(busy)
  for name in ('mass_add_files','mass_add_folder','mass_reset','mass_new_button',
               'reset_button','_add_material_button'):
   control=getattr(self,name,None)
   if control is not None:control.setEnabled(not busy)
  if hasattr(self,'mass_remove_selected'):
   self.mass_remove_selected.setEnabled(not busy and bool(self.mass_input_list.selectedItems()))
  if hasattr(self,'mass_input_list'):
   for index in range(self.mass_input_list.count()):
    holder=self.mass_input_list.itemWidget(self.mass_input_list.item(index))
    if holder is not None:
     for control in holder.findChildren(QPushButton):control.setEnabled(not busy)
  # Keep the palette stable while the active analysis is using it.
  self.color_editor.setEnabled(not busy)

 def _settings_snapshot(self):
  return dict(tolerance=self.tolerance.value(),solid_limit=self.solid_limit.value(),
       full_bom=self.full_bom.isChecked(),bom_mode=self.bom_mode.currentIndex(),
       bom_csv=self.bom_csv.isChecked(),cache_import=self.cache_import.isChecked(),
       output=self.output.text(),preview_html=self.preview_html.isChecked(),
       transparency=self.opacity.value(),colors=dict(self.export_colors))
 def _install_settings_transactions(self):
  self._settings_saved=self._settings_snapshot();self._settings_restoring=False
  for widget,signal in ((self.tolerance,'valueChanged'),(self.solid_limit,'valueChanged'),
     (self.full_bom,'toggled'),(self.bom_mode,'currentIndexChanged'),
     (self.bom_csv,'toggled'),(self.cache_import,'toggled'),(self.output,'textChanged'),
     (self.preview_html,'toggled'),(self.opacity,'valueChanged')):
   getattr(widget,signal).connect(self._settings_changed)
  self._settings_changed()
 def _settings_dirty(self):
  return hasattr(self,'_settings_saved') and self._settings_snapshot()!=self._settings_saved
 def _settings_changed(self,*args):
  if getattr(self,'_settings_restoring',False):return
  self.bom_mode.setEnabled(self.full_bom.isChecked())
  self.bom_csv.setEnabled(self.full_bom.isChecked())
  if hasattr(self,'_settings_save_button'):
   dirty=self._settings_dirty()
   self._settings_save_button.setEnabled(dirty and self.process is None)
   self._settings_cancel_button.setEnabled(dirty)
   self._settings_save_feedback.setText('● Niezapisane zmiany' if dirty else '')
 def _settings_revert(self):
  if not hasattr(self,'_settings_saved'):return
  self._settings_restoring=True
  try:
   saved=self._settings_saved
   self.tolerance.setValue(saved['tolerance'])
   self.solid_limit.setValue(saved['solid_limit'])
   self.full_bom.setChecked(saved['full_bom'])
   self.bom_csv.setChecked(saved['bom_csv'])
   self.cache_import.setChecked(saved['cache_import'])
   self.bom_mode.setCurrentIndex(saved['bom_mode'])
   self.output.setText(saved['output'])
   self.preview_html.setChecked(saved['preview_html'])
   self.opacity.setValue(saved['transparency'])
   self.export_colors=dict(saved['colors'])
  finally:self._settings_restoring=False
  self._settings_changed()
 def navigate(self,key):
  if (hasattr(self,'_settings_saved') and key!='settings' and
      self.stack.currentWidget() is self.pages['settings'] and self._settings_dirty()):
   prompt=QMessageBox(self);prompt.setWindowTitle('Niezapisane ustawienia')
   prompt.setIcon(QMessageBox.Question)
   prompt.setText('Zmodyfikowano ustawienia. Co zrobić przed zmianą zakładki?')
   save=prompt.addButton('Zapisz',QMessageBox.AcceptRole)
   discard=prompt.addButton('Odrzuć zmiany',QMessageBox.DestructiveRole)
   stay=prompt.addButton('Pozostań',QMessageBox.RejectRole)
   if self.process is not None:save.setEnabled(False)
   prompt.setDefaultButton(stay);prompt.exec()
   clicked=prompt.clickedButton()
   if clicked is save and self.process is None:
    self._save_settings_explicit()
    if self._settings_dirty():return
   elif clicked is discard:self._settings_revert()
   else:return
  return super().navigate(key)
 def save_settings(self,*args):
  # Legacy change handlers cannot persist without explicit Save.
  return None
 def _save_settings_explicit(self):
  if self.process is not None:return
  super().save_settings()
  for key,value in (('solid_limit',self.solid_limit.value()),
      ('full_bom',self.full_bom.isChecked()),
      ('bom_mode',self.bom_mode.currentData()),
      ('bom_csv',self.bom_csv.isChecked()),
      ('output',self.output.text().strip()),
      ('import_cache',self.cache_import.isChecked()),
      ('preview_html',self.preview_html.isChecked())):
   self.store.setValue(key,value)
  for key,value in self.export_colors.items():self.store.setValue('export_color_'+key,value)
  self.store.sync()
  if self.store.status()!=self.store.Status.NoError:
   QMessageBox.warning(self,'Ustawienia','Nie udało się zapisać ustawień. Sprawdź uprawnienia do zapisu.')
   return
  os.environ['DSCOMPARE_IMPORT_CACHE']='auto' if self.cache_import.isChecked() else 'off'
  self._settings_saved=self._settings_snapshot()
  self._settings_changed()
  self._settings_save_feedback.setText('✓ Zapisano.')
 def choose_output(self):
  from PySide6.QtWidgets import QFileDialog
  selected=QFileDialog.getExistingDirectory(self,'Folder wyników',self.output.text())
  if selected:self.output.setText(selected)
 def closeEvent(self,event):
  if self.process is None and self._settings_dirty():
   answer=QMessageBox.question(self,'Niezapisane ustawienia','Zapisać zmiany ustawień przed zamknięciem?',
       QMessageBox.Save|QMessageBox.Discard|QMessageBox.Cancel,QMessageBox.Cancel)
   if answer==QMessageBox.Cancel:
    event.ignore();return
   if answer==QMessageBox.Save:
    self._save_settings_explicit()
    if self._settings_dirty():
     event.ignore();return
  super().closeEvent(event)
 def _modern_compare(self):
  _,lay=self._new_page('compare')
  title=QLabel('Porównanie rewizji');title.setObjectName('hero')
  title.setAlignment(Qt.AlignCenter);lay.addWidget(title)
  self._compare_hint=QLabel('Wybierz dwa modele CAD')
  self._compare_hint.setObjectName('muted')
  self._compare_hint.setAlignment(Qt.AlignCenter);lay.addWidget(self._compare_hint)
  self._tile(self.a,'A');self._tile(self.b,'B')
  self._compare_selector_host=QWidget()
  self.source_grid=QGridLayout(self._compare_selector_host)
  self.source_grid.setContentsMargins(0,0,0,0);self.source_grid.setSpacing(12)
  self.swap_button.setText('');self.swap_button.setObjectName('info-btn')
  self.swap_button.setFixedSize(38,38)
  self.source_grid.addWidget(self.a,0,0)
  self.source_grid.addWidget(self.swap_button,0,1,Qt.AlignCenter)
  self.source_grid.addWidget(self.b,0,2)
  self.source_grid.setColumnStretch(0,1);self.source_grid.setColumnStretch(2,1)
  lay.addWidget(self._compare_selector_host)
  self._compare_run_host=QWidget()
  row=QHBoxLayout(self._compare_run_host)
  row.setContentsMargins(0,0,0,0);row.setSpacing(9);row.addStretch()
  self.run_compare.setText('Porównaj');self.run_compare.setMinimumWidth(220)
  row.addWidget(self.run_compare)
  self.cancel_compare.setText('Anuluj');row.addWidget(self.cancel_compare);row.addStretch()
  lay.addWidget(self._compare_run_host)
  self._compare_progress_panel=QFrame();self._compare_progress_panel.setObjectName('surface')
  pp=QVBoxLayout(self._compare_progress_panel);pp.setContentsMargins(16,11,16,12)
  self.compare_summary.setAlignment(Qt.AlignLeft);self.compare_summary.setObjectName('muted')
  self.compare_summary.setText('Wybierz dwa modele, aby rozpocząć.')
  pp.addWidget(self.compare_summary)
  self.progress.setRange(0,100);self.progress.setValue(0);pp.addWidget(self.progress)
  self.progress.hide()
  self._bom_label=QLabel('Raport i BOM');self._bom_label.setObjectName('muted');pp.addWidget(self._bom_label)
  self._bom_label.hide()
  self.report_progress.setRange(0,100);self.report_progress.setValue(0)
  pp.addWidget(self.report_progress);self.report_progress.hide()
  lay.addWidget(self._compare_progress_panel)
  self._success=QFrame();self._success.setObjectName('success')
  content=QVBoxLayout(self._success);content.setContentsMargins(20,19,20,19);content.setSpacing(13)
  self._success_title=QLabel('✓  Porównanie zakończone')
  self._success_title.setObjectName('section');content.addWidget(self._success_title)
  self._summary_stats=QLabel('')
  self._summary_stats.setWordWrap(True);self._summary_stats.setObjectName('result-figure')
  content.addWidget(self._summary_stats)
  self._alignment_notice=QLabel('');self._alignment_notice.setWordWrap(True)
  self._alignment_notice.setObjectName('muted');content.addWidget(self._alignment_notice)
  self._alignment_notice.hide()
  lay.addWidget(self._success);self._success.hide()
  self._actions=QFrame();self._actions.setObjectName('surface')
  actions=QGridLayout(self._actions);actions.setContentsMargins(12,10,12,10);actions.setSpacing(9)
  for index,file in enumerate(('POROWNANIE_KOLORY.step','RAPORT.html','PODGLAD_KOLOROW_3D.html','ZMIANY.csv','BOM_A.csv','BOM_B.csv','')):
   button=self.compare_open[file];button.setMinimumWidth(0);button.show();actions.addWidget(button,index//2,index%2)
  actions.setColumnStretch(0,1);actions.setColumnStretch(1,1)
  lay.addWidget(self._actions);self._actions.hide()
  self.reset_button.setText('Nowe porównanie');self.reset_button.setObjectName('text-button')
  try:self.reset_button.clicked.disconnect()
  except (TypeError,RuntimeError):pass
  self.reset_button.clicked.connect(self.new_comparison)
  lay.addWidget(self.reset_button,alignment=Qt.AlignCenter)
  self.reset_button.hide()
  self._details_toggle=QPushButton('Pokaż szczegółową listę zmian')
  self._details_toggle.setObjectName('text-button')
  self._details_toggle.clicked.connect(self._toggle_details)
  self._details_toggle.hide();lay.addWidget(self._details_toggle)
  self._details=QFrame();self._details.setObjectName('details')
  dt=QVBoxLayout(self._details);dt.setContentsMargins(0,0,0,0)
  search_row=QHBoxLayout();search_row.addWidget(self.search,1)
  search_row.addWidget(self.filter_selector);dt.addLayout(search_row)
  self.compare_table.setMinimumHeight(260)
  dt.addWidget(self.compare_table);lay.addWidget(self._details);self._details.hide()
  lay.addStretch(1)
  self._source_stacked=False;self._metric_columns=6

 def _set_compare_result_state(self,done):
  self._compare_selector_host.setVisible(not done)
  self._compare_run_host.setVisible(not done)
  self._compare_hint.setVisible(not done)
  self._compare_progress_panel.setVisible(not done)
  self._success.setVisible(done)
  self._actions.setVisible(done)
  self.reset_button.setVisible(done)
  self._details_toggle.setVisible(done)
  if not done:self._details.hide()
  if done:
   self.progress.hide();self.report_progress.hide();self._bom_label.hide()
  else:
   self._success.hide();self._actions.hide()

 def new_comparison(self):
  if self.process is not None:return
  # Preserve mass calculations, output directory and user preferences.
  self.a.path.clear();self.b.path.clear()
  self.results.pop('compare',None)
  self.current_folder=None
  self.compare_table.setRowCount(0);self.row_statuses=[]
  self.search.clear();self.select_filter('ALL')
  self.compare_summary.setText('Wybierz dwa modele, aby rozpocząć.')
  self.compare_summary.setToolTip('')
  self.progress.setRange(0,100);self.progress.setValue(0);self.progress.hide()
  self.report_progress.setRange(0,100);self.report_progress.setValue(0);self.report_progress.hide()
  self._bom_label.hide();self._success.hide();self._actions.hide();self._details.hide()
  self._details_toggle.setText('Pokaż szczegółową listę zmian')
  for btn in self.compare_open.values():btn.setEnabled(False)
  for metric in self.metrics:metric.setText('—')
  self.log.clear();self._set_compare_result_state(False);self.navigate('compare')
 def _load_result_table(self,kind):
  import csv
  from itertools import islice
  from .names import display_csv_label
  folder=self.results.get(kind)
  if folder is None:return
  table=self.compare_table if kind=='compare' else self.mass_table
  filename='ZMIANY.csv' if kind=='compare' else 'MASY_CZESCI.csv'
  try:
   with (Path(folder)/filename).open(encoding='utf-8-sig',newline='') as handle:
    reader=csv.reader(handle,delimiter=';');headers=next(reader);rows=list(islice(reader,5001))
   if kind=='compare':
    summary=json.loads((Path(folder)/'PODSUMOWANIE.json').read_text(encoding='utf8'))
    self.row_statuses=[r['status'] for r in summary['records'][:5000]]
   table.setUpdatesEnabled(False)
   try:
    table.setColumnCount(len(headers));table.setHorizontalHeaderLabels(headers)
    table.setRowCount(min(len(rows),5000))
    for i,row in enumerate(rows[:5000]):
     for j in range(len(headers)):
      value=display_csv_label(row[j]) if j<len(row) else ''
      item=QTableWidgetItem(value);item.setToolTip(value)
      if kind=='compare' and j==0:item.setData(Qt.UserRole,self.row_statuses[i])
      table.setItem(i,j,item)
    table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
    for j in range(len(headers)):table.setColumnWidth(j,220 if j==0 else 180 if j<6 else 120)
   finally:table.setUpdatesEnabled(True)
   if kind=='compare':self.filter_results()
   else:self._format_mass_results()
   if len(rows)>5000:QMessageBox.information(self,'Duża lista','W aplikacji pokazano pierwsze 5000 pozycji. Pełne dane są dostępne w raporcie HTML i CSV.')
  except (OSError,ValueError,KeyError,StopIteration) as exc:
   QMessageBox.warning(self,'Lista wyników','Nie można odczytać listy: '+str(exc))
 def _toggle_details(self):
  if not self._details.isVisible() and self.compare_table.rowCount()==0:
   self._load_result_table('compare')
  visible=not self._details.isVisible();self._details.setVisible(visible)
  self._details_toggle.setText('Ukryj szczegółową listę zmian' if visible else 'Pokaż szczegółową listę zmian')
 def _modern_mass(self):
  _,lay=self._new_page('mass')
  title=QLabel('Masa części');title.setObjectName('hero')
  title.setAlignment(Qt.AlignCenter);lay.addWidget(title)
  self._tile(self.mass_file,'do obliczenia masy');self.mass_file.hide()
  from PySide6.QtWidgets import QListWidget,QHeaderView
  from .mass_drop import MassDropArea
  self.mass_inputs=[]
  self._mass_form_host=QWidget()
  form_root=QVBoxLayout(self._mass_form_host)
  form_root.setContentsMargins(0,0,0,0);form_root.setSpacing(11)
  self.mass_drop=MassDropArea(self._mass_add)
  self.mass_drop.setProperty('hasFiles',False)
  drop_layout=QVBoxLayout(self.mass_drop)
  drop_layout.setContentsMargins(16,12,16,12);drop_layout.setSpacing(7)
  self._mass_drop_title=QLabel('Przeciągnij pliki STEP/STP lub folder')
  self._mass_drop_title.setObjectName('section')
  self._mass_drop_title.setAlignment(Qt.AlignCenter);drop_layout.addWidget(self._mass_drop_title)
  self._mass_drop_hint=QLabel('Możesz dodać kilka modeli naraz.')
  self._mass_drop_hint.setObjectName('muted');self._mass_drop_hint.setAlignment(Qt.AlignCenter)
  drop_layout.addWidget(self._mass_drop_hint)
  choices=QHBoxLayout();choices.setSpacing(9)
  self.mass_add_files=QPushButton('Wybierz pliki')
  self.mass_add_folder=QPushButton('Wybierz folder')
  self.mass_add_files.clicked.connect(self._mass_pick_files)
  self.mass_add_folder.clicked.connect(self._mass_pick_folder)
  choices.addStretch(1);choices.addWidget(self.mass_add_files,1)
  choices.addWidget(self.mass_add_folder,1);choices.addStretch(1)
  drop_layout.addLayout(choices)
  self.mass_input_count=QLabel('Nie wybrano modeli')
  self.mass_input_count.setObjectName('muted')
  self.mass_input_count.setAlignment(Qt.AlignCenter)
  drop_layout.addWidget(self.mass_input_count)
  self.mass_input_list=QListWidget()
  self.mass_input_list.setObjectName('mass-input-list')
  self.mass_input_list.setSpacing(2)
  self.mass_input_list.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  self.mass_input_list.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
  self.mass_input_list.setFrameShape(QFrame.NoFrame)
  self.mass_input_list.setMinimumHeight(42);self.mass_input_list.setMaximumHeight(176)
  self.mass_input_list.setAlternatingRowColors(False)
  self.mass_input_list.setSelectionMode(QAbstractItemView.ExtendedSelection)
  self.mass_input_list.itemSelectionChanged.connect(self._update_mass_remove_button)
  self.mass_input_list.hide();drop_layout.addWidget(self.mass_input_list)
  self._mass_queue_buttons=QWidget()
  self._mass_queue_buttons.setObjectName('mass-queue-actions')
  queue_row=QHBoxLayout(self._mass_queue_buttons)
  queue_row.setContentsMargins(0,0,0,0);queue_row.addStretch(1)
  self.mass_remove_selected=QPushButton('Usuń zaznaczone')
  self.mass_remove_selected.setObjectName('text-button')
  self.mass_remove_selected.setEnabled(False)
  self.mass_remove_selected.setToolTip('Usuwa pozycje z listy, nie z dysku.')
  self.mass_remove_selected.clicked.connect(self._mass_remove_selected)
  queue_row.addWidget(self.mass_remove_selected)
  drop_layout.addWidget(self._mass_queue_buttons)
  self._mass_queue_buttons.hide()
  form_root.addWidget(self.mass_drop)
  self._mass_materials_panel=QFrame();self._mass_materials_panel.setObjectName('surface')
  material_form=QFormLayout(self._mass_materials_panel)
  material_form.setContentsMargins(20,18,20,18);material_form.setSpacing(14)
  material_form.setLabelAlignment(Qt.AlignRight|Qt.AlignVCenter)
  material_form.setRowWrapPolicy(QFormLayout.WrapLongRows)
  material_form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
  for name,widget in (('Materiał',self.materials),('Gęstość [kg/m³]',self.density)):
   title=QLabel(name);title.setObjectName('material-field-label')
   title.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
   title.setMinimumHeight(42);title.setMinimumWidth(150)
   widget.setMinimumHeight(42)
   material_form.addRow(title,NumberControl(widget,'Gęstość') if widget is self.density else widget)
  form_root.addWidget(self._mass_materials_panel)
  self._mass_material_actions=QWidget()
  more=QHBoxLayout(self._mass_material_actions)
  more.setContentsMargins(0,0,0,0);more.addStretch()
  self._add_material_button=QPushButton('Dodaj materiał')
  self._add_material_button.setObjectName('text-button')
  self._add_material_button.clicked.connect(self.add_material)
  more.addWidget(self._add_material_button);more.addStretch()
  form_root.addWidget(self._mass_material_actions)
  self._mass_run_host=QWidget()
  run_row=QHBoxLayout(self._mass_run_host)
  run_row.setContentsMargins(0,0,0,0);run_row.setSpacing(9)
  self.run_mass.setText('Oblicz masę')
  self.run_mass.setMinimumWidth(150)
  self.mass_reset=QPushButton('Wyczyść')
  self.mass_reset.setObjectName('mass-clear')
  self.mass_reset.setToolTip('Czyści listę modeli, nie usuwa plików.')
  self.mass_reset.clicked.connect(self._mass_reset)
  run_row.addWidget(self.run_mass,3)
  run_row.addWidget(self.cancel_mass,1)
  run_row.addWidget(self.mass_reset,1)
  form_root.addWidget(self._mass_run_host)
  lay.addWidget(self._mass_form_host)
  self.mass_progress.setRange(0,100);self.mass_progress.setValue(0)
  self.mass_progress.hide();lay.addWidget(self.mass_progress)
  self._mass_result_card=QFrame();self._mass_result_card.setObjectName('success')
  result_layout=QVBoxLayout(self._mass_result_card)
  result_layout.setContentsMargins(20,19,20,19);result_layout.setSpacing(12)
  self.mass_done=QLabel('✓  Obliczenia zakończone')
  self.mass_done.setObjectName('section')
  result_layout.addWidget(self.mass_done)
  self.mass_summary.setObjectName('result-figure')
  self.mass_summary.setWordWrap(True)
  result_layout.addWidget(self.mass_summary)
  lay.addWidget(self._mass_result_card)
  self._mass_result_card.hide()
  # Populate the details table only when requested, keeping startup light.
  self._mass_details=QFrame();self._mass_details.setObjectName('details')
  md=QVBoxLayout(self._mass_details);md.setContentsMargins(0,0,0,0)
  self.mass_table.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
  self.mass_table.setMinimumHeight(290)
  self.mass_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
  self.mass_table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
  self.mass_table.setTextElideMode(Qt.ElideMiddle)
  self.mass_table.setWordWrap(False)
  self.mass_table.setSelectionBehavior(QAbstractItemView.SelectRows)
  self.mass_table.verticalHeader().setDefaultSectionSize(36)
  hdr=self.mass_table.horizontalHeader()
  hdr.setSectionResizeMode(QHeaderView.Interactive)
  hdr.setMinimumSectionSize(80)
  hdr.setSectionResizeMode(0,QHeaderView.Stretch)
  for col,width in ((1,85),(2,148),(3,135),(4,145)):
   hdr.setSectionResizeMode(col,QHeaderView.Fixed)
   self.mass_table.setColumnWidth(col,width)
  md.addWidget(self.mass_table);self._mass_details.hide()
  self._mass_toggle=QPushButton('Pokaż listę części')
  self._mass_toggle.setObjectName('text-button')
  self._mass_toggle.clicked.connect(self._toggle_mass)
  self._mass_toggle.hide();lay.addWidget(self._mass_toggle);lay.addWidget(self._mass_details)
  self.mass_actions=QFrame();self.mass_actions.setObjectName('surface')
  actions=QHBoxLayout(self.mass_actions)
  actions.setContentsMargins(12,10,12,10);actions.setSpacing(9)
  for key in ('RAPORT_MASY.html','MASY_CZESCI.csv',''):
   b=self.mass_open[key];b.setMinimumWidth(0);actions.addWidget(b,1)
  lay.addWidget(self.mass_actions);self.mass_actions.hide()
  self.mass_new_button=QPushButton('Nowe obliczenia')
  self.mass_new_button.setObjectName('text-button')
  self.mass_new_button.clicked.connect(self._mass_reset)
  lay.addWidget(self.mass_new_button,alignment=Qt.AlignCenter)
  self.mass_new_button.hide()
  lay.addStretch(1)
  self._scroll_page('mass')
  self._update_mass_file_visual()

 def _set_mass_result_state(self,done):
  self._mass_form_host.setVisible(not done)
  self.mass_done.setVisible(done)
  self._mass_result_card.setVisible(done)
  self.mass_actions.setVisible(done)
  self.mass_new_button.setVisible(done)
  self._mass_toggle.setVisible(done)
  if not done:self._mass_details.hide()
  if done:self.mass_progress.hide()

 def _update_mass_file_visual(self):
  count=len(self.mass_inputs)
  ready=count>0
  self._mass_drop_title.setText('Pliki do obliczenia masy' if ready else 'Przeciągnij pliki STEP/STP lub folder')
  self._mass_drop_hint.setVisible(not ready)
  self.mass_add_files.setText('+ Dodaj pliki' if ready else 'Wybierz pliki')
  self.mass_add_folder.setText('+ Dodaj folder' if ready else 'Wybierz folder')
  self.mass_input_count.setText(
   f'✓  {count} wybranych modeli STEP/STP' if ready else 'Nie wybrano modeli')
  self.mass_input_count.setObjectName('chosen-file' if ready else 'muted')
  self.mass_input_count.style().unpolish(self.mass_input_count)
  self.mass_input_count.style().polish(self.mass_input_count)
  self._mass_queue_buttons.setVisible(ready)
  self.mass_input_list.setVisible(ready)
  self.mass_drop.setProperty('hasFiles',ready)
  self.mass_drop.style().unpolish(self.mass_drop);self.mass_drop.style().polish(self.mass_drop)
  if ready:
   # Frame + QSS padding + row spacing. One entry must fit fully.
   self.mass_input_list.setFixedHeight(min(176, 8+count*36+max(0,count-1)*2))

 def _render_mass_file_rows(self):
  from PySide6.QtWidgets import QListWidgetItem
  from PySide6.QtCore import QSize
  self.mass_input_list.clear()
  for model in self.mass_inputs:
   item=QListWidgetItem(self.mass_input_list)
   item.setToolTip(str(model));item.setSizeHint(QSize(20,36))
   holder=MassRowWidget(self,item)
   holder.setObjectName('mass-file-row')
   holder.setFixedHeight(36);holder.setProperty('selected',False)
   line=QHBoxLayout(holder)
   line.setContentsMargins(10,0,5,0);line.setSpacing(6)
   label=QLabel(model.name);label.setObjectName('mass-row-label')
   label.setProperty('massSelected',False)
   label.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
   label.setAttribute(Qt.WA_TransparentForMouseEvents,True)
   label.setToolTip(str(model))
   label.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
   line.addWidget(label,1,Qt.AlignVCenter)
   delete=QPushButton('×');delete.setObjectName('delete-one')
   delete.setFixedSize(26,26)
   delete.setProperty('massSelected',False)
   delete.setToolTip('Usuń '+model.name+' z listy')
   delete.setAccessibleName('Usuń '+model.name)
   delete.clicked.connect(lambda checked=False,item=item:self._mass_remove_one(item))
   line.addWidget(delete,0,Qt.AlignVCenter)
   self.mass_input_list.setItemWidget(item,holder)
  self.mass_file.path.setText(str(self.mass_inputs[0]) if self.mass_inputs else '')
  self._last_mass_selection=None
  self._update_mass_file_visual()
  self._update_mass_row_selection()

 def _update_mass_row_selection(self):
  for index in range(self.mass_input_list.count()):
   item=self.mass_input_list.item(index)
   holder=self.mass_input_list.itemWidget(item)
   if holder is None:continue
   selected=bool(item.isSelected())
   if holder.property('selected')!=selected:
    holder.setProperty('selected',selected)
    # Explicit paint refresh is required for embedded custom QWidget rows.
    holder.style().unpolish(holder);holder.style().polish(holder)
    for child in holder.findChildren(QLabel)+holder.findChildren(QPushButton):
     if child.objectName() in ('mass-row-label','delete-one'):
      child.setProperty('massSelected',selected)
      child.style().unpolish(child);child.style().polish(child)
      child.update()
    holder.update()

 def _mass_toggle_row(self,item,modifiers):
  """Selection works on embedded rows, including toggle, Ctrl and Shift."""
  if self.process is not None:return
  index=self.mass_input_list.row(item)
  if index<0:return
  current=item.isSelected()
  if modifiers & Qt.ShiftModifier and self._last_mass_selection is not None:
   start=min(self._last_mass_selection,index)
   stop=max(self._last_mass_selection,index)
   if not (modifiers & Qt.ControlModifier):self.mass_input_list.clearSelection()
   for pos in range(start,stop+1):self.mass_input_list.item(pos).setSelected(True)
  elif modifiers & Qt.ControlModifier:
   item.setSelected(not current)
   self._last_mass_selection=index
  else:
   self.mass_input_list.clearSelection()
   item.setSelected(not current)
   self._last_mass_selection=index
  self._update_mass_remove_button()

 def _mass_remove_one(self,item):
  if self.process is not None:return
  index=self.mass_input_list.row(item)
  if index<0 or index>=len(self.mass_inputs):return
  del self.mass_inputs[index]
  self._render_mass_file_rows()
  self._mass_invalidate()

 def _mass_invalidate(self):
  self.results.pop('mass',None)
  self.mass_done.hide();self.mass_actions.hide()
  self.mass_progress.hide();self.mass_progress.setRange(0,100);self.mass_progress.setValue(0)
  self.mass_table.setRowCount(0)
  self._set_mass_result_state(False)
  for action in self.mass_open.values():action.setEnabled(False)
 def _mass_add(self,paths):
  if self.process is not None:return
  known={str(p).casefold() for p in self.mass_inputs}
  fresh=[]
  try:
   for raw in paths:
    p=Path(raw).expanduser().resolve()
    candidates=sorted((x for x in p.rglob('*') if x.is_file() and x.suffix.lower() in ('.step','.stp')),
                      key=lambda x:str(x).casefold()) if p.is_dir() else (p,)
    for model in candidates:
     if model.is_file() and model.suffix.lower() in ('.step','.stp'):
      key=str(model).casefold()
      if key not in known:
       known.add(key);fresh.append(model)
       if len(fresh)+len(self.mass_inputs)>500:break
    if len(fresh)+len(self.mass_inputs)>500:break
  except (OSError,ValueError) as exc:
   QMessageBox.warning(self,'Wybór modeli',str(exc));return
  if len(fresh)+len(self.mass_inputs)>500:
   QMessageBox.warning(self,'Limit modeli','Maksymalnie 500 modeli STEP/STP na analizę.')
   return
  if not fresh:return
  self.mass_inputs.extend(fresh)
  self._render_mass_file_rows()
  self._mass_invalidate()

 def _update_mass_remove_button(self):
  self.mass_remove_selected.setEnabled(self.process is None and bool(self.mass_input_list.selectedItems()))
  self._update_mass_row_selection()
 def _mass_remove_selected(self):
  if self.process is not None:return
  indices={i.row() for i in self.mass_input_list.selectedIndexes()}
  if not indices:return
  self.mass_inputs=[m for index,m in enumerate(self.mass_inputs) if index not in indices]
  self._render_mass_file_rows()
  self._mass_invalidate()
  self.mass_remove_selected.setEnabled(False)

 def _mass_pick_files(self):
  if self.process is not None:return
  from PySide6.QtWidgets import QFileDialog
  selected,_=QFileDialog.getOpenFileNames(self,'Dodaj modele do obliczenia masy',
    str(self.mass_inputs[-1].parent if self.mass_inputs else Path.home()),
    'Modele STEP (*.step *.stp);;Wszystkie pliki (*)')
  self._mass_add(selected)
 def _mass_pick_folder(self):
  if self.process is not None:return
  from PySide6.QtWidgets import QFileDialog
  folder=QFileDialog.getExistingDirectory(self,'Wybierz folder modeli STEP/STP',
    str(self.mass_inputs[-1].parent if self.mass_inputs else Path.home()))
  if folder:
   base=Path(folder)
   files=sorted((p for p in base.rglob('*') if p.is_file() and p.suffix.lower() in ('.step','.stp')),
      key=lambda p:str(p).casefold())
   if len(files)>500:
    QMessageBox.warning(self,'Za dużo plików','Folder zawiera ponad 500 plików STEP/STP. Wybierz mniejszy folder.')
    return
   if not files:
    QMessageBox.information(self,'Brak modeli','Nie znaleziono plików STEP / STP.')
    return
   self._mass_add(files)
 def _mass_reset(self):
  if self.process is not None:return
  self.mass_inputs.clear()
  self._render_mass_file_rows()
  self.mass_log.clear()
  self._mass_invalidate()
  self.mass_remove_selected.setEnabled(False)
  self._set_mass_result_state(False)

 def _mass_running_controls(self,busy):
  for ctrl in (self.mass_add_files,self.mass_add_folder,self.mass_reset):
   ctrl.setEnabled(not busy)
  self.mass_drop.setBusy(busy)
  self.mass_input_list.setEnabled(not busy)
  self.mass_remove_selected.setEnabled(not busy and bool(self.mass_input_list.selectedItems()))
 def _toggle_mass(self):
  if not self._mass_details.isVisible() and self.mass_table.rowCount()==0:
   self._load_result_table('mass')
  active=not self._mass_details.isVisible();self._mass_details.setVisible(active)
  self._mass_toggle.setText('Ukryj listę części' if active else 'Pokaż listę części')
 def _center_form_fields(self):
  from PySide6.QtWidgets import QLineEdit,QAbstractSpinBox,QComboBox
  from PySide6.QtCore import Qt
  # Paths stay left aligned; numeric, switch and choice controls are centered.
  excluded=(self.output,self.mass_file.path,self.a.path,self.b.path)
  for field in self.findChildren(QLineEdit):
   if field not in excluded:field.setAlignment(Qt.AlignCenter)
  for spin in self.findChildren(QAbstractSpinBox):
   spin.setButtonSymbols(QAbstractSpinBox.NoButtons)
   spin.setAlignment(Qt.AlignCenter)
  for choice in (self.schema,self.verify_mode,self.bom_mode,self._theme_select):
   choice.setEditable(True)
   choice.setInsertPolicy(QComboBox.NoInsert)
   choice.lineEdit().setReadOnly(True)
   choice.lineEdit().setAlignment(Qt.AlignCenter)
 def _scroll_page(self,key):
  from PySide6.QtWidgets import QScrollArea,QLayout
  page=self.pages[key]
  index={'compare':0,'mass':1,'settings':2}[key]
  wrapper=QScrollArea(self.stack);wrapper.setObjectName('page')
  wrapper.setWidgetResizable(True);wrapper.setFrameShape(QFrame.NoFrame)
  # Only exceptionally narrow settings screens can exceed the viewport.
  # Do not clip options: enable a horizontal fallback when they cannot wrap.
  wrapper.setHorizontalScrollBarPolicy(
   Qt.ScrollBarAsNeeded if key=='settings' else Qt.ScrollBarAlwaysOff)
  wrapper.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
  page.layout().setSizeConstraint(QLayout.SetMinimumSize)
  wrapper.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
  wrapper.setMinimumSize(0,0)
  self.stack.removeWidget(page)
  wrapper.setWidget(page)
  self.stack.insertWidget(index,wrapper)
  self.pages[key]=wrapper
 def _settings_card(self,title):
  box=QFrame();box.setObjectName('settings-card');layout=QFormLayout(box);layout.setContentsMargins(17,17,17,14);layout.setSpacing(10)
  heading=QLabel(title);heading.setObjectName('section');heading.setAlignment(Qt.AlignCenter);layout.addRow(heading)
  return box,layout
 def _modern_settings(self):
  _,lay=self._new_page('settings')
  title=QLabel('Ustawienia');title.setObjectName('hero');title.setAlignment(Qt.AlignCenter)
  lay.addWidget(title)
  grid=QGridLayout();grid.setSpacing(14)
  compare,cp=self._settings_card('Porównanie i import')
  cp.addRow('Tolerancja geometrii',NumberControl(self.tolerance,'Tolerancja geometrii'))
  cp.addRow('Limit brył / plik',NumberControl(self.solid_limit,'Limit brył na plik'))
  # Alignment is automatic for all comparisons; no manual setting.
  self.align.setChecked(False)
  self.align.hide()
  info=QLabel('Program sprawdza przesunięcie modeli. Jednoznaczne wyrównanie zastosuje automatycznie i pokaże w wyniku; w pozostałych przypadkach zapyta o decyzję.')
  info.setObjectName('muted');info.setWordWrap(True);cp.addRow(info)
  self.full_bom.setText('Twórz pełny BOM A i B')
  self.cache_import.setText('Przyspiesz ponowny import')
  self.bom_csv.setText('Zapisuj BOM także jako CSV')
  if self.bom_mode.count()>1:
   self.bom_mode.setItemText(0,'Dokładny — kontrola geometrii')
   self.bom_mode.setItemText(1,'Szybki — pewne duplikaty')
  cp.addRow(self.full_bom)
  cp.addRow('Tryb BOM',self.bom_mode)
  cp.addRow(self.cache_import)
  cp.addRow(self.clear_import_cache_button)

  report,rp=self._settings_card('Raport i eksport')
  folder=QWidget();folder.setStyleSheet('background:transparent;')
  folder_line=QHBoxLayout(folder);folder_line.setContentsMargins(0,0,0,0);folder_line.setSpacing(8)
  self.output.setMinimumWidth(120);folder_line.addWidget(self.output,1)
  self.output_button.setMinimumWidth(104);folder_line.addWidget(self.output_button,0)
  rp.addRow('Folder wyników',folder)
  rp.addRow('Kolory modeli',self.color_editor)
  rp.addRow('Przezroczystość wersji A',NumberControl(self.opacity,'Przezroczystość wersji A'))
  self.opacity.show()
  self.opacity.setToolTip('0%: pełny kolor; 90%: prawie przezroczysta. Wygląd STEP zależy od importera CAD.')
  rp.addRow(self.bom_csv)
  self.preview_html=QCheckBox('Twórz podgląd 3D w HTML (dodatkowy czas analizy)')
  self.preview_html.setChecked(str(self.store.value('preview_html','true')).lower()=='true')
  rp.addRow(self.preview_html)

  # Keep internal compatibility controls, but do not expose old settings.
  # Force a stable ZW3D compatible AP214 / automatic verification policy.
  self.schema.setCurrentText('AP214IS')
  auto=self.verify_mode.findData('auto')
  if auto>=0:self.verify_mode.setCurrentIndex(auto)
  self._theme_select=QComboBox()
  self._theme_select.addItems(['Ciemny','Jasny'])
  self._theme_select.setCurrentText(self.theme.currentText())
  self._theme_select.currentTextChanged.connect(self.theme.setCurrentText)
  self.theme.currentTextChanged.connect(self._theme_select.setCurrentText)

  for form in (cp,rp):
   form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
   form.setRowWrapPolicy(QFormLayout.WrapLongRows)
   form.setLabelAlignment(Qt.AlignRight|Qt.AlignVCenter)
   form.setFormAlignment(Qt.AlignTop)
   form.setHorizontalSpacing(18);form.setVerticalSpacing(16)
   for row in range(form.rowCount()):
    item=form.itemAt(row,QFormLayout.LabelRole)
    if item and isinstance(item.widget(),QLabel):
     label=item.widget();label.setAlignment(Qt.AlignRight|Qt.AlignVCenter)
     label.setMinimumHeight(40);label.setMinimumWidth(140)
     label.setWordWrap(True)
  self._settings_grid=grid
  self._settings_compare_card=compare
  self._settings_report_card=report
  self._settings_stacked=False
  grid.addWidget(compare,0,0);grid.addWidget(report,0,1)
  grid.setColumnStretch(0,1);grid.setColumnStretch(1,1)
  lay.addLayout(grid);lay.addStretch(1)
  self._scroll_page('settings')
  self.safe_export.setChecked(True);self.safe_export.hide()
  save_row=QHBoxLayout();save_row.setContentsMargins(0,8,0,0)
  save_row.addStretch(1)
  self._settings_save_feedback=QLabel('')
  self._settings_save_feedback.setObjectName('muted')
  self._settings_save_feedback.setWordWrap(True)
  save_row.addWidget(self._settings_save_feedback)
  self._settings_save_button=QPushButton('Zapisz ustawienia')
  self._settings_save_button.setObjectName('primary')
  self._settings_save_button.clicked.connect(self._save_settings_explicit)
  save_row.addWidget(self._settings_save_button)
  self._settings_cancel_button=QPushButton('Anuluj')
  self._settings_cancel_button.setObjectName('text-button')
  self._settings_cancel_button.clicked.connect(self._settings_revert)
  save_row.addWidget(self._settings_cancel_button)
  lay.insertLayout(lay.count()-1,save_row)
  self._settings_note=QLabel(
   'Podczas analizy możesz przeglądać ustawienia. Ich zapis będzie dostępny po zakończeniu.')
  self._settings_note.setObjectName('muted')
  self._settings_note.setWordWrap(True)
  lay.insertWidget(lay.count()-1,self._settings_note)

 def create_zw3d_macro(self):
  from .zw3d_launcher import create_macro
  try:
   path=create_macro()
   QMessageBox.information(self,'Uruchamianie z ZW3D 2019',
      'Przygotowano makro:\n'+str(path)+
      '\n\nWczytaj ten plik .mac w menedżerze makr ZW3D 2019 i przypisz do przycisku. '+
      'Makro wywołuje aktualną lokalizację DSCompare.exe. Po przeniesieniu EXE utwórz makro ponownie. '+
      'Działanie w ZW3D 2019 wymaga sprawdzenia na zainstalowanym programie.')
   if os.name=='nt':os.startfile(str(path.parent))
  except (OSError,ValueError,RuntimeError) as exc:
   QMessageBox.warning(self,'Integracja ZW3D','Nie udało się utworzyć makra: '+str(exc))
 def apply_theme(self,name):
  super().apply_theme(name)
  self.setStyleSheet(skin(name=='Ciemny'))
  p=DARK if name=='Ciemny' else LIGHT
  self._refresh_action_icons(p['ink'],p['accent'])
  if hasattr(self,'mass_input_list'):
   self._update_mass_row_selection()
   for i in range(self.mass_input_list.count()):
    holder=self.mass_input_list.itemWidget(self.mass_input_list.item(i))
    if holder is not None:holder.update()
  if hasattr(self,'about_button'):self.about_button.setIcon(vector_icon('info',p['ink']))
  if hasattr(self,'swap_button'):self.swap_button.setIcon(vector_icon('swap',p['ink']))
  for key,button in self.nav.items():button.setIcon(vector_icon(key,p['ink']))
  if hasattr(self,'run_compare'):set_action(self.run_compare,'run','#FFFFFF')
  if hasattr(self,'run_mass'):set_action(self.run_mass,'mass','#FFFFFF')
 def _reflow_compare(self,width):
  if not hasattr(self,'source_grid'):return
  stacked=width<1180
  if getattr(self,'_source_stacked',None)==stacked:return
  for widget in (self.a,self.b,self.swap_button):self.source_grid.removeWidget(widget)
  if stacked:
   self.source_grid.addWidget(self.a,0,0,1,3);self.source_grid.addWidget(self.swap_button,1,1,Qt.AlignCenter);self.source_grid.addWidget(self.b,2,0,1,3)
  else:
   self.source_grid.addWidget(self.a,0,0);self.source_grid.addWidget(self.swap_button,0,1,Qt.AlignCenter);self.source_grid.addWidget(self.b,0,2)
  self._source_stacked=stacked
 def start(self,kind):
  if kind=='compare':
   self._step_export_failed=False
   self._success.hide();self._actions.hide();self._details.hide();self._bom_label.hide()
   self.report_progress.hide();self._details_toggle.setText('Pokaż szczegółową listę zmian')
  if kind=='mass':
   if not self.mass_inputs:
    QMessageBox.warning(self,'Brak modeli','Najpierw dodaj pliki STEP albo folder.')
    return
   self._mass_invalidate()
  super().start(kind)
  if kind=='compare':
   self._last_compare_stage=None
   self._compare_step_announced=False
  if self.process is not None:self._set_busy_ui(True)
  if kind=='mass' and self.process is not None:
   self.store.setValue('density',self.density.value())
   self._mass_running_controls(True)
   self.mass_summary.setText(f'Trwa obliczanie masy {len(self.mass_inputs)} modeli…')
  if self.process is not None:
   if kind=='compare':
    self.progress.setRange(0,0);self.progress.show();self.reset_button.setEnabled(False)
   else:self.mass_progress.setRange(0,0);self.mass_progress.show()
 def poll(self):
  super().poll()
  if self.process is None:return
  self._refresh_global_activity()
  if self.task=='mass':
   self.mass_progress.setRange(0,0);return
  if self.task!='compare' or not self.current_folder:return
  stage=Path(self.current_folder)/'_ETAPY.json'
  data=self._stage_data()
  if not data:return
  signature=(data.get('step'),data.get('step_bytes'),
             data.get('reports'),data.get('report_percent'),data.get('step_error'))
  if signature==getattr(self,'_last_compare_stage',None):
   return
  self._last_compare_stage=signature
  step=Path(self.current_folder)/'POROWNANIE_KOLORY.step'
  complete=(data.get('step')=='gotowy' and step.is_file() and step.stat().st_size>=100
   and step.stat().st_size==data.get('step_bytes'))
  if complete:
   self.progress.setRange(0,100);self.progress.setValue(100);self.progress.hide()
   if not getattr(self,'_compare_step_announced',False):
    self.results['compare']=Path(self.current_folder)
    self._actions.show()
    self._refresh_outputs()
    self._compare_step_announced=True
   self._bom_label.setText('STEP gotowy do otwarcia · Raport i BOM: '+str(data.get('reports','przygotowanie')).replace('_',' '))
   self._bom_label.show();self.report_progress.show()
   self.report_progress.setRange(0,100)
   pct=max(0,min(100,int(data.get('report_percent',0))))
   self.report_progress.setValue(max(self.report_progress.value(),pct))
  elif data.get('step')=='blad':
   self.progress.setRange(0,100);self.progress.setValue(0);self.progress.hide()
   self.compare_summary.setText('Błąd eksportu STEP. Raport może być nadal przygotowywany.')
  else:self.progress.setRange(0,0)
 def finished(self,code,status):
  try:
   super().finished(code,status)
  finally:
   self._set_busy_ui(False)
  self.progress.hide();self.mass_progress.hide();self.report_progress.hide()
  self._bom_label.hide();self.reset_button.setEnabled(True)
  self.compare_summary.setToolTip('');self.mass_summary.setToolTip('')
  self._global_status.setToolTip('')
  if self.task=='mass':
   self._mass_running_controls(False)
   success=bool(getattr(self,'completion_ok',False) and self.results.get('mass'))
   self._set_mass_result_state(success)
   if success:
    self.mass_progress.setRange(0,100);self.mass_progress.setValue(100)
  if self.task=='compare':
   success=bool(getattr(self,'completion_ok',False) and self.results.get('compare'))
   self._set_compare_result_state(success)
   if not success:
    # Keep the input cards available for retry, and make reset discoverable.
    self.reset_button.setVisible(True)
    self.reset_button.setEnabled(True)
    self.reset_button.setToolTip('Wyczyść oba modele i rozpocznij nowe porównanie.')
    self.compare_summary.setText('Porównanie anulowane — możesz rozpocząć je ponownie.' if self.was_cancelled else 'Nie udało się zakończyć porównania — zobacz komunikat błędu.')
  elif self.task=='mass' and not getattr(self,'completion_ok',False):
   self.mass_summary.setText('Obliczanie masy anulowane.' if self.was_cancelled else 'Obliczanie masy nie zostało ukończone.')
  self._refresh_outputs()
 def load_result(self,kind,folder):
  super().load_result(kind,folder)
  if kind=='compare':
   s=json.loads((Path(folder)/'PODSUMOWANIE.json').read_text('utf8'));c=s['statuses']
   self._summary_stats.setText('A: {a} brył    →    B: {b} brył\nBez zmian: {same}    ·    Nowe: {new}    ·    Usunięte: {old}    ·    Przesunięte: {move}'.format(
    a=s.get('solids_A',0),b=s.get('solids_B',0),
    same=c.get('SAME',0)+c.get('RENAMED',0),
    new=c.get('ADDED',0),old=c.get('REMOVED',0),move=c.get('MOVED',0)))
   self._summary_stats.setText(self._summary_stats.text()+f'\nZmieniona geometria: {c.get("CHANGED",0)}')
   if c.get('UNCERTAIN'):self._summary_stats.setText(self._summary_stats.text()+f'\nDo sprawdzenia: {c["UNCERTAIN"]}')
   from .alignment_notice import alignment_notice
   note=alignment_notice(s.get('alignment',{}))
   self._alignment_notice.setText(note);self._alignment_notice.setVisible(bool(note))
   self._step_export_failed=bool(s.get('step_export_error'))
   self._refresh_outputs();self._details.hide()
  else:
   self._refresh_mass_summary(folder)
   self._format_mass_results()
 def _format_mass_results(self):
  for i in range(self.mass_table.rowCount()):
   for j in range(self.mass_table.columnCount()):
    item=self.mass_table.item(i,j)
    if item is None:continue
    content=item.text()
    if j==0 and '="' in content:
     content=content.replace('="','').rstrip('"')
     item.setText(content)
    item.setToolTip(content)
    if j>0:item.setTextAlignment(Qt.AlignCenter)
 def _refresh_mass_summary(self,folder):
  try:
   s=json.loads((Path(folder)/'PODSUMOWANIE_MASY.json').read_text('utf8'))
   volume=s.get('objetosc_calosci_mm3')
   detail='Masa: {:.3f} kg  ·  {} brył  ·  {} pozycji'.format(s['masa_calosci_kg'],s.get('liczba_bryl',0),s.get('liczba_pozycji',0))
   if s.get('liczba_plikow'):detail='Przeanalizowano {} modeli  ·  '.format(s['liczba_plikow'])+detail
   if volume is None and self.density.value()>0:volume=s['masa_calosci_kg']/self.density.value()*1e9
   if volume is not None:detail+='  ·  Objętość: {:.1f} mm³'.format(volume)
   omitted=s.get('import_diagnostics',{}).get('faces_outside_solids',0)
   if omitted:detail+=f'\nUwaga: pominięto {omitted} powierzchni — masa obejmuje tylko bryły.'
   self.mass_summary.setText(detail)
  except (OSError,ValueError,KeyError,TypeError):pass
 def _refresh_outputs(self):
  for kind,files in (('compare',tuple(self.compare_open)),('mass',tuple(self.mass_open))):
   folder=self.results.get(kind)
   for f in files:
    button=(self.compare_open if kind=='compare' else self.mass_open).get(f)
    if button is None:continue
    button.setEnabled(bool(folder and (Path(folder)/f).is_file() and (f!='POROWNANIE_KOLORY.step' or not getattr(self,'_step_export_failed',False))) if f else bool(folder and Path(folder).is_dir()))
 def reset_session(self):
  super().reset_session();self._success.hide();self._actions.hide();self._details.hide();self.progress.hide();self.mass_progress.hide();self.report_progress.hide();self._bom_label.hide()
  self._mass_reset()
  self._set_compare_result_state(False)
 def invalidate_comparison(self,*args):
  super().invalidate_comparison(*args)
  if hasattr(self,'_success'):
   self._set_compare_result_state(False)
