"""Conservative *negative-only* surface witness when OCCT Boolean algorithms fail.

Never proves parts identical. OCCT BRepMesh samples are only used to disprove a
single suggested orientation: a point on surface A with a nearest distance to
surface B greater than the CAD tolerance plus conservative tessellation slack
means these solids cannot coincide under that orientation. If uncertain, the
usual explicit BOM warning remains. No name/volume guess and no auto healing.
"""
from __future__ import annotations

import numpy as np


def _surface_mesh(shape, deflection: float, triangle_limit: int):
    import vtk
    from OCP.BRepMesh import BRepMesh_IncrementalMesh
    from OCP.BRep import BRep_Tool
    from OCP.TopAbs import TopAbs_FACE
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopoDS import TopoDS
    from OCP.TopLoc import TopLoc_Location

    mesher = BRepMesh_IncrementalMesh(shape, deflection, False, 0.12, False)
    mesher.Perform()
    if not mesher.IsDone():
        raise RuntimeError('OCCT triangulation failed')
    points = vtk.vtkPoints()
    points.SetDataTypeToDouble()  # avoid float32 rounding for large CAD origins
    triangles = vtk.vtkCellArray()
    samples = []
    face_count = 0
    ex = TopExp_Explorer(shape, TopAbs_FACE)
    while ex.More():
        face_count += 1
        if face_count > triangle_limit:  # no huge unbounded fallback
            raise RuntimeError('Surface witness too complex')
        face = TopoDS.Face_s(ex.Current())
        loc = TopLoc_Location()
        tri = BRep_Tool.Triangulation_s(face, loc)
        if tri is None or tri.NbTriangles() == 0:
            raise RuntimeError('Missing CAD face triangulation')
        if triangles.GetNumberOfCells() + tri.NbTriangles() > triangle_limit:
            raise RuntimeError('Surface witness triangle limit')
        offset = points.GetNumberOfPoints()
        location = loc.Transformation()
        nodes = []
        for i in range(1, tri.NbNodes()+1):
            p = tri.Node(i).Transformed(location)
            xyz = (p.X(),p.Y(),p.Z())
            points.InsertNextPoint(*xyz)
            nodes.append(np.asarray(xyz,dtype=float))
            samples.append(xyz)
        for k in range(1, tri.NbTriangles()+1):
            t = tri.Triangle(k).Get()
            ids = [offset + n-1 for n in t]
            cell = vtk.vtkTriangle()
            for n,id_ in enumerate(ids):
                cell.GetPointIds().SetId(n,id_)
            triangles.InsertNextCell(cell)
            a,b,c = (nodes[n-1] for n in t)
            # The centroid and edge midpoints also detect interior gaps that
            # would be missed by testing tessellation vertices alone.
            samples.append(tuple((a+b+c)/3))
            samples.append(tuple((a+b)/2))
            samples.append(tuple((b+c)/2))
            samples.append(tuple((c+a)/2))
        ex.Next()
    poly = vtk.vtkPolyData()
    poly.SetPoints(points)
    poly.SetPolys(triangles)
    if not poly.GetNumberOfCells():
        raise RuntimeError('Empty CAD surface mesh')
    return poly, samples


def definitely_different_surfaces(a, b, tolerance: float = .01,
                                  deflection: float = .001,
                                  max_triangles: int = 40000) -> bool:
    """Return True only on a surface-distance witness larger than safe bounds.

    This function must never be used as a positive-match predicate. OCCT mesh
    approximation ≤ deflection on *both* shapes is accounted for in the
    admissible distance. A sample from either surface beyond the bound proves
    a mismatch above CAD tolerance at that alignment. Any failure raises and
    the caller retains the inconclusive Boolean error as a BOM warning.
    """
    import vtk
    pa, samples_a = _surface_mesh(a, deflection, max_triangles)
    pb, samples_b = _surface_mesh(b, deflection, max_triangles)
    limit = tolerance + 2*deflection + 1e-5
    limit_sq = limit*limit
    def too_far(samples, target):
        locator = vtk.vtkStaticCellLocator()
        locator.SetDataSet(target)
        locator.BuildLocator()
        closest = [0.,0.,0.]
        cell_id, sub_id, distance_squared = vtk.mutable(0), vtk.mutable(0), vtk.mutable(0.)
        for sample in samples:
            locator.FindClosestPoint(sample,closest,cell_id,sub_id,distance_squared)
            if float(distance_squared) > limit_sq:
                return True
        return False
    return too_far(samples_a, pb) or too_far(samples_b, pa)


def independent_surface_identity(a, b, max_triangles: int = 40000) -> bool:
    """Rare Boolean-failure fallback for *near machine-exact* B-Rep faces.

    Unlike definitely_different_surfaces, this positive decision requires:
    - bidirectional mesh surface distance < 10^-7 mm (not 0.01 mm),
    - same face count, OCCT parametric surface types and orientations,
    - matching exact analytic face areas, centroids and bounding boxes to 10^-6,
    - caller's unchanged strict B-Rep volume/area/inertia prefilter.

    It does not accept mere similar names, masses, or loose mesh tolerances.
    If any part of the check fails, the original explicit BOM warning remains.
    """
    import vtk
    from OCP.BRepAdaptor import BRepAdaptor_Surface
    from OCP.BRepGProp import BRepGProp
    from OCP.GProp import GProp_GProps
    from OCP.TopoDS import TopoDS
    from OCP.TopAbs import TopAbs_FACE
    from OCP.TopExp import TopExp_Explorer
    from OCP.BRepBndLib import BRepBndLib
    from OCP.Bnd import Bnd_Box

    def descriptors(shape):
        result=[]
        ex=TopExp_Explorer(shape,TopAbs_FACE)
        while ex.More():
            face=TopoDS.Face_s(ex.Current())
            props=GProp_GProps()
            BRepGProp.SurfaceProperties_s(face,props)
            c=props.CentreOfMass()
            bounds=Bnd_Box();BRepBndLib.AddOptimal_s(face,bounds,False,False)
            descriptor=(str(BRepAdaptor_Surface(face).GetType()),str(face.Orientation()),
                        float(props.Mass()),c.X(),c.Y(),c.Z(),*bounds.Get())
            result.append(descriptor)
            ex.Next()
        return sorted(result, key=lambda row:(row[0],row[1],round(row[2],5),
                                              round(row[3],5),round(row[4],5),round(row[5],5)))

    sig_a,sig_b=descriptors(a),descriptors(b)
    if len(sig_a)!=len(sig_b) or not sig_a:
        return False
    for first,second in zip(sig_a,sig_b):
        if first[:2]!=second[:2]:
            return False
        if any(abs(x-y)>1e-6 for x,y in zip(first[2:],second[2:])):
            return False
    pa,sa=_surface_mesh(a,.001,max_triangles)
    pb,sb=_surface_mesh(b,.001,max_triangles)
    # The exact coincidence threshold is 100 nanometres and independent of
    # the user's 0.01 mm geometric tolerance. Sampling in both directions.
    def coincident(samples,target):
        locator=vtk.vtkStaticCellLocator()
        locator.SetDataSet(target);locator.BuildLocator()
        cp=[0.,0.,0.];cid=vtk.mutable(0);sid=vtk.mutable(0);dist=vtk.mutable(0.)
        for sample in samples:
            locator.FindClosestPoint(sample,cp,cid,sid,dist)
            if float(dist)>1e-14:
                return False
        return True
    return coincident(sa,pb) and coincident(sb,pa)
