"""OCCT material regions with one pair-scoped PaveFiller for Common/Cut.

Production calls run in material_guard's crash-contained worker. Repairs are
deep copies, accepted only after original oriented trim equivalence is proven.
"""
from __future__ import annotations
from dataclasses import dataclass
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common,BRepAlgoAPI_Cut
from OCP.BRepGProp import BRepGProp
from OCP.GProp import GProp_GProps
from OCP.TopAbs import TopAbs_SOLID
from OCP.TopExp import TopExp_Explorer

from .palette import MATERIAL_COLORS as COLORS

@dataclass(frozen=True)
class CommonEvidence:
    """Pair-bound Common produced earlier by the trusted OCCT pipeline.

    This is a provenance guard, NOT an independent geometric proof. Keep
    source shape references so location/orientation and topology identity
    can be checked before reusing a previously calculated intersection.
    """
    shape: object
    old_shape: object
    new_shape: object
    tolerance_mm: float


def bind_common(common, old_shape, new_shape, tolerance):
    """Bind a trusted precomputed Common to its exact input B-Reps."""
    from .brep_safety import is_valid
    tol = float(tolerance)
    if not 0. < tol <= .01:
        raise ValueError('Common evidence tolerance must be within 0.01 mm')
    if not is_valid(old_shape) or not is_valid(new_shape):
        raise ValueError('Cannot cache Common for invalid source B-Reps')
    return CommonEvidence(_check_result(common), old_shape, new_shape, tol)


@dataclass(frozen=True)
class MaterialRegions:
    common:object
    added:object
    removed:object
    common_mm3:float
    added_mm3:float
    removed_mm3:float

def volume(shape):
    prop=GProp_GProps()
    BRepGProp.VolumeProperties_s(shape,prop)
    import math
    value=float(prop.Mass())
    if not math.isfinite(value) or value<0:raise ValueError('Invalid material volume')
    return value

def solids(shape,epsilon=1e-7):
    ex=TopExp_Explorer(shape,TopAbs_SOLID)
    while ex.More():
        piece=ex.Current();ex.Next()
        if volume(piece)>epsilon:yield piece

def _check_result(result):
    from .brep_safety import is_valid
    if result.IsNull() or not is_valid(result):
        raise RuntimeError('OCCT Boolean returned invalid or null topology')
    return result

@dataclass(frozen=True)
class RegionEvidence:
    """Pair-scoped material regions from a trusted isolated OCCT calculation.

    Like CommonEvidence, this is provenance, not a geometric SAME proof.
    """
    regions: MaterialRegions
    old_shape: object
    new_shape: object
    tolerance_mm: float


def bind_regions(regions, old, new, tolerance):
    """Bind a verified producer's material regions to exact source shapes."""
    from .brep_safety import is_valid
    tol = float(tolerance)
    if not 0. < tol <= .01:
        raise ValueError('Region evidence tolerance must be within 0.01 mm')
    if not isinstance(regions, MaterialRegions):
        raise TypeError('Only MaterialRegions can be bound')
    if not is_valid(old.shape) or not is_valid(new.shape):
        raise ValueError('Cannot cache regions for invalid original B-Reps')
    for shape in (regions.common, regions.added, regions.removed):
        _check_result(shape)
    if not _regions_balance(regions, old, new, tol):
        raise ValueError('Cannot bind material regions with invalid volume balance')
    return RegionEvidence(regions, old.shape, new.shape, tol)


def _regions_balance(regions, old, new, tolerance):
    import math
    if not all(math.isfinite(v) and v>0 for v in (old.volume,new.volume)):return False
    cv, av, rv = regions.common_mm3, regions.added_mm3, regions.removed_mm3
    if not all(math.isfinite(v) and v >= 0 for v in (cv, av, rv)):
        return False
    limit = max(1e-3, 10.*tolerance**3, 5e-5*max(old.volume, new.volume))
    actual=tuple(volume(s) for s in (regions.common,regions.added,regions.removed))
    if any(abs(x-y)>limit for x,y in zip(actual,(cv,av,rv))):return False
    return (abs(cv + rv - old.volume) <= limit
            and abs(cv + av - new.volume) <= limit)


def _matching_regions(entry, old, new, tolerance):
    """Reject unbound, stale, repaired, or cross-pair precomputed regions."""
    from .brep_safety import is_valid
    if not isinstance(entry, RegionEvidence):
        return False
    if entry.tolerance_mm != float(tolerance):
        return False
    if not is_valid(old.shape) or not is_valid(new.shape):
        return False
    if not (entry.old_shape.IsEqual(old.shape)
            and entry.new_shape.IsEqual(new.shape)):
        return False
    if not _regions_balance(entry.regions, old, new, float(tolerance)):
        return False
    return all(is_valid(shape) for shape in
               (entry.regions.common, entry.regions.added, entry.regions.removed))


def operate(klass,s,t,tolerance):
    """One-off native Boolean, used only in isolated proof operations."""
    from .boolean_ops import configured
    from .brep_safety import validated_copy
    s,_=validated_copy(s,tolerance)
    t,_=validated_copy(t,tolerance)
    op=configured(klass,s,t,tolerance)
    from . import trace_r22 as trace
    trace.brep_call('occt_'+klass.__name__,None,None,op.Build)
    if not op.IsDone():
        raise RuntimeError('OCCT Boolean did not complete')
    result=op.Shape()
    # A negative signed intersection volume is impossible for two valid,
    # positive-volume solids. OCCT may return IsDone=True with malformed
    # Common topology; reject before a costly BRepCheck_Analyzer traversal.
    # Never convert an invalid intersection into a zero intersection.
    if klass is BRepAlgoAPI_Common:
        from OCP.BRepGProp import BRepGProp
        from OCP.GProp import GProp_GProps
        from . import trace_r22 as trace
        trace.mark('occt_common_output','VOLUME_BEGIN')
        signed=_common_signed_volume(result)
        trace.mark('occt_common_output','VOLUME_END',signed_volume_mm3=signed)
        import math
        if not math.isfinite(signed) or signed < -max(1e-5,float(tolerance)**3):
            error=f'OCCT Common returned impossible signed volume {signed:.9g} mm3; no valid material intersection'
            from os import environ, _exit
            from pathlib import Path
            import json
            reply_path=environ.get('DSCOMPARE_COMMON_FAILFAST_REPLY')
            if reply_path:
                # Explicit negative verdict, never a fabricated empty Common.
                destination=Path(reply_path)
                try:
                    destination.write_text(json.dumps(dict(ok=False,error=error)),encoding='utf-8')
                    destination.with_suffix('.phase').write_text('common_rejected',encoding='utf-8')
                except OSError:
                    pass  # Do not mask the native geometry failure with a logging failure.
                _exit(70)
            raise RuntimeError(error)
    from . import trace_r22 as trace
    trace.mark('occt_boolean_result','VALIDATE_BEGIN')
    checked=_check_result(result)
    trace.mark('occt_boolean_result','VALIDATE_END')
    return checked

def _shared_filler(a,b,tolerance):
    from OCP.BOPAlgo import BOPAlgo_PaveFiller
    from OCP.TopTools import TopTools_ListOfShape
    args=TopTools_ListOfShape();args.Append(a);args.Append(b)
    filler=BOPAlgo_PaveFiller()
    filler.SetArguments(args)
    filler.SetNonDestructive(True)
    filler.SetUseOBB(True)
    filler.SetFuzzyValue(max(float(tolerance)/100.,1e-6))
    from . import trace_r22 as trace
    trace.brep_call('occt_pave_filler',None,None,filler.Perform)
    if filler.HasErrors():
        raise RuntimeError('OCCT PaveFiller intersection failed')
    return filler

def _from_filler(klass,filler,first,second,tolerance):
    from OCP.TopTools import TopTools_ListOfShape
    args=TopTools_ListOfShape();args.Append(first)
    tools=TopTools_ListOfShape();tools.Append(second)
    op=klass(filler)
    try:
        op.SetArguments(args);op.SetTools(tools)
        op.SetNonDestructive(True)
        op.SetUseOBB(True)
        op.SetFuzzyValue(max(float(tolerance)/100.,1e-6))
        from . import trace_r22 as trace
        trace.brep_call('occt_'+klass.__name__,None,None,op.Build)
        if not op.IsDone():
            raise RuntimeError('OCCT Boolean with shared filler failed')
        return _check_result(op.Shape())
    finally:
        del op

def calculate(old,new,tolerance=0.01,*,common_shape=None):
    """Use one intersection and validate Common/Cut volume conservation."""
    from .brep_safety import validated_copy,is_valid
    import math
    if not all(math.isfinite(v) and v>0 for v in (old.volume,new.volume)):
        raise ValueError('Invalid original volume')
    a,repaired_a=validated_copy(old.shape,tolerance)
    b,repaired_b=validated_copy(new.shape,tolerance)
    from .analytic_bore_delta import try_added_bore
    analytic=try_added_bore(a,b,tolerance)
    if analytic is not None:
        common,added,removed=analytic
        cv,av,rv=map(volume,(common,added,removed))
        regions=MaterialRegions(common,added,removed,cv,av,rv)
        if not _regions_balance(regions,old,new,tolerance):
            raise RuntimeError('Analytic bore material balance failed')
        return regions
    filler=_shared_filler(a,b,tolerance)
    # A bare TopoDS_Shape has no pair provenance: its volume may happen
    # to balance even when the intersection belongs to a different pair.
    # IsEqual checks TShape, location and orientation; repairs invalidate it.
    cached = None
    if isinstance(common_shape, CommonEvidence) and not (repaired_a or repaired_b):
        if (common_shape.tolerance_mm == float(tolerance)
                and common_shape.old_shape.IsEqual(a)
                and common_shape.new_shape.IsEqual(b)):
            cached = _check_result(common_shape.shape)
    common = cached if cached is not None else _from_filler(
        BRepAlgoAPI_Common, filler, a, b, tolerance)
    added=_from_filler(BRepAlgoAPI_Cut,filler,b,a,tolerance)
    removed=_from_filler(BRepAlgoAPI_Cut,filler,a,b,tolerance)
    cv,av,rv=map(volume,(common,added,removed))
    abs_tol=max(1e-3,10.*tolerance**3,5e-5*max(old.volume,new.volume))
    if abs(cv+rv-old.volume)>abs_tol or abs(cv+av-new.volume)>abs_tol:
        raise RuntimeError('OCCT Boolean material balance failed')
    return MaterialRegions(common,added,removed,cv,av,rv)

def all_changes(records,a,b,tolerance=0.01,progress=None,precomputed=None):
    """Generate once for STEP/HTML/CSV, reusing precomputed region evidence."""
    cache=dict(precomputed or {});out={};errors={}
    indices=[i for i,r in enumerate(records) if r.status=='CHANGED'
             and r.a_index is not None and r.b_index is not None]
    for n,index in enumerate(indices,1):
        r=records[index]
        entry=cache.get(index)
        if _matching_regions(entry,a[r.a_index],b[r.b_index],tolerance):
            out[index]=entry.regions
            continue
        if progress:progress(f'R15: podział materiału {n}/{len(indices)} — {b[r.b_index].name}')
        from .material_guard import calculate_isolated
        from .native_guard import NativeGeometryFailure
        try:out[index]=calculate_isolated(a[r.a_index],b[r.b_index],tolerance)
        except NativeGeometryFailure:raise
        except Exception as exc:
            raise NativeGeometryFailure('Niekompletna analiza materiału: '+str(exc)) from exc
    return out,errors



def _common_signed_volume(shape):
    """Read OCCT signed volume without monkeypatching C++ binding classes."""
    from OCP.BRepGProp import BRepGProp
    from OCP.GProp import GProp_GProps
    props=GProp_GProps()
    BRepGProp.VolumeProperties_s(shape,props)
    return float(props.Mass())
