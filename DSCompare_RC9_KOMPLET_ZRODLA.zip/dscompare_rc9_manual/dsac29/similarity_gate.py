"""Cheap translation-invariant warning gate for likely unrelated models.

A negative signature overlap is a heuristic, not mathematical proof. The
caller must offer an explicit override whenever the gate triggers.
"""
from collections import Counter
from .geometry import signature


class ModelsUnrelated(RuntimeError):
    pass


def check_related(a, b, min_shared=0.05):
    if not a or not b:
        raise ModelsUnrelated('Jeden z modeli nie zawiera brył.')
    ca=Counter(signature(p) for p in a)
    cb=Counter(signature(p) for p in b)
    shared=sum((ca & cb).values())
    pop=min(len(a),len(b))
    ratio=shared/pop
    va=sum(max(0.,p.volume) for p in a)
    vb=sum(max(0.,p.volume) for p in b)
    vol_ratio=min(va,vb)/max(va,vb) if max(va,vb)>0 else 0.
    if ratio<min_shared and vol_ratio<0.5:
        raise ModelsUnrelated(
            f'Modele mogą być niezwiązane: wspólnych definicji brył {shared}/{pop} '
            f'({ratio:.0%}), stosunek objętości {vol_ratio:.0%}. '
            'To test orientacyjny; mocno zmieniona rewizja może dać taki sam wynik.')
    return {'shared_signatures':shared,'shared_ratio':ratio,'total_volume_ratio':vol_ratio}
