"""Z3 is proprietary; use a current, explicitly exported companion STEP when available."""
from pathlib import Path

class NativeZW3DExportRequired(ValueError):
    pass

def resolve_model(path):
    source=Path(path).expanduser()
    if source.suffix.lower()!='.z3':
        return source
    if not source.is_file():
        raise FileNotFoundError(source)
    # Never rename a native archive to .step. Prefer the newest real STEP next to it.
    exports=[source.with_suffix(ext) for ext in ('.step','.stp','.STEP','.STP')]
    candidates=[p for p in exports if p.is_file() and p.stat().st_size>=100]
    if candidates:
        newest=max(candidates,key=lambda p:p.stat().st_mtime)
        if newest.stat().st_mtime+2 >= source.stat().st_mtime:
            return newest
        raise NativeZW3DExportRequired(f'Znaleziony STEP ({newest.name}) jest starszy niż plik Z3. Wyeksportuj nowy STEP, aby nie porównać nieaktualnej rewizji.')
    raise NativeZW3DExportRequired(f'{source.name}: plik Z3 wymaga eksportu do STEP w ZW3D 2019. Zapisz plik {source.stem}.step obok oryginalnego Z3; aplikacja wykryje go automatycznie.')
