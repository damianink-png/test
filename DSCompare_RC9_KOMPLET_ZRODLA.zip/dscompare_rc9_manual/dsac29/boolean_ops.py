"""Configure OCC Boolean operations before their single Build."""
from OCP.TopTools import TopTools_ListOfShape

def configured(klass,a,b,tolerance):
    arguments=TopTools_ListOfShape();arguments.Append(a)
    tools=TopTools_ListOfShape();tools.Append(b)
    op=klass();op.SetArguments(arguments);op.SetTools(tools)
    op.SetNonDestructive(True)
    op.SetUseOBB(True)
    op.SetFuzzyValue(max(tolerance/100.,1e-6))
    return op
