"""Offline presentation layer; never changes comparison or BOM records."""
import html
import re

CSS = '''
:root{color-scheme:light;--bg:#f1f5f9;--surface:#fff;--field:#f8fafc;--ink:#172b42;--muted:#52657a;--line:#cbd5e1}
body[data-theme=dark]{color-scheme:dark;--bg:#0b1420;--surface:#152333;--field:#1b2d41;--ink:#eef4fc;--muted:#b3c3d5;--line:#3b526d}
body{background:var(--bg);color:var(--ink);margin:24px auto;font-size:14px}
.panel{background:var(--surface);border-color:var(--line);box-shadow:0 3px 14px #142b4210}
table{background:var(--surface)}th,td{border-color:var(--line);padding:10px;line-height:1.5}th{background:var(--field);color:var(--ink)}
tbody tr:nth-child(even),tbody tr:nth-child(even):not([hidden]){background:var(--field)}tbody tr:hover{outline:1px solid var(--line)}
small{color:var(--muted)}a{color:#0072b2}body[data-theme=dark] a{color:#8cc5e3}
input,select,button{font:inherit;background:var(--surface);color:var(--ink);border:1px solid var(--line);border-radius:8px;padding:9px 12px}
button,a,summary,th[role=button]{cursor:pointer}button:hover{background:var(--field)}:focus-visible{outline:3px solid #0072b2;outline-offset:2px}
.report-toolbar{display:flex;flex-wrap:wrap;align-items:center;gap:10px;margin:18px 0}.report-toolbar a{padding:8px 10px}
.status-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:10px;margin:20px 0}
.status-cards button{text-align:left;border-top:4px solid var(--status-color);background:var(--surface)}.status-cards strong{display:block;font-size:26px;margin-top:5px}
.status-chip{display:inline-flex;align-items:center;gap:7px;font-weight:650;white-space:nowrap}.status-chip i{background:var(--status-color);width:11px;height:11px;border-radius:3px;flex:none}
.preview-link{display:block;font-size:11px;margin-top:4px}#table td:first-child{border-left:4px solid var(--status-color)}
.bom-content{max-height:none}.bom-panel:not([open]),.bom-panel summary:hover{background:var(--surface);color:var(--ink)}#print-scope{color:var(--muted);font-size:12px}#no-results{padding:20px;text-align:center;color:var(--muted)}
@media(max-width:700px){body{padding:0 10px;margin:15px auto}.panel{padding:12px}h1{font-size:21px}.status-cards{grid-template-columns:repeat(2,1fr)}}
@media print{body{background:white!important;color:#111!important;max-width:none;margin:0;font-size:10px}.panel,table,th,td{background:white!important;color:#111!important;box-shadow:none}.report-toolbar,.filters,.status-cards,.preview-link{display:none!important}div[style*="overflow"],.bom-content{overflow:visible!important;max-height:none!important}th{position:static!important}thead{display:table-header-group}tr{break-inside:avoid}table{font-size:8px}a{color:#111}details:not([open]){display:none}.status-chip{white-space:normal}.dot,.status-chip i{print-color-adjust:exact} @page{size:A3 landscape;margin:12mm}}
'''

SCRIPT = r'''
<script>(function(){
const select=document.getElementById('status'),search=document.getElementById('search'),table=document.getElementById('table');
function scope(){const count=document.getElementById('count').textContent;document.getElementById('print-scope').textContent=count+' · '+select.options[select.selectedIndex].text+(search.value?' · Szukaj: '+search.value:'');document.getElementById('no-results').hidden=!![...table.tBodies[0].rows].find(r=>!r.hidden);}
document.querySelectorAll('[data-filter]').forEach(b=>b.onclick=()=>{select.value=b.dataset.filter;select.dispatchEvent(new Event('change'));scope();});
document.getElementById('reset-filters').onclick=()=>{search.value='';select.value='ALL';search.dispatchEvent(new Event('input'));select.dispatchEvent(new Event('change'));};
search.addEventListener('input',scope);select.addEventListener('change',scope);scope();
document.getElementById('print-report').onclick=()=>window.print();
const theme=document.getElementById('report-theme');
function applyTheme(dark){document.body.dataset.theme=dark?'dark':'light';theme.textContent=dark?'Jasny motyw':'Ciemny motyw';theme.setAttribute('aria-pressed',String(dark));}
try{applyTheme(localStorage.getItem('dscompare-report-theme')==='dark');}catch(e){applyTheme(false);}
theme.onclick=()=>{const dark=document.body.dataset.theme!=='dark';applyTheme(dark);try{localStorage.setItem('dscompare-report-theme',dark?'dark':'light');}catch(e){}};
const numeric=new Set([6,7,8,9,10,12,14,15,16]);
[...table.tHead.rows[0].cells].forEach((th,index)=>{
 th.tabIndex=0;th.setAttribute('role','button');th.setAttribute('aria-sort','none');th.title='Sortuj: '+th.textContent;
 function sort(){const ascending=th.getAttribute('aria-sort')!=='ascending';
  const rows=[...table.tBodies[0].rows];rows.sort((a,b)=>{
   const left=a.cells[index].querySelector('.status-chip')?.textContent||a.cells[index].textContent;
   const right=b.cells[index].querySelector('.status-chip')?.textContent||b.cells[index].textContent;
   if(numeric.has(index)){if(!left.trim()||!right.trim())return !left.trim()?(right.trim()?1:0):-1;const n=Number(left.replace(/\s/g,'').replace(',','.'))-Number(right.replace(/\s/g,'').replace(',','.'));return ascending?n:-n;}
   const result=left.localeCompare(right,'pl',{numeric:true});return ascending?result:-result;
  });rows.forEach(row=>table.tBodies[0].append(row));[...table.tHead.rows[0].cells].forEach(h=>h.setAttribute('aria-sort','none'));th.setAttribute('aria-sort',ascending?'ascending':'descending');
 }
 th.onclick=sort;th.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();sort();}};
});
})();</script>
'''

def enhance_report(page, palette, counts, preview_ready, available_files):
    def color(key):
        rgb=palette.get(key,palette['SAME'])
        return '#'+''.join(f'{round(max(0,min(1,c))*255):02x}' for c in rgb)
    number=iter(range(sum(counts.values())))
    def badge(match):
        opening,status,text=match.groups();index=next(number)
        key={'CHANGED':'CHANGED_NEW','UNCERTAIN':'UNCERTAIN_NEW'}.get(status,status)
        value=color(key)
        link=(f'<a class="preview-link" href="PODGLAD_KOLOROW_3D.html#pair=PAIR_{index:06d}">Pokaż w 3D ↗</a>' if preview_ready else '')
        return opening+f'<td style="--status-color:{value}"><span class="status-chip" style="--status-color:{value}"><i aria-hidden="true"></i>{text}</span>{link}</td>'
    page=re.sub(r'(<tr[^>]*data-status="([A-Z_]+)"[^>]*>)<td>(.*?)</td>',badge,page)
    cards=[]
    for key,label in [('SAME','Bez zmian'),('MOVED','Przesunięte'),('CHANGED','Zmieniona geometria'),('ADDED','Nowe'),('REMOVED','Usunięte'),('UNCERTAIN','Do sprawdzenia')]:
        count=counts.get(key,0)+(counts.get('RENAMED',0) if key=='SAME' else 0)
        cards.append(f'<button data-filter="{key}" style="--status-color:{color(key)}">{label}<strong>{count}</strong></button>')
    links=''.join(f'<a href="{html.escape(name,quote=True)}">{label}</a>' for name,label in available_files)
    toolbar='<div class="report-toolbar"><button id="report-theme">Ciemny motyw</button><button id="print-report">Drukuj / PDF</button><button id="reset-filters">Wyczyść filtry</button>'+links+'</div><p id="print-scope"></p><div class="status-cards">'+''.join(cards)+'</div>'
    heading=re.search(r'<h1>.*?</h1>',page)
    if heading:
        page=page.replace(heading.group(),'',1).replace('<body>','<body>'+heading.group(),1)
    page=page.replace('</head>','<style>'+CSS+'</style></head>',1)
    page=page.replace('<div class="panel filters">',toolbar+'<div class="panel filters">',1)
    page=page.replace('</body>','<p id="no-results" hidden>Brak pozycji spełniających wybrane kryteria.</p>'+SCRIPT+'</body>',1)
    return page

def enhance_mass_report(page):
    """Use the same readable offline presentation for single/batch mass."""
    page=page.replace('<head>','<head><meta name="viewport" content="width=device-width,initial-scale=1">',1)
    style=CSS+'@page{size:A4 landscape}@media print{body .card,body .box,body details{background:white!important;color:#111!important}.mass-table-wrap{overflow:visible!important}#mass-print-scope{color:#444}}body .card,body .box,body details{background:var(--surface);border:1px solid var(--line);color:var(--ink)}.mass-table-wrap{overflow:auto}#mass-query{width:100%;max-width:420px}'
    page=page.replace('</head>','<style>'+style+'</style></head>',1)
    page=page.replace('<table>','<div class="mass-table-wrap"><table id="mass-table">',1).replace('</table>','</table></div>',1)
    tools='<div class="report-toolbar"><button id="mass-theme">Ciemny motyw</button><button id="mass-print">Drukuj / PDF</button><a href="MASY_CZESCI.csv">Zestawienie CSV</a><input id="mass-query" type="search" aria-label="Szukaj w zestawieniu mas" placeholder="Szukaj modelu lub części…"><span id="mass-count" aria-live="polite"></span></div><p id="mass-print-scope"></p>'
    page=re.sub(r'(</h1>)',lambda m:m.group()+tools,page,count=1)
    script='''<script>(function(){const q=document.getElementById('mass-query'),rows=[...document.querySelectorAll('#mass-table tbody tr')];function update(){let n=0;for(const r of rows){r.hidden=!r.textContent.toLocaleLowerCase('pl').includes(q.value.toLocaleLowerCase('pl'));if(!r.hidden)n++;}document.getElementById('mass-count').textContent='Pozycji: '+n+' / '+rows.length;document.getElementById('mass-print-scope').textContent='Wyświetlono '+n+' z '+rows.length+' pozycji'+(q.value?' · Szukaj: '+q.value:'');}q.addEventListener('input',update);update();document.getElementById('mass-print').onclick=()=>window.print();const theme=document.getElementById('mass-theme');theme.onclick=()=>{const dark=document.body.dataset.theme!=='dark';document.body.dataset.theme=dark?'dark':'light';theme.textContent=dark?'Jasny motyw':'Ciemny motyw';};})();</script>'''
    return page.replace('</body>',script+'</body>',1)
