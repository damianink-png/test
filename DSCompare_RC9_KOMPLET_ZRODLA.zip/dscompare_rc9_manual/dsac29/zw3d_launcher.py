"""Prepare optional ZW3D macro that opens standalone DS Compare EXE.

No native ZW3D API calls; ZW3D 2019 macro execution needs user verification.
The user receives only one EXE, which creates the .mac locally when asked.
"""
from __future__ import annotations
import os
from pathlib import Path
import sys

MACRO_NAME = "DS_COMPARE_START.mac"

def create_macro(executable=None, output_dir=None):
    exe=Path(executable or sys.executable).resolve()
    if not exe.is_file() or exe.suffix.casefold() != ".exe":
        raise ValueError("Wymagany istniejący plik programu DSCompare.exe")
    if '"' in str(exe) or chr(10) in str(exe) or chr(13) in str(exe):
        raise ValueError("Niepoprawna ścieżka do programu")
    target=Path(output_dir) if output_dir is not None else (
        Path(os.environ.get("APPDATA") or (Path.home()/"AppData"/"Roaming"))
        /"DSCompare"/"ZW3D2019")
    target.mkdir(parents=True,exist_ok=True)
    # ZW3D $tm=more file-open macro technique reported by community;
    # this is not guaranteed to be accepted by every ZW3D 2019 installation.
    data=('MACRO main\n'
          '[vxSend,"$tm=more"]\n'
          'BUFFER\n'
          'BUFFER\n'
          '[vxSend,"'+str(exe)+'"]\n'
          'ENDBUFFER\n'
          'ENDBUFFER\n'
          'ENDMACRO\n')
    dest=target/MACRO_NAME
    dest.write_bytes(data.encode("cp1250",errors="strict"))
    return dest
