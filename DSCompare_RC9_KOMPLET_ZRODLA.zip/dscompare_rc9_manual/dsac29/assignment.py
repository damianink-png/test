"""Component-wise minimum-cost one-to-one assignment, with ambiguity audit.

Original implementation of the rectangular Hungarian algorithm. No SciPy
runtime dependency. Candidate generation and geometric evidence stay upstream.
"""
from collections import defaultdict
import numpy as np

def _hungarian(cost):
    n,m=cost.shape
    u=np.zeros(n+1);v=np.zeros(m+1);p=np.zeros(m+1,dtype=int);way=np.zeros(m+1,dtype=int)
    for i in range(1,n+1):
        p[0]=i;j0=0;minimum=np.full(m+1,np.inf);used=np.zeros(m+1,dtype=bool)
        while True:
            used[j0]=True;i0=p[j0];delta=np.inf;j1=0
            available=np.flatnonzero(~used[1:])+1
            current=cost[i0-1,available-1]-u[i0]-v[available]
            improved=available[current<minimum[available]]
            minimum[improved]=cost[i0-1,improved-1]-u[i0]-v[improved]
            way[improved]=j0
            j1=int(available[np.argmin(minimum[available])]);delta=minimum[j1]
            visited=np.flatnonzero(used)
            u[p[visited]]+=delta;v[visited]-=delta
            minimum[~used]-=delta
            j0=j1
            if p[j0]==0:break
        while True:
            j1=way[j0];p[j0]=p[j1];j0=j1
            if j0==0:break
    result=[(int(p[j])-1,j-1) for j in range(1,m+1) if p[j]]
    return result,sum(float(cost[i,j]) for i,j in result)

def assign(edges,margin=0.025,max_component=60):
    """edges[(A,B)] = cost in [0,1]. Return (A,B,ambiguous,gap).

    Maximize eligible pair count, then minimize total cost. Rejecting one chosen
    edge and solving again measures ambiguity of the WHOLE assignment. Large
    components retain exact assignment; expensive uniqueness audit is omitted
    and explicitly reported as unverified.
    """
    adjacent=defaultdict(set)
    for i,j in edges:
        adjacent['a',i].add(('b',j));adjacent['b',j].add(('a',i))
    remaining=set(adjacent);answer=[]
    for root in sorted(adjacent):
        if root not in remaining:continue
        todo=[root];component={root}
        while todo:
            node=todo.pop()
            unseen=adjacent[node]-component
            component.update(unseen);todo.extend(unseen)
        remaining-=component
        aa=sorted(i for role,i in component if role=='a');bb=sorted(j for role,j in component if role=='b')
        if len(aa)==len(bb)==1:
            # Only possible matching in this connected component. By the
            # minimum-cardinality-first objective it is compulsory and its
            # global uniqueness is exact, not a heuristic.
            answer.append((aa[0],bb[0],False,float('inf')))
            continue
        # Enumerate sparse adjacent edges instead of Cartesian aa × bb.
        available_b=set(bb)
        local={(i,j):edges[i,j] for i in aa
               for _,j in adjacent['a',i] if j in available_b}
        audit=max(len(aa),len(bb))<=max_component
        ix={a:i for i,a in enumerate(aa)};jx={b:j for j,b in enumerate(bb)}
        # Dummy penalty dominates the sum of all valid edge costs.
        penalty=len(aa)+len(bb)+1
        matrix=np.full((len(aa),len(bb)+len(aa)),float(penalty))
        matrix[:,:len(bb)]=penalty*100
        for (i,j),cost in local.items():matrix[ix[i],jx[j]]=cost
        chosen,best=_hungarian(matrix)
        for i,j in chosen:
            if j>=len(bb) or (aa[i],bb[j]) not in local:continue
            if not audit:
                # Global optimum is exact; uniqueness is conservatively unverified.
                answer.append((aa[i],bb[j],True,None));continue
            old=matrix[i,j];matrix[i,j]=penalty*100
            _,alternative=_hungarian(matrix);matrix[i,j]=old
            gap=max(0.,alternative-best)
            answer.append((aa[i],bb[j],gap<=margin,gap))
    return sorted(answer)
