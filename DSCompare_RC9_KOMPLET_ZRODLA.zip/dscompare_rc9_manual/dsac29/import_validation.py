"""Repair orientation only when the resulting solid is valid; never drop CAD."""
from OCP.BRepGProp import BRepGProp
from OCP.GProp import GProp_GProps
from OCP.BRepCheck import BRepCheck_Analyzer

class InvalidStepSolid(ValueError):
    pass

def orient_positive_solid(shape,path):
    props=GProp_GProps();BRepGProp.VolumeProperties_s(shape,props)
    volume=float(props.Mass())
    if volume<0:
        corrected=shape.Reversed()
        if BRepCheck_Analyzer(corrected).IsValid():
            check=GProp_GProps();BRepGProp.VolumeProperties_s(corrected,check)
            if check.Mass()>0:return corrected
    reason='niepoprawną strukturę B-Rep' if not BRepCheck_Analyzer(shape).IsValid() else 'zerową objętość'
    raise InvalidStepSolid(f'Nie można porównać części: {path}\nBryła ma {reason} '
        f'(objętość ze znakiem: {volume:.9g} mm³). Napraw tę część w programie CAD '
        'i ponownie wyeksportuj STEP. Analizę przerwano; nie pominięto części ani nie zmieniono jej geometrii.')
