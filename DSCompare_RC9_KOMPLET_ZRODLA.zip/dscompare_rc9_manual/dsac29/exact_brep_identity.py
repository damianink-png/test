"""Exact byte identity of two complete serialized world B-Reps."""
from pathlib import Path

def identical_serialized_brep(a,b):
    a,b=Path(a),Path(b)
    if not a.is_file() or not b.is_file():return False
    if a.stat().st_size!=b.stat().st_size:return False
    # Compare actual bytes, not merely a hash digest.
    with a.open('rb') as left,b.open('rb') as right:
        while True:
            x=left.read(1024*1024)
            y=right.read(1024*1024)
            if x!=y:return False
            if not x:return True
