DS Compare 4.6 R1 — eksport STEP zoptymalizowany i podzłożenia

ZMIANY:
- Współdzielenie definicji identycznych części (bez utraty wystąpień i lokalizacji).
- Dla modeli powyżej 150 brył domyślnie szybka kontrola zapisanych rekordów STEP
  zamiast powtórnego pełnego importu. Wymuszenie pełnego testu: środowiskowa
  zmienna DSCOMPARE_STEP_VERIFY=full. W raporcie JSON widoczny faktyczny tryb.
- Podzłożenia STEP: 01_BEZ_ZMIAN, 02_ZMIENIONE, 03_PRZESUNIETE,
  04_NOWE, 05_USUNIETE, 06_DO_SPRAWDZENIA. Grupy zmienione/przesunięte
  zawierają A_STARA i B_NOWA. ZW3D 2019 powinien otrzymać strukturę STEP,
  ale jej zachowanie przez importer wymaga sprawdzenia na Twoim komputerze.
- Ustawienie AP242IS? NIE: prawidłowa wartość dla OCCT to AP242DIS.
  AP242DIS jest domyślny dla nowej instalacji; można wybrać AP214IS.
  Stare zapisane ustawienie schematu nie jest nadpisywane.
- Przezroczystość starej A: zapisywana na powierzchniach (RGBA plus
  SURFACE_STYLE_TRANSPARENT). NIE ma gwarancji odwzorowania w ZW3D 2019.
  W razie ignorowania jej przez importer ukryj grupę starej rewizji w drzewie.
- Motyw: przycisk słońce / księżyc w górnym pasku. Bez listy rozwijanej.
- Jaśniejszy motyw: wyraźniejsze ramki, tło pól i nagłówki tabel.

URUCHOMIENIE: Rozpakuj cały ZIP, uruchom DSCompareV3.exe.
Nie usuwaj folderu _internal. Przed nowym porównaniem wybierz modele A i B.

OSTRZEŻENIA: Silnik nie zmienia algorytmu porównania/parowania.
Test 120 wystąpień jednej definicji: mediana pełnego eksportu 1.269 s
(v4.6) vs 0.109 s (R1), lokalny Linux / Python, 3 próby. Nie jest to
gwarancja dla unikalnych dużych części. Tryb szybkiej weryfikacji nie jest
równoznaczny z pełną diagnostyką po ponownym imporcie.
