@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUDUJ_WINDOWS.ps1"
if errorlevel 1 (
 echo BLAD KOMPILACJI. Sprawdz komunikaty powyzej.
 pause
 exit /b 1
)
echo Gotowe: dist\DSCompare\DSCompare.exe
pause
