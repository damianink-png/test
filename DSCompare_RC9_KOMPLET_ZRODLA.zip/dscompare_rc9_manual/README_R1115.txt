DS Compare R11.15 — pierwsza analiza STEP:
Trwały cache B-Rep domyślnie wyłączony; opcjonalny w Ustawieniach.
Nie zmieniono obliczania dokładnej powierzchni/masy, reguł BOM ani klasyfikacji B-Rep.
Import bez nieużywanych metadanych źródłowych (kolor/layer/material/PMI).
STEP bez pustych elementów ABSR, równoległy import A/B i interfejs R11.14 zachowane.
Wyniki wydajności z GitHub Actions dotyczą testowanych modeli, nie gwarantują zysku na każdym STEP.
