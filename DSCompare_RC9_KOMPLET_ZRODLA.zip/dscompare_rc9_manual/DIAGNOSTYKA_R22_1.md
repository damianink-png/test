# DS Compare R22.1 – wariant diagnostyczny (bez zmiany algorytmu)

- Przed i po etapach zapisuje `_ETAPY_DIAGNOSTYKA.jsonl` ze znacznikiem UTC, czasem, PID, RAM (RSS i peak), liczbą wywołań B-Rep. Każdy wiersz zapisany i `fsync`.
- `AWARIA_PYTHON_FAULTHANDLER.txt`: stos Pythona w razie sygnału obsługiwanego przez faulthandler. Na Windows natywne 0xC0000005 może wymagać WER LocalDumps, konfigurowanego w workflow.
- `DSCOMPARE_TRACE_BREP=1` włącza zapisy natychmiast PRZED i PO ryzykownej operacji CAD z identyfikatorami części; wyłączyć poza diagnostyką, bo `fsync` spowalnia przetwarzanie.
- W CI tworzone minidumpy i logi nawet gdy porównanie upadnie lub osiągnie 2400s. Zmiana nie podnosi limitu 40 minut.
- Ta wersja **nie naprawia** jeszcze miejsca awarii — umożliwia jego wskazanie. Nie zastępuje testów >600 brył i zmian rzeczywistych rewizji.
- W razie awarii zadanie **nie przechodzi**. Nie oznacza części jako identycznych.
