# DS Compare R22.2 SAFE RC1 — wariant stabilizacyjny

## Poprawki

- `dsac29/native_guard.py`: wywołania Open CASCADE w odizolowanym procesie z serializowanymi B-Rep, kontrolą błędów, awarii i indywidualnym limitem 35 sekund. Wykryty crash, nieznany wynik lub przekroczenie czasu **zatrzymuje porównanie**. Nigdy nie jest oznaczany jako SAME.
- `DSCompareV3.py`: nowa komenda techniczna `--native-brep-compare`, również w skompilowanym EXE, bez uruchamiania Qt.
- `dsac29/compare.py`: po potwierdzonym globalnym przesunięciu dużych złożeń (co najmniej 600 brył i >40% potwierdzonych par) ryzykowne testy obrotów odbywają się w procesie odizolowanym. Budżet tych testów: 240 s. W razie niemożności ukończenia — błąd, nie zgadywana klasyfikacja.
- `dsac29/revision_overlap.py`: izolacja weryfikacji wspólnego materiału OCC Common, jeśli duże złożenie (>=600 brył) posiada >=80 niedopasowanych wystąpień. Budżet: 240 s, kontrola integralności zwróconego kształtu Common. Końcowe operacje przy akceptowanych parach pozostają w procesie głównym i **nie są jeszcze w pełni odizolowane**.
- `tests/test_r22_2_native_guard.py`: testy identycznej/zmienionej geometrii, przesunięcia, obracania, celowej awarii i timeoutu, globalnego przesunięcia >600 elementów z rzeczywiście zmienioną częścią.
- `ci/large_exe.py`: scenariusze źródłowe Voron V2 i Trident oraz przesunięcie i przesunięcie+rewizja. Nie zwiększono limitu porównania (2400 s).

## Testy

- 44 PASS w wybranych testach, łącznie z testami izolowanego procesu.
- Wcześniejsze uruchomienie podstawowego zestawu: 167 PASS, 2 FAIL tylko przez brak `PySide6` w środowisku Linux, 1 SKIPPED. Ponowione uruchomienie po rozszerzeniu TESTUJ.py nie ukończyło się w dostępnym limicie, dlatego pełna regresja pozostaje NIEPOTWIERDZONA.
- Dwa testy z małych STEP: przetwarzanie bez STEP oraz przetwarzanie z eksportem STEP+HTML — PASS. Eksportowany STEP gotowy, HTML 8/8 brył, pominiętych 0.
- Kompilacja Windows i duże testy Voron dla tej konkretnej wersji NIE zostały jeszcze wykonane. Plik workflow jest gotowy do uruchomienia na GitHub Actions.

## Ograniczenia

Poprawki **przeciwdziałają zamknięciu procesu** przy ryzykownych operacjach i ograniczają jego wiszenie. Nie stanowią jeszcze dowodu, że duże złożenia będą poprawnie sklasyfikowane jako całkowicie zgodne po globalnym przesunięciu. Jeśli geometria nie zostanie zweryfikowana, program przerwie analizę z błędem, zamiast pokazać fałszywy pozytywny wynik. W kolejnej iteracji trzeba przeanalizować artefakty z Windows, zoptymalizować faktycznie kosztowne operacje i objąć procesem odizolowanym również etapy obliczania materiału przy akceptowanych parach.
