"""Compare the old/new wire filter on one captured B-Rep pair."""
import json, sys, types, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from dsac29.native_guard import _load_brep
from dsac29.geometry import describe
from dsac29.step_reexport_tolerance import reexport_equivalent_world
import dsac29.parametric_identity as current
folder=Path(sys.argv[1])
a,b=[describe(_load_brep(folder/(n+'.brep')),n,n) for n in ('A','B')]
source=Path(current.__file__).read_text()
assert source.count('bb=Bnd_Box();BRepBndLib.AddOptimal_s(w,bb,False,False)')==1
old=types.ModuleType('dsac29.parametric_identity')
exec(compile(source.replace('bb=Bnd_Box();BRepBndLib.AddOptimal_s(w,bb,False,False)',
                           'bb=Bnd_Box();BRepBndLib.Add_s(w,bb,False)'),str(current.__file__),'exec'),old.__dict__)
for label,module in [('before',old),('after',current)]:
 sys.modules['dsac29.parametric_identity']=module
 t=time.monotonic()
 result=reexport_equivalent_world(a,b,.01,allow_boolean=False)
 print(json.dumps({'pair':folder.name,'version':label,'match':result,'seconds':round(time.monotonic()-t,3)}),flush=True)
sys.modules['dsac29.parametric_identity']=current
