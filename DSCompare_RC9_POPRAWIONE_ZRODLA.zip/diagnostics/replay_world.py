import sys,time,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from dsac29.native_guard import _load_brep
from dsac29.geometry import describe
from dsac29.step_reexport_tolerance import reexport_equivalent_world,shape_valid
root=Path(sys.argv[1])
for d in sorted(root.glob('world_negative_*')):
 t=time.monotonic();a=describe(_load_brep(d/'A.brep'),'A','A');b=describe(_load_brep(d/'B.brep'),'B','B')
 phases=[]
 try:result=reexport_equivalent_world(a,b,.01,allow_boolean=False,progress=phases.append,_original_boundary_only=not shape_valid(a.shape) and not shape_valid(b.shape))
 except Exception as e:result=str(e)
 print(json.dumps(dict(pair=d.name,result=result,seconds=round(time.monotonic()-t,2),valid=[shape_valid(a.shape),shape_valid(b.shape)],last_phase=phases[-1])),flush=True)
