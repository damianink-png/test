// DS Assembly Compare V1.0.0 - ZW3D 2019 Standard x64 / Windows
// Portable ZW3D add-in: ZW3D symbols located dynamically; does NOT import zw3d.lib.
// READ ONLY.  Commands after DLL load: ~DSAC_A, ~DSAC_B, ~DSAC_INFO.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define PSAPI_VERSION 1
#include <windows.h>
#include <psapi.h>
#include <shlobj.h>
#include <shellapi.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <map>
#include <sstream>
#include <string>
#include <vector>
#include "compare_core.hpp"

namespace {
struct svxPoint { double x,y,z; };
struct svxVector { double x,y,z; };
struct svxTriangle { svxPoint Pnt[3]; svxVector Normal; };
struct svxMatrix { char identity; double xx,yx,zx,xt, xy,yy,zy,yt, xz,yz,zz,zt; };
struct svxMassProp { double Density,Area,Volume,Mass; svxPoint Center; svxVector Axis[3]; double Im[6],Ip[3],Rad[3]; };
using FnCmd=int (*)(const char*,void*,double);
using FnUnload=int (*)(const char*);
using FnMsg=void (*)(char*);
using FnFree=void (*)(void**);
using FnActive=void (*)(char*,int);
using FnComps=int (*)(char*,char*,int*,int**);
using FnCompPart=int (*)(int,char*,int,char*,int);
using FnMatrix=int (*)(int,svxMatrix*);
using FnName=int (*)(int,char*,int);
using FnShapes=int (*)(char*,char*,int*,int**);
using FnMass=int (*)(int,double,svxMassProp*);
using FnShapeList=int (*)(int,int*,int**);
using FnFacets=int (*)(int,int*,svxTriangle**);

struct Api {
 FnCmd command=nullptr; FnUnload unload=nullptr; FnMsg msg=nullptr; FnFree freeMem=nullptr;
 FnActive fileActive=nullptr, rootActive=nullptr;
 FnComps comps=nullptr;FnCompPart compPart=nullptr;FnMatrix matrix=nullptr;
 FnName entName=nullptr;FnShapes shapes=nullptr;FnMass mass=nullptr;
 FnShapeList faces=nullptr,edges=nullptr;FnFacets facets=nullptr;
} api;

dsac::Snapshot referenceA;
bool haveA=false;
std::string lastError;

// GetProcAddress from every module already loaded by the ZW3D process.
void* exportSymbol(const char* symbol){
 HMODULE mods[2048]={}; DWORD bytes=0;
 if(!EnumProcessModules(GetCurrentProcess(),mods,sizeof(mods),&bytes))return nullptr;
 DWORD n=std::min<DWORD>(bytes/sizeof(HMODULE),2048);
 for(DWORD i=0;i<n;i++)if(mods[i])if(FARPROC p=GetProcAddress(mods[i],symbol))return reinterpret_cast<void*>(p);
 return nullptr;
}
template<class T> bool resolve(T&field,const char*symbol){field=reinterpret_cast<T>(exportSymbol(symbol));
 if(field)return true;lastError=std::string("Brak funkcji ZW3D API: ")+symbol;return false;}
void message(const std::string&s){if(api.msg){std::string copy=s;api.msg(&copy[0]);}else MessageBoxA(nullptr,s.c_str(),"DS Assembly Compare",MB_OK|MB_ICONWARNING);}
bool initApi(){
 // All these API symbols are present in the previously provided ZW3D headers.
 return resolve(api.command,"cvxCmdFunc")&&resolve(api.unload,"cvxCmdFuncUnload")&&
  resolve(api.msg,"cvxMsgDisp")&&resolve(api.freeMem,"cvxMemFree")&&
  resolve(api.fileActive,"cvxFileInqActive")&&resolve(api.rootActive,"cvxRootInqActive")&&
  resolve(api.comps,"cvxPartInqComps")&&resolve(api.compPart,"cvxCompInqPart")&&
  resolve(api.matrix,"cvxEntMatrix")&&resolve(api.entName,"cvxEntName")&&
  resolve(api.shapes,"cvxPartInqShapes")&&resolve(api.mass,"cvxPartInqShapeMass")&&
  resolve(api.faces,"cvxPartInqShapeFaces")&&resolve(api.edges,"cvxPartInqShapeEdges");
 // Facets optional: legacy versions may lack it.
}
void freeApi(void*p){if(p&&api.freeMem)api.freeMem(&p);}
std::string trim(const char*str){return str?std::string(str):std::string();}
// ZW3D uses ANSI strings in this vintage API. Convert Polish filenames to UTF-8 for reports.
std::string utf8(const std::string&s){
 if(s.empty())return {};
 int n=MultiByteToWideChar(CP_ACP,0,s.c_str(),int(s.size()),nullptr,0);
 if(n<=0)return s;
 std::wstring w(size_t(n),L'\0'); MultiByteToWideChar(CP_ACP,0,s.c_str(),int(s.size()),&w[0],n);
 int z=WideCharToMultiByte(CP_UTF8,0,w.c_str(),n,nullptr,0,nullptr,nullptr);
 if(z<=0)return s;
 std::string o(size_t(z),'\0');WideCharToMultiByte(CP_UTF8,0,w.c_str(),n,&o[0],z,nullptr,nullptr);return o;
}
void names(char (&file)[256],char (&root)[256]){
 std::memset(file,0,256); std::memset(root,0,256);
 api.fileActive(file,256);api.rootActive(root,256);
}
// Matrix uses ZW3D local-X/Y/Z axis columns.
dsac::Pose poseOf(const svxMatrix&m){
 dsac::Pose p;
 if(m.identity)return p;
 p.r[0]=m.xx;p.r[1]=m.xy;p.r[2]=m.xz;
 p.r[3]=m.yx;p.r[4]=m.yy;p.r[5]=m.yz;
 p.r[6]=m.zx;p.r[7]=m.zy;p.r[8]=m.zz;
 p.t[0]=m.xt;p.t[1]=m.yt;p.t[2]=m.zt;
 return p;
}
// Triangle properties, triangulation only supplies rotation-invariant face samples.
static inline double crossNorm(const svxPoint&a,const svxPoint&b,const svxPoint&c){
 double u[3]={b.x-a.x,b.y-a.y,b.z-a.z},v[3]={c.x-a.x,c.y-a.y,c.z-a.z};
 double x=u[1]*v[2]-u[2]*v[1],y=u[2]*v[0]-u[0]*v[2],z=u[0]*v[1]-u[1]*v[0];
 return 0.5*std::sqrt(x*x+y*y+z*z);
}
std::string geometryKey(const std::string&file,const std::string&part){return file+"\x1f"+part;}
class Reader {
  std::map<std::string,dsac::Geometry> geomCache;
  dsac::Snapshot& out;
  std::vector<std::string> ancestry;
  int maxNodes=2000, maxDepth=12;
public:
  explicit Reader(dsac::Snapshot& s):out(s){}
  dsac::Geometry geometry(const std::string&file,const std::string&part){
    const std::string key=geometryKey(file,part);
    auto it=geomCache.find(key);if(it!=geomCache.end())return it->second;
    dsac::Geometry g;int n=0,*ids=nullptr;
    char f[256]={},p[256]={};strncpy_s(f,file.c_str(),_TRUNCATE);strncpy_s(p,part.c_str(),_TRUNCATE);
    int rc=api.shapes(f,p,&n,&ids);
    if(rc!=0||n<0||n>1000||(n>0&&!ids)){
      g.issue="cvxPartInqShapes failed or exceeded solid limit (1000)";
      freeApi(ids);geomCache[key]=g;return g;
    }
    if(n==0){g.issue="No solid body in referenced part";freeApi(ids);geomCache[key]=g;return g;}
    g.valid=true;
    for(int i=0;i<n;i++){
      svxMassProp prop={};
      if(api.mass(ids[i],1.0,&prop)!=0||!std::isfinite(prop.Volume)||!std::isfinite(prop.Area)){
        g.valid=false;g.issue="cvxPartInqShapeMass failed";break;
      }
      dsac::SolidDescriptor d;
      d.volume=prop.Volume;d.area=prop.Area;
      d.moments[0]=prop.Ip[0];d.moments[1]=prop.Ip[1];d.moments[2]=prop.Ip[2];
      std::sort(d.moments,d.moments+3);
      int nf=0,ne=0,*faceIds=nullptr,*edgeIds=nullptr;
      bool okF=(api.faces(ids[i],&nf,&faceIds)==0&&nf>=0&&nf<=10000&&(nf==0||faceIds));
      bool okE=(api.edges(ids[i],&ne,&edgeIds)==0&&ne>=0&&ne<=20000&&(ne==0||edgeIds));
      if(!okF||!okE){g.valid=false;g.issue="Cannot query complete face/edge count";freeApi(faceIds);freeApi(edgeIds);break;}
      d.faces=nf;d.edges=ne;
      // Facets are optional because obtaining a full mesh for a large welded assembly is expensive.
      d.surfaceComplete=(api.facets!=nullptr&&nf>0&&nf<=256);
      if(d.surfaceComplete)for(int k=0;k<nf;k++){
        int nt=0;svxTriangle*tri=nullptr;
        int success=api.facets(faceIds[k],&nt,&tri);
        if(success!=0 || nt<=0 || nt>50000 || !tri){d.surfaceComplete=false;freeApi(tri);break;}
        double total=0,cx=0,cy=0,cz=0;
        for(int h=0;h<nt;h++){
          double area=crossNorm(tri[h].Pnt[0],tri[h].Pnt[1],tri[h].Pnt[2]);
          total+=area;
          cx+=area*(tri[h].Pnt[0].x+tri[h].Pnt[1].x+tri[h].Pnt[2].x)/3;
          cy+=area*(tri[h].Pnt[0].y+tri[h].Pnt[1].y+tri[h].Pnt[2].y)/3;
          cz+=area*(tri[h].Pnt[0].z+tri[h].Pnt[1].z+tri[h].Pnt[2].z)/3;
        }
        if(total<1e-15){d.surfaceComplete=false;freeApi(tri);break;}
        cx=cx/total-prop.Center.x;cy=cy/total-prop.Center.y;cz=cz/total-prop.Center.z;
        d.surface.push_back({total,std::sqrt(cx*cx+cy*cy+cz*cz)});
        freeApi(tri);
      }
      if(!d.surfaceComplete)d.surface.clear();
      else std::sort(d.surface.begin(),d.surface.end(),[](const auto&a,const auto&b){
        if(a.area!=b.area)return a.area<b.area;
        return a.radius<b.radius;});
      freeApi(faceIds);freeApi(edgeIds);
      g.solids.push_back(std::move(d));
    }
    freeApi(ids);
    if(!g.valid)g.solids.clear();
    geomCache[key]=g;return g;
  }
  // Read the current top-level part and flatten all nested subassemblies.
  bool traverse(const std::string&file,const std::string&part,const std::string&prefix,
                const dsac::Pose&world,bool worldValid,int depth){
    if(depth>=maxDepth){lastError="Hierarchy depth exceeds 12: "+part;return false;}
    const std::string key=geometryKey(file,part);
    if(std::find(ancestry.begin(),ancestry.end(),key)!=ancestry.end()){
      lastError="Cycle in component references: "+part;return false;
    }
    ancestry.push_back(key);
    char f[256]={},p[256]={};strncpy_s(f,file.c_str(),_TRUNCATE);strncpy_s(p,part.c_str(),_TRUNCATE);
    int n=0,*ids=nullptr;
    int rc=api.comps(f,p,&n,&ids);
    if(rc!=0||n<0||n>maxNodes||(n>0&&!ids)){
      lastError="cvxPartInqComps error on "+file+":"+part;
      freeApi(ids);ancestry.pop_back();return false;
    }
    // Do not truncate silently; incomplete comparison is rejected.
    if(out.items.size()+size_t(n)>size_t(maxNodes)){
      lastError="Exceeded 2000 component occurrences";
      freeApi(ids);ancestry.pop_back();return false;
    }
    for(int i=0;i<n;i++){
      int id=ids[i];char ff[256]={},pp[256]={},nn[256]={};
      if(api.compPart(id,ff,256,pp,256)!=0){
        lastError="cvxCompInqPart error, component ID "+std::to_string(id);
        freeApi(ids);ancestry.pop_back();return false;
      }
      if(api.entName(id,nn,256)!=0 || !nn[0])strncpy_s(nn,pp,_TRUNCATE);
      dsac::Item item;
      item.name=utf8(trim(nn));item.file=utf8(trim(ff));item.part=utf8(trim(pp));
      item.path=prefix+"/"+item.name;
      // Duplicate sibling names need an occurrence disambiguator for matching.
      int earlier=0;
      for(const auto&prev:out.items)if(prev.path==item.path||prev.path.rfind(item.path+"#",0)==0)earlier++;
      if(earlier)item.path+="#"+std::to_string(earlier+1);
      svxMatrix matrix={};
      bool matrixValid=(api.matrix(id,&matrix)==0);
      item.poseValid=worldValid&&matrixValid&&depth==0; // Nested cvxEntMatrix frame convention needs in-ZW3D verification.
      item.pose=dsac::multiply(world,matrixValid?poseOf(matrix):dsac::Pose{});
      // Keep the SDK-native ANSI names to query geometry, not UTF-8 strings.
      item.geometry=geometry(trim(ff),trim(pp));
      out.items.push_back(item);
      // Inspect subassemblies, if the referenced part has nested components.
      if(!traverse(trim(ff),trim(pp),item.path,item.pose,item.poseValid,depth+1)){
        freeApi(ids);ancestry.pop_back();return false;
      }
    }
    freeApi(ids);ancestry.pop_back();return true;
  }
};

std::string csvCell(std::string s){
 bool quote=s.find_first_of(";\"\r\n")!=std::string::npos;
 std::string o="\"";for(char c:s){if(c=='\"')o+='\"';o+=c;}o+='\"';return quote?o:s;
}
std::string htmlEsc(const std::string&s){std::string o;for(char c:s){switch(c){
 case '&':o+="&amp;";break;case '<':o+="&lt;";break;case '>':o+="&gt;";break;
 case '\"':o+="&quot;";break;case '\'':o+="&#39;";break;default:o+=c;}}return o;}
std::string num(double n,int dp=3){std::ostringstream q;q<<std::fixed<<std::setprecision(dp)<<n;return q.str();}
std::wstring reportDirectory(){
 wchar_t folder[MAX_PATH]={};
 if(SHGetFolderPathW(nullptr,CSIDL_PERSONAL,nullptr,SHGFP_TYPE_CURRENT,folder)!=S_OK){
   if(!GetTempPathW(MAX_PATH,folder))return L"";
 }
 std::wstring path=folder;
 if(!path.empty()&&path.back()!=L'\\')path+=L'\\';
 path+=L"DSAssemblyCompare";
 if(!CreateDirectoryW(path.c_str(),nullptr)&&GetLastError()!=ERROR_ALREADY_EXISTS)return L"";
 return path;
}
std::wstring reportStem(){
 SYSTEMTIME t;GetLocalTime(&t);wchar_t name[80]={};
 swprintf_s(name,L"DSAC_%04u%02u%02u_%02u%02u%02u",t.wYear,t.wMonth,t.wDay,t.wHour,t.wMinute,t.wSecond);
 return name;
}
bool writeText(const std::wstring&filename,const std::string&bytes){
 HANDLE fd=CreateFileW(filename.c_str(),GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
 if(fd==INVALID_HANDLE_VALUE)return false;
 DWORD done=0;bool ok=WriteFile(fd,bytes.data(),DWORD(bytes.size()),&done,nullptr)&&done==bytes.size();
 CloseHandle(fd);return ok;
}
// Quantities are counted by referenced part, regardless of the number of unique definitions.
std::map<std::string,int> countParts(const dsac::Snapshot&s){
 std::map<std::string,int> count;
 for(const auto&item:s.items)count[item.part+" | "+item.file]++;
 return count;
}
std::string reportQuantitiesCsv(const dsac::Snapshot&a,const dsac::Snapshot&b){
 auto ac=countParts(a),bc=countParts(b);
 std::ostringstream o;
 o<<"Part_i_plik;Liczba_A;Liczba_B;Roznica_B_minus_A\r\n";
 for(const auto&kv:bc)if(!ac.count(kv.first))ac[kv.first]=0;
 for(const auto&kv:ac){int nb=bc.count(kv.first)?bc[kv.first]:0;
  o<<csvCell(kv.first)<<';'<<kv.second<<';'<<nb<<';'<<(nb-kv.second)<<"\r\n";
 }
 return std::string("\xef\xbb\xbf")+o.str();
}
std::string reportCsv(const dsac::Snapshot&a,const dsac::Snapshot&b,const std::vector<dsac::Result>&rows){
 std::ostringstream o;
 o<<"Lp;Status;Nazwa_A;Nazwa_B;Part_A;Part_B;Sciezka_A;Sciezka_B;Plik_A;Plik_B;Geometria;DX_mm;DY_mm;DZ_mm;Przesuniecie_mm;Obrot_stopnie;Pewnosc_dopasowania\r\n";
 for(size_t k=0;k<rows.size();k++){
  const auto&r=rows[k];const dsac::Item*pa=r.ia>=0?&a.items[size_t(r.ia)]:nullptr;
  const dsac::Item*pb=r.ib>=0?&b.items[size_t(r.ib)]:nullptr;
  auto c=[&](const std::string&s){return csvCell(s);};
  bool poseOK=pa&&pb&&pa->poseValid&&pb->poseValid;
  o<<k+1<<';'<<c(r.status)<<';'
   <<c(pa?pa->name:"")<<';'<<c(pb?pb->name:"")<<';'
   <<c(pa?pa->part:"")<<';'<<c(pb?pb->part:"")<<';'
   <<c(pa?pa->path:"")<<';'<<c(pb?pb->path:"")<<';'
   <<c(pa?pa->file:"")<<';'<<c(pb?pb->file:"")<<';'
   <<(r.ia<0||r.ib<0?"-":[&]{return r.geo==1?"CECHY_ZGODNE":r.geo<0?"ROZNE":"NIEZWERYFIKOWANE";}())<<';'
   <<(poseOK?num(r.dx):"")<<';'<<(poseOK?num(r.dy):"")<<';'<<(poseOK?num(r.dz):"")<<';'
   <<(poseOK?num(r.move):"")<<';'<<(poseOK?num(r.rotation):"")<<';'
   <<(r.uncertain?"NIEPEWNE":"WYSOKIE")<<"\r\n";
 }
 return std::string("\xef\xbb\xbf")+o.str();
}
std::string reportHtml(const dsac::Snapshot&a,const dsac::Snapshot&b,const std::vector<dsac::Result>&rows){
 int added=0,removed=0,changed=0,move=0,renamed=0,unchanged=0,uncertain=0;
 for(const auto&r:rows){if(r.ia<0)added++;else if(r.ib<0)removed++;else {
  if(r.geo<0)changed++;if(r.moved||r.rotated)move++;if(r.nameChange)renamed++;
  if(r.geo==1&&!r.moved&&!r.rotated&&!r.nameChange&&!r.referenceChange)unchanged++;
  if(r.uncertain)uncertain++;
 }}
 std::ostringstream s;
 s<<"<!doctype html><html lang='pl'><head><meta charset='utf-8'><title>DS Assembly Compare</title>"
  "<meta name='viewport' content='width=device-width,initial-scale=1'>"
  "<style>body{font:14px Segoe UI,Arial,sans-serif;background:#f4f6f9;color:#182233;margin:0}"
  ".wrap{max-width:1500px;margin:32px auto;padding:0 22px}h1{font-size:25px;margin:0 0 5px}.muted{color:#64748b}"
  ".grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin:22px 0}"
  ".stat{background:white;border:1px solid #dee5ed;padding:15px;border-radius:10px}.stat b{font-size:26px;display:block}"
  ".panel{background:white;border:1px solid #dee5ed;border-radius:10px;padding:12px;overflow:auto}"
  "table{border-collapse:collapse;width:100%;min-width:1100px}td,th{padding:10px;border-bottom:1px solid #e7ebf1;text-align:left;white-space:nowrap}"
  "th{background:#f8fafc;position:sticky;top:0}tr:hover{background:#f8fafc}.new{color:#19794d}.del{color:#b42318}"
  ".warn{color:#b45309}.sub{font-size:12px;color:#64748b}input{padding:10px;border:1px solid #d2dce7;border-radius:8px;min-width:300px;margin:10px 0}"
  "</style></head><body><div class='wrap'><h1>DS Assembly Compare <small>V1</small></h1>"
  "<p class='muted'>Porównanie bez zmian w modelach. Zgodność geometrii oznacza zgodność badanych cech, a nie matematyczny dowód identyczności B-Rep.</p>";
 s<<"<p><b>A:</b> "<<htmlEsc(a.file)<<" / "<<htmlEsc(a.root)<<"<br><b>B:</b> "<<htmlEsc(b.file)<<" / "<<htmlEsc(b.root)<<"</p>";
 s<<"<div class='grid'>";
 for(const auto&v:std::vector<std::pair<std::string,int>>{{"Wystąpienia A",int(a.items.size())},{"Wystąpienia B",int(b.items.size())},{"Bez zmian",unchanged},{"Geometria inna",changed},{"Położenie / obrót",move},{"Nazwy zmienione",renamed},{"Dodane",added},{"Usunięte",removed},{"Niepewne",uncertain}}){
  s<<"<div class='stat'><b>"<<v.second<<"</b>"<<v.first<<"</div>";
 }
 auto ac=countParts(a),bc=countParts(b);
 for(const auto&kv:bc)if(!ac.count(kv.first))ac[kv.first]=0;
 s<<"<h2>Porównanie liczby wystąpień</h2><div class='panel'><table><thead><tr><th>Część / plik</th><th>Wystąpienia A</th><th>Wystąpienia B</th><th>Różnica</th></tr></thead><tbody>";
 for(const auto&kv:ac){
  int nb=bc.count(kv.first)?bc[kv.first]:0;
  s<<"<tr><td>"<<htmlEsc(kv.first)<<"</td><td>"<<kv.second<<"</td><td>"<<nb<<"</td><td>"<<(nb-kv.second)<<"</td></tr>";
 }
 s<<"</tbody></table></div><h2>Zmiany komponentów</h2>";
 s<<"</div><div class='panel'><input id='filter' placeholder='Szukaj nazwy, statusu lub ścieżki...' oninput='filterRows()'>"
   "<table id='report'><thead><tr><th>Lp</th><th>Status</th><th>Wystąpienie A</th><th>Wystąpienie B</th><th>Część A / B</th><th>Δ X [mm]</th><th>Δ Y [mm]</th><th>Δ Z [mm]</th><th>Δ położenia [mm]</th><th>Obrót [°]</th><th>Ścieżka A → B</th></tr></thead><tbody>";
 for(size_t i=0;i<rows.size();i++){
  const auto&r=rows[i];const dsac::Item*pa=r.ia>=0?&a.items[size_t(r.ia)]:nullptr;
  const dsac::Item*pb=r.ib>=0?&b.items[size_t(r.ib)]:nullptr;
  bool poseOK=pa&&pb&&pa->poseValid&&pb->poseValid;
  const char*css=r.ia<0?"new":r.ib<0?"del":r.geo<0||r.uncertain?"warn":"";
  s<<"<tr><td>"<<i+1<<"</td><td class='"<<css<<"'>"<<htmlEsc(r.status)<<"</td>"
   <<"<td>"<<htmlEsc(pa?pa->name:"")<<"</td><td>"<<htmlEsc(pb?pb->name:"")<<"</td>"
   <<"<td>"<<htmlEsc(pa?pa->part:"")<<" <span class='sub'>→</span> "<<htmlEsc(pb?pb->part:"")<<"</td>"
   <<"<td>"<<(poseOK?num(r.dx):"—")<<"</td><td>"<<(poseOK?num(r.dy):"—")<<"</td><td>"<<(poseOK?num(r.dz):"—")<<"</td>"
   <<"<td>"<<(poseOK?num(r.move):"—")<<"</td><td>"<<(poseOK?num(r.rotation):"—")<<"</td>"
   <<"<td>"<<htmlEsc(pa?pa->path:"")<<" → "<<htmlEsc(pb?pb->path:"")<<"</td></tr>";
 }
 s<<"</tbody></table></div><p class='muted'>Progi: przesunięcie 0,01 mm, obrót 0,05°. "
   "Element o odmiennej nazwie i geometrii bez jednoznacznej referencji może być pokazany jako usunięty i dodany. "
   "Przy nieudanym odczycie geometrii wynik jest NIEZWERYFIKOWANY.</p>"
   "</div><script>function filterRows(){var v=document.getElementById('filter').value.toLowerCase();"
   "document.querySelectorAll('#report tbody tr').forEach(function(r){r.style.display=r.innerText.toLowerCase().includes(v)?'':'none'})}</script></body></html>";
 return s.str();
}
void info(){MessageBoxW(nullptr,
 L"DS Assembly Compare V1 - ZW3D 2019 x64\n\n"
 L"1. Otworz pierwsze zlozenie (A) i wpisz ~DSAC_A.\n"
 L"2. Przelacz na drugie zlozenie (B) i wpisz ~DSAC_B.\n"
 L"3. Raport HTML i CSV zapisze sie w Dokumenty\\DSAssemblyCompare.\n\n"
 L"Dziala w trybie TYLKO ODCZYT. Nie zmienia modelu.\n"
 L"Dopasowania i porownanie geometrii to w V1 analiza cech, nie dokladny B-Rep.",
 L"DS Assembly Compare",MB_OK|MB_ICONINFORMATION);
}
void snapshotA(){
 char file[256],root[256];names(file,root);
 if(!file[0]||!root[0]){message("DSAC: Otworz zlozenie A przed ~DSAC_A.");return;}
 dsac::Snapshot s;s.file=utf8(file);s.root=utf8(root);
 Reader r(s);lastError.clear();
 if(!r.traverse(file,root,"",dsac::Pose{},true,0)||s.items.empty()){
   message("DSAC A: blad odczytu: "+(lastError.empty()?"no components found":lastError));return;
 }
 referenceA=std::move(s);haveA=true;
 message("DSAC: A zapisane w pamieci ("+std::to_string(referenceA.items.size())+" wystapien). Przelacz na B i wpisz ~DSAC_B.");
}
void compareB(){
 if(!haveA){message("DSAC: brak A. Uruchom ~DSAC_A na zlozeniu bazowym.");return;}
 char file[256],root[256];names(file,root);
 if(!file[0]||!root[0]){message("DSAC: brak aktywnego zlozenia B.");return;}
 dsac::Snapshot b;b.file=utf8(file);b.root=utf8(root);
 Reader reader(b);lastError.clear();
 if(!reader.traverse(file,root,"",dsac::Pose{},true,0)||b.items.empty()){
   message("DSAC B: blad odczytu: "+(lastError.empty()?"no components found":lastError));return;
 }
 auto rows=dsac::compare(referenceA,b);
 std::wstring dir=reportDirectory();if(dir.empty()){
   message("DSAC: nie mozna utworzyc katalogu raportow (Dokumenty/TEMP).");return;
 }
 std::wstring stem=reportStem();std::wstring html=dir+L"\\"+stem+L".html",csv=dir+L"\\"+stem+L".csv";
 std::wstring qty=dir+L"\\"+stem+L"_ILOSCI.csv";
 if(!writeText(html,reportHtml(referenceA,b,rows))||!writeText(csv,reportCsv(referenceA,b,rows))||
    !writeText(qty,reportQuantitiesCsv(referenceA,b))){
   message("DSAC: blad zapisu HTML/CSV. Sprawdz uprawnienia do folderu.");return;
 }
 int diff=0;for(const auto&r:rows)if(r.ia<0||r.ib<0||r.geo!=1||r.moved||r.rotated||r.nameChange||r.referenceChange)diff++;
 message("DSAC: raport utworzony. Roznice/niepewne: "+std::to_string(diff)+"; porownane wystapienia A="+
         std::to_string(referenceA.items.size())+" B="+std::to_string(b.items.size())+". Otwieram raport HTML.");
 ShellExecuteW(nullptr,L"open",html.c_str(),nullptr,nullptr,SW_SHOWNORMAL);
}
} // namespace
extern "C" __declspec(dllexport) int DSAssemblyCompare2019Init(int,void*){
 if(!initApi()){MessageBoxA(nullptr,lastError.c_str(),"DS Assembly Compare: API",MB_OK|MB_ICONERROR);return 1;}
 // Optional API: if not exported, validation uses mass/inertia/topology only.
 api.facets=reinterpret_cast<FnFacets>(exportSymbol("cvxPartInqFaceFacets"));
 api.command("DSAC_A",reinterpret_cast<void*>(&snapshotA),0);
 api.command("DSAC_B",reinterpret_cast<void*>(&compareB),0);
 api.command("DSAC_INFO",reinterpret_cast<void*>(&info),0);
 message("DS Assembly Compare V1 gotowy: ~DSAC_A / ~DSAC_B / ~DSAC_INFO");
 return 0;
}
extern "C" __declspec(dllexport) int DSAssemblyCompare2019Exit(){
 if(api.unload){api.unload("DSAC_A");api.unload("DSAC_B");api.unload("DSAC_INFO");}
 return 0;
}
