#pragma once
// DS Assembly Compare V1 - independent comparison engine (standard C++17).
// No ZW3D or Windows dependency. All geometry values use millimetres.
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <string>
#include <vector>
#include <limits>
#include <utility>

namespace dsac {
struct Pose {
  // Row-major rotation, and origin in root-assembly coordinates.
  double r[9]={1,0,0, 0,1,0, 0,0,1};
  double t[3]={0,0,0};
};
inline Pose multiply(const Pose&a,const Pose&b){
  Pose c;
  for(int i=0;i<3;i++) {
    for(int j=0;j<3;j++){c.r[3*i+j]=0;for(int k=0;k<3;k++)c.r[3*i+j]+=a.r[3*i+k]*b.r[3*k+j];}
    c.t[i]=a.t[i];for(int k=0;k<3;k++)c.t[i]+=a.r[3*i+k]*b.t[k];
  }
  return c;
}
inline double distance(const Pose&a,const Pose&b){
  double d=0;for(int i=0;i<3;i++)d+=(a.t[i]-b.t[i])*(a.t[i]-b.t[i]);return std::sqrt(d);
}
inline double rotationDeg(const Pose&a,const Pose&b){
  double trace=0;
  for(int i=0;i<3;i++)for(int k=0;k<3;k++)trace+=b.r[3*i+k]*a.r[3*i+k];
  double c=std::max(-1.0,std::min(1.0,(trace-1.0)/2.0));
  return std::acos(c)*180.0/3.14159265358979323846;
}
struct FaceDescriptor {
  double area=0;
  // Distance of face's area-weighted centroid from solid centroid (rotation invariant).
  double radius=0;
};
struct SolidDescriptor {
  double volume=0, area=0;
  double moments[3]={0,0,0}; // sorted principal moments of inertia
  int faces=0,edges=0;
  std::vector<FaceDescriptor> surface;
  bool surfaceComplete=false;
};
struct Geometry {
  std::vector<SolidDescriptor> solids;
  bool valid=false;
  std::string issue;
};
struct Item {
  std::string path; // occurrence path in assembly tree
  std::string name; // instance name
  std::string file;
  std::string part;
  Pose pose;
  bool poseValid=true;
  Geometry geometry;
  double massKg=0;
  bool massKnown=false;
};
struct Snapshot {
  std::string file,root;
  std::vector<Item> items;
};
inline bool nearlyEqual(double a,double b,double rel,double abs){
  return std::abs(a-b)<=std::max(abs,rel*std::max(std::abs(a),std::abs(b)));
}
// +1 verified-by-invariants, 0 unknown, -1 distinctly different.
// This is NOT exact B-Rep equivalence; UI must label positive results as 'zgodna wg cech'.
inline int compareGeometry(const Geometry&a,const Geometry&b){
  if(!a.valid||!b.valid) return 0;
  if(a.solids.size()!=b.solids.size())return -1;
  auto norm=[](const SolidDescriptor&x,const SolidDescriptor&y){
    if(x.faces!=y.faces || x.edges!=y.edges) return false;
    if(!nearlyEqual(x.volume,y.volume,1e-6,0.001))return false;
    if(!nearlyEqual(x.area,y.area,1e-6,0.001))return false;
    for(int i=0;i<3;i++) if(!nearlyEqual(x.moments[i],y.moments[i],2e-5,1e-4)) return false;
    if(x.surfaceComplete && y.surfaceComplete){
      if(x.surface.size()!=y.surface.size())return false;
      for(std::size_t k=0;k<x.surface.size();k++) {
        if(!nearlyEqual(x.surface[k].area,y.surface[k].area,0.02,0.01))return false;
        if(!nearlyEqual(x.surface[k].radius,y.surface[k].radius,0.005,0.05))return false;
      }
    }
    return true;
  };
  // Solids may be returned in different orders. Greedy match with no reuse.
  std::vector<bool> used(b.solids.size(),false);
  for(const auto&sa:a.solids) {
    bool hit=false;
    for(std::size_t j=0;j<b.solids.size();j++) if(!used[j]&&norm(sa,b.solids[j])){used[j]=true;hit=true;break;}
    if(!hit)return -1;
  }
  return 1;
}
inline bool sameRef(const Item&a,const Item&b){return a.file==b.file && a.part==b.part;}
struct Result {
  int ia=-1,ib=-1;
  int geo=0;
  double move=0,rotation=0, dx=0,dy=0,dz=0;
  bool nameChange=false,referenceChange=false,moved=false,rotated=false,uncertain=false;
  std::string status;
};
inline std::vector<Result> compare(const Snapshot&a,const Snapshot&b,
            double positionToleranceMm=0.01,double angleToleranceDeg=0.05){
  struct Pair {int i,j,level;double score;};
  std::vector<Pair> pairs;
  for(std::size_t i=0;i<a.items.size();++i) for(std::size_t j=0;j<b.items.size();++j){
    const Item&x=a.items[i],&y=b.items[j];
    int g=compareGeometry(x.geometry,y.geometry);
    bool samePath=(x.path==y.path),sameName=(x.name==y.name),sameFile=sameRef(x,y);
    // Strong: same occurrence path. Medium: matching geometry. Weak: same reference/name.
    int level = samePath ? 0 : (g==1 ? 1 : (sameName || (sameFile && distance(x.pose,y.pose)<=1.0) ? 2 : 99));
    if(level==99)continue; // Never invent a correspondence just due to proximity.
    double m=distance(x.pose,y.pose);
    double ang=rotationDeg(x.pose,y.pose);
    double score=level*1e9 + ((g==1)?0:1e7) + ((sameName)?0:1e6) +
                 ((sameFile)?0:100000) + std::min(100000.0,m)*10+ang;
    pairs.push_back({static_cast<int>(i),static_cast<int>(j),level,score});
  }
  std::sort(pairs.begin(),pairs.end(),[](const Pair&x,const Pair&y){
    if(x.score!=y.score)return x.score<y.score;
    if(x.i!=y.i)return x.i<y.i;
    return x.j<y.j;
  });
  std::vector<int> usedA(a.items.size(),-1),usedB(b.items.size(),-1);
  std::vector<Result> out;
  for(const auto&p:pairs){
    if(usedA[p.i]>=0||usedB[p.j]>=0)continue;
    const Item&x=a.items[p.i],&y=b.items[p.j];
    Result r;
    r.ia=p.i;r.ib=p.j;r.geo=compareGeometry(x.geometry,y.geometry);
    r.move=distance(x.pose,y.pose);r.rotation=rotationDeg(x.pose,y.pose);
    r.dx=y.pose.t[0]-x.pose.t[0];r.dy=y.pose.t[1]-x.pose.t[1];r.dz=y.pose.t[2]-x.pose.t[2];
    r.moved=x.poseValid && y.poseValid && r.move>positionToleranceMm;
    r.rotated=x.poseValid && y.poseValid && r.rotation>angleToleranceDeg;
    r.nameChange=x.name!=y.name || x.part!=y.part;
    r.referenceChange=!sameRef(x,y);
    r.uncertain=(p.level>=2)||(r.geo==0)||(!x.poseValid)||(!y.poseValid);
    r.status=(r.geo<0?"ZMIANA_GEOMETRII":r.geo==0?"GEOMETRIA_NIEZWERYFIKOWANA":"CECHY_GEOMETRII_ZGODNE");
    if(r.moved)r.status+=" + PRZESUNIECIE";
    if(r.rotated)r.status+=" + OBROT";
    if(r.nameChange)r.status+=" + ZMIANA_NAZWY";
    if(r.referenceChange)r.status+=" + ZMIANA_REFERENCJI";
    if(!x.poseValid||!y.poseValid)r.status+=" + POLOZENIE_NIEZWERYFIKOWANE";
    if(r.uncertain)r.status+=" [DOPASOWANIE_NIEPEWNE]";
    usedA[p.i]=p.j;usedB[p.j]=p.i;out.push_back(std::move(r));
  }
  for(std::size_t i=0;i<a.items.size();++i)if(usedA[i]<0){Result r;r.ia=int(i);r.status="USUNIETY";out.push_back(r);}
  for(std::size_t j=0;j<b.items.size();++j)if(usedB[j]<0){Result r;r.ib=int(j);r.status="DODANY";out.push_back(r);}
  std::sort(out.begin(),out.end(),[](const Result&x,const Result&y){
    if(x.ia!=y.ia)return (x.ia<0?1000000000:x.ia)<(y.ia<0?1000000000:y.ia);
    return x.ib<y.ib;
  });
  return out;
}
} // namespace dsac
