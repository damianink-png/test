#pragma once
// DSAC V2.4: matching individual occurrences. Pure C++17, independent of ZW3D.
// Never treat a different name/reference alone as a deletion/addition.
#include "compare_core.hpp"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <map>
#include <string>
#include <vector>

namespace dsac {
inline std::string normName(std::string s) {
  std::transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return char(std::tolower(c));});
  for(auto &c:s)if(c=='\\')c='/';
  return s;
}
inline bool identicalReference(const Item&a,const Item&b) {
  return normName(a.file)==normName(b.file) && normName(a.part)==normName(b.part);
}
// Larger = more trustworthy. '2' is same-position tentative, never proof of geometry.
enum class MatchEvidence { None=0, PositionOnly=1, NameAndPose=2, SameReference=3, GeometryFeatures=4 };
struct Candidate24 {int a=-1,b=-1;int evidence=0;double cost=0;};
inline std::vector<Result> matchOccurrences(const Snapshot&a,const Snapshot&b,
        double toleranceMm=0.01,double angleToleranceDeg=0.05) {
  std::vector<Candidate24> candidates;
  const size_t na=a.items.size(),nb=b.items.size();
  if(na==0||nb==0){
    std::vector<Result> res;
    for(size_t i=0;i<na;++i){Result r;r.ia=int(i);r.status="USUNIETY";res.push_back(r);}
    for(size_t j=0;j<nb;++j){Result r;r.ib=int(j);r.status="DODANY";res.push_back(r);}
    return res;
  }
  std::vector<int> nearCountA(na,0),nearCountB(nb,0);
  // Approximate position-based disambiguation is only permissible for an unambiguous pair.
  for(size_t i=0;i<na;++i)for(size_t j=0;j<nb;++j){
    const auto&x=a.items[i];const auto&y=b.items[j];
    if(x.poseValid&&y.poseValid && distance(x.pose,y.pose)<=toleranceMm &&
        rotationDeg(x.pose,y.pose)<=angleToleranceDeg){nearCountA[i]++;nearCountB[j]++;}
  }
  for(size_t i=0;i<na;++i)for(size_t j=0;j<nb;++j){
    const Item&x=a.items[i];const Item&y=b.items[j];
    const int g=compareGeometry(x.geometry,y.geometry);
    const bool sameRef=identicalReference(x,y);
    const bool sameName=normName(x.name)==normName(y.name)||normName(x.part)==normName(y.part);
    const bool poses=x.poseValid&&y.poseValid;
    const double d=poses?distance(x.pose,y.pose):1e9;
    const double angle=poses?rotationDeg(x.pose,y.pose):360;
    const bool samePose=poses && d<=toleranceMm && angle<=angleToleranceDeg;
    int evidence=0;
    if(g==1)evidence=int(MatchEvidence::GeometryFeatures);
    else if(sameRef)evidence=int(MatchEvidence::SameReference);
    else if(sameName && samePose)evidence=int(MatchEvidence::NameAndPose);
    else if(samePose && nearCountA[i]==1 && nearCountB[j]==1)evidence=int(MatchEvidence::PositionOnly);
    // Same-name moved parts with different references and no verified geometry are NOT paired:
    // repeated fixture parts could otherwise be matched arbitrarily.
    if(evidence==0)continue;
    // Identical geometry is the strongest signal; then seek nearest occurrence.
    const double cost=(4-evidence)*1e10+(g<0?1e8:0) +
      (samePose?0:1e6)+(sameName?0:1e5) + std::min(d,100000.0)*10 + angle;
    candidates.push_back({int(i),int(j),evidence,cost});
  }
  std::sort(candidates.begin(),candidates.end(),[](const Candidate24&x,const Candidate24&y){
    if(x.cost!=y.cost)return x.cost<y.cost;
    if(x.a!=y.a)return x.a<y.a;
    return x.b<y.b;
  });
  std::vector<bool> usedA(na,false),usedB(nb,false);
  std::vector<Result> out;
  for(const auto&c:candidates){
    if(usedA[c.a]||usedB[c.b])continue;
    const Item&x=a.items[size_t(c.a)],&y=b.items[size_t(c.b)];
    Result r;r.ia=c.a;r.ib=c.b;r.geo=compareGeometry(x.geometry,y.geometry);
    r.nameChange=normName(x.name)!=normName(y.name)||normName(x.part)!=normName(y.part);
    r.referenceChange=!identicalReference(x,y);
    if(x.poseValid&&y.poseValid){
      r.dx=y.pose.t[0]-x.pose.t[0];r.dy=y.pose.t[1]-x.pose.t[1];r.dz=y.pose.t[2]-x.pose.t[2];
      r.move=distance(x.pose,y.pose);r.rotation=rotationDeg(x.pose,y.pose);
      r.moved=r.move>toleranceMm;r.rotated=r.rotation>angleToleranceDeg;
    }
    r.uncertain=(c.evidence<=int(MatchEvidence::NameAndPose) && r.geo!=1) ||
                (!x.poseValid||!y.poseValid);
    r.status=r.geo<0?"ZMIANA_GEOMETRII":r.geo==1?"ZGODNE_CECHY_GEOMETRII":
      c.evidence==int(MatchEvidence::SameReference)?"WSPOLNA_REFERENCJA":
      "PARA_DO_WERYFIKACJI_GEOMETRII";
    if(r.moved)r.status+=" + PRZESUNIECIE";
    if(r.rotated)r.status+=" + OBROT";
    if(r.nameChange)r.status+=" + ZMIANA_NAZWY: "+x.name+" -> "+y.name;
    if(r.uncertain)r.status+=" [GEOMETRIA_NIEPOTWIERDZONA]";
    usedA[c.a]=usedB[c.b]=true;
    out.push_back(std::move(r));
  }
  // Quarantine still-unmatched co-located components. This prevents "new blue +
  // removed orange" doubles at exactly the same location when source names changed.
  // Ambiguous pairs are explicitly UNVERIFIED, never marked as geometrically equal.
  for(size_t i=0;i<na;++i)if(!usedA[i]&&a.items[i].poseValid){
    int best=-1;bool sameName=false;
    for(size_t j=0;j<nb;++j)if(!usedB[j]&&b.items[j].poseValid){
      const auto&x=a.items[i];const auto&y=b.items[j];
      if(distance(x.pose,y.pose)>toleranceMm || rotationDeg(x.pose,y.pose)>angleToleranceDeg)continue;
      const bool matchName=normName(x.name)==normName(y.name)||normName(x.part)==normName(y.part);
      if(best<0||(matchName&&!sameName)){best=int(j);sameName=matchName;}
    }
    if(best>=0){
      const auto&x=a.items[i];const auto&y=b.items[size_t(best)];
      Result r;r.ia=int(i);r.ib=best;r.geo=compareGeometry(x.geometry,y.geometry);
      r.uncertain=true;r.nameChange=normName(x.name)!=normName(y.name)||normName(x.part)!=normName(y.part);
      r.referenceChange=!identicalReference(x,y);
      r.status="NIEJEDNOZNACZNE_WSPOLNE_POLOZENIE [SPRAWDZ_RECZNIE]";
      if(r.nameChange)r.status+=" + MOZLIWA_ZMIANA_NAZWY: "+x.name+" -> "+y.name;
      usedA[i]=usedB[size_t(best)]=true;out.push_back(std::move(r));
    }
  }
  for(size_t i=0;i<na;++i)if(!usedA[i]){Result r;r.ia=int(i);r.status="USUNIETY";out.push_back(r);}
  for(size_t j=0;j<nb;++j)if(!usedB[j]){Result r;r.ib=int(j);r.status="DODANY";out.push_back(r);}
  std::sort(out.begin(),out.end(),[](const Result&x,const Result&y){
    if(x.ia!=y.ia)return (x.ia<0?100000000:x.ia)<(y.ia<0?100000000:y.ia);
    return x.ib<y.ib;
  });
  return out;
}
}
