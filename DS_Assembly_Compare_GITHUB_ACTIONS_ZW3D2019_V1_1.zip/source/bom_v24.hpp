#pragma once
#include "compare_core.hpp"
#include <algorithm>
#include <cmath>
#include <map>
#include <string>
#include <vector>
namespace dsac {
struct BomLine {
 std::string part,ref,name;
 int count=0;
 double unitMassKg=0;
 bool massKnown=false;
};
inline std::vector<BomLine> makeBom(const Snapshot&s){
 std::map<std::string,BomLine> grouped;
 for(const Item&v:s.items){
  const std::string key=v.file+"\x1f"+v.part;
  auto &b=grouped[key];
  b.part=v.part;b.ref=v.file;b.name=v.name;b.count++;
  // Unit mass comes only from a verified CAD source or user-supplied mapping.
  if(v.massKnown){if(!b.massKnown){b.massKnown=true;b.unitMassKg=v.massKg;}
    else if(std::abs(b.unitMassKg-v.massKg)>1e-7)b.massKnown=false;}
 }
 std::vector<BomLine> rows;
 for(auto &entry:grouped)rows.push_back(entry.second);
 return rows;
}
inline int knownMassOccurrences(const std::vector<BomLine>&b){int result=0;for(auto&v:b)if(v.massKnown)result+=v.count;return result;}
inline double knownMassTotalKg(const std::vector<BomLine>&b){double sum=0;for(auto&v:b)if(v.massKnown)sum+=v.unitMassKg*v.count;return sum;}
}
