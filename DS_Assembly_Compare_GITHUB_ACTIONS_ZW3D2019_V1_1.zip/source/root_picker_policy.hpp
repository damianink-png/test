#pragma once
// Portable root-selection policy. Never select an arbitrary object when ambiguous.
#include <vector>
#include <cstddef>
namespace dsac {
inline int autoRootIndex(const std::vector<bool>&assemblyFlags) {
 if(assemblyFlags.size()==1)return 0;
 int last=-1;
 for(std::size_t i=0;i<assemblyFlags.size();++i)if(assemblyFlags[i]){
  if(last!=-1)return -1;
  last=static_cast<int>(i);
 }
 return last;
}
}
