#pragma once
// DSAC V2.3. A single explicit classification drives 3D, HTML and CSV.
// Never interpret merely matching filenames/names as proof of identical geometry.
#include "compare_core.hpp"

namespace dsac {
enum class ChangeKind {
  Unchanged, Renamed, Moved, GeometryChanged, Added, Removed, Unverified
};

inline ChangeKind classify(const Result&r,bool samePhysicalReference,bool posesAvailable) {
  if(r.ia<0 && r.ib>=0)return ChangeKind::Added;
  if(r.ib<0 && r.ia>=0)return ChangeKind::Removed;
  if(r.ia<0 || r.ib<0)return ChangeKind::Unverified;
  // Differences in measured geometry take precedence over movement or naming.
  if(r.geo<0)return ChangeKind::GeometryChanged;
  if(!posesAvailable)return ChangeKind::Unverified;
  const bool establishedEquivalent=(r.geo==1 || samePhysicalReference);
  if(!establishedEquivalent)return ChangeKind::Unverified;
  if(r.moved||r.rotated)return ChangeKind::Moved;
  if(r.nameChange)return ChangeKind::Renamed;
  return ChangeKind::Unchanged;
}
inline const char* kindCode(ChangeKind k){
 switch(k){
 case ChangeKind::Unchanged:return "BEZ_ZMIAN";
 case ChangeKind::Renamed:return "ZMIANA_NAZWY";
 case ChangeKind::Moved:return "ZMIANA_POLOZENIA";
 case ChangeKind::GeometryChanged:return "ZMIANA_GEOMETRII";
 case ChangeKind::Added:return "DODANY";
 case ChangeKind::Removed:return "USUNIETY";
 default:return "NIEZWERYFIKOWANY";
 }
}
// ZW3D 2019 VxApi.h evxColor, NOT RGB: 1 GREEN, 2 RED, 3 BROWN,
// 4 GOLDENROD, 5 MED_BLUE, 9 VIOLET, 17 YELLOW, 18 MED_GREY.
enum class Role {
 Green, Renamed, Added, Violet, OldPosition, Yellow, OldGeometry, Removed, Gray
};
inline Role newRole(ChangeKind k){
 switch(k){
 case ChangeKind::Unchanged:return Role::Green;
 case ChangeKind::Renamed:return Role::Renamed;
 case ChangeKind::Moved:return Role::Violet;
 case ChangeKind::GeometryChanged:return Role::Yellow;
 case ChangeKind::Added:return Role::Added;
 case ChangeKind::Removed:return Role::Removed;
 default:return Role::Gray;
 }
}
inline bool showsOld(ChangeKind k){
 return k==ChangeKind::Moved || k==ChangeKind::GeometryChanged || k==ChangeKind::Removed;
}
inline Role oldRole(ChangeKind k){
 if(k==ChangeKind::Moved)return Role::OldPosition;
 if(k==ChangeKind::GeometryChanged)return Role::OldGeometry;
 return Role::Removed;
}
inline int zw3dColor(Role r){
 switch(r){
 case Role::Green:return 1;
 case Role::Renamed:return 11;
 case Role::Added:return 5;
 case Role::Violet:return 9;
 case Role::OldPosition:return 4;
 case Role::Yellow:return 17;
 case Role::OldGeometry:return 3;
 case Role::Removed:return 4;
 case Role::Gray:return 18;
 }
 return 18;
}
inline bool isGhost(Role r){return r==Role::OldPosition||r==Role::OldGeometry||r==Role::Removed;}
inline const char* rolePrefix(Role r){
 switch(r){
 case Role::Green:return "B_BEZ_ZMIAN_";
 case Role::Renamed:return "B_NAZWA_";
 case Role::Added:return "B_DODANY_";
 case Role::Violet:return "B_NOWA_POZYCJA_";
 case Role::OldPosition:return "A_STARA_POZYCJA_";
 case Role::Yellow:return "B_NOWA_GEOMETRIA_";
 case Role::OldGeometry:return "A_STARA_GEOMETRIA_";
 case Role::Removed:return "A_USUNIETY_";
 case Role::Gray:return "B_NIEZWERYFIKOWANY_";
 }
 return "B_NIEZWERYFIKOWANY_";
}
} // namespace dsac
