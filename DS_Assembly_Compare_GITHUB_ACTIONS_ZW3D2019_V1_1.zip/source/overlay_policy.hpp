#pragma once
#include "compare_core.hpp"
namespace dsac {
// Three principal presentation categories. Unverified is a necessary safety exception.
enum class ChangeKind { Unchanged=0, Modified=1, Added=2, Removed=3, Unverified=4 };
inline ChangeKind classify(const Result&r,bool samePhysicalReference,bool poseAvailable) {
 if(r.ia<0 && r.ib>=0)return ChangeKind::Added;
 if(r.ib<0 && r.ia>=0)return ChangeKind::Removed;
 if(r.ia<0||r.ib<0)return ChangeKind::Unverified;
 if(r.geo<0)return ChangeKind::Modified;
 if(!poseAvailable)return ChangeKind::Unverified;
 if(!samePhysicalReference && r.geo!=1)return ChangeKind::Unverified;
 if(r.moved||r.rotated)return ChangeKind::Modified;
 return ChangeKind::Unchanged; // Changing the name alone is reported, not colored differently.
}
inline const char* kindCode(ChangeKind c){
 switch(c){case ChangeKind::Unchanged:return "BEZ_ZMIAN";
 case ChangeKind::Modified:return "ZMIENIONY";
 case ChangeKind::Added:return "NOWY";
 case ChangeKind::Removed:return "USUNIETY";
 default:return "DO_WERYFIKACJI";}
}
enum class Role { Green=0, Blue=1, Orange=2, Gray=3 };
inline Role newRole(ChangeKind k){switch(k){
 case ChangeKind::Unchanged:return Role::Green;
 case ChangeKind::Modified:case ChangeKind::Added:return Role::Blue;
 case ChangeKind::Removed:return Role::Orange;
 default:return Role::Gray;
}}
inline bool showsOld(ChangeKind k){return k==ChangeKind::Removed;}
inline Role oldRole(ChangeKind){return Role::Orange;}
inline int zw3dColor(Role r){switch(r){case Role::Green:return 1;case Role::Blue:return 5;case Role::Orange:return 4;default:return 18;}}
inline bool isGhost(Role r){return r==Role::Orange;}
inline const char* rolePrefix(Role r){switch(r){case Role::Green:return "B_BEZ_ZMIAN_";case Role::Blue:return "B_NOWY_LUB_ZMIENIONY_";case Role::Orange:return "A_USUNIETY_";default:return "B_DO_WERYFIKACJI_";}}
}
