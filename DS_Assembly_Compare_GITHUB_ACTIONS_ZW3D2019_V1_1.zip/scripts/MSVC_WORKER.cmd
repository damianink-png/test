@echo off
setlocal EnableExtensions DisableDelayedExpansion
if not exist "%DSAC_VCVARS%" (echo ERROR=VCVARS_NOT_FOUND&exit /b 11)
call "%DSAC_VCVARS%"
if errorlevel 1 (echo ERROR=VCVARS_FAILED&exit /b 12)
where cl.exe >nul 2>nul
if errorlevel 1 (echo ERROR=CL_MISSING&exit /b 13)
where link.exe >nul 2>nul
if errorlevel 1 (echo ERROR=LINK_MISSING&exit /b 14)
echo STAGE=COMPILE_CORE_TESTS
cl.exe /nologo /std:c++17 /utf-8 /EHsc /O2 /W4 /MD /Fo"%DSAC_OUTPUT%\test_core.obj" /Fe"%DSAC_OUTPUT%\test_core.exe" "%DSAC_ROOT%\tests\test_core.cpp"
if errorlevel 1 (echo ERROR=CORE_TEST_COMPILATION_FAILED&exit /b 16)
echo STAGE=RUN_CORE_TESTS
"%DSAC_OUTPUT%\test_core.exe"
if errorlevel 1 (echo ERROR=CORE_TESTS_FAILED&exit /b 17)
echo STAGE=MSVC_BUILD
cl.exe /nologo /std:c++17 /utf-8 /EHsc /O2 /W4 /MD /DWINVER=0x0601 /D_WIN32_WINNT=0x0601 /D_CRT_SECURE_NO_WARNINGS /LD /Fo"%DSAC_OUTPUT%\DSAssemblyCompare2019.obj" /Fe"%DSAC_OUTPUT%\DSAssemblyCompare2019.dll" "%DSAC_ROOT%\source\DSAssemblyCompare2019.cpp" /link /MACHINE:X64 /IMPLIB:"%DSAC_OUTPUT%\DSAssemblyCompare2019.lib" psapi.lib shell32.lib user32.lib kernel32.lib ole32.lib
if errorlevel 1 (echo ERROR=MSVC_BUILD_FAILED&exit /b 15)
echo STAGE=CHECK_DLL_EXPORTS
dumpbin.exe /exports "%DSAC_OUTPUT%\DSAssemblyCompare2019.dll" > "%DSAC_OUTPUT%\EXPORTS.txt"
if errorlevel 1 (echo ERROR=DUMPBIN_FAILED&exit /b 18)
findstr /C:"DSAssemblyCompare2019Init" "%DSAC_OUTPUT%\EXPORTS.txt" >nul
if errorlevel 1 (echo ERROR=PLUGIN_INIT_EXPORT_MISSING&exit /b 19)
findstr /C:"DSAssemblyCompare2019Exit" "%DSAC_OUTPUT%\EXPORTS.txt" >nul
if errorlevel 1 (echo ERROR=PLUGIN_EXIT_EXPORT_MISSING&exit /b 20)
echo MSVC_BUILD_OK
exit /b 0
