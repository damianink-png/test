$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Out = Join-Path $Root 'output'
New-Item -ItemType Directory -Path $Out -Force | Out-Null
$Log = Join-Path $Out 'KOMPILACJA.log'
$Status = Join-Path $Out 'STATUS.txt'
$Worker = Join-Path $PSScriptRoot 'MSVC_WORKER.cmd'
$Dll = Join-Path $Out 'DSAssemblyCompare2019.dll'
Set-Content -LiteralPath $Log -Encoding UTF8 -Value ('DSAC build ' + (Get-Date -Format s))
Set-Content -LiteralPath $Status -Encoding ASCII -Value 'STARTED'
function WriteLog([string] $t){ Write-Host $t; Add-Content -LiteralPath $Log -Encoding UTF8 -Value $t }
function Abort([string] $reason,[int] $code){ WriteLog "ERROR=$reason";Set-Content -LiteralPath $Status -Encoding ASCII -Value "ERROR=$reason";exit $code }
try {
  if (-not (Test-Path -LiteralPath (Join-Path $Root 'source\DSAssemblyCompare2019.cpp'))) { Abort 'SOURCE_NOT_FOUND' 21 }
  $Found = @()
  $Roots = @(${env:ProgramFiles(x86)},$env:ProgramFiles) | Where-Object { $_ }
  foreach ($base in $Roots) {
    $vswhere = Join-Path $base 'Microsoft Visual Studio\Installer\vswhere.exe'
    if(Test-Path -LiteralPath $vswhere){
      $Found += @(& $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath)
    }
    foreach ($year in @('2026','2022','2019','2017')) {
      foreach($ed in @('BuildTools','Community','Professional','Enterprise')){
        $Found += (Join-Path $base "Microsoft Visual Studio\$year\$ed")
      }
    }
  }
  $Vcvars = $null
  foreach($inst in $Found){
    if([string]::IsNullOrWhiteSpace($inst)){continue}
    $candidate = Join-Path $inst.Trim() 'VC\Auxiliary\Build\vcvars64.bat'
    if(Test-Path -LiteralPath $candidate){$Vcvars = $candidate; break}
  }
  if (-not $Vcvars){ Abort 'MSVC_CXX_X64_NOT_FOUND' 22 }
  WriteLog "MSVC_VCVARS=$Vcvars"
  if(Test-Path -LiteralPath $Dll){
    try{Remove-Item -LiteralPath $Dll -Force -ErrorAction Stop}
    catch{Abort 'DLL_LOCKED_CLOSE_ZW3D' 23}
  }
  $env:DSAC_ROOT = $Root
  $env:DSAC_OUTPUT = $Out
  $env:DSAC_VCVARS = $Vcvars
  WriteLog 'STAGE=WORKER'
  $ErrorActionPreference = 'Continue'
  & $Worker 2>&1 | ForEach-Object { WriteLog ([string]$_) }
  $rc = $LASTEXITCODE
  $ErrorActionPreference = 'Stop'
  if ($rc -ne 0){Abort "WORKER_$rc" 24}
  if (-not (Test-Path -LiteralPath $Dll)){Abort 'DLL_OUTPUT_NOT_FOUND' 25}
  $bytes = [System.IO.File]::ReadAllBytes($Dll)
  if($bytes.Length -lt 512 -or $bytes[0] -ne 77 -or $bytes[1] -ne 90){Abort 'NOT_PE_DLL' 26}
  $pe = [BitConverter]::ToInt32($bytes,0x3c)
  if($pe -lt 64 -or $pe+6 -gt $bytes.Length -or $bytes[$pe] -ne 80 -or $bytes[$pe+1] -ne 69){Abort 'INVALID_PE' 27}
  $machine = [BitConverter]::ToUInt16($bytes,$pe+4)
  if($machine -ne 0x8664){Abort 'EXPECTED_X64_PE' 28}
  WriteLog ('DLL_SHA256=' + (Get-FileHash -LiteralPath $Dll -Algorithm SHA256).Hash)
  WriteLog 'BUILD_OK_X64_UNTESTED_IN_ZW3D'
  Set-Content -LiteralPath $Status -Encoding ASCII -Value 'BUILD_OK'
  exit 0
} catch {
  WriteLog ('EXCEPTION=' + $_.Exception.ToString())
  Set-Content -LiteralPath $Status -Encoding ASCII -Value 'ERROR=EXCEPTION'
  exit 29
}
