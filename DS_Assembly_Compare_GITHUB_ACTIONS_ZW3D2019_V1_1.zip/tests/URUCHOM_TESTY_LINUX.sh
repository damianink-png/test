#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
g++ -std=c++17 -O2 -Wall -Wextra -Werror tests/test_core.cpp -o /tmp/dsac_core_test
/tmp/dsac_core_test
