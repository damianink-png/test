#include "../source/compare_core.hpp"
#include <cassert>
#include <iostream>
using namespace dsac;
static Geometry shape(double v=100){ Geometry g;g.valid=true;SolidDescriptor s;s.volume=v;s.area=200;s.faces=6;s.edges=12;s.moments[0]=10;s.moments[1]=20;s.moments[2]=30;g.solids.push_back(s);return g;}
static Item item(const char*path,const char*name,double x,double v=100){Item i;i.path=path;i.name=name;i.file="a.z3";i.part="PartA";i.pose.t[0]=x;i.geometry=shape(v);return i;}
int main(){
 Snapshot a,b;a.items={item("/a","profil",0),item("/b","profil",100),item("/c","nowy",200)};
 b.items={item("/a","profil",10),item("/b","przemianowany",100),item("/d","dodatkowy",250)};
 b.items[1].part="PartChanged";b.items[1].geometry=shape(101);b.items[2].geometry=shape(201);
 auto r=compare(a,b);assert(r.size()==4);
 assert(r[0].ia==0&&r[0].ib==0&&r[0].moved&&r[0].geo==1);
 assert(r[1].ia==1&&r[1].ib==1&&r[1].geo==-1&&r[1].nameChange);
 assert(r[2].status=="USUNIETY"&&r[3].status=="DODANY");
 Pose p,q;q.r[0]=0;q.r[1]=-1;q.r[3]=1;q.r[4]=0;
 assert(std::abs(rotationDeg(p,q)-90)<1e-6);
 Pose c=multiply(q,item("/x","",5).pose);assert(std::abs(c.t[1]-5)<1e-9);
 Geometry unknown;assert(compareGeometry(shape(),unknown)==0);
 // Geometry must be independent of orientation of the instance.
 Snapshot rotated,rotatedB;
 rotated.items={item("/p","P",0)};rotatedB.items=rotated.items;
 rotatedB.items[0].pose=q;
 auto turn=compare(rotated,rotatedB);
 assert(turn.size()==1 && turn[0].rotated && turn[0].geo==1);
 // A renamed but identical component must retain geometry match.
 rotatedB.items[0].name="P_NEW";
 auto rename=compare(rotated,rotatedB);
 assert(rename.size()==1 && rename[0].nameChange && rename[0].geo==1);
 // A part that could not be read is never declared equal.
 rotatedB.items[0].geometry.valid=false;
 assert(compare(rotated,rotatedB)[0].geo==0);
 // Two additional occurrences are visible in the report.
 rotatedB=rotated;rotatedB.items.push_back(item("/q","P",200));
 auto extra=compare(rotated,rotatedB);
 assert(extra.size()==2&&extra.back().status=="DODANY");
 std::cout<<"DSAC core tests PASS\n";
}
