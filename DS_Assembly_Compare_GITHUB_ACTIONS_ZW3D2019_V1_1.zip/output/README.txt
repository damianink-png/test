This folder contains local build output. GitHub Actions uploads DLL and logs in an artifact.
