# DS Assembly Compare V1.1 — GitHub Actions / ZW3D 2019 Standard x64

Repozytorium przygotowane do **automatycznej kompilacji DLL na GitHubie** (Windows Server 2022, MSVC 2022, architektura x64).

## Co jest kompilowane

- **`DSAssemblyCompare2019.dll`** — dodatek ZW3D: porównanie części między złożeniami A i B.
- **Testy C++** — uruchamiane przed kompilacją DLL; jeżeli testy nie przejdą, kompilacja zostaje oznaczona jako nieudana.
- **Kontrola DLL** — sprawdzenie formatu PE x64 i eksportów `DSAssemblyCompare2019Init` oraz `DSAssemblyCompare2019Exit`.

Zakres porównywania: geometria na podstawie wybranych cech brył, nazwy części i wystąpień, referencje, położenie XYZ, obroty, liczba wystąpień, dodane/usunięte elementy i hierarchia podzłożeń. Raport jest zapisywany jako HTML + CSV. Program nie modyfikuje modeli.

**Ważne:** pozytywna kompilacja na GitHubie nie oznacza jeszcze potwierdzenia działania w ZW3D 2019. Dodatek dynamicznie wywołuje funkcje API ZW3D; zgodność z konkretną instalacją musi zostać sprawdzona lokalnie. Zbieżność cech geometrycznych **nie jest** dowodem identyczności matematycznej brył B-Rep. Położenie wewnątrz zagnieżdżonych podzłożeń jest oznaczane jako niezweryfikowane do czasu sprawdzenia konwencji macierzy w ZW3D.

## Jak uruchomić na GitHub

1. **Rozpakuj ZIP** z tej paczki. W repozytorium GitHub muszą znaleźć się bezpośrednio `source/`, `scripts/`, `tests/` i `.github/workflows/build-ds-assembly-compare.yml`.
2. Prześlij **rozpakowane pliki i katalogi** do swojego prywatnego repozytorium `DS-ZW3D-Plugins`, gałąź `main`, zachowując strukturę. **Nie przesyłaj ZIP-a jako jednego pliku** — GitHub Actions nie uruchomi plików znajdujących się wewnątrz ZIP-a.
3. Otwórz zakładkę **Actions** → **DS Assembly Compare - DLL ZW3D 2019 x64** → **Run workflow** → **Run workflow**. Kompilacja uruchamia się też po wysłaniu/zmianie kodu w odpowiednich katalogach na gałęzi `main`.
4. Kliknij najnowsze uruchomienie, poczekaj aż pojawi się zielony znacznik. Na dole ekranu w **Artifacts** znajdź `DSAssemblyCompare2019-Windows-x64`.
5. Pobierz artefakt ZIP z GitHub Actions. Wewnątrz znajdziesz `DSAssemblyCompare2019.dll`, `KOMPILACJA.log`, `STATUS.txt`, `EXPORTS.txt` i `SHA256.txt` (w przypadku błędu mogą być tylko logi).
6. Po stronie ZW3D załaduj DLL zgodnie z procedurą Twojej instalacji (np. `$load` lub menedżer dodatków), następnie wywołaj: `~DSAC_INFO`, `~DSAC_A` na pierwszym złożeniu i `~DSAC_B` na drugim złożeniu.

**Jeżeli GitHub pokazuje pustą zakładkę Actions:** sprawdź, czy plik `.github/workflows/build-ds-assembly-compare.yml` trafił we właściwe miejsce i czy GitHub Actions nie jest wyłączone w ustawieniach repozytorium.

## Struktura repozytorium

```text
.github/
  workflows/
    build-ds-assembly-compare.yml     # automatyczna kompilacja
source/
  DSAssemblyCompare2019.cpp          # integracja API ZW3D i raporty
  compare_core.hpp                   # silnik porównania bez zależności od ZW3D
tests/
  test_core.cpp                      # testy porównywania
  URUCHOM_TESTY_LINUX.sh             # testy na Linux, opcjonalnie
scripts/
  build.ps1                          # kompilacja w PowerShell
  MSVC_WORKER.cmd                    # kompilator MSVC, testy, weryfikacja eksportów
output/
  README.txt                         # wynik tworzy się podczas kompilacji
KOMPILUJ_JEDNYM_KLIKNIECIEM.bat      # opcjonalna kompilacja na własnym Windows
README.md
.gitignore
```

## Co dokładnie dzieje się w CI?

Uruchomienie GitHub Actions na `windows-2022` używa zainstalowanego Visual Studio C++ i Windows SDK. Skrypt `build.ps1` wyszukuje `vcvars64.bat`, uruchamia `MSVC_WORKER.cmd`, wykonuje testy jednostkowe, kompiluje DLL, weryfikuje jej format i zapisuje logi. DLL zostaje udostępniona do pobrania jako **artifact** uruchomienia.

Ten projekt **nie wymaga do kompilacji** bibliotek ZW3D ani `VxApi.h` w repozytorium, ponieważ wiąże funkcje ZW3D dynamicznie podczas ładowania dodatku. To ułatwia budowanie na GitHub, ale **nie rozwiązuje** konieczności weryfikacji zgodności wersji API w działającym ZW3D 2019.

## Test po kompilacji

Przygotuj dwa proste złożenia: jedno identyczne, następnie w drugim przesuń detal o 10 mm, obróć inny o 90°, zmień nazwę, zmień geometrię jednego i dodaj kolejny. Porównaj oczekiwane wyniki z raportem w `Dokumenty\DSAssemblyCompare`. Jeżeli kompilacja na GitHubie nie przejdzie, potrzebny jest log z **Actions → run → MSVC x64 - unit tests and DLL**, a w razie powodzenia — raport HTML/CSV z ZW3D.

Nie włączono funkcji automatycznego kolorowania i nakładania modeli w programie. To etap testowy V1.1.
