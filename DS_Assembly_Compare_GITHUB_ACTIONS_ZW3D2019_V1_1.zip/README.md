# DS Assembly Compare V2.5 — wersja diagnostyczna

**WAŻNE: model 3D jest domyślnie wyłączony ze względu na powtarzalny crash ZW3D.** Pierwszy test wykonaj bez niego.

Wynik bezpiecznej poprawki: operacje CAD z przycisku wywołuje zarejestrowane polecenie `~DSAC_EXEC` przez `cvxCmdBuffer`. Zobacz `README_V25_DIAGNOSTYKA.txt`.

# DS Assembly Compare V2.4 — diagnostyczna wersja dla ZW3D 2019 Standard x64

Wydanie źródłowe do kompilacji na GitHub Actions / MSVC 2022.

## Obsługa

Załaduj `DSAssemblyCompare2019.dll`, uruchom `~DSAC`.
Wskaż plik A (stary) i B (nowy), wybierz obiekty z listy, ustaw kolory.
Możesz wybrać dodatkowy plik z masami `CSV` (patrz szablon poniżej).
Polecenie `~DSAC_INFO` wyświetla pomoc. Okno jest niemodalne, bez przymusowego „zawsze na wierzchu”; przycisk **Ukryj** je chowa, a `~DSAC` otwiera z powrotem.

## Kolory w modelu

- **Zielony:** część bez zmian lub tylko ze zmienioną nazwą, gdy zgodność jest potwierdzona geometrią porównywalnych cech lub wspólną referencją.
- **Niebiesko-fioletowy:** nowy albo zmodyfikowany lub przesunięty detal; bez dodatkowego „starego położenia”.
- **Pomarańczowy, 65% przezroczystości:** tylko element rzeczywiście usunięty.
- **Szary:** niepotwierdzona geometria/referencja; nie należy mylić go z potwierdzonym brakiem zmian.

Kolory można dostosować klikając próbki legendy.

## Dopasowanie nazw i części powtarzalnych

Algorytm wykonuje dopasowanie wystąpień 1:1, niezależnie od kolejności w drzewie. Sprawdza (w tej kolejności) cechy geometrii, wspólną referencję, nazwę i układ współrzędnych oraz jednoznaczne identyczne położenie. Przy samej zmianie nazwy i braku innych zmian raport pokazuje np. `ABC -> CBA`, bez nowego i usuniętego ducha. Elementy o tym samym położeniu, których geometrii nie da się zweryfikować, trafiają do grupy niepewnych zamiast automatycznie do dodanych/usuniętych. Powtarzalne pozycje z identyczną pozą nie stanowią dowodu, że bryły są jednakowe.

## Raport

W folderze `Dokumenty\DSAssemblyCompare` powstają:

- `DSAC_V24_...html` — zbiorcza tabela i dwa zestawienia BOM;
- `DSAC_V24_...csv` — zestawienie zmian (nazwy, pozycje, przesunięcia);
- `DSAC_V24_..._ZMIANY_NAZW.csv` — zmiany nazewnictwa;
- `DSAC_V24_..._BOM_A.csv`, `_BOM_B.csv` — ilości, masa jednostkowa i łączna.

BOM grupuje identyczne referencje (plik + nazwa części) na **poziomie bezpośrednich wystąpień**. Podzłożeń nie rozkłada rekurencyjnie: nie ma więc jeszcze mas wszystkich ich części. Nie sumuje też masy podzłożenia razem z masą jego części (bez podwójnego liczenia).

### Masy

Użytkownik może załadować własny CSV UTF-8, format:

```csv
Nazwa_czesci;masa_kg
PLYTA_01;2,5
PROFIL_02;7.35
```

Przy braku danych masa jest oznaczona `BRAK`, a nie `0`. Całkowita masa złożenia jest prezentowana jako kompletna **tylko jeśli wszystkie wystąpienia mają masę**. Ustawianie gęstości i pobieranie mas z geometrii CAD przez niedostatecznie zweryfikowane API zostało celowo odłożone — powodowało awarie.

## Stan funkcji i ograniczenia

- Analiza dokładnej geometrii B-Rep ZW3D nadal wyłączona; powtarzalny crash w poprzednich wydaniach. Zbieżność mas czy prostych charakterystyk nie jest dowodem równości brył.
- Podzłożenia: obecnie tylko najwyższy poziom wystąpień; masa całego podzłożenia wymaga dostarczenia danych masowych.
- Model wynikowy jest zapisywany i przywracany jest aktywny dokument wejściowy, żeby nie pozostawiać generatora w edycji nowego modelu. Nie potwierdzono jeszcze, czy rozwiązuje to blokowanie zamykania pliku lub błędy przy wyjściu z ZW3D.
- Import STEP przechodzi przez translator ZW3D 2019, jego dostępność zależy od licencji.
- Nie testowano działania wewnątrz ZW3D w tym środowisku. Kompilacja Windows wymaga GitHub Actions. Przed uruchomieniem zrób kopię modeli.

## GitHub Actions

W repozytorium `damianink-png/test` zastąp **plik archiwum źródłowego**
`DS_Assembly_Compare_GITHUB_ACTIONS_ZW3D2019_V1_1.zip` (nie ZIP z samą DLL).

Obecny workflow rozpakowuje archiwum i wywołuje `scripts/build.ps1`. W GitHub Actions pobierz artefakt DLL po pomyślnym zakończeniu.

Log pracy: `%TEMP%\DSAC_V24_TRACE.log`.
