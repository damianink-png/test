# DS Assembly Compare V2.3 — test stabilności dla ZW3D 2019 Standard x64

**Status:** kompletne źródła C++ do skompilowania przez GitHub Actions (MSVC, Windows x64). Nie jest to gotowa DLL. Testy reguł porównywania są wykonywane niezależnie od ZW3D; nie wykonano testu DLL w uruchomionym ZW3D.

## Co zmieniono względem V2.2

1. **Możliwość ustawienia własnego koloru każdej kategorii.** Kliknij kolorowy kwadrat w legendzie. Otworzy się standardowy systemowy wybór koloru RGB. Ustawienia są zapisywane w `%APPDATA%\DSAC_Colors.ini`. Obok jest przycisk przywrócenia barw domyślnych.
2. Domyślnie **nowy detal = niebieski**, zmiana samej nazwy = turkusowy, nowa pozycja = fioletowy, stara pozycja = jasnopomarańczowy (65% przezroczystości). Kolor nowej geometrii to żółty, starej — brązowy półprzezroczysty, usuniętej części — pomarańczowy, niezweryfikowanej — szary.
3. Zapis koloru do modelu odbywa się przez `cvxEntRgbSet`. Jeśli funkcja zwróci błąd lub jest niedostępna, program próbuje dobrać najbliższy kolor z palety ZW3D przez `cvxColorNear` i `cvxEntColorSet`. W tym awaryjnym wariancie odcień może się różnić od legendy.
4. **Usunięto zagnieżdżoną pętlę `GetMessageW`** z komendy `~DSAC`. Okno jest teraz modeless — komenda od razu zwraca sterowanie do ZW3D. Zmiana ma usunąć ryzyko blokowania zamykania dokumentów i programu wynikające z pętli komunikatów. Konieczny test w rzeczywistym ZW3D.
5. Okno jest domyślnie **zawsze na wierzchu**, z możliwością odznaczenia tej opcji.
6. Filtr wyboru obejmuje `.z3`, `.stp`, `.step`. STEP jest przekazywany do translatora ZW3D przez `cvxFileImport` i zapisywany jako *osobna* kopia `.Z3` w `Dokumenty\DSAssemblyCompare`; plik źródłowy STEP nie jest modyfikowany. Import i odczyt struktury zależą od dostępnego translatora/licencji ZW3D 2019. To nowa, eksperymentalna ścieżka, **niezbadana w uruchomionym ZW3D**.
7. Dla wybranego obiektu-części bez wystąpień komponentów makro traktuje go jako jedną część do porównania, zamiast zgłaszać błąd.
8. **Zaawansowana analiza geometrii jest tymczasowo całkowicie zablokowana.** W V2.2 prowadziła do natychmiastowego zamykania ZW3D. Nie należy jej włączać dopóki nie zostanie ustalona i usunięta przyczyna w API. Gdy brak pewnej zgodności brył między różnymi plikami, element jest oznaczany jako niezweryfikowany (szary), a nie fałszywie uznawany za zgodny.
9. Otwieranie raportu HTML po generowaniu nie jest już domyślne; w oknie znajduje się opcja „Otwórz raport automatycznie” i przycisk „Ostatni raport”.

## Instalacja przez dotychczasowy GitHub Actions

Repozytorium: https://github.com/damianink-png/test

Prześlij **ten sam plik ZIP źródłowy** do repozytorium na gałęzi `main`, z dokładną nazwą:

`DS_Assembly_Compare_GITHUB_ACTIONS_ZW3D2019_V1_1.zip`

Workflow `.github/workflows/build-ds-assembly-compare.yml` pobiera ten ZIP, rozpakowuje go, uruchamia `scripts/build.ps1` i publikuje wynik jako artefakt `DSAssemblyCompare2019-Windows-x64`. Jeśli w repo istnieje plik o tej nazwie, **zastąp** jego zawartość — nie twórz pliku o przyrostku `-1.zip`.

Wynikowa DLL jest do pobrania w GitHub → Actions → ostatni poprawny run → Artifacts. Przed aktualizacją zamknij ZW3D. Nie kopiuj paczki ZIP ze źródłami do folderu z DLL — należy wgrać bibliotekę z artefaktu GitHub Actions.

## Przebieg testu w ZW3D

1. Uruchom ZW3D 2019 Standard x64, wczytaj nową bibliotekę i wpisz `~DSAC`.
2. Upewnij się, że okno generatora nie znika po przełączeniu aktywnego dokumentu.
3. Kliknij próbkę obok „Nowy detal”, ustaw własny kolor i sprawdź, czy próbka się aktualizuje.
4. Wybierz dwie **kopie małych plików Z3** i wykonaj porównanie. Niezmieniona część może być zielona tylko przy potwierdzonej wspólnej referencji. Inne modele, których geometria nie została zbadana, muszą pozostać szare.
5. Obejrzyj wygenerowany wynik `.Z3`, zapisz/ zamknij go z menu ZW3D **bez zamykania programu**. Potwierdź, czy nie pojawia się Error Report.
6. Następnie spróbuj importować *mały* testowy plik `.STP` i wybierz właściwy obiekt z listy. Sprawdź, czy kopia Z3 powstała w katalogu raportów.
7. Nie testuj „zaawansowanej analizy geometrii” — jej UI jest wyszarzone z powodu wcześniejszych awarii.

Jeżeli program się zamknie, przekaż `%TEMP%\DSAC_V23_TRACE.log`, informację o ostatniej czynności i ewentualny raport awarii ZW3D. Ostatni zapis `BEGIN` / `END` pomoże zawęzić przyczynę.

## Ograniczenia

- Przesunięcia i obroty są porównywane dla bezpośrednich wystąpień; zagnieżdżone podzłożenia nie są jeszcze rozwijane.
- Pełne porównanie geometrii B-Rep nie jest dostępne w tej wersji, ponieważ opcjonalny odczyt poprzednio powodował crash.
- Wiarygodność odczytu STEP zależy od translacji do Z3 i odczytanej struktury w ZW3D.
- Nie ma gwarancji usunięcia wszystkich awarii; zmiany nie były jeszcze sprawdzane na instalacji ZW3D 2019.
- API Windows i ZW3D używa w kilku funkcjach 256-bajtowych ścieżek ANSI. Zbyt długa ścieżka lub niedostępne znaki będą zgłaszane zamiast obcinania nazwy.
