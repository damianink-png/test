@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
echo ============================================================
echo  DS Assembly Compare V1.1 / ZW3D 2019 Standard x64
echo  Kompilacja przez MSVC - BEZ ADMINISTRATORA
echo ============================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\build.ps1"
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  echo GOTOWE: output\DSAssemblyCompare2019.dll
) else (
  echo KOMPILACJA NIEUDANA - kod %RC%
  echo Sprawdz output\KOMPILACJA.log i output\STATUS.txt
)
pause
exit /b %RC%
