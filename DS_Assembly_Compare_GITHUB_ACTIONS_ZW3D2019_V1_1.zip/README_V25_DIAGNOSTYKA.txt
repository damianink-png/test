DS Assembly Compare V2.5 — test diagnostyczny (niezweryfikowany w ZW3D)

1. Przy uruchomieniu ~DSAC generowanie 3D jest WYŁĄCZONE. Najpierw wypróbuj sam raport.
2. Żeby testować 3D, zaznacz opcję generowania świadomie, na KOPIACH małych modeli.
3. Przycisk PORÓWNAJ tylko wysyła ~DSAC_EXEC do kolejki poleceń ZW3D.
4. Operacje otwierania, wstawiania, kolorowania i zapisywania odbywają się w komendzie hosta, nie w wndproc.
5. Przed kolejnym testem zamknij całą aplikację ZW3D, by nie ładować dwóch wersji DLL jednocześnie.
6. Po ewentualnej awarii wyślij %TEMP%\DSAC_V25_TRACE.log; ważne są OSTATNIE wpisy.
7. Geometria B-Rep NADAL nie jest sprawdzana; szare elementy nie są błędem samego renderer-a.
8. Nie wolno oznaczać samej zgodności nazwy i położenia jako dowodu identycznej geometrii.
9. Wynik kompilacji GitHub Actions i uruchomienie DLL w ZW3D to DWA RÓŻNE testy.
10. NOWE: identyczne bajtowo pliki źródłowe tego samego obiektu mogą być zielone mimo różnych katalogów. Zmienione pliki nadal wymagają rzeczywistej analizy geometrii.
