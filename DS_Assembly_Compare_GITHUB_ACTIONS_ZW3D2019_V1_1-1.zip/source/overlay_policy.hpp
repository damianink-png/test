#pragma once
#include "compare_core.hpp"
namespace dsac {
enum class OverlayState { Unchanged, Changed, Unverified, Added, Removed };
// When geometry is unknown and reference is different, NEVER claim green.
inline OverlayState overlayState(const Result& r,bool exactSameReference,bool posesAvailable){
 if(r.ia<0)return OverlayState::Added;
 if(r.ib<0)return OverlayState::Removed;
 if(r.geo<0||r.moved||r.rotated||r.nameChange||r.referenceChange)return OverlayState::Changed;
 if(!posesAvailable)return OverlayState::Unverified;
 if(r.geo==1||exactSameReference)return OverlayState::Unchanged;
 return OverlayState::Unverified;
}
}
