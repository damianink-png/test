# DS Assembly Compare V2 (wersja testowa)

**Platforma:** ZW3D 2019 Standard, Windows x64; kompilacja MSVC 2022 przez GitHub Actions. Dodatkowe biblioteki ZW3D nie są wymagane do **kompilacji**, bo eksporty API są wiązane podczas działania DLL w ZW3D.

**To jest źródłowa paczka do kompilacji, NIE gotowa DLL.** Testy algorytmu porównania przechodzą na Linux. Integracja z ZW3D 2019, rzeczywiste wstawianie i kolorowanie komponentów nie są jeszcze przetestowane na instalacji użytkownika. Zanim użyjesz na prawdziwym projekcie, wykonaj test na kopiach prostych złożeń.

## Co nowego

- Komenda `~DSAC` otwiera własne okno Windows z wyborem modelu A (stary) i B (nowy) bez wcześniejszego otwierania obu.
- Dwa pola na nazwy obiektów (`root`) są opcjonalne; automatyczny wybór działa, gdy z pliku wynika jeden jednoznaczny obiekt/złożenie.
- Wczytywane są **bezpośrednie wystąpienia** komponentów (pierwszy poziom); nie jest jeszcze obsłużone pełne rozwijanie podzłożeń.
- Model porównawczy `DSAC_V2_..._WYNIK.Z3` powstaje w Dokumenty/DSAssemblyCompare jako nowy plik, poza oryginałami. Nie powinien edytować plików A ani B.
- Zielony: komponent w aktualnej pozycji bez wykrytych zmian, potwierdzona geometria lub identyczna referencja; czerwony: nowy albo zmieniony aktualny komponent; pomarańczowy z przezroczystością 65%: poprzedni kształt/pozycja/usunięty detal; szary: nieustalona równoważność geometrii.
- Po przesunięciu jednego elementu wynik zawiera **dwa wystąpienia**: nowe czerwone i poprzednie pomarańczowe. Nie są sumowane jako dwie części do produkcji.
- Raport HTML/CSV zawiera przyporządkowania, statusy, przesunięcia i obroty.
- Diagnostyka `%TEMP%\\DSAC_V2_TRACE.log` zapisuje punkty bezpośrednio przed wywołaniami API, ułatwiając zlokalizowanie przyczyny ewentualnego crasha.

## Stabilność i geometria

**W trybie domyślnym szczegółowy odczyt brył jest wyłączony**, ponieważ wcześniejsza wersja `~DSAC_A` powodowała awarię ZW3D. Zostaw ten tryb podczas pierwszych testów. Nazwy, liczby i położenia są porównywane, ale geometria dwóch *różnych* referencji może zostać sklasyfikowana jako niezweryfikowana.

W oknie jest opcja `Zaawansowana analiza geometrii (testowa)`, wymagająca dodatkowego potwierdzenia. Odczytuje podstawowe cechy brył i topologii przy użyciu `cvxPartInqShapes`, `cvxPartInqShapeMass`, `cvxPartInqShapeFaces` i `cvxPartInqShapeEdges`. **To nie jest ścisłe porównanie B-Rep**, a opcja wymaga ostrożnych testów ZW3D. Przy różnicy w nazwie referencji, nawet ze zgodnymi cechami bryły, wystąpienie traktowane jest jako zmienione (czerwone) i widoczne jest stare (pomarańczowe).

Efekty przezroczystości i przypisywania koloru do komponentu zależą od obsługi `cvxEntTransSet` i `cvxEntColorSet` przez instalację ZW3D. Gdy odpowiednia funkcja zawiedzie, operacja jest logowana. Nie gwarantujemy wyświetlenia przezroczystości do czasu testu w aplikacji.

## Uruchomienie

1. Zamknij ZW3D, szczególnie jeśli wcześniej ładowałeś V1.1/SAFE.
2. Skompiluj na GitHubie lub lokalnie za pomocą `KOMPILUJ_JEDNYM_KLIKNIECIEM.bat` (Visual Studio C++).
3. Załaduj wynik `DSAssemblyCompare2019.dll` w ZW3D zgodnie z lokalną metodą (`$load`/menedżer dodatków, zależnie od konfiguracji).
4. Wpisz `~DSAC`. Polecenie `~DSAC_INFO` otwiera pomoc.
5. Wybierz pliki Z3 A i B. Jeżeli plik zawiera kilka obiektów, wpisz nazwę obiektu w dodatkowym polu.
6. Na pierwszy test **nie włączaj analizy geometrii** i użyj kopii bardzo prostych złożeń.
7. Kliknij `POROWNAJ I UTWORZ RAPORT`.
8. Sprawdź raport HTML, CSV i model wynikowy `.Z3` w Dokumenty/DSAssemblyCompare.

**Ważne:** Ścieżki w API ZW3D 2019 mają limit 255 bajtów i są konwertowane do lokalnej strony kodowej Windows. Przy zbyt długich ścieżkach lub znakach nieobsługiwanych przez API program zgłosi błąd zamiast obcinać nazwę.

## Kompilacja na istniejącym repozytorium

Twoje repo `damianink-png/test` już ma workflow, który szuka paczki o nazwie `DS_Assembly_Compare_GITHUB_ACTIONS_ZW3D2019_V1_1.zip`. Aby nie zmieniać działającego procesu, nowe wydanie V2 rozpowszechniamy **pod tą samą nazwą pliku ZIP**. Wgraj plik i zastąp w repo starą wersję; obecny workflow uruchomi MSVC automatycznie.

Repozytorium może też przechowywać te pliki rozpakowane pod `source/`, `tests/`, `scripts/` i `.github/workflows/`.

## Pliki wynikowe

- `DSAssemblyCompare2019.dll` — biblioteka x64 po kompilacji na GitHub.
- `output/KOMPILACJA.log` — dziennik MSVC.
- `%TEMP%\\DSAC_V2_TRACE.log` — diagnostyka środowiska ZW3D.
- `Dokumenty/DSAssemblyCompare/DSAC_V2_*.html` — raport.
- `Dokumenty/DSAssemblyCompare/DSAC_V2_*.csv` — tabela do Excela.
- `Dokumenty/DSAssemblyCompare/DSAC_V2_*_WYNIK.Z3` — wynikowy model złożenia.

Nie podmieniaj starej DLL przy uruchomionym ZW3D; zamknij aplikację przed zamianą i przetestuj V2 na kopii modeli.
