#include "../source/overlay_policy.hpp"
#include <iostream>
#include <cmath>
#include <cassert>
using namespace dsac;
static Item item(const std::string&name,double x){Item v;v.name=name;v.part=name;v.file="model.Z3";v.path="/"+name;v.pose.t[0]=x;return v;}
int main(){
 Snapshot a,b;a.items.push_back(item("P1",0));b.items.push_back(item("P1",150));
 auto rows=compare(a,b);assert(rows.size()==1&&rows[0].moved);
 assert(std::abs(rows[0].dx-150)<1e-8);
 assert(overlayState(rows[0],true,true)==OverlayState::Changed);
 Result r;r.ia=0;r.ib=0;r.geo=0;
 assert(overlayState(r,true,true)==OverlayState::Unchanged);
 assert(overlayState(r,false,true)==OverlayState::Unverified);
 assert(overlayState(r,true,false)==OverlayState::Unverified);
 r.nameChange=true;assert(overlayState(r,true,true)==OverlayState::Changed);
 r.nameChange=false;r.geo=-1;assert(overlayState(r,true,true)==OverlayState::Changed);
 r.geo=1;assert(overlayState(r,false,true)==OverlayState::Unchanged);
 Result added;added.ia=-1;added.ib=0;assert(overlayState(added,false,true)==OverlayState::Added);
 Result removed;removed.ia=0;removed.ib=-1;assert(overlayState(removed,false,true)==OverlayState::Removed);
 Snapshot c,d;c.items.push_back(item("ABC",0));d.items.push_back(item("ABC",0));d.items.push_back(item("NEW",0));
 auto rr=compare(c,d);assert(rr.size()==2);
 Result rotated;r=Result{};r.ia=r.ib=0;r.rotated=true;assert(overlayState(r,true,true)==OverlayState::Changed);
 Geometry g1,g2;g1.valid=true;g2.valid=true;
 SolidDescriptor so;so.area=123;so.volume=345;so.faces=6;so.edges=12;
 g1.solids.push_back(so);g2.solids.push_back(so);
 assert(compareGeometry(g1,g2)==1);g2.solids[0].faces=7;
 assert(compareGeometry(g1,g2)==-1);
 std::cout<<"DSAC V2: 13 checks PASS\n";
}
