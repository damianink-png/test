import sys,json,time,statistics
from pathlib import Path
from collections import Counter
sys.path.insert(0,sys.argv[1])
from dsac29.cli import process
root=Path(__file__).resolve().parent
if '--generate' in sys.argv:
 from dsac29.step_io import ColoredDocument
 from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox,BRepPrimAPI_MakeCylinder
 from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
 from OCP.gp import gp_Trsf,gp_Vec,gp_Ax2,gp_Pnt,gp_Dir
 from OCP.TopLoc import TopLoc_Location
 from OCP.TDataStd import TDataStd_Name
 from OCP.TCollection import TCollection_ExtendedString
 from OCP.STEPCAFControl import STEPCAFControl_Writer
 from OCP.IFSelect import IFSelect_RetDone
 for rev in ('A','B'):
  doc=ColoredDocument();definitions=[]
  for k in range(3):
   box=BRepPrimAPI_MakeBox(60+k*10,40,8+k).Shape()
   hole=BRepPrimAPI_MakeCylinder(gp_Ax2(gp_Pnt(20,20,-1),gp_Dir(0,0,1)),5,15).Shape()
   shape=BRepAlgoAPI_Cut(box,hole).Shape();definitions.append(doc.tool.AddShape(shape,False))
  for i in range(120):
   tr=gp_Trsf();tr.SetTranslation(gp_Vec((i%12)*120,(i//12)*100+(15 if rev=='B' and i>=114 else 0),0))
   label=doc.tool.AddComponent(doc.root,definitions[i%3],TopLoc_Location(tr));TDataStd_Name.Set_s(label,TCollection_ExtendedString(f'PART_{i:03}'))
  doc.tool.UpdateAssemblies();writer=STEPCAFControl_Writer();writer.SetNameMode(True);assert writer.Transfer(doc.doc);assert writer.Write(str(root/f'{rev}.step'))==IFSelect_RetDone
results=[]
for n in range(3):
 events=[];start=time.perf_counter()
 folder,records,error=process(root/'A.step',root/'B.step',root/f'{sys.argv[2]}_{n}',step="--full" in sys.argv,diff_step=False,revision_style=True,progress=events.append,**({'thumbnails':True} if '--thumbnails' in sys.argv else {}))
 results.append({'seconds':time.perf_counter()-start,'pairs':[(r.a_index,r.b_index,r.status) for r in records],'counts':dict(Counter(r.status for r in records)),'events':events})
(root/(sys.argv[2]+'.json')).write_text(json.dumps({'runs':results,'median':statistics.median(r['seconds'] for r in results)},indent=2))
print(sys.argv[2],statistics.median(r['seconds'] for r in results),results[0]['counts'])
