Uruchom z katalogu repo: python POMIARY/benchmark.py /pelna/sciezka/v46 nowy_pomiar --full --thumbnails
Porównuj mediany na tym samym komputerze. baseline to 4.5, optimized to 4.6.
