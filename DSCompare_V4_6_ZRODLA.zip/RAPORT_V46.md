# DS Compare 4.6 — zmiany i weryfikacja

## Interfejs

Nowy układ zgodny z kierunkiem zaakceptowanej wizualizacji: nawigacja u góry,
karty A/B, cztery liczniki, filtrowana lista z kolorowymi statusami, panel eksportu
po prawej. Motywy Jasny/Ciemny, bez Historii, pusty start normalnego uruchomienia.
Ustawienia i folder zapisu są zapamiętywane, modele i wyniki nie są odtwarzane.
Istniejące pliki na dysku nie są usuwane. Zmiana wskazanego modelu unieważnia
wyświetlany wynik porównania, zapobiegając pomyleniu rewizji.

Miniatury są prawdziwymi rzutami krawędzi z geometrii, generowanymi po analizie
w osobnym procesie. Nie odtwarzają cieniowanego renderu z konceptu. Limit 6000
krawędzi dotyczy tylko obrazka i jest oznaczony jako uproszczenie. Nie wpływa na
liczbę części w analizie lub STEP. Widoki na mniejszych ekranach można przewijać.

## Szybkość

Cache właściwości brył korzysta wyłącznie z tej samej definicji OpenCascade,
orientacji oraz czystego przesunięcia. Obrócone wystąpienia nadal są liczone
bezpośrednio. Zachowano własne nazwy, ścieżki i położenia wszystkich wystąpień.
Grupowanie BOM rozpoznaje tę samą definicję przed kosztowną serializacją B-Rep.
Nie zmieniono tolerancji, nie pominięto części, nie zmieniono logiki parowania.
Cache nie jest zapisywany między uruchomieniami.

Pomiar: Linux, ta sama sesja, mediana 3 uruchomień, modele A/B po 120 wystąpień
trzech powtarzalnych części. Oczekiwany wynik: 114 bez zmian, 6 przesuniętych.
W każdym pomiarze zachowano identyczne indeksy par i statusy. Czasy obejmują
odczyt modeli; nie obejmują uruchamiania interpretera i importu bibliotek.

| Zakres | 4.5 | 4.6 | Skrócenie czasu |
|---|---:|---:|---:|
| Analiza + raport, bez eksportu | 0.624 s | 0.110 s | 82.3% |
| Analiza + raport + STEP | 1.581 s | 1.113 s | 29.6% |
| Pełny przebieg 4.6 z miniaturami vs 4.5 bez miniaturek | 1.581 s | 1.145 s | 27.6% |

To test syntetycznego złożenia z powtarzalnymi definicjami, nie gwarancja takiego
samego przyspieszenia dla dowolnego STEP. Modele z unikalnymi częściami, obrotami
lub drogimi operacjami Boolean mogą zyskać znacznie mniej. Nie powtórzono testów
na dużych publicznych modelach OpenArm. Dane historyczne testy_trafnosci pochodzą
z wcześniejszych wersji. Brak deklaracji wzrostu trafności parowania.

## Testy

`QT_QPA_PLATFORM=offscreen python -m pytest -q tests`:
**119 passed in 9.75s**. Testy zawierają regresję geometrii, globalnego parowania,
AP214/AP242, kolorów/przezroczystości, raportów oraz nowe sprawdzenia zgodności
właściwości cache z obliczeniami bezpośrednimi, liczby serializacji BOM, prawdziwych
miniaturek i ich limitu, pełnego workera z GUI, filtrów, zapamiętywania motywu,
pustego ponownego uruchomienia i nieusuwania zapisanych wyników przy czyszczeniu.
Obejrzano rzeczywiste zrzuty obu motywów na przykładzie ramy.

Workflow Windows sprawdza gotowy EXE: porównanie, oba schematy STEP, miniatury,
masę, trzy zakładki w dwóch motywach, ładowanie DLL i jej eksporty. Nie wykonano
tego workflow w tej sesji. Importer ani działanie DLL wewnątrz ZW3D nie zostały
przetestowane. To źródła do kompilacji, nie skompilowana aplikacja Windows.
