"""Revision workspace: empty sessions, two themes, static geometry thumbnails."""
import json,sys
from pathlib import Path
from PySide6.QtCore import Qt,QSize,QPointF
from PySide6.QtGui import QColor,QPainter,QPen,QIcon
from PySide6.QtWidgets import (QApplication,QWidget,QFrame,QLabel,QPushButton,QLineEdit,
 QVBoxLayout,QHBoxLayout,QGridLayout,QStackedWidget,QComboBox,QCheckBox,
 QProgressBar,QPlainTextEdit,QHeaderView,QScrollArea,QStyledItemDelegate,QStyle)
from .gui45 import Window as BaseWindow,FileCard as BaseFileCard,button,table,icon as base_icon

def icon(key):
 pix=base_icon(key).pixmap(48,48);paint=QPainter(pix);paint.setCompositionMode(QPainter.CompositionMode_SourceIn);paint.fillRect(pix.rect(),QColor('#4b85ff'));paint.end();return QIcon(pix)

PALETTES={
 'Jasny':dict(bg='#f4f7fc',card='#ffffff',ink='#17253d',muted='#65758f',line='#dce4f0',accent='#2163ef',soft='#edf3ff',field='#f8faff',hover='#e5edfc',green='#168953',orange='#d66b20',blue='#2463eb',purple='#8353cf'),
 'Ciemny':dict(bg='#101722',card='#192333',ink='#edf3fc',muted='#9eafc8',line='#33445c',accent='#4b85ff',soft='#213553',field='#111d2c',hover='#2b405e',green='#51ce92',orange='#ffaa66',blue='#76a6ff',purple='#bc99ff')}

def theme_style(p):
 return '''
 QWidget {background:BG;color:INK;font-family:"Segoe UI";font-size:13px;}
 QFrame#topbar,QFrame#card,QFrame#metric,QFrame#export {background:CARD;border:1px solid LINE;border-radius:10px;}
 QFrame#topbar {border-radius:0px;} QLabel {background:transparent;}
 QLabel#heading {font-size:27px;font-weight:700;} QLabel#sub {color:MUTED;}
 QLabel#brand {font-size:22px;font-weight:700;} QLabel#section {font-size:18px;font-weight:600;}
 QPushButton {background:CARD;border:1px solid LINE;border-radius:7px;padding:8px 12px;min-height:21px;}
 QPushButton:hover {background:HOVER;border-color:ACCENT;}
 QPushButton:disabled {color:MUTED;background:FIELD;border-color:LINE;}
 QPushButton#primary {background:ACCENT;color:white;border:1px solid ACCENT;font-weight:600;padding:10px 15px;}
 QPushButton#primary:disabled {background:SOFT;color:MUTED;border-color:LINE;}
 QPushButton#nav {background:transparent;border:0;border-radius:7px;padding:13px 20px;}
 QPushButton#nav:checked {background:SOFT;color:ACCENT;border-bottom:3px solid ACCENT;}
 QPushButton#filter {padding:7px 10px;} QPushButton#filter:checked {background:ACCENT;color:white;border-color:ACCENT;}
 QLineEdit,QDoubleSpinBox,QSpinBox,QComboBox {background:FIELD;color:INK;border:1px solid LINE;border-radius:6px;padding:7px;min-height:20px;}
 QLineEdit:focus {border-color:ACCENT;}
 QTableWidget {background:CARD;alternate-background-color:FIELD;border:1px solid LINE;border-radius:7px;gridline-color:LINE;selection-background-color:SOFT;selection-color:INK;}
 QHeaderView::section {background:FIELD;color:MUTED;padding:10px;border:0;border-bottom:1px solid LINE;}
 QPlainTextEdit {background:FIELD;border:1px solid LINE;border-radius:6px;color:MUTED;}
 QCheckBox {spacing:7px;padding:3px;} QProgressBar {border:0;background:LINE;border-radius:2px;max-height:4px;} QProgressBar::chunk {background:ACCENT;}
 QToolTip {background:CARD;color:INK;border:1px solid LINE;}
 '''.replace('BG',p['bg']).replace('CARD',p['card']).replace('INK',p['ink']).replace('MUTED',p['muted']).replace('LINE',p['line']).replace('ACCENT',p['accent']).replace('SOFT',p['soft']).replace('FIELD',p['field']).replace('HOVER',p['hover'])

class Thumbnail(QWidget):
 def __init__(self):
  super().__init__();self.lines=[];self.setMinimumSize(145,110);self.setMaximumWidth(200);self.ink='#7387a3'
 def set_data(self,data):self.lines=data.get('lines',[]);self.update()
 def paintEvent(self,event):
  p=QPainter(self);p.setRenderHint(QPainter.Antialiasing);p.setPen(QPen(QColor(self.ink),.85))
  if not self.lines:
   p.drawText(self.rect(),Qt.AlignCenter,'Miniatura modelu\npo analizie');return
  points=[xy for line in self.lines for xy in line];xs=[xy[0] for xy in points];ys=[xy[1] for xy in points]
  xmin,xmax,ymin,ymax=min(xs),max(xs),min(ys),max(ys);scale=min((self.width()-16)/max(xmax-xmin,.001),(self.height()-16)/max(ymax-ymin,.001))
  cx=(xmin+xmax)/2;cy=(ymin+ymax)/2
  for line in self.lines:
   for a,b in zip(line,line[1:]):
    p.drawLine(QPointF((a[0]-cx)*scale+self.width()/2,(a[1]-cy)*scale+self.height()/2),QPointF((b[0]-cx)*scale+self.width()/2,(b[1]-cy)*scale+self.height()/2))

class FileCard(BaseFileCard):
 def __init__(self,title,subtitle):
  QFrame.__init__(self);self.setObjectName('card');self.setAcceptDrops(True)
  row=QHBoxLayout(self);row.setContentsMargins(18,16,18,16);col=QVBoxLayout()
  heading=QLabel(title);heading.setObjectName('section');col.addWidget(heading)
  self.path=QLineEdit();self.path.setAcceptDrops(False);self.path.setPlaceholderText('Wybierz model STEP…');self.path.textChanged.connect(self.changed.emit);col.addWidget(self.path)
  self.caption=QLabel('Przeciągnij plik STEP / STP');self.caption.setObjectName('sub');col.addWidget(self.caption)
  choose=button('Wybierz plik',self.choose);col.addWidget(choose,0,Qt.AlignLeft);row.addLayout(col,1)
  self.thumbnail=Thumbnail();row.addWidget(self.thumbnail,1)
  self.path.textChanged.connect(self.clear_preview)
 def clear_preview(self):self.thumbnail.set_data({});self.caption.setText('Przeciągnij plik STEP / STP')

class StatusDelegate(QStyledItemDelegate):
 def paint(self,painter,option,index):
  painter.save()
  status=index.data(Qt.UserRole);key={'SAME':'green','ADDED':'blue','REMOVED':'orange','UNCERTAIN':'orange'}.get(status,'purple')
  win=self.parent().window();palette=PALETTES.get(win.theme.currentText(),PALETTES['Jasny']);color=QColor(palette[key]);background=QColor(color);background.setAlpha(28)
  if option.state & QStyle.State_Selected:painter.fillRect(option.rect,QColor(palette['soft']))
  rect=option.rect.adjusted(6,5,-6,-5);painter.setRenderHint(QPainter.Antialiasing);painter.setPen(Qt.NoPen);painter.setBrush(background);painter.drawRoundedRect(rect,5,5);painter.setPen(color);painter.drawText(rect,Qt.AlignCenter,index.data());painter.restore()

class Window(BaseWindow):
 generate_thumbnails=True
 def __init__(self,a='',b=''):
  super().__init__(a,b)
  self.setWindowTitle('DS Compare 4.6 — porównanie rewizji');self.resize(1480,950);self.setMinimumSize(1100,720)
  old=self.takeCentralWidget();self.stack.setParent(None)
  central=QWidget();layout=QVBoxLayout(central);layout.setContentsMargins(0,0,0,0);layout.setSpacing(0)
  bar=QFrame();bar.setObjectName('topbar');bl=QHBoxLayout(bar);bl.setContentsMargins(24,9,24,9)
  brand=QLabel('DS  Compare');brand.setObjectName('brand');bl.addWidget(brand);bl.addStretch()
  for key,label in [('compare','Porównanie'),('mass','Masa części'),('settings','Ustawienia')]:
   bnav=self.nav[key];bnav.setParent(bar);bnav.setText(label);bnav.setIconSize(QSize(22,22));bl.addWidget(bnav)
  bl.addStretch();self.theme_quick=QComboBox();self.theme_quick.addItems(PALETTES);self.theme_quick.setCurrentText(self.theme.currentText());self.theme_quick.currentTextChanged.connect(self.theme.setCurrentText);bl.addWidget(self.theme_quick)
  scroll=QScrollArea();scroll.setFrameShape(QFrame.NoFrame);scroll.setWidgetResizable(True);self.stack.setMinimumSize(1140,860);scroll.setWidget(self.stack)
  layout.addWidget(bar);layout.addWidget(scroll,1);self.setCentralWidget(central);old.deleteLater()
  self.apply_theme(self.theme.currentText());self.navigate('compare')
  for card in (self.a,self.b):card.path.textChanged.connect(self.invalidate_comparison)
 def create_settings(self):
  super().create_settings()
  self.theme=QComboBox();self.theme.addItems(PALETTES);self.theme.setCurrentText(str(self.store.value('theme46','Jasny')))
  card=self.pages['settings'].findChild(QFrame,'card');card.layout().insertRow(0,'Wygląd programu',self.theme)
  self.theme.currentTextChanged.connect(self.apply_theme)
 def apply_theme(self,name):
  p=PALETTES.get(name,PALETTES['Jasny']);self.setStyleSheet(theme_style(p));self.store.setValue('theme46',name)
  if hasattr(self,'theme_quick'):
   self.theme_quick.blockSignals(True);self.theme_quick.setCurrentText(name);self.theme_quick.blockSignals(False)
  for key,b in self.nav.items():b.setIcon(icon(key))
  for card in [getattr(self,'a',None),getattr(self,'b',None)]:
   if card:card.thumbnail.ink=p['muted'];card.thumbnail.update()
  if hasattr(self,'metrics'):
   for label,key in zip(self.metrics,('green','blue','orange','purple')):label.setStyleSheet(f'font-size:28px;font-weight:700;color:{p[key]}')
 def create_compare(self):
  self.filter_status='ALL';self.metrics=[]
  lay=self.page('compare','Co zmieniło się w projekcie?','Porównaj rewizje i otwórz kolorowy wynik w ZW3D.');lay.setSpacing(10)
  row=QHBoxLayout();self.a=FileCard('A   Stara rewizja','');self.b=FileCard('B   Nowa rewizja','');row.addWidget(self.a,1);row.addWidget(button('⇄',self.swap));row.addWidget(self.b,1);lay.addLayout(row)
  row=QHBoxLayout();self.run_compare=button('Porównaj modele',lambda:self.start('compare'),True);row.addWidget(self.run_compare)
  self.cancel_compare=button('Anuluj',self.cancel);self.cancel_compare.setEnabled(False);row.addWidget(self.cancel_compare)
  self.compare_summary=QLabel('Wybierz dwa modele, aby rozpocząć.');self.compare_summary.setWordWrap(True);row.addWidget(self.compare_summary,1);lay.addLayout(row)
  metricrow=QHBoxLayout()
  for title in ('Bez zmian','Nowych','Usuniętych','Zmienionych'):
   card=QFrame();card.setObjectName('metric');ml=QHBoxLayout(card);ml.setContentsMargins(18,10,18,10);count=QLabel('—');ml.addWidget(count);ml.addWidget(QLabel(title));ml.addStretch();self.metrics.append(count);metricrow.addWidget(card,1)
  lay.addLayout(metricrow)
  body=QHBoxLayout();left=QVBoxLayout();head=QHBoxLayout();title=QLabel('Zmiany w rewizji');title.setObjectName('section');head.addWidget(title);head.addStretch()
  self.search=QLineEdit();self.search.setPlaceholderText('Szukaj części…');self.search.textChanged.connect(self.filter_results);head.addWidget(self.search);left.addLayout(head)
  filters=QHBoxLayout();self.filter_buttons={}
  for key,label in [('ALL','Wszystkie'),('ADDED','Nowe'),('REMOVED','Usunięte'),('CHANGES','Zmienione'),('UNCERTAIN','Do sprawdzenia')]:
   b=button(label,lambda checked=False,k=key:self.select_filter(k));b.setObjectName('filter');b.setCheckable(True);b.setChecked(key=='ALL');self.filter_buttons[key]=b;filters.addWidget(b)
  filters.addStretch();left.addLayout(filters)
  self.only_changes=QCheckBox('Ukryj pozycje bez zmian');self.only_changes.setChecked(True);self.only_changes.toggled.connect(self.filter_results);left.addWidget(self.only_changes)
  self.compare_table=table(['Status','Stara rewizja A','Nowa rewizja B','Szczegóły']);self.compare_table.setItemDelegateForColumn(0,StatusDelegate(self.compare_table));self.compare_table.verticalHeader().setDefaultSectionSize(36);self.compare_table.setColumnWidth(0,140);self.compare_table.setColumnWidth(1,175);self.compare_table.setColumnWidth(2,175);left.addWidget(self.compare_table,1);body.addLayout(left,1)
  export=QFrame();export.setObjectName('export');export.setFixedWidth(285);export.setMinimumHeight(340);el=QVBoxLayout(export);el.setContentsMargins(16,14,16,14);el.setSpacing(7)
  h=QLabel('Wynik porównania');h.setObjectName('section');el.addWidget(h)
  self.export_name=QLabel('Kolorowy model STEP');self.export_name.setWordWrap(True);el.addWidget(self.export_name)
  self.legend=QLabel('● Bez zmian — zielony\n\n● Stara geometria — pomarańczowy\n\n● Nowa geometria — niebieski');self.legend.setWordWrap(True);self.legend.setMinimumHeight(75);el.addWidget(self.legend);el.addStretch()
  self.compare_open={}
  for text,filename in [('Otwórz STEP','POROWNANIE_KOLORY.step'),('Raport zmian','RAPORT.html'),('Eksport CSV','ZMIANY.csv'),('Pokaż folder wyników','')]:
   b=button(text,lambda checked=False,f=filename:self.open_result('compare',f),filename.endswith('.step'));b.setEnabled(False);self.compare_open[filename]=b;el.addWidget(b)
  self.compare_open['POROWNANIE_KOLORY.step'].setToolTip('Otwiera plik w domyślnej aplikacji Windows dla STEP.');body.addWidget(export);lay.addLayout(body,1)
  self.progress=QProgressBar();self.progress.setRange(0,1);self.progress.setValue(0);self.progress.setTextVisible(False);lay.addWidget(self.progress)
  self.log=QPlainTextEdit();self.log.setReadOnly(True);self.log.setMaximumHeight(44);self.log.document().setMaximumBlockCount(150);lay.addWidget(self.log)
  foot=QHBoxLayout();label=QLabel('Każdy start programu otwiera pustą sesję.');label.setObjectName('sub');foot.addWidget(label);foot.addStretch();self.reset_button=button('Nowe porównanie',self.reset_session);foot.addWidget(self.reset_button);lay.addLayout(foot)
  self.output=QLineEdit(str(self.store.value('output',str(Path.home()/'Documents'/'DSCompare'))))
  outputrow=QWidget();ol=QHBoxLayout(outputrow);ol.setContentsMargins(0,0,0,0);ol.addWidget(self.output);ol.addWidget(button('Wybierz folder',self.choose_output))
  self.pages['settings'].findChild(QFrame,'card').layout().addRow('Folder zapisu wyników',outputrow)
 def create_mass(self):
  super().create_mass();self.mass_summary.setText('Wybierz model. Folder zapisu oraz gęstość ustawisz w Ustawieniach.')
 def select_filter(self,key):
  self.filter_status=key
  for k,b in self.filter_buttons.items():b.setChecked(k==key)
  self.filter_results()
 def filter_results(self,*args):
  if not hasattr(self,'compare_table'):return
  query=self.search.text().casefold();wanted=getattr(self,'filter_status','ALL')
  for i in range(self.compare_table.rowCount()):
   status=self.row_statuses[i];text=' '.join(self.compare_table.item(i,j).text() for j in range(4))
   allowed=wanted=='ALL' or wanted==status or wanted=='CHANGES' and status in ('MOVED','CHANGED','RENAMED')
   self.compare_table.setRowHidden(i,not allowed or query not in text.casefold() or self.only_changes.isChecked() and status=='SAME')
 def start(self,kind):
  super().start(kind)
  self.reset_button.setEnabled(self.process is None)
  if self.process is not None:self.compare_summary.setText('Analiza trwa…' if kind=='compare' else 'Obliczanie masy…')
 def finished(self,code,status):
  super().finished(code,status);self.reset_button.setEnabled(True)
  if self.was_cancelled:self.compare_summary.setText('Analiza anulowana.')
  elif code:self.compare_summary.setText('Analiza nie została ukończona — sprawdź komunikat błędu.')
 def load_result(self,kind,folder):
  super().load_result(kind,folder)
  if kind!='compare':return
  for i,status in enumerate(self.row_statuses):self.compare_table.item(i,0).setData(Qt.UserRole,status)
  folder=Path(folder);s=json.loads((folder/'PODSUMOWANIE.json').read_text(encoding='utf-8'));c=s['statuses']
  values=[c.get('SAME',0),c.get('ADDED',0),c.get('REMOVED',0),sum(c.get(k,0) for k in ('MOVED','CHANGED','RENAMED'))]
  for label,value in zip(self.metrics,values):label.setText(str(value))
  uncertain=c.get('UNCERTAIN',0);message=f"Porównanie zakończone · A: {s['solids_A']} części → B: {s['solids_B']} części"
  if uncertain:message+=f' · Do sprawdzenia: {uncertain}'
  if s.get('step_export_error'):message+=' · Błąd eksportu STEP — raport dostępny'
  self.compare_summary.setText(message);self.export_name.setText('POROWNANIE_KOLORY.step')
  old=s.get('colors_hex',{}).get('REMOVED','#ff610f');alpha=round((1-s.get('old_alpha',.4))*100)
  self.legend.setText(f'<span style="color:#24aa67">● Bez zmian</span><br><br><span style="color:{old}">● Stara geometria · {alpha}% przezr.</span><br><br><span style="color:#4b85ff">● Nowa geometria</span>')
  for role,card in [('A',self.a),('B',self.b)]:
   file=folder/f'MINIATURA_{role}.json'
   if file.exists():
    data=json.loads(file.read_text());card.thumbnail.set_data(data);card.caption.setText(f"{s['solids_'+role]} części · miniatura krawędziowa"+(' (uproszczona)' if data.get('truncated') else ''))
 def invalidate_comparison(self,*args):
  if self.process is not None or 'compare' not in self.results:return
  self.results.pop('compare');self.compare_table.setRowCount(0);self.row_statuses=[]
  for b in self.compare_open.values():b.setEnabled(False)
  for label in self.metrics:label.setText('—')
  self.compare_summary.setText('Modele zmienione — uruchom nowe porównanie.');self.export_name.setText('Kolorowy model STEP')
 def reset_session(self):
  if self.process is not None:return
  for card in (self.a,self.b,self.mass_file):card.path.clear()
  self.results.clear();self.compare_table.setRowCount(0);self.mass_table.setRowCount(0);self.row_statuses=[]
  for b in list(self.compare_open.values())+list(self.mass_open.values()):b.setEnabled(False)
  for label in self.metrics:label.setText('—')
  self.search.clear();self.select_filter('ALL');self.only_changes.setChecked(True);self.log.clear();self.mass_log.clear();self.progress.setValue(0);self.mass_progress.setValue(0)
  self.compare_summary.setText('Wybierz dwa modele, aby rozpocząć.');self.mass_summary.setText('Wybierz model do obliczenia masy.');self.export_name.setText('Kolorowy model STEP');self.navigate('compare')

def main(a='',b=''):
 app=QApplication.instance() or QApplication(sys.argv);app.setStyle('Fusion');w=Window(a,b);w.show();return app.exec()
