"""STEPCAF load/save to keep STEP names and per-body colors. Lengths expected in mm."""
from __future__ import annotations
from dataclasses import dataclass
import re
from pathlib import Path
from OCP.STEPCAFControl import STEPCAFControl_Reader, STEPCAFControl_Writer
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.TDF import TDF_LabelSequence, TDF_Label
from OCP.TDataStd import TDataStd_Name
from OCP.XCAFDoc import XCAFDoc_DocumentTool, XCAFDoc_ColorType
from OCP.TopoDS import TopoDS_Shape
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE
from OCP.TopLoc import TopLoc_Location
from OCP.Quantity import Quantity_Color,Quantity_ColorRGBA,Quantity_TOC_RGB
from OCP.IFSelect import IFSelect_RetDone
from .geometry import SolidInfo,describe


def _label_name(label: TDF_Label, default=''): 
    attr=TDataStd_Name()
    if label.FindAttribute(TDataStd_Name.GetID_s(),attr):
        txt=attr.Get().ToExtString().strip()
        if txt: return txt
    return default


from .names import technical

def _real_name(label):return not technical(label)


def _solids(shape: TopoDS_Shape):
    ex=TopExp_Explorer(shape, TopAbs_SOLID)
    while ex.More():
        yield ex.Current()
        ex.Next()


def _faces(shape: TopoDS_Shape):
    ex=TopExp_Explorer(shape,TopAbs_FACE)
    while ex.More():
        yield ex.Current()
        ex.Next()


def inspect_step_colors(path: str) -> dict:
    """Nie ufaj samemu sukcesowi zapisu: sprawdź kolory po ponownym imporcie XCAF."""
    from OCP.Quantity import Quantity_Color
    p=Path(path)
    document=TDocStd_Document(TCollection_ExtendedString('BinXCAF'))
    reader=STEPCAFControl_Reader()
    reader.SetNameMode(True);reader.SetColorMode(True)
    if reader.ReadFile(str(p))!=IFSelect_RetDone or not reader.Transfer(document):
        raise RuntimeError('Nie można ponownie odczytać wynikowego STEP')
    shape_tool=XCAFDoc_DocumentTool.ShapeTool_s(document.Main())
    colors=XCAFDoc_DocumentTool.ColorTool_s(document.Main())
    roots=TDF_LabelSequence();shape_tool.GetFreeShapes(roots)
    alphas=[]
    seen=[]; colored_labels=0;colored_faces=0;missing_bodies=0;missing_faces=0
    def detect(lab,depth=0):
        nonlocal colored_labels,colored_faces,missing_bodies,missing_faces
        if depth>64:raise RuntimeError('Cykliczna struktura STEP')
        target=TDF_Label()
        if shape_tool.IsReference_s(lab) and shape_tool.GetReferredShape_s(lab,target):
            detect(target,depth+1);return
        comps=TDF_LabelSequence()
        if shape_tool.GetComponents_s(lab,comps) and comps.Length():
            for i in range(1,comps.Length()+1):detect(comps.Value(i),depth+1)
            return
        shape=shape_tool.GetShape_s(lab)
        if shape.IsNull():return
        color=Quantity_Color()
        has=(colors.GetColor_s(lab,XCAFDoc_ColorType.XCAFDoc_ColorSurf,color) or
             colors.GetColor_s(lab,XCAFDoc_ColorType.XCAFDoc_ColorGen,color))
        if has:
            colored_labels+=1
            seen.append(tuple(round(x,4) for x in [color.Red(),color.Green(),color.Blue()]))
        else:missing_bodies+=1
        for face in _faces(shape):
            facecol=Quantity_ColorRGBA()
            if colors.GetColor(face,XCAFDoc_ColorType.XCAFDoc_ColorSurf,facecol):
                colored_faces+=1
                alphas.append(round(facecol.Alpha(),4))
                facecol=facecol.GetRGB()
                seen.append(tuple(round(x,4) for x in [facecol.Red(),facecol.Green(),facecol.Blue()]))
            else:missing_faces+=1
    for idx in range(1,roots.Length()+1):detect(roots.Value(idx))
    # Diagnostyka zapisanych rekordów stylu STEP, a nie tylko wyglądu CADbro.
    with p.open('rb') as inp:data=inp.read()
    result={'liczba_etykiet':roots.Length(),'bryly_bez_koloru':missing_bodies,'powierzchnie_bez_koloru':missing_faces,
            'pokolorowane_etykiety':colored_labels,
            'pokolorowane_powierzchnie':colored_faces,
            'brak_kolorow_powierzchni':not bool(colored_faces),
            'kolory_wczytane_rgb':sorted(set(seen)),
            'alfy_powierzchni':sorted(set(alphas)),
            'powierzchnie_przezroczyste':sum(x<0.9999 for x in alphas),
            'rekordy_przezroczystosci_step':data.count(b'SURFACE_STYLE_TRANSPARENT('),
            'rekordy_kolorow_step':data.count(b'COLOUR_RGB('),
            'rekordy_stylow_step':data.count(b'STYLED_ITEM(')}
    if not result['rekordy_kolorow_step'] or not result['rekordy_stylow_step']:
        raise RuntimeError('STEP został zapisany bez rekordów koloru — nie uznajemy eksportu za udany')
    if not (colored_labels or colored_faces):
        raise RuntimeError('Po ponownym wczytaniu STEP nie wykryto kolorów przypisanych do brył/powierzchni')
    return result

def load_step(path: str, max_solids: int = 1000, progress=None) -> list[SolidInfo]:
    p=Path(path)
    if not p.is_file(): raise FileNotFoundError(str(path))
    if p.suffix.lower() not in ('.stp','.step'): raise ValueError('Prototyp B-Rep wymaga STEP/STP (eksport z ZW3D).')
    document=TDocStd_Document(TCollection_ExtendedString('BinXCAF'))
    reader=STEPCAFControl_Reader();reader.SetNameMode(True);reader.SetColorMode(True)
    if reader.ReadFile(str(p))!=IFSelect_RetDone: raise ValueError('Nie można odczytać STEP: '+str(p))
    if not reader.Transfer(document): raise ValueError('Błąd transferu STEP: '+str(p))
    tool=XCAFDoc_DocumentTool.ShapeTool_s(document.Main())
    roots=TDF_LabelSequence();tool.GetFreeShapes(roots)
    from .geometry import DescriptionCache
    description_cache=DescriptionCache()
    out=[]
    def add_shape(shape,name,hierarchy,name_origin):
        solids=list(_solids(shape))
        for k,s in enumerate(solids,1):
            if len(out)>=max_solids: raise ValueError(f'Limit bezpieczenstwa: {max_solids} bryl na plik')
            name2=name if len(solids)==1 else f'{name}#{k}'
            info=description_cache.describe(s,name2,hierarchy+'/'+name2,str(p))
            info.name_origin=name_origin
            out.append(info)
            if progress and len(out)%10==0: progress(f'{p.name}: wczytano {len(out)} brył')
    def walk(lab: TDF_Label, parent_loc: TopLoc_Location, hierarchy:str, depth:int):
        if depth>32: raise ValueError('Zbyt głębokie podzłożenie (>32 poziomów)')
        is_ref=tool.IsReference_s(lab)
        actual=TDF_Label()
        if is_ref and tool.GetReferredShape_s(lab,actual):
            target=actual
            loc=parent_loc.Multiplied(tool.GetLocation_s(lab))
        else:target=lab;loc=parent_loc
        # ZW3D eksportuje czasem referencję jako =>[0:1:1:102].
        # To znacznik OCAF, nie nazwa części; preferuj nazwę docelowego kształtu.
        local_name=_label_name(lab,'')
        target_name=_label_name(target,'')
        name_origin='explicit' if _real_name(local_name) else 'definition_fallback'
        label_name=local_name if _real_name(local_name) else target_name
        if not _real_name(label_name):
            name_origin='generated'
            meaningful=[v for v in reversed(hierarchy.split('/')) if _real_name(v)]
            label_name=meaningful[0] if meaningful else f'Element_{len(out)+1:04d}'
        fullname=f'{hierarchy}/{label_name}' if hierarchy else label_name
        comps=TDF_LabelSequence()
        if tool.GetComponents_s(target,comps) and comps.Length()>0:
            for idx in range(1,comps.Length()+1): walk(comps.Value(idx),loc,fullname,depth+1)
        else:
            sh=tool.GetShape_s(target)
            if sh.IsNull():return
            # Apply parent transform to shape if necessary. A shape may have its own location.
            if not loc.IsIdentity(): sh=sh.Moved(loc)
            add_shape(sh,label_name,fullname,name_origin)
    for i in range(1,roots.Length()+1): walk(roots.Value(i),TopLoc_Location(),'',0)
    if not out: raise ValueError('W pliku STEP nie znaleziono zadnej bryly zamknietej (SOLID).')
    if progress:progress(f'{p.name}: gotowe {len(out)} brył')
    return out


COLORS={'SAME':(0.57,0.60,0.65),'RENAMED':(0.57,0.60,0.65),
        'MOVED':(0.55,0.30,0.85),'CHANGED':(0.40,0.35,0.83),
        'ADDED':(0.15,0.85,0.35),'REMOVED':(0.95,0.23,0.20),
        'UNCERTAIN':(1.,0.78,0.15)}

# Distinct subassemblies can be hidden as a whole in CAD applications that
# preserve the XCAF/STEP product assembly structure (including ZW3D on import).
REVISION_GROUPS = {
    'SAME': '01_BEZ_ZMIAN',
    'RENAMED': '01_BEZ_ZMIAN',
    'CHANGED': '02_ZMIENIONE',
    'MOVED': '03_PRZESUNIETE',
    'ADDED': '04_NOWE',
    'REMOVED': '05_USUNIETE',
    'UNCERTAIN': '06_DO_SPRAWDZENIA', # legacy only; new revision policy never emits it
}

class ColoredDocument:
    """XCAF assembly writer with shared part definitions and per-face RGBA.

    Each unique native geometry + color + opacity is only copied and styled
    once. Repeated occurrences remain separately located assembly components.
    When enabled, categorized subassemblies can be suppressed from the CAD
    assembly tree without deleting geometry.
    """
    def __init__(self, group_by_status=False, reuse_definitions=True):
        from OCP.TopoDS import TopoDS_Compound
        from OCP.BRep import BRep_Builder
        self.doc=TDocStd_Document(TCollection_ExtendedString('BinXCAF'))
        self.tool=XCAFDoc_DocumentTool.ShapeTool_s(self.doc.Main())
        self.colors=XCAFDoc_DocumentTool.ColorTool_s(self.doc.Main())
        self.root=self._assembly('DS Compare - POROWNANIE REWIZJI')
        self.count=0
        self.transparent_faces=0
        self.group_by_status=group_by_status
        self._groups={}
        self._definitions={}
        self.reuse_definitions=reuse_definitions
        self.definitions_created=0
        self.definitions_reused=0

    def _assembly(self,name,parent=None):
        from OCP.TopoDS import TopoDS_Compound
        from OCP.BRep import BRep_Builder
        shape=TopoDS_Compound();BRep_Builder().MakeCompound(shape)
        label=self.tool.AddShape(shape,True)
        TDataStd_Name.Set_s(label,TCollection_ExtendedString(name))
        if parent is not None:
            comp=self.tool.AddComponent(parent,label,TopLoc_Location())
            TDataStd_Name.Set_s(comp,TCollection_ExtendedString(name))
        return label

    def _parent(self,group,revision):
        if not self.group_by_status or group is None:return self.root
        name=REVISION_GROUPS.get(group,group)
        if name not in self._groups:self._groups[name]=self._assembly(name,self.root)
        parent=self._groups[name]
        if group in ('CHANGED','MOVED','UNCERTAIN') and revision in ('A','B'):
            name2=('A_STARA' if revision=='A' else 'B_NOWA')
            path=(name,name2)
            if path not in self._groups:self._groups[path]=self._assembly(name2,parent)
            parent=self._groups[path]
        return parent

    def add(self,shape,name,rgb,alpha=1.0,group=None,revision=None):
        import math
        if not math.isfinite(float(alpha)) or not 0.0 <= float(alpha) <= 1.0:
            raise ValueError('Nieprawidłowa przezroczystość')
        loc=shape.Location()
        local=shape.Located(TopLoc_Location())
        rgba=tuple(round(float(c),7) for c in rgb)+(round(float(alpha),7),)
        key=(hash(local),int(local.Orientation()),rgba)
        label=None
        for candidate,known,known_faces in (self._definitions.get(key,()) if self.reuse_definitions else ()):
            if local.IsSame(candidate) and local.Orientation()==candidate.Orientation():
                label=known;num_faces=known_faces;break
        if label is None:
            # Do not modify the source shape. Copy only once per native definition.
            from OCP.BRepBuilderAPI import BRepBuilderAPI_Copy
            unlocated=BRepBuilderAPI_Copy(local,True,False).Shape()
            label=self.tool.AddShape(unlocated,False)
            col=Quantity_ColorRGBA(Quantity_Color(*map(float,rgb),Quantity_TOC_RGB),float(alpha))
            TDataStd_Name.Set_s(label,TCollection_ExtendedString(name))
            for kind in (XCAFDoc_ColorType.XCAFDoc_ColorGen,XCAFDoc_ColorType.XCAFDoc_ColorSurf):
                self.colors.SetColor(label,col,kind)
            # Face level opacity is important: occurrence-only alpha is often
            # discarded during STEP -> CAD transfer.
            num_faces=0
            for face in _faces(unlocated):
                num_faces+=1
                sub=self.tool.AddSubShape(label,face)
                if sub.IsNull():raise RuntimeError('Nie można przypisać koloru powierzchni')
                self.colors.SetColor(sub,col,XCAFDoc_ColorType.XCAFDoc_ColorSurf)
                self.colors.SetColor(sub,col,XCAFDoc_ColorType.XCAFDoc_ColorGen)
            self._definitions.setdefault(key,[]).append((local,label,num_faces))
            self.definitions_created+=1
        else:
            self.definitions_reused+=1
        parent=self._parent(group,revision)
        occurrence=self.tool.AddComponent(parent,label,loc)
        TDataStd_Name.Set_s(occurrence,TCollection_ExtendedString(name))
        col=Quantity_ColorRGBA(Quantity_Color(*map(float,rgb),Quantity_TOC_RGB),float(alpha))
        for kind in (XCAFDoc_ColorType.XCAFDoc_ColorGen,XCAFDoc_ColorType.XCAFDoc_ColorSurf):
            self.colors.SetColor(occurrence,col,kind)
        if alpha<0.9999:
            self.transparent_faces+=num_faces
        self.count+=1

    def write(self,path):
        import os
        from OCP.Interface import Interface_Static
        from OCP.STEPControl import STEPControl_Controller
        STEPControl_Controller.Init_s()
        schema=os.getenv('DSCOMPARE_STEP_SCHEMA','AP242DIS')
        if schema not in ('AP214IS','AP242DIS'):schema='AP242DIS'
        if not Interface_Static.SetCVal_s('write.step.schema',schema):
            raise RuntimeError('Nie można ustawić schematu STEP')
        Interface_Static.SetIVal_s('write.step.assembly',1)
        self.tool.UpdateAssemblies()
        writer=STEPCAFControl_Writer();writer.SetNameMode(True);writer.SetColorMode(True)
        if not writer.Transfer(self.doc):raise RuntimeError('Transfer kolorowego STEP nie powiódł się')
        target=Path(path);temporary=target.with_name(target.name+'.tmp')
        try:
            if writer.Write(str(temporary))!=IFSelect_RetDone:raise RuntimeError('Zapis STEP nie powiódł się')
            # Full read-back preserves the rigorous v4.6 diagnostics on smaller
            # models. Very large models can opt into lightweight structural
            # checks to avoid an entire second OpenCascade STEP import.
            verify=os.getenv('DSCOMPARE_STEP_VERIFY','auto').lower()
            if verify not in ('auto','full','fast'):verify='auto'
            do_full=(verify=='full' or verify=='auto' and self.count<=150)
            if do_full:
                diag=inspect_step_colors(str(temporary))
                if diag['bryly_bez_koloru'] or diag['powierzchnie_bez_koloru']:
                    raise RuntimeError('Niepełny zapis kolorów powierzchni STEP')
                if diag['pokolorowane_etykiety']!=self.count:
                    raise RuntimeError('Niepełny zapis elementów STEP')
                if diag['powierzchnie_przezroczyste']!=self.transparent_faces:
                    raise RuntimeError('Niepełny zapis przezroczystości STEP')
                diag['weryfikacja']='pelna_ponowny_import'
            else:
                data=temporary.read_bytes()
                ncol=data.count(b'COLOUR_RGB(')
                nstyle=data.count(b'STYLED_ITEM(')
                nalpha=data.count(b'SURFACE_STYLE_TRANSPARENT(')
                if not ncol or not nstyle or (self.transparent_faces and not nalpha):
                    raise RuntimeError('Wynikowy STEP nie ma oczekiwanych styli koloru/przezroczystości')
                diag={'pokolorowane_etykiety':self.count,
                    'pokolorowane_powierzchnie':None,
                    'powierzchnie_przezroczyste':self.transparent_faces,
                    'rekordy_przezroczystosci_step':nalpha,
                    'rekordy_kolorow_step':ncol,
                    'rekordy_stylow_step':nstyle,
                    'weryfikacja':'szybka_strukturalna_bez_ponownego_importu'}
            diag.update(definicje_unikalne=self.definitions_created,
                ponownie_uzyte_definicje=self.definitions_reused,
                grupowanie_zlozenia=bool(self.group_by_status),
                zapis_alfy_step=self.transparent_faces>0,
                przezroczystosc_w_zw3d='zalezy_od_importera')
            temporary.replace(target)
            return diag
        finally:
            if temporary.exists():temporary.unlink()

def export_colored_step(path: str, records, a_parts, b_parts, colors=None):
    palette={**COLORS,**(colors or {})}
    document=ColoredDocument()
    for number,r in enumerate(records):
        if r.b_index is not None:part=b_parts[r.b_index];model='B'
        elif r.a_index is not None:part=a_parts[r.a_index];model='A'
        else:continue
        document.add(part.shape,f'[{r.status}] [R{number:06d}] {part.name} [{model}]',palette[r.status])
    return document.write(path)


def export_differences_step(path: str, records, a_parts, b_parts,
                            tolerance: float = 0.01, progress=None,
                            max_changed: int = 60, colors: dict | None = None):
    """Second STEP: highlight *only* changed material (A\\B orange, B\\A violet).

    For ADDED/REMOVED include the whole new/old body. For MOVED include
    ghost old + new placement; no ghosts in the main comparison STEP.
    CHANGED requires two real Boolean cuts, executed only for this export.
    """
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
    from OCP.BRepGProp import BRepGProp
    from OCP.GProp import GProp_GProps
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE

    changed = [r for r in records if r.status == 'CHANGED']
    if len(changed) > max_changed:
        raise ValueError(f'Model ma {len(changed)} zmienionych par. Szczegółowa geometria różnic '
                         f'ograniczona do {max_changed}; rozważ porównanie podzłożenia.')

    document=ColoredDocument()
    palette={**COLORS, **(colors or {})}
    added_rgb=tuple(palette['ADDED']); removed_rgb=tuple(palette['REMOVED'])
    n=0; deltas=[]; errors=[]

    def insert(shape, name, rgb):
        nonlocal n
        exp=TopExp_Explorer(shape,TopAbs_SOLID)
        if not exp.More():return 0.0
        props=GProp_GProps();BRepGProp.VolumeProperties_s(shape,props)
        volume=max(0.0,float(props.Mass()))
        if volume <= max(tolerance**3,1e-5):return 0.0
        document.add(shape,name,rgb)
        n+=1
        return volume

    def cut_shape(a,b):
        op=BRepAlgoAPI_Cut(a,b)
        op.SetFuzzyValue(max(tolerance/100.,1e-6))
        op.Build()
        if not op.IsDone():raise RuntimeError('Boolean CUT not completed')
        return op.Shape()

    for num,r in enumerate(records,1):
        old=a_parts[r.a_index] if r.a_index is not None else None
        new=b_parts[r.b_index] if r.b_index is not None else None
        if r.status in ('SAME','RENAMED','UNCERTAIN'):continue
        key=f'{num:04d}'
        if r.status=='ADDED':
            insert(new.shape,key+' NOWA: '+new.name,added_rgb)
        elif r.status=='REMOVED':
            insert(old.shape,key+' USUNIETA: '+old.name,removed_rgb)
        elif r.status=='MOVED':
            insert(old.shape,key+' POPRZEDNIE POLOZENIE: '+old.name,removed_rgb)
            insert(new.shape,key+' NOWE POLOZENIE: '+new.name,tuple(palette['MOVED']))
        elif r.status=='CHANGED':
            if progress:progress(f'Różnice B-Rep {len(deltas)+1}/{len(changed)}: {new.name}')
            try:
                va=insert(cut_shape(old.shape,new.shape),key+' USUNIETY MATERIAL: '+old.name,removed_rgb)
                vb=insert(cut_shape(new.shape,old.shape),key+' DODANY MATERIAL: '+new.name,tuple(palette['CHANGED']))
                deltas.append((old.name,new.name,round(va,5),round(vb,5)))
            except Exception as exc:
                errors.append(f'{new.path}: {exc}')
    if n:
        document.write(path)
    return {'written':n>0,'solids':n,'changes':deltas,'errors':errors}


REVISION_COLORS = {'SAME':(0.12,0.72,0.32), 'MOVED':(0.55,0.30,0.85), 'REMOVED':(1.0,0.38,0.08), 'ADDED':(0.12,0.43,0.95)}

def _export_revision_step(path, records, a_parts, b_parts, colors=None, old_alpha=0.4, progress=None, reuse_definitions=True):
    """Unchanged B once; changed/moved pairs as old A + new B, in world coordinates."""
    palette={**REVISION_COLORS,**(colors or {})}
    document=ColoredDocument(group_by_status=True,reuse_definitions=reuse_definitions)
    roles={'SAME':0,'OLD':0,'NEW':0}
    total=len(records)
    for number,r in enumerate(records):
        if progress and number and number%50==0: progress(f'Kolorowy STEP: przygotowano {number}/{total} pozycji...')
        if r.status in ('SAME','RENAMED'):
            if r.b_index is None:raise ValueError('Brak nowej części dla pozycji bez zmian')
            entries=[(b_parts[r.b_index],'SAME','B',1.0)]
        else:
            entries=[]
            if r.a_index is not None:entries.append((a_parts[r.a_index],'OLD','A',old_alpha))
            if r.b_index is not None:entries.append((b_parts[r.b_index],'NEW','B',1.0))
        for part,role,revision,alpha in entries:
            # Purple is reserved for identical geometry relocated in an unchanged-size group.
            # Its old occurrence is translucent, its new occurrence is opaque.
            key=('MOVED' if r.status=='MOVED' else {'SAME':'SAME','OLD':'REMOVED','NEW':'ADDED'}[role])
            legacy_warning=' [DO_SPRAWDZENIA]' if r.status=='UNCERTAIN' else ''  # legacy direct-export API only
            document.add(part.shape,f'[{r.status}] [R{number:06d}] [{role}] {part.name} [{revision}]{legacy_warning}',palette[key],alpha,group=r.status,revision=revision)
            roles[role]+=1
    if progress:progress(f'Kolorowy STEP: {document.count} wystąpień, {document.definitions_created} definicji; zapis pliku...')
    diag=document.write(path)
    if progress:progress('Kolorowy STEP: zapis oraz kontrola styli zakończone.')
    diag.update(export_style='revision_A_B',roles=roles,old_alpha=old_alpha)
    return diag


def export_revision_step(path, records, a_parts, b_parts, colors=None, old_alpha=0.4, progress=None):
    """Retry a failed shared-definition export without sharing; never weaken verification."""
    import math
    if not math.isfinite(float(old_alpha)) or not 0.0 <= old_alpha <= 1.0:raise ValueError("Nieprawidłowa przezroczystość")
    records=list(records)
    try:
        result=_export_revision_step(path,records,a_parts,b_parts,colors,old_alpha,progress)
        result['tryb_zapisu']='wspoldzielone_definicje'
        return result
    except Exception as first:
        if progress:progress('Eksport współdzielony nie powiódł się: '+str(first)+'. Ponawiam z niezależnymi definicjami części...')
        try:
            result=_export_revision_step(path,records,a_parts,b_parts,colors,old_alpha,progress,reuse_definitions=False)
            result.update(tryb_zapisu='niezalezne_definicje_awaryjne',pierwszy_blad=str(first))
            return result
        except Exception as second:
            raise RuntimeError(f'STEP: zapis współdzielony: {first}; zapis niezależny: {second}') from second
