import json,os
from pathlib import Path
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from dsac29.geometry import describe
from dsac29.compare import Record
from dsac29.step_io import ColoredDocument,export_revision_step

def test_export_retry_preserves_validation_and_groups(tmp_path,monkeypatch):
 original=ColoredDocument.write;attempts=[]
 def fail_shared(self,path):
  attempts.append(self.reuse_definitions)
  if self.reuse_definitions:raise RuntimeError('simulated shared-definition error')
  return original(self,path)
 monkeypatch.setattr(ColoredDocument,'write',fail_shared)
 part=describe(BRepPrimAPI_MakeBox(2,3,4).Shape(),'P','P')
 target=tmp_path/'wynik.step'
 diag=export_revision_step(target,[Record(0,None,'REMOVED','')],[part],[])
 assert attempts==[True,False] and target.exists()
 assert diag['tryb_zapisu']=='niezalezne_definicje_awaryjne'
 assert diag['alfy_powierzchni']==[.4] and diag['grupowanie_zlozenia']
 assert diag['pokolorowane_etykiety']==1 and diag['powierzchnie_bez_koloru']==0

def test_step_exists_before_bom_and_bom_failure_is_reported(tmp_path,monkeypatch):
 from dsac29 import report
 part=describe(BRepPrimAPI_MakeBox(2,3,4).Shape(),'P','P')
 def fail(parts,progress=None):
  assert (tmp_path/'POROWNANIE_KOLORY.step').exists()
  assert (tmp_path/'DIAGNOSTYKA_KOLOROW.json').exists()
  raise RuntimeError('simulated BOM error')
 monkeypatch.setattr(report,'geometry_groups',fail)
 _,error=report.produce(tmp_path,[part],[part],[Record(0,0,'SAME','')],revision_style=True,diff_step=False)
 assert error is None
 summary=json.loads((tmp_path/'PODSUMOWANIE.json').read_text())
 assert summary['step_ready'] and len(summary['bom_warnings'])==2
 assert (tmp_path/'UWAGI_BOM.txt').exists() and (tmp_path/'RAPORT.html').exists()

def test_both_export_failures_leave_explicit_error(tmp_path,monkeypatch):
 from dsac29 import report
 part=describe(BRepPrimAPI_MakeBox(2,3,4).Shape(),'P','P')
 def fail(*args):raise RuntimeError('simulated writer error')
 monkeypatch.setattr(ColoredDocument,'write',fail)
 _,err=report.produce(tmp_path,[part],[part],[Record(0,0,'SAME','')],revision_style=True,diff_step=False)
 assert 'zapis niezależny' in err
 assert not json.loads((tmp_path/'PODSUMOWANIE.json').read_text())['step_ready']
 assert not (tmp_path/'POROWNANIE_KOLORY.step').exists()
 assert 'Traceback' in (tmp_path/'BŁĄD_EKSPORTU_STEP.txt').read_text()

@pytest.mark.parametrize('schema',['AP214IS','AP242DIS'])
def test_large_export_unicode_directory(tmp_path,monkeypatch,schema):
 monkeypatch.setenv('DSCOMPARE_STEP_SCHEMA',schema)
 folder=tmp_path/'Części ramy ąęł';folder.mkdir()
 part=describe(BRepPrimAPI_MakeBox(2,3,4).Shape(),'P','P')
 diag=export_revision_step(folder/'wynik.step',[Record(None,i,'ADDED','') for i in range(151)],[],[part]*151)
 assert diag['pokolorowane_etykiety']==151 and diag['ponownie_uzyte_definicje']==150
 assert diag['weryfikacja']=='szybka_strukturalna_bez_ponownego_importu'

def test_normal_picker_no_quick_menu_and_drop(tmp_path):
 os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
 from PySide6.QtWidgets import QApplication,QFileDialog,QPushButton,QLineEdit
 from PySide6.QtCore import QTimer,QMimeData,QUrl
 from dsac29.gui46 import Window
 app=QApplication.instance() or QApplication([]);w=Window();seen=[]
 sample=Path(__file__).resolve().parents[1]/'samples/MODEL_A.step'
 def choose():
  for d in app.topLevelWidgets():
   if isinstance(d,QFileDialog):
    seen.append(d.testOption(QFileDialog.DontUseNativeDialog));d.findChild(QLineEdit,"fileNameEdit").setText(str(sample));QTimer.singleShot(200,d.accept);QTimer.singleShot(2000,d.reject)
 QTimer.singleShot(200,choose);w.a.choose()
 assert seen==[True] and Path(w.a.path.text())==sample
 assert not hasattr(w.a,'quick_menu')
 assert not any('Szybki' in b.text() for b in w.findChildren(QPushButton))
 mime=QMimeData();mime.setUrls([QUrl.fromLocalFile(str(sample))]);assert w.b.drop_path(mime)==str(sample)
 w.close()
