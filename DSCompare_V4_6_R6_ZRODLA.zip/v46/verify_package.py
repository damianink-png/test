"""Windows CI: verify the actual frozen EXE and DLL, not only source code."""
import json,os,subprocess,sys,ctypes
from pathlib import Path
out=Path(sys.argv[1]).resolve();exe=out/'DSCompareV3.exe'
checks=out/'WERYFIKACJA';checks.mkdir(exist_ok=True)
env=dict(os.environ,QT_QPA_PLATFORM='offscreen')
def run(args):
 p=subprocess.run([str(exe),*map(str,args)],env=env,timeout=180)
 assert p.returncode==0,(args,p.returncode)
for schema in ('AP214IS','AP242DIS'):
 folder=checks/schema
 run(['--worker','compare','--a',out/'samples/MODEL_A.step','--b',out/'samples/MODEL_B.step','--output',folder,'--generate-step','--revision-style','--thumbnails','--old-alpha','.4','--schema',schema])
 diag=json.loads((folder/'DIAGNOSTYKA_KOLOROW.json').read_text(encoding='utf-8'))
 result=json.loads((folder/'_WYNIK_V37.json').read_text(encoding='utf-8'))
 assert (folder/'MINIATURA_A.json').exists() and (folder/'MINIATURA_B.json').exists()
 assert result['ok'] and result['blad_step'] is None
 assert diag['pokolorowane_etykiety']==7 and diag['powierzchnie_bez_koloru']==0
 assert diag['roles']=={'SAME':1,'OLD':3,'NEW':3} and diag['alfy_powierzchni']==[.4,1.]
 assert diag['grupowanie_zlozenia'] and b'01_BEZ_ZMIAN' in (folder/'POROWNANIE_KOLORY.step').read_bytes()
 assert diag['powierzchnie_przezroczyste']>0 and not list(folder.glob('SCENA*'))
run(['--worker','mass','--input',out/'samples/MODEL_A.step','--output',checks/'MASA','--no-preview'])
assert (checks/'MASA/MASY_CZESCI.csv').exists() and not list((checks/'MASA').glob('SCENA*'))
run(['--smoke-test-ui',checks/'GUI'])
run(['--smoke-test-interactions',checks/'INTERAKCJE'])
ui=json.loads((checks/'GUI/UI_OK.json').read_text())
assert ui=={'version':'4.6 R6','pages':3,'icons':3,'themes':2,'toggle':'PASS'}
bridge=ctypes.WinDLL(str(out/'DSAssemblyCompare2019.dll'))
for symbol in ('DSAssemblyCompare2019Init','DSAssemblyCompare2019Exit'):assert getattr(bridge,symbol)
(checks/'TESTY_GOTOWEGO_PROGRAMU.json').write_text(json.dumps({'version':'4.6 R6','packaged_compare':'PASS','AP214_AP242_colors_transparency':'PASS','packaged_mass':'PASS','packaged_gui':'PASS','file_picker_and_compare_click':'PASS','dll_load_and_exports':'PASS','ZW3D_runtime':'NOT_TESTED'},indent=2),encoding='utf-8')
print('Frozen EXE, revision STEP, mass, three-page GUI and DLL load: PASS')
