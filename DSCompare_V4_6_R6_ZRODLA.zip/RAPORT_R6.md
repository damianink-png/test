# DS Compare 4.6 R6 — raport

DS Compare 4.6 R6 — eksport STEP i wybór plików

Baza: źródła DSCompare_V4_6_R5_ZRODLA.zip z rozmowy „Kompilacja DS Compare ZIP”.
Zachowano grupy złożeń, klasyfikację R4/R5, optymalizację współdzielonych definicji,
motyw jasny/grafitowy, przełącznik słońce/księżyc, pusty start, trzy zakładki.

ZMIANY R6
- Usunięto przyciski Szybki dostęp i odwołania do ulubionych folderów pulpitu.
- Wybierz plik otwiera zwykły dialog wyboru pliku STEP/STP. Można też przeciągać pliki.
  Zachowano dialog Qt zamiast Windows Shell z powodu wcześniejszych awarii R2.
- Wyraźna nazwa pliku, pełna ścieżka w polu i podpowiedzi, czytelny stan STEP.
- Kolorowy STEP i jego diagnostyka są zapisywane PRZED grupowaniem BOM.
- Błąd BOM nie blokuje modelu: raport zastępczy pokazuje osobno każde wystąpienie
  oraz wyraźne ostrzeżenie UWAGI_BOM.txt. Nie udaje poprawnego grupowania.
- Nieudany eksport współdzielony jest ponawiany z niezależnymi definicjami części,
  z tym samym schematem, grupami, kolorami, alpha i kryteriami weryfikacji.
- STEP staje się dostępny po zapisie i kontroli, jeszcze przed końcem raportu.
- Nieudany zapis nie jest pokazywany jako STEP gotowy. BŁĄD_EKSPORTU_STEP.txt
  zawiera pełny traceback, a DIAGNOSTYKA_KOLOROW.json podaje użyty tryb zapisu.

WAŻNE DLA DIAGNOSTYKI
Na małym przykładzie oryginalna R5 tworzyła STEP poprawnie. Bez plików i logu z
nieudanego uruchomienia nie potwierdzono konkretnej przyczyny problemu użytkownika.
R6 usuwa wykryte punkty blokowania i dodaje kontrolowany zapis awaryjny.
Jeżeli problem powtórzy się na Twoim złożeniu, prześlij z folderu wyników:
BŁĄD_EKSPORTU_STEP.txt, _POSTEP_V37.jsonl, _WYNIK_V37.json i PODSUMOWANIE.json
(te, które powstały). Logi aplikacji: %LOCALAPPDATA%/DSCompare/logs.

131 testów regresji i nowych przypadków PASS. Testy wyboru pliku oraz analizy
przez QProcess i przycisk GUI PASS. Lokalnie Linux, OpenCascade, Qt offscreen.
Dla >150 wystąpień pozostawiono tryb szybkiej kontroli strukturalnej R5, nie pełny
ponowny import; szczegóły w diagnostyce. Nie potwierdzono importu w samym ZW3D.
Workflow Windows kompiluje EXE + DLL i testuje gotowy program; nie uruchomiono
kompilacji GitHub ani testów Windows/ZW3D w tej sesji.

Testy: 131 passed in 10.27s. Sześć nowych przypadków: ponowienie zapisu, błąd BOM, obie próby zapisu nieudane, AP214/AP242 z 151 wystąpieniami i polską ścieżką, wybór pliku + drag/drop bez szybkiego menu.

Sprawdzono obie strony motywów oraz rzeczywistą ścieżkę: dialog → przycisk porównania → proces → gotowy STEP. Nie deklarujemy ustalenia przyczyny nieudanego eksportu na nieudostępnionych danych użytkownika.
