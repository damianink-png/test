#pragma once
#include <math.h>
#include <stdio.h>
#include <string.h>
struct Vec { double x,y,z; };
static Vec vadd(Vec a,Vec b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
static Vec vsub(Vec a,Vec b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
static Vec vmul(Vec a,double t){return {a.x*t,a.y*t,a.z*t};}
static double dot(Vec a,Vec b){return a.x*b.x+a.y*b.y+a.z*b.z;}
static Vec cross(Vec a,Vec b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
static double length(Vec a){return sqrt(dot(a,a));}
static Vec unit(Vec a){return vmul(a,1.0/length(a));}
struct Config {
 double L,W,H,nose,tail,holeZ,holeD,angleMin,angleTarget,angleMax;
 double profile,wall,post,postWall,tubeD,tubeWall,gap;
 double blockX,blockY,blockZ;
 int assembly,pick;
 char fit[12];
};
static Config defaults(){Config c={2600,190,390,800,300,240,21,30,42,60,40,2,30,2,25,1.5,2,64,5,40,1,0,"H7"};return c;}
enum Kind {PROFILE,TUBE,BLOCK};
struct Member {char name[32];Kind kind;Vec a,b;double width,depth,wall;int group;bool hole;Vec sectionX;};
struct Plan {Member m[1800];int count,fields;double angle,pitch,mainLen;};
static bool add(Plan&p,const char*prefix,Kind k,Vec a,Vec b,double w,double d,double t,int group){
 if(p.count>=1800||length(vsub(b,a))<.01)return false;
 Member&m=p.m[p.count++];snprintf(m.name,sizeof(m.name),"%s_%03d",prefix,p.count);m.kind=k;m.a=a;m.b=b;m.width=w;m.depth=d;m.wall=t;m.group=group;m.hole=false;m.sectionX={0,0,0};return true;
}
static bool configValid(const Config&c,char*err){
 const double vals[]={c.L,c.W,c.H,c.nose,c.tail,c.holeZ,c.holeD,c.angleMin,c.angleTarget,c.angleMax,c.profile,c.wall,c.post,c.postWall,c.tubeD,c.tubeWall,c.gap,c.blockX,c.blockY,c.blockZ};
 for(double v:vals)if(!isfinite(v)){strcpy(err,"Parametry musza byc skonczonymi liczbami.");return false;}
 if(c.L<300||c.L>20000||c.W>3000||c.H>3000||c.W<50||c.H<100||c.nose<100||c.nose>c.L-100||c.tail<0||c.tail>c.L){strcpy(err,"Sprawdz gabaryty, dlugosc koncowki i wysuniecie tylne.");return false;}
 if(c.profile<20||c.profile>100||c.wall<1||c.wall>=c.profile/2){strcpy(err,"Nieprawidlowy profil lub grubosc scianki.");return false;}
 if(c.tubeD<10||c.tubeD>60||c.tubeWall<.5||c.tubeWall>=c.tubeD/2){strcpy(err,"Nieprawidlowa rura.");return false;}
 if(c.W<2*c.profile+2*c.blockY+30||c.H<=2*c.profile+2*c.blockY+60){strcpy(err,"Za male gabaryty.");return false;}
 if(c.gap<0||c.gap>20){strcpy(err,"Odstep rur musi byc w zakresie 0..20 mm.");return false;}
 if(c.angleMin<10||c.angleMax>75||c.angleMin>c.angleTarget||c.angleTarget>c.angleMax){strcpy(err,"Nieprawidlowy zakres katow.");return false;}
 if(c.blockY<2||c.blockY>10||c.blockX<c.holeD+12||c.blockX>150||c.blockZ<c.holeD+12||c.blockZ>c.profile+10||c.holeD<3||c.holeD>c.profile-8){strcpy(err,"Sprawdz nakladki i srednice otworu.");return false;}
 if(c.holeZ<c.profile||c.holeZ>c.H-c.profile){strcpy(err,"Os otworu poza dopuszczalna wysokoscia.");return false;}
 return true;
}
// Extend the circular end past its support plane so the whole end can be trimmed.
static double trimAllowance(Vec axis,Vec planeNormal,double radius){
 double c=fabs(dot(unit(axis),unit(planeNormal)));
 if(c<1e-4)c=1e-4;
 return radius*sqrt(fmax(0,1-c*c))/c+2.0/c;
}
static void extendTube(Member&m,Vec firstNormal,Vec lastNormal){
 Vec axis=unit(vsub(m.b,m.a));double a=trimAllowance(axis,firstNormal,m.width/2),b=trimAllowance(axis,lastNormal,m.width/2);
 m.a=vsub(m.a,vmul(axis,a));m.b=vadd(m.b,vmul(axis,b));
}
static bool makePlan(const Config&c,Plan&p,char*err){
 p.count=0;if(!configValid(c,err))return false;
 const double P=c.profile,D=c.tubeD,T=c.blockY,main=c.L-c.nose;
 const double side=(c.W-2*T-P)/2,lo=P/2,hi=c.H-2*T-P/2,rise=hi-lo-P;
 const double first=main*(160.0/1800),last=main-P/2;
 const double endHigh=hi-P/2-D-c.gap;
 const double nosePostZ=P+D/2+c.gap;
 const double endLow=fmax(P+D+c.gap,nosePostZ+(D+c.gap)*sqrt(1+pow((endHigh-nosePostZ)/(2*side),2))+2);
 if(endHigh<=endLow||nosePostZ>hi-P/2-D-c.gap){strcpy(err,"Za mala wysokosc na odstep krzyzulca czolowego od rur nosa.");return false;}
 const double inset=fmax(90.0*main/1800,D+c.gap+P/2);
 int best=0;double score=1e9;
 for(int n=1;n<=80;n++){double pitch=(last-first)/n,run=pitch-2*inset;
 if(run<=D*2)continue;double ang=atan2(rise,run)*180/3.141592653589793;
 if(ang<c.angleMin||ang>c.angleMax)continue;if(fabs(ang-c.angleTarget)<score){best=n;score=fabs(ang-c.angleTarget);p.angle=ang;}}
 if(!best){strcpy(err,"Brak funkcjonalnego podzialu pol w zadanym zakresie katow.");return false;}
 p.fields=best;p.mainLen=main;p.pitch=(last-first)/best;
 for(int s=-1;s<=1;s+=2){
 add(p,"PAS_DOL",PROFILE,{0,s*side,lo},{main,s*side,lo},P,P,c.wall,0);
 add(p,"PAS_GORA",PROFILE,{-c.tail,s*side,hi},{main,s*side,hi},P,P,c.wall,0);}
 add(p,"POPRZECZKA_NOS",PROFILE,{last,-side+P/2,hi},{last,side-P/2,hi},P,P,c.wall,0);
 // Nose top profile lifted so its top face aligns with the upper main profile after vertical trimming.
 Vec start={main-P*0.75,0,hi+P*0.5},end={c.L+P*1.2,0,c.holeZ-P*1.2*(hi-c.holeZ)/c.nose};
 add(p,"NOS_GORA",PROFILE,start,end,P,P,c.wall,0);p.m[p.count-1].hole=true;
 Vec along=unit(vsub(end,start));
 for(int s=-1;s<=1;s+=2){
 add(p,"NAKLADKA_OTWOR",PROFILE,{c.L,s*(P/2+T/2)-T/2,c.holeZ},{c.L,s*(P/2+T/2)+T/2,c.holeZ},c.blockX,c.blockZ,0,1);
 Member&m=p.m[p.count-1];m.kind=BLOCK;m.sectionX=along;m.hole=true;
 }
 // Automatic L-shaped support plates, two separate flat plates per support.
 for(int top=0;top<2;top++)for(int j=0;j<2;j++)for(int s=-1;s<=1;s+=2){
 double len=top&&j==0?120:180;
 double x=top?(j==0?-c.tail+len/2:main*.50556):(j==0?main*.29444:main-len/2);
 double z=top?hi+P/2+T/2:-T/2;
 add(p,"PODKLADKA",BLOCK,{x,s*side,z-T/2},{x,s*side,z+T/2},len,P,0,1);
 double zs=top?hi+T/2:lo-T/2;
 add(p,"NAKLADKA_BOK",BLOCK,{x,s*(side+P/2+T/2),zs-(P+T)/2},{x,s*(side+P/2+T/2),zs+(P+T)/2},len,T,0,1);
 }
 for(int i=0;i<=best;i++){
 double x=first+i*p.pitch;
 for(int s=-1;s<=1;s+=2)add(p,"SLUPEK_RURA",TUBE,{x,s*side,P},{x,s*side,hi-P/2},D,D,c.tubeWall,0);
 }
 // Reserve an X separation from the full plate envelopes, including the untrimmed
 // tube circular end and its axial trimming allowance. Solve the attachment station.
 const double plateFront=c.L-(c.blockX*fabs(along.x)+c.blockZ*fabs(along.z))/2;
 const double plateGap=fmax(c.gap,D/2);
 double contactMin=last+P,contactMax=plateFront-plateGap;
 Vec normal={-along.z,0,along.x};
 auto noseEnd=[&](double x){return Vec{x,D/2+c.gap+4,hi+(x-main)*along.z/along.x-P/(2*along.x)};};
 auto endEnvelopeX=[&](double x){Vec b=noseEnd(x),a={last,side,nosePostZ};Vec axis=unit(vsub(b,a));return x+axis.x*trimAllowance(axis,normal,D/2)+(D/2)*sqrt(fmax(0,1-axis.x*axis.x));};
 if(contactMin>=contactMax||endEnvelopeX(contactMin)>plateFront-plateGap){strcpy(err,"Koncowka za krotka na mocowanie rur przed plytkami otworu.");return false;}
 for(int k=0;k<60;k++){double mid=(contactMin+contactMax)/2;if(endEnvelopeX(mid)<=plateFront-plateGap)contactMin=mid;else contactMax=mid;}
 const Vec safeEnd=noseEnd(contactMin-.01);
 for(int s=-1;s<=1;s+=2){
 if(c.tail>D)add(p,"ZASTRZAL_TYL",TUBE,{-c.tail+P*1.7,s*side,hi-P/2},{first*.42,s*side,P},D,D,c.tubeWall,3);
 add(p,"NOS_DOL",TUBE,{last+P*0.15,s*side,nosePostZ},{safeEnd.x,s*safeEnd.y,safeEnd.z},D,D,c.tubeWall,3);
 }
 for(int i=0;i<best;i++){
 double xa=first+i*p.pitch+inset,xb=first+(i+1)*p.pitch-inset;
 for(int s=-1;s<=1;s+=2){bool up=(i%2==0)==(s==-1);
 add(p,"KRZYZULEC_BOK",TUBE,{xa,s*side,up?P:hi-P/2},{xb,s*side,up?hi-P/2:P},D,D,c.tubeWall,3);}

 // Separate side/horizontal weld zones and reserve room for the full circular end.
 double span=2*side-P;
 double hinset=fmax(inset+D+c.gap,(D+c.gap+2+(D/2)*p.pitch/span)/(1+D/span));
 if(2*hinset>=p.pitch-D){strcpy(err,"Pole za krotkie na krzyzulce i wymagany odstep.");return false;}
 double hx0=first+i*p.pitch+hinset,hx1=first+(i+1)*p.pitch-hinset;
 for(int z=0;z<2;z++){bool forward=(i%2==0)==(z==0);
 add(p,"KRZYZULEC_POZIOM",TUBE,{hx0,forward?-side+P/2:side-P/2,z?hi:lo},{hx1,forward?side-P/2:-side+P/2,z?hi:lo},D,D,c.tubeWall,3);}
 }
 add(p,"POPRZECZKA_TYL",TUBE,{-c.tail+P*.75,-side+P/2,hi},{-c.tail+P*.75,side-P/2,hi},D,D,c.tubeWall,3);
 for(int i=0;i<=best;i++)for(int z=0;z<2;z++){
 if(i==best&&z==1)continue;
 double x=first+i*p.pitch;if(i==0&&z==0)x=first*.625;
 add(p,"POPRZECZKA_RURA",TUBE,{x,-side+P/2,z?hi:lo},{x,side-P/2,z?hi:lo},D,D,c.tubeWall,3);
 }
 // End brace joins the two round posts. Endpoints are inside their solid envelopes;
 // the native cylindrical trim must remove the surplus, not a square-rail trim.

 add(p,"KRZYZULEC_CZOLO",TUBE,{last,-side,endLow},{last,side,endHigh},D,D,c.tubeWall,3);
 for(int i=0;i<p.count;i++){Member&m=p.m[i];if(m.kind!=TUBE)continue;
 if(strncmp(m.name,"KRZYZULEC_BOK",strlen("KRZYZULEC_BOK"))==0||strncmp(m.name,"ZASTRZAL_TYL",strlen("ZASTRZAL_TYL"))==0)extendTube(m,{0,0,1},{0,0,1});
 else if(strncmp(m.name,"KRZYZULEC_POZIOM",strlen("KRZYZULEC_POZIOM"))==0)extendTube(m,{0,1,0},{0,1,0});
 else if(strncmp(m.name,"NOS_DOL",7)==0){Vec axis=unit(vsub(m.b,m.a));m.b=vadd(m.b,vmul(axis,trimAllowance(axis,{-along.z,0,along.x},m.width/2)));}
 }
 return true;
}
// Cross-section orientation: local Z along member; local X stays as close to world Y as possible.
static void memberFrame(const Member&m,Vec&u,Vec&v,Vec&w){
 if(length(m.sectionX)>.5){w=unit(vsub(m.b,m.a));u=unit(m.sectionX);v=cross(w,u);return;}
 if(m.kind==BLOCK){u={1,0,0};v={0,1,0};w={0,0,1};return;}
 w=unit(vsub(m.b,m.a));Vec ref=fabs(w.y)<.9?Vec{0,1,0}:Vec{1,0,0};u=unit(vsub(ref,vmul(w,dot(ref,w))));v=cross(w,u);}

// Exact AABB of the uncut primitive; cutting can only shrink it.
struct MemberBounds {Vec lo,hi;};
static MemberBounds plannedBounds(const Member&m){
 Vec u,v,w;memberFrame(m,u,v,w);Vec ext;
 if(m.kind==TUBE){double r=m.width/2;ext={r*sqrt(fmax(0,1-w.x*w.x)),r*sqrt(fmax(0,1-w.y*w.y)),r*sqrt(fmax(0,1-w.z*w.z))};}
 else ext={fabs(u.x)*m.width/2+fabs(v.x)*m.depth/2,fabs(u.y)*m.width/2+fabs(v.y)*m.depth/2,fabs(u.z)*m.width/2+fabs(v.z)*m.depth/2};
 return {{fmin(m.a.x,m.b.x)-ext.x,fmin(m.a.y,m.b.y)-ext.y,fmin(m.a.z,m.b.z)-ext.z},
         {fmax(m.a.x,m.b.x)+ext.x,fmax(m.a.y,m.b.y)+ext.y,fmax(m.a.z,m.b.z)+ext.z}};
}
static bool plannedMaterialOverlap(const Member&a,const Member&b){
 MemberBounds x=plannedBounds(a),y=plannedBounds(b);const double t=1e-5;
 return fmin(x.hi.x,y.hi.x)-fmax(x.lo.x,y.lo.x)>t&&fmin(x.hi.y,y.hi.y)-fmax(x.lo.y,y.lo.y)>t&&fmin(x.hi.z,y.hi.z)-fmax(x.lo.z,y.lo.z)>t;
}

struct PlatePoint {double y,z;};
static int clipPlate(PlatePoint*pts,int count,double yc,double zc,int sy,int sz,double size){
 PlatePoint out[12];int n=0;
 for(int i=0;i<count;i++){
  PlatePoint a=pts[i],b=pts[(i+1)%count];
  double da=sy*(a.y-yc)+sz*(a.z-zc)+size,db=sy*(b.y-yc)+sz*(b.z-zc)+size;
  if(da<=1e-10)out[n++]=a;
  if((da<0&&db>0)||(da>0&&db<0)){double t=da/(da-db);out[n++]={a.y+t*(b.y-a.y),a.z+t*(b.z-a.z)};}
 }
 for(int i=0;i<n;i++)pts[i]=out[i];return n;
}
static int platePolygon(const Config&c,const Member&m,PlatePoint*pts){
 double y=m.a.y,z0=m.a.z,z1=m.b.z,T=m.depth;int side=y<0?-1:1;bool top=z0>c.H/2;
 pts[0]={y-T/2,z0};pts[1]={y+T/2,z0};pts[2]={y+T/2,z1};pts[3]={y-T/2,z1};int n=4;
 if(strncmp(m.name,"PODKLADKA",9)==0)n=clipPlate(pts,n,y-side*T/2,top?z1:z0,-side,top?1:-1,1);
 else if(strncmp(m.name,"NAKLADKA_BOK",11)==0){
  n=clipPlate(pts,n,y-side*T/2,top?z1:z0,-side,top?1:-1,c.blockY-1);
  n=clipPlate(pts,n,y+side*T/2,top?z0:z1,side,top?-1:1,1);
 }
 return n;
}
