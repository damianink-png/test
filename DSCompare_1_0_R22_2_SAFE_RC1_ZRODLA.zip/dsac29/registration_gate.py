"""Fast world-coordinate consensus with bounded B-Rep verification."""
from collections import defaultdict
from itertools import product
from math import floor
import numpy as np
from .geometry import signature,candidate,equivalent_world
from . import trace_r22 as trace

def frame_support(a,b,tolerance,proofs=8,verify_all=False,progress=None,cancelled=None):
 from .step_reexport_tolerance import coarse_candidate,reexport_equivalent_world
 from .geometry_registry import GeometryRegistry
 from .compare import _relative_location_is_same,Cancelled
 registry=GeometryRegistry();anchors={}
 def proven(i,j):
  left,right=a[i],b[j]
  if left.shape.IsSame(right.shape):return True
  key=(registry.definition(left),registry.definition(right));old=anchors.get(key)
  if old and _relative_location_is_same(left,a[old[0]],right,b[old[1]],tolerance):return True
  same=trace.brep_call('verify_reexport',i,j,reexport_equivalent_world,left,right,tolerance,allow_boolean=False)
  if not same:same=trace.brep_call('verify_world',i,j,equivalent_world,left,right,tolerance)
  if same:anchors.setdefault(key,(i,j))
  return same
 if not a or not b:return dict(count=0,ratio=0.,proofs=0,checked=0,pairs=[])
 tol=max(tolerance,1.e-6);cell_size=max(tol*2,.002)
 buckets=defaultdict(list)
 for i,part in enumerate(a):
  pos=tuple(floor(float(v)/cell_size) for v in part.center)
  buckets[pos].append(i)
 occupied=set();pairs=[]
 for j,part in enumerate(b):
  if cancelled and cancelled():raise Cancelled('Przerwano analizę')
  if progress and j%25==0:progress(f'Weryfikacja przesunięcia B-Rep: {j}/{len(b)}; potwierdzono {len(pairs)}')
  pos=np.asarray(part.center)
  base=tuple(floor(float(v)/cell_size) for v in pos)
  found=None
  for steps in product((-1,0,1),repeat=3):
   loc=tuple(x+y for x,y in zip(base,steps))
   for i in buckets.get(loc,()):
    if i in occupied:continue
    if np.linalg.norm(a[i].center-pos)>tol or not (candidate(a[i],part,tol) or coarse_candidate(a[i],part,tol)):continue
    if verify_all and not proven(i,j):continue
    found=i;break
   if found is not None:break
  if found is not None:occupied.add(found);pairs.append((found,j))
 if not pairs:return dict(count=0,ratio=0.,proofs=0,checked=0,pairs=[])
 if verify_all:return dict(count=len(pairs),ratio=len(pairs)/max(1,min(len(a),len(b))),proofs=len(pairs),checked=len(pairs),pairs=pairs)
 n=min(proofs,len(pairs))
 selection=[pairs[k*(len(pairs)-1)//max(1,n-1)] for k in range(n)]
 confirmed=sum(bool(proven(i,j)) for i,j in selection)
 return dict(count=len(pairs),ratio=len(pairs)/max(1,min(len(a),len(b))),
             proofs=confirmed,checked=n)

def already_world_aligned(a,b,tolerance):
 r=frame_support(a,b,tolerance)
 return (r['ratio']>=.55 and r['proofs']==r['checked'] and
         r['checked']>=min(2,min(len(a),len(b))))


def original_frame_fastpath(a,b,tolerance,initial=None,progress=None):
    """Decide whether a verified shared CAD world frame can skip registration.

    A matching *subset* is sufficient if independent B-Rep samples agree,
    PROVIDED no stronger whole-assembly translation is suggested by the
    unchanged geometric definitions. No native geometry is moved here.

    Descriptor/centroid votes are only a cheap NEGATIVE gate; a nonzero
    translation is never accepted from these votes. That still requires
    align_assembly() and world B-Rep validation + user approval.
    """
    from collections import defaultdict,Counter
    from .compare import _spatial_index,_nearby
    from types import SimpleNamespace
    if initial is None:
        initial=frame_support(a,b,tolerance,proofs=8)
    population=min(len(a),len(b))
    if population==0:return False,'Brak brył'
    required=min(population,max(2,__import__('math').ceil(.35*population)))
    if (initial['count']<required or initial['checked']<min(2,population)
            or initial['proofs']!=initial['checked']):
        return False,f'Potwierdzono tylko {initial["count"]}/{population} pozycji'

    # A source exported one pitch away can overlap n-1 of n repeated
    # components. Detect that cheaply via centroid votes of equally sized
    # shape cohorts, then compare the number of placement candidates.
    sig_a=defaultdict(list);sig_b=defaultdict(list)
    for i,part in enumerate(a):sig_a[signature(part)].append(i)
    for i,part in enumerate(b):sig_b[signature(part)].append(i)
    possible=Counter();representatives={}
    threshold=max(.01,tolerance)
    for key in sig_a.keys() & sig_b.keys():
        ia,ib=sig_a[key],sig_b[key]
        if len(ia)!=len(ib):continue
        # Using centroids of SAME-MULTIPLICITY shape cohorts avoids a shift
        # estimate biased by changed parts which appear only in one revision.
        offset=(np.mean([a[i].center for i in ia],axis=0)
                -np.mean([b[i].center for i in ib],axis=0))
        if np.linalg.norm(offset)<=tolerance:continue
        k=tuple(int(round(float(c)/threshold)) for c in offset)
        possible[k]+=len(ia)
        representatives[k]=offset
    if possible:
        cell_size=max(tolerance,1.e-6)
        idx=_spatial_index(a,range(len(a)),cell_size)
        # Do not evaluate hundreds of candidates. Few high-support cohort
        # translations are sufficient as a veto, not proof of registration.
        for key,weight in possible.most_common(8):
            if weight<max(2,int(.04*population)):continue
            offset=representatives[key]
            used=set();votes=0
            for part in b:
                c=part.center+offset
                for i in _nearby(idx,SimpleNamespace(center=c),cell_size):
                    if i in used or np.linalg.norm(a[i].center-c)>tolerance:
                        continue
                    if signature(a[i])!=signature(part):continue
                    if not candidate(a[i],part,tolerance):continue
                    used.add(i);votes+=1;break
            if votes>initial['count']:
                if progress:progress(
                    f'Wstępna analiza: wykryto możliwe lepsze przesunięcie '
                    f'({votes} zamiast {initial["count"]} brył); pełna weryfikacja B-Rep.')
                return False,'Podejrzenie globalnego przesunięcia'
    if progress:progress(
        f'Wstępna analiza: potwierdzono {initial["count"]}/{population} brył '
        'w obecnym układzie CAD; pomijam szukanie przesunięcia.')
    return True,'Zgodność obecnego układu potwierdzona próbką B-Rep; brak lepszego przesunięcia'
