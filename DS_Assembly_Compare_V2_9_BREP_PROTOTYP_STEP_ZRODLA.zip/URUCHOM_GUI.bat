@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Przygotowuje srodowisko Python 3.11 x64 w tym folderze...
 py -3.11 -m venv .venv
 if errorlevel 1 (
   echo BLAD: Brak Python 3.11 x64. Zainstaluj go dla biezacego uzytkownika.
   pause
   exit /b 1
 )
)
".venv\Scripts\python.exe" -c "import OCP,numpy" >nul 2>&1
if errorlevel 1 (
 echo Pobieram silnik Open CASCADE i numpy (pierwszy start wymaga Internetu)...
 ".venv\Scripts\python.exe" -m pip install --prefer-binary -r requirements.txt
 if errorlevel 1 (
   echo BLAD INSTALACJI. Sprawdz dostep do Internetu.
   pause
   exit /b 1
 )
)
".venv\Scripts\python.exe" URUCHOM_GUI.py
if errorlevel 1 (
 echo Program zakonczyl sie z bledem.
 pause
)
endlocal
