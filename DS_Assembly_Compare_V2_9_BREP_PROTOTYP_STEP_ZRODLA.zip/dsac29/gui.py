"""Separate STEP B-Rep analyzer window: runs in its own process, not inside ZW3D."""
import queue,threading,tkinter as tk
from tkinter import ttk,filedialog,messagebox,colorchooser
from pathlib import Path
import traceback,webbrowser
from .cli import process
from .step_io import COLORS

class GUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('DS Assembly Compare V2.9 — B-Rep STEP / prototyp')
        self.geometry('790x640');self.minsize(720,560)
        self.q=queue.Queue();self.stop=False;self.running=False
        self.a=tk.StringVar();self.b=tk.StringVar()
        self.folder=tk.StringVar(value=str(Path.home()/'Documents'/'DSAC_V29_WYNIKI'))
        self.tolerance=tk.StringVar(value='0.01');self.density=tk.StringVar(value='7850')
        self.step=tk.BooleanVar(value=True)
        self._build();self.after(150,self.poll)

    def _build(self):
        pad=ttk.Frame(self,padding=16);pad.pack(fill='both',expand=True)
        ttk.Label(pad,text='DS Assembly Compare V2.9 — B-Rep STEP',font=('Segoe UI',17,'bold')).pack(anchor='w')
        ttk.Label(pad,text='Dwa pliki STEP/STP → dokładna analiza brył → model STEP w kolorach i raport',foreground='#59677b').pack(anchor='w',pady=(0,15))
        for label,var,isdir in [('Model A — poprzedni',self.a,False),('Model B — aktualny',self.b,False),('Folder wynikowy',self.folder,True)]:
            line=ttk.Frame(pad);line.pack(fill='x',pady=4)
            ttk.Label(line,text=label,width=26).pack(side='left')
            ttk.Entry(line,textvariable=var).pack(side='left',fill='x',expand=True,padx=7)
            def pick(v=var,d=isdir):
                chosen=filedialog.askdirectory() if d else filedialog.askopenfilename(filetypes=[('STEP / STP','*.step *.stp'),('Wszystkie','*.*')])
                if chosen:v.set(chosen)
            ttk.Button(line,text='Wybierz…',command=pick).pack(side='left')
        cfg=ttk.Frame(pad);cfg.pack(fill='x',pady=(16,7))
        ttk.Label(cfg,text='Tolerancja [mm]:').pack(side='left')
        ttk.Entry(cfg,width=8,textvariable=self.tolerance).pack(side='left',padx=(7,30))
        ttk.Label(cfg,text='Gęstość [kg/m³]:').pack(side='left')
        ttk.Entry(cfg,width=10,textvariable=self.density).pack(side='left',padx=7)
        ttk.Checkbutton(pad,text='Zapisz kolorowy model porównawczy STEP',variable=self.step).pack(anchor='w')
        leg=ttk.LabelFrame(pad,text='Legenda modelu wynikowego (kolory można zmienić)',padding=10);leg.pack(fill='x',pady=13)
        for key,name in [('SAME','Bez zmian / nowa nazwa'),('ADDED','Nowy / zmodyfikowany'),('REMOVED','Usunięty'),('UNCERTAIN','Niepewny')]:
            c=COLORS[key]
            rgb='#%02x%02x%02x'%tuple(int(z*255) for z in c)
            bar=tk.Frame(leg);bar.pack(side='left',padx=9)
            btn=tk.Button(bar,bg=rgb,width=3,height=1,relief='solid',command=lambda k=key:self.choose_color(k))
            btn.pack(side='left',padx=5)
            ttk.Label(bar,text=name).pack(side='left')
            setattr(self,'color_btn_'+key,btn)
        ttk.Label(pad,text='Uwaga: na tym etapie Z3 należy wyeksportować z ZW3D do STEP. Kolory STEP mogą zależeć od ustawień importu ZW3D.',wraplength=750).pack(anchor='w')
        actions=ttk.Frame(pad);actions.pack(fill='x',pady=(10,6))
        self.go=ttk.Button(actions,text='PORÓWNAJ B-REP',command=self.start);self.go.pack(side='left')
        self.abort=ttk.Button(actions,text='Anuluj',command=self.cancel,state='disabled');self.abort.pack(side='left',padx=8)
        ttk.Button(actions,text='Otwórz folder',command=self.open_folder).pack(side='right')
        self.status=ttk.Label(pad,text='Gotowy do porównania.');self.status.pack(anchor='w',pady=5)
        self.gauge=ttk.Progressbar(pad,mode='indeterminate');self.gauge.pack(fill='x')
        self.log=tk.Text(pad,height=13,wrap='word');self.log.pack(fill='both',expand=True,pady=8)

    def choose_color(self,key):
        rgb=colorchooser.askcolor(title='Wybierz kolor: '+key)
        if rgb and rgb[0]:
            color=tuple(round(v/255,5) for v in rgb[0])
            if key=='SAME':COLORS.update({'SAME':color,'RENAMED':color})
            elif key=='ADDED':COLORS.update({'ADDED':color,'CHANGED':color,'MOVED':color})
            else:COLORS[key]=color
            getattr(self,'color_btn_'+key).configure(bg=rgb[1])
    def cancel(self):
        self.stop=True;self.q.put(('msg','Żądanie anulowania — oczekiwanie na zakończenie bieżącej operacji OCCT...'))
    def start(self):
        if self.running:return
        try:
            a,b=self.a.get(),self.b.get()
            if not Path(a).is_file() or not Path(b).is_file():raise ValueError('Wskaż istniejące pliki STEP A i B')
            tol=float(self.tolerance.get().replace(',','.'))
            density=float(self.density.get().replace(',','.'))
            if not 0<tol<=1:raise ValueError('Tolerancja: 0 < wartość <= 1 mm')
            if not 0<density<=25000:raise ValueError('Gęstość poza zakresem')
        except Exception as e:return messagebox.showerror('Błędne parametry',str(e))
        self.stop=False;self.running=True;self.go.configure(state='disabled');self.abort.configure(state='normal')
        self.gauge.start(11);self.log.delete('1.0','end')
        def worker():
            try:
                out,rows,err=process(a,b,self.folder.get(),tol,density,self.step.get(),
                     progress=lambda m:self.q.put(('msg',m)),cancelled=lambda:self.stop)
                self.q.put(('done',str(out/'RAPORT.html'),err))
            except Exception:
                self.q.put(('error',traceback.format_exc()))
        threading.Thread(target=worker,daemon=True).start()
    def poll(self):
        try:
            while True:
                e=self.q.get_nowait();k=e[0]
                if k=='msg':
                    self.log.insert('end',e[1]+'\n');self.log.see('end');self.status.config(text=e[1])
                elif k in ('done','error'):
                    self.running=False;self.go.configure(state='normal');self.abort.configure(state='disabled');self.gauge.stop()
                    if k=='done':
                        self.status.config(text='Zakończono')
                        webbrowser.open(Path(e[1]).as_uri())
                        if e[2]:messagebox.showwarning('Raport gotowy, ale STEP nie zapisany',e[2])
                    else:
                        self.status.config(text='Błąd analizy — sprawdź log')
                        self.log.insert('end',e[1]+'\n');messagebox.showerror('Błąd',e[1][-1300:])
        except queue.Empty:pass
        self.after(150,self.poll)
    def open_folder(self):
        p=Path(self.folder.get());p.mkdir(parents=True,exist_ok=True)
        import os
        if os.name=='nt':os.startfile(str(p))
        else:webbrowser.open(p.as_uri())

def main(): GUI().mainloop()
if __name__=='__main__':main()
