"""STEPCAF load/save to keep STEP names and per-body colors. Lengths expected in mm."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from OCP.STEPCAFControl import STEPCAFControl_Reader, STEPCAFControl_Writer
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.TDF import TDF_LabelSequence, TDF_Label
from OCP.TDataStd import TDataStd_Name
from OCP.XCAFDoc import XCAFDoc_DocumentTool, XCAFDoc_ColorType
from OCP.TopoDS import TopoDS_Shape
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID
from OCP.TopLoc import TopLoc_Location
from OCP.Quantity import Quantity_Color,Quantity_TOC_RGB
from OCP.IFSelect import IFSelect_RetDone
from .geometry import SolidInfo,describe


def _label_name(label: TDF_Label, default=''): 
    attr=TDataStd_Name()
    if label.FindAttribute(TDataStd_Name.GetID_s(),attr):
        txt=attr.Get().ToExtString().strip()
        if txt: return txt
    return default


def _solids(shape: TopoDS_Shape):
    ex=TopExp_Explorer(shape, TopAbs_SOLID)
    while ex.More():
        yield ex.Current()
        ex.Next()


def load_step(path: str, max_solids: int = 1000, progress=None) -> list[SolidInfo]:
    p=Path(path)
    if not p.is_file(): raise FileNotFoundError(str(path))
    if p.suffix.lower() not in ('.stp','.step'): raise ValueError('Prototyp B-Rep wymaga STEP/STP (eksport z ZW3D).')
    document=TDocStd_Document(TCollection_ExtendedString('BinXCAF'))
    reader=STEPCAFControl_Reader();reader.SetNameMode(True);reader.SetColorMode(True)
    if reader.ReadFile(str(p))!=IFSelect_RetDone: raise ValueError('Nie można odczytać STEP: '+str(p))
    if not reader.Transfer(document): raise ValueError('Błąd transferu STEP: '+str(p))
    tool=XCAFDoc_DocumentTool.ShapeTool_s(document.Main())
    roots=TDF_LabelSequence();tool.GetFreeShapes(roots)
    out=[]
    def add_shape(shape,name,hierarchy):
        solids=list(_solids(shape))
        for k,s in enumerate(solids,1):
            if len(out)>=max_solids: raise ValueError(f'Limit bezpieczenstwa: {max_solids} bryl na plik')
            name2=name if len(solids)==1 else f'{name}#{k}'
            info=describe(s,name2,hierarchy+'/'+name2,str(p))
            out.append(info)
            if progress and len(out)%10==0: progress(f'{p.name}: wczytano {len(out)} brył')
    def walk(lab: TDF_Label, parent_loc: TopLoc_Location, hierarchy:str, depth:int):
        if depth>32: raise ValueError('Zbyt głębokie podzłożenie (>32 poziomów)')
        is_ref=tool.IsReference_s(lab)
        actual=TDF_Label()
        if is_ref and tool.GetReferredShape_s(lab,actual):
            target=actual
            loc=parent_loc.Multiplied(tool.GetLocation_s(lab))
        else:target=lab;loc=parent_loc
        label_name=_label_name(lab, _label_name(target,'Komponent'))
        fullname=f'{hierarchy}/{label_name}' if hierarchy else label_name
        comps=TDF_LabelSequence()
        if tool.GetComponents_s(target,comps) and comps.Length()>0:
            for idx in range(1,comps.Length()+1): walk(comps.Value(idx),loc,fullname,depth+1)
        else:
            sh=tool.GetShape_s(target)
            if sh.IsNull():return
            # Apply parent transform to shape if necessary. A shape may have its own location.
            if not loc.IsIdentity(): sh=sh.Moved(loc)
            add_shape(sh,label_name,fullname)
    for i in range(1,roots.Length()+1): walk(roots.Value(i),TopLoc_Location(),'',0)
    if not out: raise ValueError('W pliku STEP nie znaleziono zadnej bryly zamknietej (SOLID).')
    if progress:progress(f'{p.name}: gotowe {len(out)} brył')
    return out


COLORS={'SAME':(0.15,0.68,0.26),'RENAMED':(0.15,0.68,0.26),
        'MOVED':(0.40,0.35,0.83),'CHANGED':(0.40,0.35,0.83),
        'ADDED':(0.40,0.35,0.83),'REMOVED':(0.90,0.56,0.24),
        'UNCERTAIN':(0.6,0.64,0.7)}

def export_colored_step(path: str, records, a_parts, b_parts,
                        colors: dict | None = None):
    colors={**COLORS,**(colors or {})}
    doc=TDocStd_Document(TCollection_ExtendedString('BinXCAF'))
    tool=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
    color_tool=XCAFDoc_DocumentTool.ColorTool_s(doc.Main())
    present=[]
    for r in records:
        if r.b_index is not None:
            present.append((b_parts[r.b_index],r.status,'B'))
        elif r.a_index is not None and r.status=='REMOVED':
            present.append((a_parts[r.a_index],'REMOVED','A'))
    for part,status,model in present:
        label=tool.AddShape(part.shape,False)
        TDataStd_Name.Set_s(label,TCollection_ExtendedString(f'[{status}] {part.name} [{model}]'))
        rgb=colors.get(status,COLORS['UNCERTAIN'])
        c=Quantity_Color(*[float(x) for x in rgb],Quantity_TOC_RGB)
        color_tool.SetColor(label,c,XCAFDoc_ColorType.XCAFDoc_ColorGen)
        color_tool.SetColor(label,c,XCAFDoc_ColorType.XCAFDoc_ColorSurf)
    writer=STEPCAFControl_Writer();writer.SetNameMode(True);writer.SetColorMode(True)
    if not writer.Transfer(doc): raise RuntimeError('Eksport STEP: transfer geometrii nie powiodl sie')
    if writer.Write(str(path))!=IFSelect_RetDone:raise RuntimeError('Nie udało się zapisać modelu STEP')
