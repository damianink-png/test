@echo off
cd /d "%~dp0"
echo Przyklad: py -3.11 -m dsac29.cli MODEL_A.step MODEL_B.step -o WYNIKI --tolerance 0.01 --density 7850
pause
