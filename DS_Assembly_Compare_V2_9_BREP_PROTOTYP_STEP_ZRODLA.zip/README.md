# DS Assembly Compare V2.9 — prototyp B-Rep STEP

**Działa jako osobny program na Windows x64, a nie jako DLL w procesie ZW3D 2019.**
To celowy tryb diagnostyczny: wcześniejsze wersje dodatku powodowały awarie przy odczycie B-Rep z ZW3D. Prototyp wykorzystuje prawdziwy Open CASCADE / OCCT i operacje logiczne na bryłach po eksporcie modeli do STEP.

## Co rzeczywiście działa w prototypie

- Wskazanie `MODEL_A.step` i `MODEL_B.step` z osobnego okna.
- Odczyt rzeczywistych brył z plików STEP/STP, nazw przeniesionych przez STEP (o ile są w plikach) i wystąpień wielobryłowych.
- Rozpoznanie identyczności **rzeczywistej geometrii** operacjami `A−B` i `B−A` w Open CASCADE.
- Dopasowanie identycznych brył przy zmianie nazwy, przesunięciu i obrocie (orientacja według osi bezwładności).
- Wykrycie różnicy geometrii mimo takiej samej objętości, np. przesunięcia otworu.
- Dopasowanie wystąpień jeden do jednego (bez generowania zdublowanej zielonej + pomarańczowej pary).
- Eksport **`POROWNANIE_KOLORY.step`**: zielony — bez zmian (również zmiana nazwy), fioletowy — nowy/przesunięty/zmieniony, pomarańczowy — usunięty. Niepewne są szare.
- Raport `RAPORT.html`, `ZMIANY.csv`, `BOM_A.csv`, `BOM_B.csv`, `PODSUMOWANIE.json`.
- Masa z objętości B-Rep i *podanej* wspólnej gęstości (domyślnie 7850 kg/m³), osobno dla A i B.
- Anulowanie pomiędzy operacjami (natywna operacja OCCT może zakończyć się dopiero po chwili).

## Czego **nie** robi ta wersja

- Nie odczytuje natywnie `.Z3`: otwórz każdy model w ZW3D i **wyeksportuj złożenie do STEP** (w mm). Nie wymaga to utrzymywania obu dokumentów otwartych podczas porównania.
- Nie instaluje dodatku `~DSAC` w ZW3D i nie generuje natywnego złożenia `.Z3`. Porównawczy STEP można otworzyć w ZW3D.
- Nie odtwarza historii operacji/cech CAD (np. nie zawsze rozpozna, czy różnica była fazowaniem czy frezowaniem).
- Nie gwarantuje automatycznego dopasowania wszystkich obróconych brył o symetrycznych momentach bezwładności, ani elementów skrajnie zdegenerowanych. Błędy B-Rep są traktowane jako niezweryfikowane lub zgłaszane.
- Nie wczytuje indywidualnej gęstości materiałowej ZW3D; masa liczona jest z jednej gęstości podanej przez użytkownika.
- W koloryzowanym STEP przezroczystość starych elementów zależy od importera CAD. W tym prototypie ustawiany jest **kolor**, nie gwarantowana transparentność.
- BOM jest zestawieniem **brył STEP**, nie pełnym natywnym BOM podzłożeń ZW3D.
- Niezmienione bryły są zielone **wyłącznie po rzeczywistym potwierdzeniu B-Rep**; gdy brak pewności, nie są zielone.

## Start na komputerze z Windows (bez administratora)

1. Zainstaluj Python 3.11 x64 dla bieżącego użytkownika, jeśli nie jest zainstalowany.
2. Rozpakuj ZIP i uruchom `URUCHOM_GUI.bat`. Przy pierwszym uruchomieniu skrypt może pobrać pakiet `cadquery-ocp` i `numpy` (wymaga internetu).
3. W ZW3D wyeksportuj oba porównywane modele jako STEP, wybierz je w oknie V2.9.
4. Kliknij `PORÓWNAJ B-REP`.
5. Otwórz `RAPORT.html` i `POROWNANIE_KOLORY.step` w ZW3D.

**Ważne:** przy otwieraniu wyeksportowanego STEP w ZW3D włącz import kolorów, jeśli Twoje ustawienia importera na to pozwalają. Dla dużych danych zrób pierwszą próbę na 10–20 unikalnych częściach.

### Test wiersza poleceń

```bat
py -3.11 -m dsac29.cli samples\MODEL_A.step samples\MODEL_B.step -o WYNIKI --tolerance 0.01 --density 7850
```

Aby wygenerować modele testowe ponownie: `py -3.11 generuj_przykladowe_step.py`.

## GitHub Actions – kompilacja aplikacji Windows x64

W odróżnieniu od starszej DLL, ten prototyp wymaga **nowego workflow** `.github/workflows/build-dsac-v29-brep.yml` i źródeł rozpakowanych w repozytorium:

1. Rozpakuj źródłowy ZIP V2.9 lokalnie.
2. Prześlij do GitHuba rozpakowane foldery `dsac29`, `tests`, `samples`, pliki `requirements.txt`, `README.md`, `URUCHOM_GUI.py`, `generuj_przykladowe_step.py` oraz `.github/workflows/build-dsac-v29-brep.yml`, zachowując strukturę folderów.
3. Otwórz GitHub → Actions → `DS Assembly Compare V2.9 B-Rep - Windows x64 prototype` → `Run workflow`.
4. Pobierz z artefaktów folder programu `DSAC-V2.9-BREP-Windows-x64-Standalone`, w którym znajduje się `DSAC_V29_BREP.exe` i potrzebne biblioteki.

**Uwaga:** Samo umieszczenie ZIP-a w `damianink-png/test` nie uruchomi tego workflow. Dotychczasowy workflow `build-ds-assembly-compare.yml` kompiluje natywną DLL V2.6 i nie może służyć do budowania nowej aplikacji B-Rep. Wersja źródłowa z tego ZIP-a jest od razu uruchamialna przez Python na Windows bez GitHuba.

## Architektura i bezpieczeństwo

- GUI uruchamia się **poza procesem ZW3D**, dlatego awaria procesu porównywania OCCT nie powinna wywrócić otwartego ZW3D.
- Nie nadpisuje źródłowych modeli A i B, zawsze tworzy nowy folder wyników.
- Dopasowanie zachowuje inwariant jeden-do-jednego. Brak wiarygodnej pary nie oznacza automatycznie identyczności.
- Jednostki: STEP zakładamy w mm po imporcie z Open CASCADE; tolerancja 0,01 mm dotyczy B-Rep. Wyniki zależą od dokładności wyeksportowanych modeli.
- Próbne limity: 1000 brył na plik, 15 000 wymagających porównań Boolean. Są jawne, a ich przekroczenie przerywa analizę z błędem, nie generuje niepełnego „gotowego” raportu.

## Akceptacja prototypu

Przetestuj: dwa identyczne detale o różnych nazwach, powtarzalne wystąpienia, płytę z przesuniętym otworem oraz detal obrócony. Wyślij mi raport HTML / CSV i informację, czy ZW3D importuje kolory z `POROWNANIE_KOLORY.step`. Potem możemy zdecydować, czy integrować analizę B-Rep bezpośrednio z ZW3D lub dodać bezpieczny eksport A/B do STEP z poziomu jednej komendy DLL.
