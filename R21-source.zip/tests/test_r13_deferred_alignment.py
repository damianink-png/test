import json
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from test_r7_alignment_preview import occurrence
from dsac29 import cli
from dsac29.compare import compare
from dsac29.deferred_alignment import propose


def models(count=40,stable=40,shift=0):
 s=BRepPrimAPI_MakeBox(17,11,9).Shape();other=BRepPrimAPI_MakeBox(17,12,9).Shape()
 a=[occurrence(s,'P',i*41.,i*i*3.) for i in range(count)]
 b=[occurrence(s if i<stable else other,'P',i*41.+shift,i*i*3.) for i in range(count)]
 return a,b


def run(tmp_path,monkeypatch,a,b,decision='original'):
 pa=tmp_path/'a.step';pb=tmp_path/'b.step';pa.write_text('a');pb.write_text('b')
 monkeypatch.setattr(cli,'load_step',lambda path,**kw:a if path==pa else b)
 calls=[]
 def approval(info):calls.append(info);return decision
 out=tmp_path/'out';out.mkdir()
 cli.process(pa,pb,out,step=False,diff_step=False,full_bom=False,revision_style=True,
             auto_align=True,alignment_approval=approval,progress=None)
 return json.loads((out/'PODSUMOWANIE.json').read_text()),calls


@pytest.mark.parametrize('stable',[40,10,0])
def test_no_shift_no_global_search(tmp_path,monkeypatch,stable):
 import dsac29.alignment as alignment
 import dsac29.deferred_alignment as deferred
 def forbidden(*a,**kw):raise AssertionError('Unnecessary registration')
 monkeypatch.setattr(alignment,'align_assembly',forbidden)
 monkeypatch.setattr(deferred,'frame_support',forbidden)
 a,b=models(stable=stable)
 summary,calls=run(tmp_path,monkeypatch,a,b)
 assert not calls
 assert summary['statuses'].get('SAME',0)==stable


def test_local_move_does_not_move_assembly(tmp_path,monkeypatch):
 a,b=models();b[0]=occurrence(BRepPrimAPI_MakeBox(17,11,9).Shape(),'P',8,0)
 summary,calls=run(tmp_path,monkeypatch,a,b)
 assert not calls and summary['statuses']['SAME']==39


@pytest.mark.parametrize('decision',['align','original'])
def test_translation_decision(tmp_path,monkeypatch,decision):
 # R14: 40/40 unambiguous B-Rep-proven placements are automatic.
 a,b=models(shift=1000)
 summary,calls=run(tmp_path,monkeypatch,a,b,decision)
 assert not calls
 assert summary['statuses'].get('SAME',0)==40
 assert summary['alignment']['translation_B_to_A_mm']==[-1000.,0.,0.]
 assert summary['alignment']['approved_by_user'] is False


def test_unequal_periodic_population():
 s=BRepPrimAPI_MakeBox(17,11,9).Shape();positions=list(range(29))+[40]
 a=[occurrence(s,'P',x*40.,0) for x in positions]
 b=[occurrence(s,'P',(x+1)*40.,0) for x in positions]+[occurrence(s,'P',4040.,0)]
 records=compare(a,b,revision_only=True,exact_serialization=True)
 proposal=propose(a,b,records,.01)
 assert proposal['votes']==30 and proposal['translation_B_to_A_mm']==[-40.,0.,0.]


def test_cancel_prevents_reports(tmp_path,monkeypatch):
 # The 8/80 partial support is deliberately NOT auto-accepted.
 from test_r14_sparse_shift import case
 a,b,_=case()
 with pytest.raises(InterruptedError):run(tmp_path,monkeypatch,a,b,'cancel')
 assert not (tmp_path/'out/PODSUMOWANIE.json').exists()


def test_single_comparison_without_shift_and_reused_cache_after_shift(tmp_path,monkeypatch):
 original=cli.compare;contexts=[]
 def wrapped(*args,**kwargs):
  contexts.append(kwargs['geometry_context']);return original(*args,**kwargs)
 monkeypatch.setattr(cli,'compare',wrapped)
 a,b=models();run(tmp_path,monkeypatch,a,b)
 assert len(contexts)==1
 contexts.clear();other=tmp_path/'shifted';other.mkdir()
 a,b=models(shift=1000);run(other,monkeypatch,a,b,'align')
 assert len(contexts)==2 and contexts[0] is contexts[1]
