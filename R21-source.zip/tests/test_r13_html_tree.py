"""R13 HTML panel: preserve A/B body IDs and removed geometry on every revision."""
import json
import re
import base64
from pathlib import Path
from dsac29.preview3d import create_preview
from dsac29.compare import Record
from dsac29.step_io import load_step

ROOT=Path(__file__).resolve().parents[1]

def load_chunks(path):
    text=path.read_text(encoding='utf-8')
    return json.loads(re.search(r'^const scene=(.*);$',text,flags=re.M).group(1))

def test_html_tree_has_unique_selectable_occurrences_and_both_versions(tmp_path):
    a=load_step(str(ROOT/'samples/MODEL_A.step'))
    b=load_step(str(ROOT/'samples/MODEL_B.step'))
    records=[Record(0,None,'REMOVED','removed'),Record(None,0,'ADDED','added'),
             Record(1,1,'MOVED','moved'),Record(2,2,'CHANGED','changed'),
             Record(3,3,'SAME','unchanged')]
    page=tmp_path/'preview.html'
    result=create_preview(page,records,a,b)
    chunks=load_chunks(page)
    assert result['elementy']==7
    assert [(v['status'],v['role']) for v in chunks]==[
       ('REMOVED','A'),('MOVED_OLD','A'),('CHANGED_OLD','A'),
       ('ADDED','B'),('MOVED','B'),('CHANGED_NEW','B'),('SAME','B')]
    assert all(c['name'] and c['record_index'] in range(len(records)) for c in chunks)
    assert all(isinstance(c['part_index'],int) and len(base64.b64decode(c['data']))>0 for c in chunks)
    html=page.read_text(encoding='utf-8')
    assert 'id="tree"' in html and 'id="treeSearch"' in html
    assert 'function pickAt(' in html and 'function setSelected(' in html
    assert 'function focusSelected(' in html
    assert 'id="removed"' in html and 'id="xray"' in html
    assert 'src="https:' not in html and 'fetch(' not in html


def test_html_escapes_step_labels_without_breaking_script(tmp_path):
    b=load_step(str(ROOT/'samples/MODEL_B.step'))
    b[0].name='nazwa </script><img src=x onerror=alert(1)>'
    page=tmp_path/'safe.html'
    create_preview(page,[Record(None,0,'ADDED','')],[],b)
    html=page.read_text(encoding='utf-8')
    assert '</script><img' not in html
    assert '\\u003c/script>' in html
    assert load_chunks(page)[0]['name'].startswith('nazwa </script>')
