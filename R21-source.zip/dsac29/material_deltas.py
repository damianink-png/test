"""R15: non-destructive Boolean material regions for uniquely paired modified parts.
All regions are in the aligned world coordinate system. Failed Booleans are
never silently represented as correct geometric differences.
"""
from __future__ import annotations
from dataclasses import dataclass
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common, BRepAlgoAPI_Cut
from OCP.BRepGProp import BRepGProp
from OCP.GProp import GProp_GProps
from OCP.BRepCheck import BRepCheck_Analyzer
from OCP.TopAbs import TopAbs_SOLID
from OCP.TopExp import TopExp_Explorer

COLORS = {
 'CHANGED_COMMON': (38/255,117/255,247/255),  # wspólny materiał, niebieski
 'CHANGED_ADDED': (245/255,158/255,11/255),  # dodany materiał, bursztynowy
 'CHANGED_REMOVED': (190/255,18/255,60/255), # usunięty materiał, karminowy
}

@dataclass
class MaterialRegions:
    common: object
    added: object
    removed: object
    common_mm3: float
    added_mm3: float
    removed_mm3: float


def solids(shape,epsilon=1e-7):
    ex=TopExp_Explorer(shape,TopAbs_SOLID)
    while ex.More():
        piece=ex.Current();ex.Next()
        if volume(piece)>epsilon:yield piece


def volume(shape):
    prop=GProp_GProps()
    BRepGProp.VolumeProperties_s(shape,prop)
    return max(0.,float(prop.Mass()))


def operate(klass,s,t,tolerance):
    from .boolean_ops import configured
    op=configured(klass,s,t,tolerance);op.Build()
    if not op.IsDone():raise RuntimeError('Boolean OCC nie ukończony')
    result=op.Shape()
    if result.IsNull() or not BRepCheck_Analyzer(result).IsValid():
        raise RuntimeError('Boolean OCC zwrócił nieprawidłową topologię')
    return result


def calculate(old,new,tolerance=0.01,*,common_shape=None):
    """Use actual OCC Boolean shapes, not just net volume difference."""
    common=common_shape if common_shape is not None else operate(BRepAlgoAPI_Common,old.shape,new.shape,tolerance)
    if common.IsNull() or not BRepCheck_Analyzer(common).IsValid():
        raise RuntimeError('Nieprawidłowa wspólna geometria Boolean')
    added=operate(BRepAlgoAPI_Cut,new.shape,old.shape,tolerance)
    removed=operate(BRepAlgoAPI_Cut,old.shape,new.shape,tolerance)
    cv,av,rv=map(volume,(common,added,removed))
    abs_tol=max(1e-3,10.*tolerance**3, 5e-5*max(old.volume,new.volume))
    if abs(cv+rv-old.volume)>abs_tol or abs(cv+av-new.volume)>abs_tol:
        raise RuntimeError('Kontrola objętości po operacji Boolean nie powiodła się')
    return MaterialRegions(common,added,removed,cv,av,rv)


def all_changes(records,a,b,tolerance=0.01,progress=None,precomputed=None):
    out=dict(precomputed or {});errors={}
    indices=[i for i,r in enumerate(records) if r.status=='CHANGED' and r.a_index is not None and r.b_index is not None]
    for n,index in enumerate(indices,1):
        if index in out:continue
        r=records[index]
        if progress:progress(f'R15: podział materiału {n}/{len(indices)} — {b[r.b_index].name}')
        try:out[index]=calculate(a[r.a_index],b[r.b_index],tolerance)
        except Exception as exc:errors[index]=str(exc)
    return out,errors
