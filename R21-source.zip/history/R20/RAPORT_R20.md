# DS Compare 1.0 R20

## Zmiany
- Błędne SAME po reeksporcie STEP: deskryptory ścian służą wyłącznie jako filtr.
  Dopasowanie wymaga dwóch operacji różnicy bryłowej A/B i B/A.
  Fuzzy distance nie przekracza tolerancji użytkownika; każda pozostałość
  musi mieć objętość nie większą niż tolerancja do sześcianu.
  Obwiednie i środki ścian respektują tolerancję bez wcześniejszych stałych progów.
- Przesunięcie okresowe jest sprawdzane również przy różnej liczbie wystąpień,
  jeśli niedopasowana geometria występuje po obu stronach. Nadal wymagane jest
  potwierdzenie B-Rep i jednoznaczny zwycięzca. Analiza w miejscu jest pierwsza.
- Operacje Boolean konfigurowane przed jednym Build, bez obliczeń w konstruktorze.
- Wspólna geometria najlepszego kandydata jest używana ponownie przy podziale materiału.
  Zachowano walidację topologii i objętości.
- Cache siatek dokładnie tych samych definicji natywnych (do 32 MiB na eksport).
  Osobne transformacje i identyfikatory wystąpień pozostają zachowane.
  HTML nadal przechowuje dane dla każdego wystąpienia; nie wdrożono instancji WebGL.
- Zaktualizowane oznaczenia wersji, samodzielny workflow kompilacji Windows.
  Stare workflow przeniesione do history/workflows.

## Testy końcowe
147 testów PASS na Python 3.12, OCP 7.8.1.1, Linux.
W tym: 380 części z dokładnie 231 bez zmian; przesunięcie okresowe 30/31;
regresja tolerancji 0,001 mm wobec odchyłki 0,0025 mm; pełne CLI dla 8 zmienionych
części; poprawne drobne odchyłki wewnątrz tolerancji; zapis i odczyt STEP;
zgodność regionów materiału w STEP i HTML; zachowanie pozycji po obrocie/translacji
przy użyciu cache siatek. Log dołączony w validation.

## Zakres
Nie wykonano kompilacji Windows EXE ani testu w ZW3D. Nie posiadam modeli użytkownika.
Zmiany nie ingerują w obsługę ABSR ani układ interfejsu.

Publiczne złożenie NIST/CAx-IF: 18/18 SAME po translacji całego złożenia
(1275, -395, 210) mm i niezależnym zapisie STEP; STEP i HTML gotowe, 0 pominiętych.

## Niezaliczony test SO-ARM100 — ważne ograniczenie
Test prawdziwego złożenia SO-ARM100 i przesuniętej kopii został przerwany
po 240 sekundach (kod 124), podczas weryfikacji 14/19 części.
Stos wykonania wskazuje kosztowne operacje Cut przy niemal pokrywających się
powierzchniach po reeksporcie STEP. Nie ma potwierdzenia końcowego wyniku tego modelu.
R20 należy traktować jako wersję testową, nie w pełni zweryfikowane wydanie produkcyjne.
Log diagnostyczny jest dołączony. Należy zachować działającą kopię R19.
