# DS Compare 1.0 R21

Instrukcja: 00_START_TUTAJ.txt. Zmiany i testy: RAPORT_R21.md.
