# Aktualne wydanie: DS Compare 1.0 R22.3 RC2

Zacznij od `00_START_TUTAJ.txt` i `RAPORT_R22_3_RC2.md`. Poniższe informacje zawierają historię projektu.

# DS Compare 1.0 R21

Instrukcja: 00_START_TUTAJ.txt. Zmiany i testy: RAPORT_R21.md.
