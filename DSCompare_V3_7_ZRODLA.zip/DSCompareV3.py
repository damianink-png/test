"""DS Compare V3.7 entry. Worker mode is kept separate from the UI."""
import sys

if __name__=='__main__':
    if '--dscompare-worker' in sys.argv:
        from dsac29.gui import _worker_main
        sys.exit(_worker_main(sys.argv[1:]))
    elif '--worker' in sys.argv:
        from dsac29.worker_v37 import main
        sys.exit(main(sys.argv[1:]))
    else:
        import argparse
        p=argparse.ArgumentParser()
        p.add_argument('--a',default='')
        p.add_argument('--b',default='')
        args=p.parse_args()
        from dsac29.gui_qt37 import main
        sys.exit(main(args.a,args.b))
