"""DS Compare V3.7: responsive Qt dashboard with embedded VTK 3D model viewer.

CAD operations run in a separate process, never on the Qt GUI thread.
"""
from __future__ import annotations
import csv,json,os,sys
from pathlib import Path
from collections import Counter
from PySide6.QtCore import Qt,QProcess,QTimer,QUrl,QSettings,QSize
from PySide6.QtGui import QIcon,QColor,QDesktopServices,QFont
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QFrame,QHBoxLayout,QVBoxLayout,
    QGridLayout,QStackedWidget,QLabel,QPushButton,QLineEdit,QFileDialog,QCheckBox,
    QComboBox,QTableWidget,QTableWidgetItem,QHeaderView,QTextEdit,QSplitter,QColorDialog,
    QMessageBox,QScrollArea,QAbstractItemView,QProgressBar,QSizePolicy,QButtonGroup)

COLORS={'SAME':'#26AD42','RENAMED':'#26AD42','MOVED':'#6659D4',
        'CHANGED':'#6659D4','ADDED':'#6659D4','REMOVED':'#E68F3D','UNCERTAIN':'#99A3B2'}
TABS=[('start','Przegląd','⌂'),('compare','Porównanie','⇄'),('viewer','Podgląd 3D','◈'),
      ('results','Wyniki','▤'),('mass','Masa części','◉'),('settings','Ustawienia','⚙')]

def _settings_path():
    root=Path(os.getenv('APPDATA') or (Path.home()/'.config'))
    return root/'DSCompare'/'ustawienia_v37.json'

def load_settings():
    try:return json.loads(_settings_path().read_text(encoding='utf-8'))
    except (OSError,ValueError):return {}

def save_settings(settings):
    path=_settings_path();path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(settings,indent=2,ensure_ascii=False),encoding='utf-8')

def theme_qss(light=False):
    bg='#F0F2F5' if light else '#1D2030'
    card='#FFFFFF' if light else '#2A2D40'
    inp='#F7F8FA' if light else '#222638'
    text='#22263A' if light else '#F3F5FB'
    muted='#677087' if light else '#ACB5C9'
    edge='#DCE1EA' if light else '#3B4157'
    side='#E5E7EB' if light else '#161C2A'
    selection='#E2F2F1' if light else '#344E56'
    hover='#D6DDE7' if light else '#384157'
    return f'''
    QWidget#root {{background:{bg};color:{text};font-family:'Segoe UI';font-size:12px;}}
    QFrame#sidebar {{background:{side};border:none;border-radius:18px;}}
    QFrame#card,QFrame#panel {{background:{card};border:1px solid {edge};border-radius:17px;}}
    QFrame#colorcard {{background:{card};border:1px solid {edge};border-radius:14px;}}
    QLabel {{color:{text};background:transparent;}}
    QLabel#muted {{color:{muted};font-size:11px;}}
    QLabel#title {{color:{text};font-size:25px;font-weight:700;}}
    QLabel#section {{color:{text};font-size:16px;font-weight:700;}}
    QLabel#big {{color:{text};font-size:27px;font-weight:700;}}
    QLabel#kpi {{color:{text};font-size:24px;font-weight:700;}}
    QLabel#brand {{color:{text};font-size:18px;font-weight:800;}}
    QPushButton {{background:{card};border:1px solid {edge};border-radius:10px;color:{text};padding:10px 15px;font-weight:600;}}
    QPushButton:hover {{background:{hover};border:1px solid #56BDAD;}}
    QPushButton:pressed {{background:{selection};}}
    QPushButton:disabled {{color:{muted};background:{inp};}}
    QPushButton#nav {{background:transparent;border:none;text-align:left;border-radius:10px;padding:13px 14px;}}
    QPushButton#nav:hover {{background:{hover};}}
    QPushButton#nav[active="true"] {{background:{selection};color:{'#206B68' if light else '#7AE4D2'};font-weight:800;}}
    QPushButton#primary {{background:#58C8B1;color:#102731;border:none;border-radius:11px;font-weight:800;}}
    QPushButton#primary:hover {{background:#87E5D0;}}
    QPushButton#coral {{background:#FE7774;color:#261D25;border:none;font-weight:800;}}
    QPushButton#coral:hover {{background:#FF9A98;}}
    QPushButton#teal {{background:#49B8AC;color:#142D33;border:none;font-weight:800;}}
    QPushButton#teal:hover {{background:#81DBCD;}}
    QPushButton#subtle {{background:transparent;border:1px solid {edge};}}
    QLineEdit,QComboBox,QTextEdit {{background:{inp};color:{text};border:1px solid {edge};border-radius:10px;padding:10px 12px;selection-background-color:#52B8AC;}}
    QLineEdit:focus,QComboBox:focus {{border:1px solid #51BEB3;}}
    QCheckBox {{color:{text};spacing:8px;}}
    QCheckBox::indicator {{width:16px;height:16px;}}
    QTableWidget {{background:{card};alternate-background-color:{inp};gridline-color:{edge};color:{text};border:0;border-radius:8px;selection-background-color:{selection};selection-color:{text};}}
    QHeaderView::section {{background:{inp};color:{muted};padding:11px;border:none;border-bottom:1px solid {edge};font-weight:700;}}
    QTableWidget::item {{padding:6px;}}
    QProgressBar {{background:{inp};color:{text};border:none;border-radius:5px;height:8px;}}
    QProgressBar::chunk {{background:#58C8B1;border-radius:5px;}}
    QScrollBar:vertical {{background:transparent;width:9px;}}
    QScrollBar::handle:vertical {{background:{edge};border-radius:4px;min-height:22px;}}
    '''


def _label(text, kind=None):
    l=QLabel(text)
    if kind:l.setObjectName(kind)
    return l

def _panel(parent=None):
    f=QFrame(parent);f.setObjectName('card');return f

def _button(text,action=None,kind=None):
    b=QPushButton(text)
    if kind:b.setObjectName(kind)
    b.setMinimumHeight(39)
    if action:b.clicked.connect(action)
    return b

class Window(QMainWindow):
    def __init__(self, model_a='',model_b=''):
        super().__init__()
        self.settings=load_settings()
        self.settings.setdefault('motyw','ciemny')
        self.settings.setdefault('kolory',dict(COLORS))
        self.setWindowTitle('DS Compare — porównywanie złożeń i geometrii')
        self.resize(1320,790);self.setMinimumSize(970,650)
        img=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parents[1]))/'assets'/'DSCompare.ico'
        if img.exists():self.setWindowIcon(QIcon(str(img)))
        self.process=None;self.worker_dir=None;self.worker_kind=None;self.worker_position=0
        self.result_dir=Path(self.settings.get('ostatni_wynik') or (Path.home()/'Documents'/'DSCompare'/'Wyniki'))
        self.viewer_actors={};self.viewer_ready=False
        self.root=QWidget();self.root.setObjectName('root');self.setCentralWidget(self.root)
        self.outer=QHBoxLayout(self.root);self.outer.setContentsMargins(15,15,15,15);self.outer.setSpacing(16)
        self.build_sidebar()
        self.stack=QStackedWidget();self.outer.addWidget(self.stack,1)
        self.pages={}
        for key,_,_ in TABS:
            w=QWidget();self.pages[key]=w;self.stack.addWidget(w)
        self.build_start();self.build_compare(model_a,model_b);self.build_viewer();self.build_results();self.build_mass();self.build_settings()
        self.set_theme(self.settings['motyw'],persist=False)
        self.navigate('start')
        if self.result_dir.exists():self.load_summary()

    def build_sidebar(self):
        self.side=QFrame();self.side.setObjectName('sidebar');self.side.setFixedWidth(205)
        self.outer.addWidget(self.side)
        lay=QVBoxLayout(self.side);lay.setContentsMargins(16,25,16,20);lay.setSpacing(6)
        logo=QHBoxLayout();logo.setSpacing(9)
        emblem=_label('◈');emblem.setStyleSheet('color:#54BFAF;font-size:31px;font-weight:900')
        logo.addWidget(emblem)
        label=_label('DS Compare','brand');logo.addWidget(label);logo.addStretch()
        lay.addLayout(logo)
        lay.addSpacing(28)
        self.nav={}
        for key,name,icon in TABS:
            btn=_button('  '+icon+'    '+name,lambda checked=False,k=key:self.navigate(k),'nav')
            btn.setCursor(Qt.PointingHandCursor)
            lay.addWidget(btn);self.nav[key]=btn
        lay.addStretch()
        self.theme_sidebar=_button('☀ / ☾   Zmień motyw',self.toggle_theme,'subtle')
        lay.addWidget(self.theme_sidebar)
        about=_button('ⓘ   O programie',self.show_about,'nav');lay.addWidget(about)

    def top(self,key,title,subtitle):
        page=self.pages[key]
        v=QVBoxLayout(page);v.setContentsMargins(2,4,2,4);v.setSpacing(17)
        row=QHBoxLayout();txt=QVBoxLayout();txt.setSpacing(5)
        txt.addWidget(_label(title,'title'));txt.addWidget(_label(subtitle,'muted'))
        row.addLayout(txt);row.addStretch()
        v.addLayout(row)
        return v

    def build_start(self):
        v=self.top('start','Centrum porównania','Twoje modele, analiza geometrii i wyniki w jednym miejscu')
        row=QHBoxLayout();row.setSpacing(15)
        for name,sub,obj,func in [('Porównaj modele','Złożenie A i B','coral',lambda:self.navigate('compare')),
                                  ('Otwórz podgląd','Obracaj modele 3D','teal',lambda:self.navigate('viewer')),
                                  ('Policz masę','Jeden model STEP','primary',lambda:self.navigate('mass'))]:
            tile=_panel();tl=QVBoxLayout(tile);tl.setContentsMargins(18,18,18,18)
            tl.addWidget(_label(name,'section'));tl.addWidget(_label(sub,'muted'));tl.addStretch()
            tl.addWidget(_button('Otwórz   →',func,obj));row.addWidget(tile,1)
        v.addLayout(row,2)
        v.addWidget(_label('Ostatnia analiza','section'))
        self.dashboard_kpi=QHBoxLayout()
        for k,name,color in [('SAME','Bez zmian','#58C8B1'),('CHANGED','Zmienione','#FD807C'),('ADDED','Nowe','#897BDE'),('REMOVED','Usunięte','#E5A55F')]:
            tile=_panel();t=QVBoxLayout(tile);t.setContentsMargins(16,14,16,14)
            num=_label('—','kpi');num.setStyleSheet(f'color:{color}')
            setattr(self,'kpi_'+k,num)
            t.addWidget(num);t.addWidget(_label(name,'muted'));self.dashboard_kpi.addWidget(tile,1)
        v.addLayout(self.dashboard_kpi,1)
        helpbox=_panel();h=QVBoxLayout(helpbox);h.setContentsMargins(20,18,20,18)
        h.addWidget(_label('Geometria bez zewnętrznego CAD','section'))
        h.addWidget(_label('Podgląd 3D działa w aplikacji. Dokładność porównania zapewnia silnik Open CASCADE; widok 3D wykorzystuje siatkę VTK.','muted'))
        h.addWidget(_label('STEP może zawierać kolory, ale ZW3D i CADbro mogą interpretować style inaczej. Wynik zawiera diagnostykę kolorów.','muted'))
        v.addWidget(helpbox,1)
        v.addStretch(1)

    def _file_line(self,title,initial='',folder=False):
        col=QVBoxLayout();col.setSpacing(6);col.addWidget(_label(title,'muted'))
        row=QHBoxLayout();entry=QLineEdit(initial);entry.setClearButtonEnabled(True)
        btn=_button('Wybierz…')
        def pick():
            path=QFileDialog.getExistingDirectory(self,'Wybierz folder',entry.text()) if folder else QFileDialog.getOpenFileName(self,'Otwórz STEP',entry.text(),'Model STEP (*.step *.stp)')[0]
            if path:entry.setText(path)
        btn.clicked.connect(pick)
        row.addWidget(entry,1);row.addWidget(btn);col.addLayout(row)
        return col,entry

    def build_compare(self,a,b):
        v=self.top('compare','Porównanie modeli','Dokładna analiza B-Rep z podglądem wyników w aplikacji')
        p=_panel();pl=QVBoxLayout(p);pl.setContentsMargins(22,19,22,19);pl.setSpacing(15)
        r,self.file_a=self._file_line('MODEL A · wersja poprzednia',a);pl.addLayout(r)
        r,self.file_b=self._file_line('MODEL B · wersja nowa',b);pl.addLayout(r)
        r,self.file_out=self._file_line('KATALOG WYNIKÓW',str(self.result_dir),True);pl.addLayout(r)
        line=QHBoxLayout();line.setSpacing(15)
        line.addWidget(_label('Tolerancja [mm]','muted'))
        self.tolerance=QLineEdit('0,01');self.tolerance.setMaximumWidth(100);line.addWidget(self.tolerance)
        line.addWidget(_label('Gęstość [kg/m³]','muted'))
        self.density=QLineEdit('7850');self.density.setMaximumWidth(112);line.addWidget(self.density)
        line.addWidget(_label('STEP:','muted'))
        self.schema=QComboBox();self.schema.addItems(['AP214IS','AP242DIS']);self.schema.setCurrentText(self.settings.get('step_schema','AP214IS'));line.addWidget(self.schema)
        line.addStretch();pl.addLayout(line)
        opt=QHBoxLayout();opt.setSpacing(16)
        self.write_step=QCheckBox('Kolorowy STEP');self.write_step.setChecked(True);opt.addWidget(self.write_step)
        self.make_diff=QCheckBox('Dokładne różnice materiału (wolniej)');opt.addWidget(self.make_diff)
        opt.addStretch();pl.addLayout(opt)
        v.addWidget(p,4)
        bar=QHBoxLayout()
        self.btn_compare=_button('▶  Rozpocznij porównanie',self.start_compare,'primary');bar.addWidget(self.btn_compare)
        self.btn_cancel=_button('Anuluj',self.cancel);self.btn_cancel.setEnabled(False);bar.addWidget(self.btn_cancel)
        bar.addStretch();bar.addWidget(_button('⇄ Zamień A i B',self.swap_models))
        v.addLayout(bar)
        self.progress=QProgressBar();self.progress.setRange(0,100);self.progress.setValue(0);self.progress.setMaximumHeight(9);v.addWidget(self.progress)
        self.log=QTextEdit();self.log.setReadOnly(True);self.log.setPlaceholderText('Tutaj pojawią się informacje o postępie analizy…')
        self.log.setMaximumHeight(175);v.addWidget(self.log,2)
        self.status=_label('Gotowy do analizy','muted');v.addWidget(self.status)

    def build_viewer(self):
        v=self.top('viewer','Podgląd 3D','Obracaj, przybliżaj i oglądaj geometrię bez ZW3D i CADbro')
        toolbar=QHBoxLayout();toolbar.addWidget(_label('Model:','muted'))
        self.viewer_model=QComboBox()
        self.viewer_model.addItems(['Wynik kolorowy','Model A','Model B','Wybierz STEP…'])
        self.viewer_model.setMinimumWidth(190);toolbar.addWidget(self.viewer_model)
        toolbar.addWidget(_label('Szczegółowość:','muted'))
        self.viewer_quality=QComboBox();self.viewer_quality.addItems(['szybka','normalna','dokladna']);self.viewer_quality.setCurrentIndex(1)
        toolbar.addWidget(self.viewer_quality)
        self.mesh_button=_button('Załaduj model 3D',self.start_mesh,'primary');toolbar.addWidget(self.mesh_button)
        toolbar.addStretch()
        v.addLayout(toolbar)
        frame=_panel();frame.setMinimumHeight(300)
        fl=QVBoxLayout(frame);fl.setContentsMargins(8,8,8,8)
        self.vtk_host=QWidget();self.vtk_layout=QVBoxLayout(self.vtk_host);self.vtk_layout.setContentsMargins(0,0,0,0)
        self.viewer_hint=_label('◈  Wybierz model i kliknij „Załaduj model 3D”')
        self.viewer_hint.setAlignment(Qt.AlignCenter);self.vtk_layout.addWidget(self.viewer_hint)
        fl.addWidget(self.vtk_host,1)
        v.addWidget(frame,1)
        self.viewer_message=_label('Podgląd tworzy uproszczoną siatkę całego modelu. Analiza B-Rep pozostaje dokładna.','muted')
        v.addWidget(self.viewer_message)

    def build_results(self):
        v=self.top('results','Wyniki porównania','Wybierz zmianę i otwórz kolorowy podgląd 3D')
        self.results_kpis=QHBoxLayout();self.results_numbers={}
        for key,name in [('SAME','Bez zmian'),('CHANGED','Zmienione'),('ADDED','Nowe'),('MOVED','Przesunięte'),('REMOVED','Usunięte')]:
            card=_panel();l=QVBoxLayout(card);l.setContentsMargins(13,12,13,12)
            t=_label('—','kpi');l.addWidget(t);l.addWidget(_label(name,'muted'));self.results_numbers[key]=t
            self.results_kpis.addWidget(card)
        v.addLayout(self.results_kpis)
        line=QHBoxLayout();line.addWidget(_label('Szukaj:','muted'))
        self.filter_results=QLineEdit();self.filter_results.setPlaceholderText('Nazwa części, opis zmiany…');line.addWidget(self.filter_results,1)
        self.filter_results.textChanged.connect(self.apply_filter)
        self.only_changed=QCheckBox('Tylko zmiany');self.only_changed.toggled.connect(self.apply_filter)
        line.addWidget(self.only_changed);v.addLayout(line)
        self.table=QTableWidget(0,5);self.table.setHorizontalHeaderLabels(['Rodzaj','Nazwa A','Nazwa B','Przesunięcie [mm]','Uwagi'])
        self.table.setAlternatingRowColors(True);self.table.setSortingEnabled(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(4,QHeaderView.Stretch)
        self.table.setColumnWidth(0,165);self.table.setColumnWidth(1,170);self.table.setColumnWidth(2,170);self.table.setColumnWidth(3,140)
        v.addWidget(self.table,1)
        btn=QHBoxLayout();btn.addWidget(_button('◈  Podgląd 3D',lambda:self.navigate('viewer'),'primary'))
        btn.addWidget(_button('Raport HTML',lambda:self.open_result('RAPORT.html')))
        btn.addWidget(_button('Kolorowy STEP',lambda:self.open_result('POROWNANIE_KOLORY.step')))
        btn.addStretch();btn.addWidget(_button('Folder wyników',self.open_folder))
        v.addLayout(btn)

    def build_mass(self):
        v=self.top('mass','Masa części','Obliczanie masy jednego modelu — bez porównywania dwóch plików')
        p=_panel();pl=QVBoxLayout(p);pl.setContentsMargins(22,20,22,20);pl.setSpacing(16)
        r,self.mass_file=self._file_line('PLIK MODELU STEP / STP');pl.addLayout(r)
        row=QHBoxLayout();row.addWidget(_label('Gęstość [kg/m³]','muted'))
        self.mass_density=QLineEdit('7850');self.mass_density.setMaximumWidth(170);row.addWidget(self.mass_density);row.addStretch();pl.addLayout(row)
        row=QHBoxLayout();self.mass_go=_button('◉  Oblicz masy',self.start_mass,'primary');row.addWidget(self.mass_go)
        row.addWidget(_button('Raport HTML',lambda:self.open_result('RAPORT_MASY.html')));row.addWidget(_button('CSV do Excela',lambda:self.open_result('MASY_CZESCI.csv')));row.addStretch();pl.addLayout(row)
        v.addWidget(p)
        self.mass_summary=_label('Wczytaj pojedynczy STEP, aby otrzymać masy i BOM.','muted');v.addWidget(self.mass_summary)
        self.mass_table=QTableWidget(0,5)
        self.mass_table.setHorizontalHeaderLabels(['Część','Ilość','Objętość [mm³]','Masa szt. [kg]','Masa łączna [kg]'])
        self.mass_table.setAlternatingRowColors(True);self.mass_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.mass_table.verticalHeader().setVisible(False)
        v.addWidget(self.mass_table,1)

    def build_settings(self):
        v=self.top('settings','Ustawienia','Motyw aplikacji, własne kolory zmian oraz eksportu STEP')
        p=_panel();pl=QVBoxLayout(p);pl.setContentsMargins(22,18,22,18)
        pl.addWidget(_label('Wygląd aplikacji','section'))
        row=QHBoxLayout();row.addWidget(_label('Motyw:','muted'))
        self.theme_select=QComboBox();self.theme_select.addItems(['ciemny','jasny']);self.theme_select.currentTextChanged.connect(self.set_theme)
        row.addWidget(self.theme_select);row.addStretch();pl.addLayout(row)
        pl.addSpacing(12);pl.addWidget(_label('Kolory porównania','section'))
        self.color_buttons={}
        for status,name in [('SAME','Bez zmian'),('CHANGED','Zmienione'),('ADDED','Nowe'),('MOVED','Przesunięte'),('REMOVED','Usunięte'),('UNCERTAIN','Do sprawdzenia')]:
            row=QHBoxLayout();row.addWidget(_label(name));row.addStretch()
            btn=_button('Zmień kolor',lambda checked=False,s=status:self.change_color(s))
            self.color_buttons[status]=btn;row.addWidget(btn);pl.addLayout(row)
        pl.addSpacing(8)
        pl.addWidget(_button('Przywróć domyślne kolory',self.reset_colors,'subtle'))
        v.addWidget(p);v.addStretch()

    def navigate(self,key):
        self.stack.setCurrentWidget(self.pages[key]);self.current_page=key
        for k,b in self.nav.items():
            b.setProperty('active',str(k==key).lower());b.style().unpolish(b);b.style().polish(b)

    def set_theme(self,name,persist=True):
        self.settings['motyw']=name
        self.root.setStyleSheet(theme_qss(name=='jasny'))
        self.theme_select.blockSignals(True);self.theme_select.setCurrentText(name);self.theme_select.blockSignals(False)
        self.update_color_buttons()
        if persist:save_settings(self.settings)

    def toggle_theme(self):self.set_theme('jasny' if self.settings['motyw']=='ciemny' else 'ciemny')
    def update_color_buttons(self):
        for key,b in self.color_buttons.items():
            color=self.settings['kolory'].get(key,COLORS[key]);b.setStyleSheet(f'border-left:11px solid {color};')
    def change_color(self,key):
        color=QColorDialog.getColor(QColor(self.settings['kolory'].get(key,COLORS[key])),self,'Wybierz kolor')
        if color.isValid():
            self.settings['kolory'][key]=color.name().upper()
            if key=='SAME':self.settings['kolory']['RENAMED']=color.name().upper()
            self.update_color_buttons();save_settings(self.settings)
    def reset_colors(self):self.settings['kolory']=dict(COLORS);self.update_color_buttons();save_settings(self.settings)
    def show_about(self):
        QMessageBox.information(self,'O programie','DS Compare\nWersja 3.7\nAutor: Szymczyk Damian\n'
                'Analiza geometrii: Open CASCADE\nPodgląd 3D: VTK\nInterfejs: Qt')
    def swap_models(self):a=self.file_a.text();self.file_a.setText(self.file_b.text());self.file_b.setText(a)

    def _numeric(self,text,minimum,maximum,label):
        try:n=float(text.replace(',','.'))
        except ValueError:raise ValueError(f'{label}: podaj liczbę')
        if not minimum<n<=maximum:raise ValueError(f'{label}: wartość poza zakresem')
        return n

    def start_compare(self):
        try:
            a,b=Path(self.file_a.text()),Path(self.file_b.text())
            if not a.is_file() or not b.is_file():raise ValueError('Wybierz dwa istniejące pliki STEP')
            tol=self._numeric(self.tolerance.text(),0,1,'Tolerancja')
            rho=self._numeric(self.density.text(),0,25000,'Gęstość')
            folder=Path(self.file_out.text());folder.mkdir(parents=True,exist_ok=True)
        except (ValueError,OSError) as exc:QMessageBox.warning(self,'Dane wejściowe',str(exc));return
        colors={k:[int(v[i:i+2],16)/255 for i in (1,3,5)] for k,v in self.settings['kolory'].items()}
        args=['--worker','compare','--a',str(a),'--b',str(b),'--output',str(folder),
              '--tolerance',str(tol),'--density',str(rho),'--schema',self.schema.currentText(),'--palette',json.dumps(colors)]
        if self.write_step.isChecked():args.append('--generate-step')
        if self.make_diff.isChecked():args.append('--diff-step')
        self.settings['ostatni_wynik']=str(folder);self.settings['step_schema']=self.schema.currentText();save_settings(self.settings)
        self.file_a.setText(str(a));self.file_b.setText(str(b))
        self.launch_worker('compare',args,folder)

    def start_mass(self):
        try:
            step=Path(self.mass_file.text());rho=self._numeric(self.mass_density.text(),0,25000,'Gęstość')
            if not step.is_file():raise ValueError('Wskaż istniejący model STEP')
        except ValueError as exc:QMessageBox.warning(self,'Masa części',str(exc));return
        folder=Path(self.file_out.text())/'Masa_czesci'
        self.launch_worker('mass',['--worker','mass','--input',str(step),'--output',str(folder),'--density',str(rho)],folder)

    def start_mesh(self):
        idx=self.viewer_model.currentIndex()
        if idx==0:step=self.result_dir/'POROWNANIE_KOLORY.step'
        elif idx==1:step=Path(self.file_a.text())
        elif idx==2:step=Path(self.file_b.text())
        else:step=Path(QFileDialog.getOpenFileName(self,'Wskaż plik STEP','','STEP (*.step *.stp)')[0])
        if not step.is_file():QMessageBox.warning(self,'Podgląd','Brak pliku STEP. Wybierz model lub wykonaj porównanie.');return
        import hashlib
        identifier=hashlib.sha1((str(step.resolve())+str(step.stat().st_mtime_ns)+self.viewer_quality.currentText()).encode()).hexdigest()[:12]
        folder=self.result_dir/'_sceny_3d'/identifier
        cached=folder/'SCENA_3D.npz'
        if cached.exists():self.render_vtk(cached);return
        args=['--worker','mesh','--input',str(step),'--output',str(folder),'--quality',self.viewer_quality.currentText()]
        self.launch_worker('mesh',args,folder)

    def launch_worker(self,kind,args,folder):
        if self.process and self.process.state()!=QProcess.NotRunning:
            QMessageBox.information(self,'Trwa analiza','Najpierw zakończ lub anuluj aktualne zadanie.');return
        folder.mkdir(parents=True,exist_ok=True)
        self.worker_kind=kind;self.worker_dir=folder;self.worker_position=0
        self.status.setText('Trwa zadanie: '+kind);self.progress.setRange(0,0)
        self.btn_compare.setEnabled(False);self.mass_go.setEnabled(False);self.mesh_button.setEnabled(False)
        self.btn_cancel.setEnabled(True)
        self.log.clear()
        self.process=QProcess(self)
        self.process.finished.connect(self.worker_finished)
        self.process.errorOccurred.connect(lambda err:self.log.append('Proces: '+str(err)))
        if getattr(sys,'frozen',False):
            self.process.start(sys.executable,args)
        else:
            self.process.start(sys.executable,[str(Path(__file__).resolve().parents[1]/'DSCompareV3.py'),*args])
        if not hasattr(self,'worker_timer'):
            self.worker_timer=QTimer(self);self.worker_timer.timeout.connect(self.read_progress)
        self.worker_timer.start(250)

    def read_progress(self):
        if not self.worker_dir:return
        path=self.worker_dir/'_POSTEP_V37.jsonl'
        if not path.exists():return
        try:
            with path.open('r',encoding='utf-8') as stream:
                stream.seek(self.worker_position)
                lines=stream.readlines();self.worker_position=stream.tell()
            for line in lines:
                try:msg=json.loads(line)['tekst']
                except (ValueError,KeyError):continue
                self.log.append(msg);self.status.setText(msg)
                if self.worker_kind=='mesh':self.viewer_message.setText(msg)
        except (OSError,UnicodeError):pass

    def worker_finished(self,code,status):
        self.read_progress();self.worker_timer.stop()
        self.progress.setRange(0,100);self.progress.setValue(100 if code==0 else 0)
        for button in (self.btn_compare,self.mass_go,self.mesh_button):button.setEnabled(True)
        self.btn_cancel.setEnabled(False)
        result=self.worker_dir/'_WYNIK_V37.json'
        try:data=json.loads(result.read_text(encoding='utf-8'))
        except (OSError,ValueError):
            QMessageBox.critical(self,'Błąd','Proces zakończył się bez raportu. Sprawdź dziennik.')
            return
        if not data.get('ok'):
            QMessageBox.critical(self,'Błąd analizy',data.get('error','Nieznany błąd')[-1800:]);return
        self.status.setText('Zakończono pomyślnie')
        if self.worker_kind=='compare':
            self.result_dir=Path(data['folder']);self.load_summary();self.navigate('results')
            if data.get('blad_step'):
                QMessageBox.warning(self,'Ostrzeżenie STEP',str(data['blad_step']))
        elif self.worker_kind=='mass':
            s=data['podsumowanie'];self.mass_summary.setText(
                f"Brył: {s['liczba_bryl']}   •   Pozycji: {s['liczba_pozycji']}   •   Masa łączna: {s['masa_calosci_kg']:.3f} kg".replace('.',','))
            self.fill_mass_table(self.worker_dir/'MASY_CZESCI.csv')
        else:self.render_vtk(self.worker_dir/'SCENA_3D.npz')

    def cancel(self):
        if self.process and self.process.state()!=QProcess.NotRunning:
            self.process.kill();self.status.setText('Przerwano — proces obliczeniowy zatrzymany')

    def load_summary(self):
        summary=self.result_dir/'PODSUMOWANIE.json'
        if not summary.is_file():return
        try:content=json.loads(summary.read_text(encoding='utf-8'));statuses=content['statuses']
        except (OSError,ValueError,KeyError):return
        for key,value in [('SAME',statuses.get('SAME',0)+statuses.get('RENAMED',0)),
                          ('CHANGED',statuses.get('CHANGED',0)+statuses.get('MOVED',0)),
                          ('ADDED',statuses.get('ADDED',0)),('REMOVED',statuses.get('REMOVED',0))]:
            getattr(self,'kpi_'+key).setText(str(value))
        for key,lbl in self.results_numbers.items():
            lbl.setText(str(statuses.get(key,0)+(statuses.get('RENAMED',0) if key=='SAME' else 0)))
        path=self.result_dir/'ZMIANY.csv'
        if not path.exists():return
        with path.open('r',encoding='utf-8-sig',newline='') as stream:rows=list(csv.DictReader(stream,delimiter=';'))
        self.table.setSortingEnabled(False);self.table.setRowCount(len(rows))
        for i,row in enumerate(rows):
            vals=[row.get('Rodzaj zmiany',''),row.get('Nazwa A',''),row.get('Nazwa B',''),
                  row.get('Przesunięcie środka [mm]',''),row.get('Uwagi','')]
            for k,val in enumerate(vals):
                if val.startswith('="') and val.endswith('"'):val=val[2:-1]
                item=QTableWidgetItem(val)
                if k==0:
                    c='#58C8B1' if 'Bez zmian' in val else '#F6AF67' if 'Usuni' in val else '#C2B4FC'
                    item.setForeground(QColor(c))
                self.table.setItem(i,k,item)
        self.table.setSortingEnabled(True);self.apply_filter()

    def apply_filter(self,*_):
        target=self.filter_results.text().casefold().strip()
        for i in range(self.table.rowCount()):
            values=[self.table.item(i,j).text() if self.table.item(i,j) else '' for j in range(self.table.columnCount())]
            show=(not target or any(target in v.casefold() for v in values)) and (
                not self.only_changed.isChecked() or 'Bez zmian' not in values[0])
            self.table.setRowHidden(i,not show)

    def fill_mass_table(self,path):
        with path.open('r',encoding='utf-8-sig',newline='') as stream:rows=list(csv.DictReader(stream,delimiter=';'))
        self.mass_table.setRowCount(len(rows))
        keys=['Nazwa części','Ilość','Objętość jednej sztuki [mm³]','Masa jednej sztuki [kg]','Masa łączna [kg]']
        for i,row in enumerate(rows):
            for j,k in enumerate(keys):self.mass_table.setItem(i,j,QTableWidgetItem(row.get(k,'')))

    def open_result(self,name):
        path=self.result_dir/name
        if not path.exists() and name in ('RAPORT_MASY.html','MASY_CZESCI.csv'):
            path=Path(self.file_out.text())/'Masa_czesci'/name
        if not path.exists():QMessageBox.warning(self,'Nie znaleziono pliku',str(path));return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
    def open_folder(self):QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.result_dir)))

    def render_vtk(self,path):
        try:
            import os
            os.environ.setdefault('QT_API','pyside6')
            import numpy as np
            import vtkmodules.vtkRenderingOpenGL2
            import vtkmodules.vtkInteractionStyle
            from vtkmodules.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor
            from vtkmodules.vtkRenderingCore import vtkRenderer,vtkPolyDataMapper,vtkActor
            from vtkmodules.vtkCommonDataModel import vtkPolyData,vtkCellArray
            from vtkmodules.vtkCommonCore import vtkPoints
            from vtkmodules.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray
            arr=np.load(path,allow_pickle=False)
            vertex=arr['vertices'];offset=arr['offsets'];colors=arr['colors']
            if not self.viewer_ready:
                self.viewer_hint.hide()
                self.vtk_widget=QVTKRenderWindowInteractor(self.vtk_host)
                self.vtk_layout.addWidget(self.vtk_widget,1)
                self.renderer=vtkRenderer();self.renderer.SetBackground(0.12,0.15,0.21)
                self.vtk_widget.GetRenderWindow().AddRenderer(self.renderer)
                self.interactor=self.vtk_widget.GetRenderWindow().GetInteractor()
                self.viewer_ready=True
            self.renderer.RemoveAllViewProps()
            groups={}
            for i,c in enumerate(colors):
                key=tuple(round(float(x),3) for x in c)
                groups.setdefault(key,[]).append(vertex[offset[i]:offset[i+1]])
            for rgb,bodies in groups.items():
                xyz=np.concatenate(bodies).astype(np.float32)
                pts=vtkPoints();pts.SetData(numpy_to_vtk(xyz,deep=True))
                n=len(xyz)//3
                cells=np.arange(n*4,dtype=np.int64).reshape(n,4)
                cells[:,0]=3
                cells[:,1:]=np.arange(n*3,dtype=np.int64).reshape(n,3)
                tri=vtkCellArray();tri.SetCells(n,numpy_to_vtkIdTypeArray(cells.ravel(),deep=True))
                poly=vtkPolyData();poly.SetPoints(pts);poly.SetPolys(tri)
                mapper=vtkPolyDataMapper();mapper.SetInputData(poly)
                actor=vtkActor();actor.SetMapper(mapper);actor.GetProperty().SetColor(*rgb)
                actor.GetProperty().SetSpecular(0.18);actor.GetProperty().SetSpecularPower(18)
                self.renderer.AddActor(actor)
            self.renderer.ResetCamera()
            self.interactor.Initialize();self.vtk_widget.GetRenderWindow().Render()
            self.viewer_message.setText(f'Wyświetlono {len(offset)-1} brył · {len(vertex)//3:,} trójkątów · wszystkie bryły w pliku')
            self.navigate('viewer')
        except Exception as exc:
            QMessageBox.critical(self,'Podgląd 3D','Nie można wyświetlić modelu VTK: '+str(exc))

    def closeEvent(self,event):
        if self.process and self.process.state()!=QProcess.NotRunning:
            self.process.kill();self.process.waitForFinished(1000)
        save_settings(self.settings)
        event.accept()


def main(a='',b=''):
    app=QApplication.instance() or QApplication(sys.argv)
    app.setStyle('Fusion')
    w=Window(a,b);w.show()
    return app.exec()
