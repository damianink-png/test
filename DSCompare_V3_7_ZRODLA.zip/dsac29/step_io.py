"""STEPCAF load/save to keep STEP names and per-body colors. Lengths expected in mm."""
from __future__ import annotations
from dataclasses import dataclass
import re
from pathlib import Path
from OCP.STEPCAFControl import STEPCAFControl_Reader, STEPCAFControl_Writer
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.TDF import TDF_LabelSequence, TDF_Label
from OCP.TDataStd import TDataStd_Name
from OCP.XCAFDoc import XCAFDoc_DocumentTool, XCAFDoc_ColorType
from OCP.TopoDS import TopoDS_Shape
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE
from OCP.TopLoc import TopLoc_Location
from OCP.Quantity import Quantity_Color,Quantity_TOC_RGB
from OCP.IFSelect import IFSelect_RetDone
from .geometry import SolidInfo,describe


def _label_name(label: TDF_Label, default=''): 
    attr=TDataStd_Name()
    if label.FindAttribute(TDataStd_Name.GetID_s(),attr):
        txt=attr.Get().ToExtString().strip()
        if txt: return txt
    return default


_TECH_LABEL = re.compile(r"^(?:=>\s*)?(?:\[[0-9:.,;\s-]+\]|[0-9]+(?::[0-9]+)+)$")

def _real_name(label):
    return bool(label and not _TECH_LABEL.fullmatch(label.strip()) and
                label.strip().casefold() not in ('component','komponent','shape','solid'))


def _solids(shape: TopoDS_Shape):
    ex=TopExp_Explorer(shape, TopAbs_SOLID)
    while ex.More():
        yield ex.Current()
        ex.Next()


def _faces(shape: TopoDS_Shape):
    ex=TopExp_Explorer(shape,TopAbs_FACE)
    while ex.More():
        yield ex.Current()
        ex.Next()


def inspect_step_colors(path: str) -> dict:
    """Nie ufaj samemu sukcesowi zapisu: sprawdź kolory po ponownym imporcie XCAF."""
    from OCP.Quantity import Quantity_Color
    p=Path(path)
    document=TDocStd_Document(TCollection_ExtendedString('BinXCAF'))
    reader=STEPCAFControl_Reader()
    reader.SetNameMode(True);reader.SetColorMode(True)
    if reader.ReadFile(str(p))!=IFSelect_RetDone or not reader.Transfer(document):
        raise RuntimeError('Nie można ponownie odczytać wynikowego STEP')
    shape_tool=XCAFDoc_DocumentTool.ShapeTool_s(document.Main())
    colors=XCAFDoc_DocumentTool.ColorTool_s(document.Main())
    roots=TDF_LabelSequence();shape_tool.GetFreeShapes(roots)
    seen=[]; colored_labels=0;colored_faces=0
    def detect(lab):
        nonlocal colored_labels,colored_faces
        color=Quantity_Color()
        if colors.GetColor_s(lab,XCAFDoc_ColorType.XCAFDoc_ColorSurf,color) or colors.GetColor_s(lab,XCAFDoc_ColorType.XCAFDoc_ColorGen,color):
            colored_labels+=1
            seen.append(tuple(round(x,4) for x in [color.Red(),color.Green(),color.Blue()]))
        sub=TDF_LabelSequence()
        shape_tool.GetSubShapes_s(lab,sub)
        for j in range(1,sub.Length()+1):
            facecol=Quantity_Color()
            if colors.GetColor_s(sub.Value(j),XCAFDoc_ColorType.XCAFDoc_ColorSurf,facecol):
                colored_faces+=1
        comps=TDF_LabelSequence()
        if shape_tool.GetComponents_s(lab,comps):
            for i in range(1,comps.Length()+1):detect(comps.Value(i))
    for idx in range(1,roots.Length()+1):detect(roots.Value(idx))
    # Diagnostyka zapisanych rekordów stylu STEP, a nie tylko wyglądu CADbro.
    with p.open('rb') as inp:data=inp.read()
    result={'liczba_etykiet':roots.Length(),
            'pokolorowane_etykiety':colored_labels,
            'pokolorowane_powierzchnie':colored_faces,
            'kolory_wczytane_rgb':sorted(set(seen)),
            'rekordy_kolorow_step':data.count(b'COLOUR_RGB('),
            'rekordy_stylow_step':data.count(b'STYLED_ITEM(')}
    if not result['rekordy_kolorow_step'] or not result['rekordy_stylow_step']:
        raise RuntimeError('STEP został zapisany bez rekordów koloru — nie uznajemy eksportu za udany')
    if not (colored_labels or colored_faces):
        raise RuntimeError('Po ponownym wczytaniu STEP nie wykryto kolorów przypisanych do brył/powierzchni')
    return result

def load_step(path: str, max_solids: int = 1000, progress=None) -> list[SolidInfo]:
    p=Path(path)
    if not p.is_file(): raise FileNotFoundError(str(path))
    if p.suffix.lower() not in ('.stp','.step'): raise ValueError('Prototyp B-Rep wymaga STEP/STP (eksport z ZW3D).')
    document=TDocStd_Document(TCollection_ExtendedString('BinXCAF'))
    reader=STEPCAFControl_Reader();reader.SetNameMode(True);reader.SetColorMode(True)
    if reader.ReadFile(str(p))!=IFSelect_RetDone: raise ValueError('Nie można odczytać STEP: '+str(p))
    if not reader.Transfer(document): raise ValueError('Błąd transferu STEP: '+str(p))
    tool=XCAFDoc_DocumentTool.ShapeTool_s(document.Main())
    roots=TDF_LabelSequence();tool.GetFreeShapes(roots)
    out=[]
    def add_shape(shape,name,hierarchy):
        solids=list(_solids(shape))
        for k,s in enumerate(solids,1):
            if len(out)>=max_solids: raise ValueError(f'Limit bezpieczenstwa: {max_solids} bryl na plik')
            name2=name if len(solids)==1 else f'{name}#{k}'
            info=describe(s,name2,hierarchy+'/'+name2,str(p))
            out.append(info)
            if progress and len(out)%10==0: progress(f'{p.name}: wczytano {len(out)} brył')
    def walk(lab: TDF_Label, parent_loc: TopLoc_Location, hierarchy:str, depth:int):
        if depth>32: raise ValueError('Zbyt głębokie podzłożenie (>32 poziomów)')
        is_ref=tool.IsReference_s(lab)
        actual=TDF_Label()
        if is_ref and tool.GetReferredShape_s(lab,actual):
            target=actual
            loc=parent_loc.Multiplied(tool.GetLocation_s(lab))
        else:target=lab;loc=parent_loc
        # ZW3D eksportuje czasem referencję jako =>[0:1:1:102].
        # To znacznik OCAF, nie nazwa części; preferuj nazwę docelowego kształtu.
        local_name=_label_name(lab,'')
        target_name=_label_name(target,'')
        label_name=local_name if _real_name(local_name) else target_name
        if not _real_name(label_name):
            meaningful=[v for v in reversed(hierarchy.split('/')) if _real_name(v)]
            label_name=meaningful[0] if meaningful else f'Element_{len(out)+1:04d}'
        fullname=f'{hierarchy}/{label_name}' if hierarchy else label_name
        comps=TDF_LabelSequence()
        if tool.GetComponents_s(target,comps) and comps.Length()>0:
            for idx in range(1,comps.Length()+1): walk(comps.Value(idx),loc,fullname,depth+1)
        else:
            sh=tool.GetShape_s(target)
            if sh.IsNull():return
            # Apply parent transform to shape if necessary. A shape may have its own location.
            if not loc.IsIdentity(): sh=sh.Moved(loc)
            add_shape(sh,label_name,fullname)
    for i in range(1,roots.Length()+1): walk(roots.Value(i),TopLoc_Location(),'',0)
    if not out: raise ValueError('W pliku STEP nie znaleziono zadnej bryly zamknietej (SOLID).')
    if progress:progress(f'{p.name}: gotowe {len(out)} brył')
    return out


COLORS={'SAME':(0.15,0.68,0.26),'RENAMED':(0.15,0.68,0.26),
        'MOVED':(0.40,0.35,0.83),'CHANGED':(0.40,0.35,0.83),
        'ADDED':(0.40,0.35,0.83),'REMOVED':(0.90,0.56,0.24),
        'UNCERTAIN':(0.6,0.64,0.7)}

def export_colored_step(path: str, records, a_parts, b_parts,
                        colors: dict | None = None):
    colors={**COLORS,**(colors or {})}
    doc=TDocStd_Document(TCollection_ExtendedString('BinXCAF'))
    tool=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
    color_tool=XCAFDoc_DocumentTool.ColorTool_s(doc.Main())
    present=[]
    for r in records:
        if r.b_index is not None:
            present.append((b_parts[r.b_index],r.status,'B'))
        elif r.a_index is not None and r.status=='REMOVED':
            present.append((a_parts[r.a_index],'REMOVED','A'))
    for part,status,model in present:
        label=tool.AddShape(part.shape,False)
        TDataStd_Name.Set_s(label,TCollection_ExtendedString(f'[{status}] {part.name} [{model}]'))
        rgb=colors.get(status,COLORS['UNCERTAIN'])
        c=Quantity_Color(*[float(x) for x in rgb],Quantity_TOC_RGB)
        color_tool.SetColor(label,c,XCAFDoc_ColorType.XCAFDoc_ColorGen)
        color_tool.SetColor(label,c,XCAFDoc_ColorType.XCAFDoc_ColorSurf)
        # Niektóre przeglądarki STEP (m.in. zależnie od trybu w CADbro)
        # ignorują kolor samego SOLID. Nadajemy więc ten sam kolor również
        # powierzchniom, aby eksport AP214/AP242 miał per-face STYLED_ITEM.
        for face in _faces(part.shape):
            sub=tool.AddSubShape(label,face)
            if not sub.IsNull():
                color_tool.SetColor(sub,c,XCAFDoc_ColorType.XCAFDoc_ColorSurf)
    # For legacy CAD readers (including older ZW3D builds), AP214 is the
    # compatibility default. AP242 can be selected in Settings per project.
    import os
    from OCP.Interface import Interface_Static
    schema=os.getenv('DSCOMPARE_STEP_SCHEMA','AP214IS')
    if schema not in ('AP214IS','AP242DIS'):
        schema='AP214IS'
    Interface_Static.SetCVal_s('write.step.schema',schema)
    writer=STEPCAFControl_Writer();writer.SetNameMode(True);writer.SetColorMode(True)
    if not writer.Transfer(doc): raise RuntimeError('Eksport STEP: transfer geometrii nie powiodl sie')
    if writer.Write(str(path))!=IFSelect_RetDone:raise RuntimeError('Nie udało się zapisać modelu STEP')


def export_differences_step(path: str, records, a_parts, b_parts,
                            tolerance: float = 0.01, progress=None,
                            max_changed: int = 60, colors: dict | None = None):
    """Second STEP: highlight *only* changed material (A\\B orange, B\\A violet).

    For ADDED/REMOVED include the whole new/old body. For MOVED include
    ghost old + new placement; no ghosts in the main comparison STEP.
    CHANGED requires two real Boolean cuts, executed only for this export.
    """
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
    from OCP.BRepGProp import BRepGProp
    from OCP.GProp import GProp_GProps
    from OCP.TopExp import TopExp_Explorer
    from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE

    changed = [r for r in records if r.status == 'CHANGED']
    if len(changed) > max_changed:
        raise ValueError(f'Model ma {len(changed)} zmienionych par. Szczegółowa geometria różnic '
                         f'ograniczona do {max_changed}; rozważ porównanie podzłożenia.')

    doc=TDocStd_Document(TCollection_ExtendedString('BinXCAF'))
    tool=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
    color_tool=XCAFDoc_DocumentTool.ColorTool_s(doc.Main())
    palette={**COLORS, **(colors or {})}
    added_rgb=tuple(palette['ADDED']); removed_rgb=tuple(palette['REMOVED'])
    n=0; deltas=[]; errors=[]

    def insert(shape, name, rgb):
        nonlocal n
        exp=TopExp_Explorer(shape,TopAbs_SOLID)
        if not exp.More():return 0.0
        props=GProp_GProps();BRepGProp.VolumeProperties_s(shape,props)
        volume=max(0.0,float(props.Mass()))
        if volume <= max(tolerance**3,1e-5):return 0.0
        label=tool.AddShape(shape,False)
        TDataStd_Name.Set_s(label,TCollection_ExtendedString(name))
        col=Quantity_Color(*rgb,Quantity_TOC_RGB)
        color_tool.SetColor(label,col,XCAFDoc_ColorType.XCAFDoc_ColorGen)
        color_tool.SetColor(label,col,XCAFDoc_ColorType.XCAFDoc_ColorSurf)
        n+=1
        return volume

    def cut_shape(a,b):
        op=BRepAlgoAPI_Cut(a,b)
        op.SetFuzzyValue(max(tolerance/100.,1e-6))
        op.Build()
        if not op.IsDone():raise RuntimeError('Boolean CUT not completed')
        return op.Shape()

    for num,r in enumerate(records,1):
        old=a_parts[r.a_index] if r.a_index is not None else None
        new=b_parts[r.b_index] if r.b_index is not None else None
        if r.status in ('SAME','RENAMED','UNCERTAIN'):continue
        key=f'{num:04d}'
        if r.status=='ADDED':
            insert(new.shape,key+' NOWA: '+new.name,added_rgb)
        elif r.status=='REMOVED':
            insert(old.shape,key+' USUNIETA: '+old.name,removed_rgb)
        elif r.status=='MOVED':
            insert(old.shape,key+' POPRZEDNIE POLOZENIE: '+old.name,removed_rgb)
            insert(new.shape,key+' NOWE POLOZENIE: '+new.name,tuple(palette['MOVED']))
        elif r.status=='CHANGED':
            if progress:progress(f'Różnice B-Rep {len(deltas)+1}/{len(changed)}: {new.name}')
            try:
                va=insert(cut_shape(old.shape,new.shape),key+' USUNIETY MATERIAL: '+old.name,removed_rgb)
                vb=insert(cut_shape(new.shape,old.shape),key+' DODANY MATERIAL: '+new.name,tuple(palette['CHANGED']))
                deltas.append((old.name,new.name,round(va,5),round(vb,5)))
            except Exception as exc:
                errors.append(f'{new.path}: {exc}')
    if n:
        writer=STEPCAFControl_Writer();writer.SetNameMode(True);writer.SetColorMode(True)
        if not writer.Transfer(doc):raise RuntimeError('Transfer STEP różnic nie powiódł się')
        if writer.Write(str(path))!=IFSelect_RetDone:raise RuntimeError('Nie udało się zapisać STEP różnic')
    return {'written':n>0,'solids':n,'changes':deltas,'errors':errors}
