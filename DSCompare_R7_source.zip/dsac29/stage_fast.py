"""Atomic progress hand-off between Windows worker and Qt main window."""
from __future__ import annotations
import json, os, time, tempfile
from pathlib import Path


class StageWriter:
    def __init__(self,folder):
        self.path=Path(folder)/'_ETAPY.json'
        self.values={'step':'oczekuje','reports':'oczekuje','report_percent':0}
        self.errors=0

    def update(self,**changes):
        if all(self.values.get(k)==v for k,v in changes.items()):
            return
        self.values.update(changes)
        payload=json.dumps(self.values,ensure_ascii=False)
        # Never reuse a constant _ETAPY.json.tmp; two writers may collide.
        # tempfile.mkstemp creates a unique file in the same directory,
        # so os.replace stays atomic on Windows/NTFS.
        tmp=None
        try:
            fd,tmp=tempfile.mkstemp(prefix='_ETAPY_',suffix='.tmp',dir=str(self.path.parent))
            with os.fdopen(fd,'w',encoding='utf8') as stream:
                stream.write(payload)
            for attempt in range(5):
                try:
                    os.replace(tmp,self.path)
                    tmp=None
                    return
                except (PermissionError, OSError):
                    # A sharing violation is usually transient.
                    if attempt<4:time.sleep(0.035*(attempt+1))
            self.errors+=1
        except OSError:
            self.errors+=1
        finally:
            if tmp is not None:
                try:Path(tmp).unlink(missing_ok=True)
                except OSError:pass
        # No exception: early STEP status may not refresh, but the worker
        # still writes its real output and final report.
        return
