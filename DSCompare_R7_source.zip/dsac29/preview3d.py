"""Self-contained WebGL preview: visual colors, independent of STEP reader settings.

The preview is an approximation produced from B-Rep triangulation, not CAD-quality
geometry, and never substitutes for the original STEP geometry or the BOM.
"""
from __future__ import annotations
import base64
import json
from pathlib import Path
import numpy as np
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRep import BRep_Tool
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS
from OCP.TopAbs import TopAbs_FACE
from OCP.TopLoc import TopLoc_Location
from .step_io import COLORS


def _faces_meshed(shape, linear_deflection):
    tess = BRepMesh_IncrementalMesh(shape, linear_deflection, False, 0.5, True)
    tess.Perform()
    ex = TopExp_Explorer(shape, TopAbs_FACE)
    while ex.More():
        face = TopoDS.Face_s(ex.Current())
        loc = TopLoc_Location()
        triangulation = BRep_Tool.Triangulation_s(face, loc)
        if triangulation and triangulation.NbTriangles():
            transform = loc.Transformation()
            nodes = [None]
            for node in range(1, triangulation.NbNodes()+1):
                point = triangulation.Node(node).Transformed(transform)
                nodes.append((point.X(),point.Y(),point.Z()))
            reversed_face = int(face.Orientation()) == 1  # TopAbs_REVERSED
            for number in range(1,triangulation.NbTriangles()+1):
                indexes=triangulation.Triangle(number).Get()
                if reversed_face:indexes=indexes[::-1]
                yield (nodes[indexes[0]], nodes[indexes[1]], nodes[indexes[2]])
        ex.Next()


def create_preview(path, records, a_parts, b_parts, colors=None, max_triangles=300000, progress=None, old_alpha=0.4):
    """Offline comparison scene, both revisions, after global registration.

    Whole occurrences only: the triangle target never drops a solid.
    Coordinates are centered in double precision before packing float32.
    """
    from .step_io import REVISION_COLORS
    palette={**REVISION_COLORS,**(colors or {})}
    entries=[]
    for record in records:
        status=record.status
        if status in ('SAME','RENAMED'):
            if record.b_index is not None:entries.append((b_parts[record.b_index],'SAME','B',1.0))
            continue
        for role,index,parts in (('A',record.a_index,a_parts),('B',record.b_index,b_parts)):
            if index is None:continue
            key=(('MOVED_OLD' if role=='A' else 'MOVED') if status=='MOVED' else
                 (status+('_OLD' if role=='A' else '_NEW')) if status in ('CHANGED','UNCERTAIN') else
                 ('REMOVED' if role=='A' else 'ADDED'))
            entries.append((parts[index],key,role,old_alpha if role=='A' else 1.0))
    if not entries:raise ValueError('Podgląd 3D: brak brył do wyświetlenia.')
    entries.sort(key=lambda item: (item[1]=='SAME', item[2]!='A'))
    origin=np.mean([p.center for p,_,_,_ in entries],axis=0)
    packed=[];total=0;omitted=0
    for i,(part,key,role,alpha) in enumerate(entries):
        extent=max(float(v) for v in part.bbox)
        vertices=[]
        for triangle in _faces_meshed(part.shape,max(0.15,min(3.0,extent*0.003))):
            for point in triangle:vertices.extend(np.asarray(point,dtype=float)-origin)
        if not vertices:raise ValueError(f'Brak siatki części {part.name}; podgląd nie został opublikowany.')
        total+=len(vertices)//9
        packed.append({'status':key,'role':role,'rgb':list(palette[key]),'alpha':float(alpha),
                       'data':base64.b64encode(np.asarray(vertices,dtype='<f4').tobytes()).decode('ascii')})
        if progress and i%100==0:progress(f'Podgląd HTML: {i+1}/{len(entries)} wystąpień')
    if not packed:raise ValueError('Podgląd 3D: brak pełnych brył w limicie siatki.')
    info={'elementy':len(packed),'wszystkie':len(entries),'trojkaty':total,'pominiete':omitted,
          'ograniczony':False,'limit_trojkatow':max_triangles,'przekroczony_cel_siatki':total>max_triangles}
    template=Path(__file__).with_name('preview_template.html').read_text(encoding='utf-8')
    html=template.replace('/*__SCENE__*/',json.dumps(packed,separators=(',',':')))
    html=html.replace('/*__STATS__*/',json.dumps(info,ensure_ascii=False))
    path=Path(path);draft=path.with_suffix('.html.tmp');draft.write_text(html,encoding='utf-8');draft.replace(path)
    if progress:progress(f'Podgląd 3D: {len(packed)} wystąpień, {total} trójkątów; pominięto {omitted}')
    return info
