"""R11.9 simplified revision workspace, HiDPI action icons, dedicated settings."""
import json,sys,time,os
from pathlib import Path
from PySide6.QtCore import Qt,QSize,QPointF
from PySide6.QtGui import QColor,QPainter,QPen,QIcon,QPixmap,QGuiApplication
from PySide6.QtWidgets import (QSpinBox,QApplication,QWidget,QFrame,QLabel,QPushButton,QLineEdit,
 QVBoxLayout,QHBoxLayout,QGridLayout,QStackedWidget,QComboBox,QCheckBox,QSizePolicy,
 QProgressBar,QPlainTextEdit,QHeaderView,QStyledItemDelegate,QStyle,QAbstractItemView,QMenu,QFormLayout,QInputDialog,QMessageBox,QAbstractSpinBox,QDialog,QDialogButtonBox,QColorDialog)
from .gui45 import Window as BaseWindow,FileCard as BaseFileCard,button,table
from .icons_r119 import vector_icon,set_action

def icon(key):
 return vector_icon(key, '#4b85ff')

EXPORT_COLOR_CHOICES = (
 ('SAME', 'Bez zmian / zmiana nazwy', '#1fb852'),
 ('ADDED', 'Nowe elementy B', '#1f6ef2'),
 ('REMOVED', 'Usunięte elementy A', '#ff6114'),
 ('MOVED', 'Przesunięte — nowe B', '#7830c7'),
 ('MOVED_OLD', 'Przesunięte — stare A', '#cab0e6'),
 ('CHANGED_NEW', 'Zmodyfikowane — nowe B', '#1f6ef2'),
 ('CHANGED_OLD', 'Zmodyfikowane — stare A', '#ff6114'),
 ('UNCERTAIN_NEW', 'Nierozstrzygnięte — B', '#1f6ef2'),
 ('UNCERTAIN_OLD', 'Nierozstrzygnięte — A', '#ff6114'),
)

PALETTES={
 'Jasny':dict(bg='#f7f8fa',card='#ffffff',ink='#1b2430',muted='#687687',line='#dde3ea',accent='#2563eb',soft='#eaf1ff',field='#f3f5f8',hover='#e9edf3',green='#168953',orange='#b85814',blue='#2463eb',purple='#8353cf'),
 'Ciemny':dict(bg='#111316',card='#1b1e23',ink='#f1f3f5',muted='#9ca5af',line='#343940',accent='#b7c5d6',soft='#2b323c',field='#23272d',hover='#333943',green='#4dca8b',orange='#ffac70',blue='#78abf7',purple='#c198ff')}

def theme_style(p):
 return '''
 QWidget {background:BG;color:INK;font-family:"Segoe UI";font-size:13px;}
 QFrame#topbar,QFrame#card,QFrame#metric,QFrame#export {background:CARD;border:1px solid LINE;border-radius:10px;}
 QFrame#topbar {border-radius:0px;border-left:0;border-right:0;border-top:0;border-bottom:1px solid LINE;}
 QFrame#card,QFrame#export {border:1px solid LINE;border-radius:10px;}
 QFrame#metric {border:1px solid LINE;border-radius:10px;}
 QLabel {background:transparent;}
 QLabel#heading {font-size:20px;font-weight:650;} QLabel#sub {color:MUTED;}
 QLabel#brand {font-size:18px;font-weight:650;} QLabel#section {font-size:15px;font-weight:650;}
 QLabel#metric-name {font-size:12px;color:MUTED;}
 QFrame#actionbar {background:CARD;border:1px solid LINE;border-radius:10px;}
 QPushButton {background:FIELD;border:1px solid LINE;border-radius:8px;padding:7px 11px;min-height:22px;}
 QPushButton:hover {background:HOVER;border:1px solid ACCENT;}
 QPushButton:pressed {background:SOFT;border-color:ACCENT;}
 QPushButton:focus {border-color:ACCENT;}
 QPushButton:disabled {color:MUTED;background:FIELD;border-color:LINE;}
 QPushButton#primary {background:ACCENT;color:PRIMINK;border:1px solid ACCENT;font-weight:650;padding:8px 14px;border-radius:9px;}
 QPushButton#primary:hover {background:PRIMHOVER;color:PRIMINK;border-color:PRIMHOVER;}
 QPushButton#primary:pressed {background:SOFT;color:INK;}
 QPushButton#primary:disabled {background:SOFT;color:MUTED;border-color:LINE;}
 QPushButton#nav {background:transparent;border:1px solid transparent;border-radius:7px;padding:8px 14px;}
 QPushButton#nav:hover {background:HOVER;border-color:LINE;}
 QPushButton#nav:checked {background:SOFT;color:INK;border-bottom:2px solid ACCENT;}
 QPushButton#theme-toggle {background:transparent;border:1px solid LINE;border-radius:18px;padding:4px;min-width:30px;max-width:30px;min-height:30px;max-height:30px;}
 QPushButton#theme-toggle:hover {background:HOVER;border-color:ACCENT;}
 QPushButton#filter {padding:5px 8px;} QPushButton#filter:hover {background:HOVER;border-color:ACCENT;} QPushButton#filter:checked {background:SOFT;color:INK;border-color:ACCENT;}
 QLineEdit,QDoubleSpinBox,QSpinBox,QComboBox {background:FIELD;color:INK;border:1px solid LINE;border-radius:8px;padding:6px 9px;min-height:24px;selection-background-color:ACCENT;}
 QComboBox {padding-right:26px;}
 QComboBox:hover,QSpinBox:hover,QDoubleSpinBox:hover {border:1px solid ACCENT;background:HOVER;}
 QComboBox:on {border:1px solid ACCENT;border-bottom-left-radius:4px;border-bottom-right-radius:4px;}
 QComboBox::drop-down {width:26px;border:0;background:transparent;subcontrol-origin:padding;subcontrol-position:top right;}

 QComboBox QAbstractItemView {background:CARD;color:INK;border:1px solid LINE;outline:0;padding:5px;selection-background-color:SOFT;selection-color:INK;min-width:140px;}
 QComboBox QAbstractItemView::item {min-height:27px;padding:5px 9px;}
 QComboBox QAbstractItemView::item:hover {background:HOVER;}
 QComboBox:disabled {color:MUTED;border-color:LINE;background:FIELD;}
 
 QLineEdit:focus {border-color:ACCENT;}
 QStackedWidget {background:BG;}
 QTableWidget {background:CARD;alternate-background-color:FIELD;border:1px solid LINE;border-radius:10px;gridline-color:transparent;selection-background-color:SOFT;selection-color:INK;}
 QHeaderView::section {background:FIELD;color:INK;font-weight:600;padding:7px;border:0;border-bottom:1px solid LINE;}
 QPlainTextEdit {background:FIELD;border:1px solid LINE;border-radius:6px;color:MUTED;}
 QCheckBox {spacing:7px;padding:3px;} QProgressBar {border:0;background:LINE;border-radius:3px;max-height:5px;} QProgressBar::chunk {background:ACCENT;}
 QToolTip {background:CARD;color:INK;border:1px solid LINE;}
 '''.replace('PRIMHOVER',('#f5f7fa' if p['bg']=='#101113' else '#164fd3')).replace('PRIMINK',('#151719' if p['bg']=='#101113' else '#ffffff')).replace('BG',p['bg']).replace('CARD',p['card']).replace('INK',p['ink']).replace('MUTED',p['muted']).replace('LINE',p['line']).replace('ACCENT',p['accent']).replace('SOFT',p['soft']).replace('FIELD',p['field']).replace('HOVER',p['hover'])

def theme_icon(dark, stroke):
 """High-DPI, centered vector sun/moon. Icon indicates the TARGET mode."""
 from PySide6.QtGui import QPainterPath
 pix=QPixmap(48,48);pix.fill(Qt.transparent)
 p=QPainter(pix);p.setRenderHint(QPainter.Antialiasing)
 color=QColor(stroke)
 if dark:
  # Dark is active -> offer the light/sun appearance.
  p.setBrush(Qt.NoBrush);pen=QPen(color,3);pen.setCapStyle(Qt.RoundCap);p.setPen(pen)
  p.drawEllipse(QPointF(24,24),7.5,7.5)
  for a,b,c,d in [(24,4,24,11),(24,37,24,44),(4,24,11,24),(37,24,44,24),
                  (10,10,15,15),(33,33,38,38),(10,38,15,33),(33,15,38,10)]:
   p.drawLine(QPointF(a,b),QPointF(c,d))
 else:
  # Light is active -> offer a compact true crescent with no text/emoji.
  outer=QPainterPath();outer.addEllipse(QPointF(23,23),16,16)
  mask=QPainterPath();mask.addEllipse(QPointF(31,16),15,15)
  p.setPen(Qt.NoPen);p.fillPath(outer.subtracted(mask),color)
 p.end();pix.setDevicePixelRatio(2);return QIcon(pix)

class FileCard(BaseFileCard):
 """Compact two-line native source chooser, with no redundant 3D thumbnails."""
 def __init__(self,title,subtitle):
  QFrame.__init__(self);self.setObjectName('card');self.setAcceptDrops(True)
  layout=QVBoxLayout(self);layout.setContentsMargins(14,10,14,10);layout.setSpacing(6)
  heading=QLabel(title);heading.setObjectName('section');layout.addWidget(heading)
  row=QHBoxLayout();row.setSpacing(8)
  self.path=QLineEdit();self.path.setPlaceholderText('Wybierz STEP / STP lub Z3 z eksportem STEP obok')
  self.path.setAcceptDrops(False);self.path.textChanged.connect(self.changed.emit)
  self.path.textChanged.connect(lambda value:self.path.setToolTip(value))
  row.addWidget(self.path,1)
  self.choose_button=button('Wybierz…',self.choose)
  row.addWidget(self.choose_button);layout.addLayout(row)

class StatusDelegate(QStyledItemDelegate):
 def paint(self,painter,option,index):
  painter.save()
  status=index.data(Qt.UserRole);key={'SAME':'green','RENAMED':'green','ADDED':'blue','CHANGED':'blue','REMOVED':'orange','UNCERTAIN':'orange'}.get(status,'purple')
  win=self.parent().window();palette=PALETTES.get(win.theme.currentText(),PALETTES['Jasny']);color=QColor(palette[key]);background=QColor(color);background.setAlpha(28)
  if option.state & QStyle.State_Selected:painter.fillRect(option.rect,QColor(palette['soft']))
  rect=option.rect.adjusted(6,5,-6,-5);painter.setRenderHint(QPainter.Antialiasing);painter.setPen(Qt.NoPen);painter.setBrush(background);painter.drawRoundedRect(rect,5,5);painter.setPen(color);painter.drawText(rect,Qt.AlignCenter,option.fontMetrics.elidedText(index.data(),Qt.ElideRight,rect.width()-6));painter.restore()

class Window(BaseWindow):
 generate_thumbnails=False
 def __init__(self,a='',b=''):
  super().__init__(a,b)
  self.setWindowTitle('DSCompare — porównanie rewizji')
  app_root=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parents[1]))
  self.app_icon=QIcon(str(app_root/'assets'/'DSCompare.ico'))
  if not self.app_icon.isNull():
   self.setWindowIcon(self.app_icon)
   QApplication.instance().setWindowIcon(self.app_icon)
  self.zw3d_body_colors=True
  screen=QGuiApplication.primaryScreen();geo=screen.availableGeometry() if screen else None
  sw=geo.width() if geo else 1366;sh=geo.height() if geo else 768
  self.compact=(sh<880 or sw<1320)
  self.setMinimumSize(min(900,max(760,sw-12)),min(610,max(540,sh-12)))
  self.resize(min(1450,max(760,sw-24)),min(860,max(540,sh-24)))
  old=self.takeCentralWidget();self.stack.setParent(None)
  central=QWidget();layout=QVBoxLayout(central);layout.setContentsMargins(0,0,0,0);layout.setSpacing(0)
  bar=QFrame();bar.setObjectName('topbar');bl=QHBoxLayout(bar);bl.setContentsMargins(18,8,18,8)
  brand_icon=QLabel()
  brand_icon.setFixedSize(28,28)
  brand_icon.setPixmap(self.app_icon.pixmap(26,26))
  brand_icon.setToolTip('DSCompare')
  bl.addWidget(brand_icon)
  brand=QLabel('DSCompare');brand.setObjectName('brand');bl.addWidget(brand);bl.addStretch()
  for key,label in [('compare','Porównanie'),('mass','Masa części'),('settings','Ustawienia')]:
   bnav=self.nav[key];bnav.setParent(bar);bnav.setText(label);bnav.setIconSize(QSize(22,22));bl.addWidget(bnav)
  bl.addStretch()
  # Theme selection is now a single click sun/moon switch, no dropdown.
  self.theme_quick=self.theme  # invisible state holder, compatibility with settings
  self.theme_button=QPushButton();self.theme_button.setObjectName('theme-toggle');self.theme_button.setFixedSize(34,34)
  self.theme_button.setAccessibleName('Przełącz motyw jasny lub ciemny')
  self.theme_button.clicked.connect(self.toggle_theme)
  bl.addWidget(self.theme_button)
  # No fixed-size workspace / no outer scroll area: page resizes with monitor.
  self.stack.setMinimumSize(0,0);self.stack.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
  layout.addWidget(bar);layout.addWidget(self.stack,1);self.setCentralWidget(central);old.deleteLater()
  for pg in self.pages.values():
   pg.layout().setContentsMargins(18,13,18,13);pg.layout().setSpacing(7 if self.compact else 10)
  self._fit_layout_to_monitor()
  self._reflow_compare(self.width())
  self.apply_theme(self.theme.currentText());self.navigate('compare')
  for card in (self.a,self.b):card.path.textChanged.connect(self.invalidate_comparison)
 def _fit_layout_to_monitor(self):
  """The result table owns all remaining height; export actions never form a tall empty card."""
  self.compare_table.setMinimumHeight(138)
  self.compare_table.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
  self.compare_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  self.compare_table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
  self.compare_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
  self.compare_table.horizontalHeader().setStretchLastSection(True)
  self.compare_table.verticalHeader().setDefaultSectionSize(30)
  self.mass_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  self.mass_table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
  self.mass_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
  self.mass_table.verticalHeader().setDefaultSectionSize(31)
  self.log.hide();self.mass_log.setMaximumHeight(42)
  self.legend.hide();self.visibility_hint.hide();self.grouping_hint.hide()
  self.compare_description.hide()
  self.export_box.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
  self.export_box.setMinimumWidth(0);self.export_box.setMaximumWidth(16777215)
  self.export_box.setMaximumHeight(63)
  self.step_progress_label.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Preferred)
  self.report_progress_label.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Preferred)
  self.settings_note.setWordWrap(True)

 def _reflow_compare(self,width):
  """Reflow source selectors and counters according to available content width."""
  if not hasattr(self,'source_grid'):return
  stacked=width<805
  self.source_grid.setColumnStretch(2,0 if stacked else 1)
  if getattr(self,'_source_stacked',None)!=stacked:
   for widget in (self.a,self.b,self.swap_button):self.source_grid.removeWidget(widget)
   if stacked:
    self.source_grid.addWidget(self.a,0,0)
    self.source_grid.addWidget(self.swap_button,1,0,alignment=Qt.AlignCenter)
    self.source_grid.addWidget(self.b,2,0)
    self.swap_button.setText('Zamień rewizje A ↔ B')
    self.swap_button.setMinimumWidth(155)
   else:
    self.source_grid.addWidget(self.a,0,0)
    self.source_grid.addWidget(self.swap_button,0,1,alignment=Qt.AlignCenter)
    self.source_grid.addWidget(self.b,0,2)
    self.swap_button.setText('Zamień')
    self.swap_button.setMinimumWidth(0)
   self._source_stacked=stacked
  columns=3 if width<1040 else 6
  if getattr(self,'_metric_columns',None)!=columns:
   for card in self.metric_cards:self.metric_grid.removeWidget(card)
   for n,card in enumerate(self.metric_cards):
    self.metric_grid.addWidget(card,n//columns,n%columns)
   self._metric_columns=columns
  # No tall blank results box; action buttons stay in one compact horizontal row.
  if hasattr(self,'export_title'):self.export_title.setVisible(width>=1190)
  self.compare_table.horizontalHeader().setMinimumSectionSize(52)
  if hasattr(self,'search'):self.search.setMinimumWidth(120)

 def resizeEvent(self,event):
  super().resizeEvent(event)
  if hasattr(self,'source_grid'):
   self._reflow_compare(event.size().width())
 def create_settings(self):
  super().create_settings()
  self.settings_note=self.pages['settings'].findChildren(QLabel)[-1]
  self.theme=QComboBox(self);self.theme.addItems(PALETTES);self.theme.setCurrentText(str(self.store.value('theme46','Ciemny')))
  form=self.pages['settings'].findChild(QFrame,'card').layout()
  for obsolete in (self.opacity,self.old_color):
   label=form.labelForField(obsolete)
   if label:label.hide()
   obsolete.hide()
  self.theme.hide()  # no selector visible anywhere; keep QSettings and existing API
  self.theme.currentTextChanged.connect(self.apply_theme)
 def toggle_theme(self):
  self.theme.setCurrentText('Ciemny' if self.theme.currentText()=='Jasny' else 'Jasny')
 def apply_theme(self,name):
  p=PALETTES.get(name,PALETTES['Jasny']);self.setStyleSheet(theme_style(p));self.store.setValue('theme46',name)
  if hasattr(self,'theme_quick'):
   self.theme_quick.blockSignals(True);self.theme_quick.setCurrentText(name);self.theme_quick.blockSignals(False)
  if hasattr(self,'theme_button'):
   self.theme_button.setText('');self.theme_button.setIcon(theme_icon(name=='Ciemny',p['ink']));self.theme_button.setIconSize(QSize(24,24))
   self.theme_button.setToolTip('Włącz motyw ciemny' if name=='Jasny' else 'Włącz motyw jasny')
  for key,b in self.nav.items():b.setIcon(vector_icon(key,p['ink']))
  self._refresh_action_icons(p['ink'],p['accent'])
  if hasattr(self,'metrics'):
   for label,key in zip(self.metrics,('green','blue','purple','blue','orange','green')):label.setStyleSheet(f'font-size:23px;font-weight:700;color:{p[key]}')
 def create_compare(self):
  """Balanced desktop layout: files, actions, counters, full-width table, compact toolbar."""
  self.filter_status='ALL';self.metrics=[];self.metric_cards=[]
  lay=self.page('compare','Porównanie rewizji','Modele A i B · raport i kolorowy STEP do ZW3D');lay.setSpacing(8)
  self.compare_description=self.pages['compare'].findChild(QLabel,'sub')
  # Source areas never push the result table into a narrow column.
  self.source_grid=QGridLayout();self.source_grid.setHorizontalSpacing(10);self.source_grid.setVerticalSpacing(4)
  self.a=FileCard('A · Stara rewizja','');self.b=FileCard('B · Nowa rewizja','')
  self.a.setMinimumWidth(0);self.b.setMinimumWidth(0)
  self.swap_button=button('Zamień',self.swap);self.swap_button.setToolTip('Zamień modele A i B')
  self.source_grid.setColumnStretch(0,1);self.source_grid.setColumnStretch(2,1)
  self.source_grid.addWidget(self.a,0,0);self.source_grid.addWidget(self.swap_button,0,1);self.source_grid.addWidget(self.b,0,2)
  lay.addLayout(self.source_grid)
  runline=QHBoxLayout();runline.setSpacing(8)
  self.run_compare=button('Porównaj i utwórz STEP',lambda:self.start('compare'),True)
  self.cancel_compare=button('Anuluj',self.cancel);self.cancel_compare.setEnabled(False)
  runline.addWidget(self.run_compare);runline.addWidget(self.cancel_compare)
  self.compare_summary=QLabel('Wybierz dwa modele, aby rozpocząć.')
  self.compare_summary.setObjectName('sub');self.compare_summary.setWordWrap(True)
  self.compare_summary.setMinimumWidth(0);self.compare_summary.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Preferred)
  runline.addWidget(self.compare_summary,1);lay.addLayout(runline)
  self._build_settings_options()
  # Six counters across a wide screen, three per row at lower desktop resolutions.
  self.metric_grid=QGridLayout();self.metric_grid.setHorizontalSpacing(7);self.metric_grid.setVerticalSpacing(6)
  for idx,title in enumerate(('Bez zmian','Do sprawdzenia','Przesunięte','Nowe','Stare','Zmiana nazwy')):
   card=QFrame();card.setObjectName('metric');card.setMinimumWidth(0)
   card.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
   inside=QHBoxLayout(card);inside.setContentsMargins(10,7,9,7);inside.setSpacing(7)
   count=QLabel('—');count.setMinimumWidth(27);inside.addWidget(count)
   caption=QLabel(title);caption.setObjectName('metric-name');caption.setWordWrap(True)
   caption.setMinimumWidth(0);inside.addWidget(caption,1)
   self.metrics.append(count);self.metric_cards.append(card)
   self.metric_grid.addWidget(card,0,idx)
  lay.addLayout(self.metric_grid)
  # Search and filter share a single row above the entire table.
  toolrow=QHBoxLayout();toolrow.setSpacing(9)
  heading=QLabel('Wykaz zmian');heading.setObjectName('section');toolrow.addWidget(heading)
  self.search=QLineEdit();self.search.setPlaceholderText('Szukaj części lub statusu…')
  self.search.textChanged.connect(self.filter_results);toolrow.addWidget(self.search,1)
  self.filter_status='ALL';self.filter_buttons={};self.filter_selector=QComboBox()
  self.filter_selector.setMinimumWidth(155);self.filter_selector.setMaximumWidth(235)
  for key,label in [('ALL','Wszystkie'),('SAME','Bez zmian'),('UNCERTAIN','Do sprawdzenia'),('MOVED','Przesunięte'),('ADDED','Nowe'),('REMOVED','Stare'),('RENAMED','Zmiana nazwy')]:
   b=button(label,lambda checked=False,k=key:self.select_filter(k));b.setObjectName('filter');b.setCheckable(True);b.setChecked(key=='ALL');self.filter_buttons[key]=b;b.setParent(self);b.hide()
   self.filter_selector.addItem(label,key)
  self.filter_selector.currentIndexChanged.connect(lambda:self.select_filter(self.filter_selector.currentData()))
  toolrow.addWidget(self.filter_selector);lay.addLayout(toolrow)
  self.only_changes=QCheckBox();self.only_changes.setChecked(False);self.only_changes.toggled.connect(self.filter_results)
  self.compare_table=table(['Status','Stara rewizja A','Nowa rewizja B','Szczegóły'])
  self.compare_table.setItemDelegateForColumn(0,StatusDelegate(self.compare_table))
  self.compare_table.verticalHeader().setDefaultSectionSize(31)
  lay.addWidget(self.compare_table,1)
  # The old vertical export panel was a large empty rectangle. It is now a
  # small action bar under the table, using the full workspace width.
  export=QFrame();self.export_box=export;export.setObjectName('actionbar')
  el=QHBoxLayout(export);el.setContentsMargins(9,7,9,7);el.setSpacing(8)
  self.export_title=QLabel('Wyniki');self.export_title.setObjectName('sub');el.addWidget(self.export_title)
  self.compare_open={}
  for label,filename in [('Otwórz STEP','POROWNANIE_KOLORY.step'),('Raport HTML','RAPORT.html'),('Podgląd 3D','PODGLAD_KOLOROW_3D.html'),('Folder wyników','')]:
   btn=button(label,lambda checked=False,f=filename:self.open_result('compare',f),filename.endswith('.step'))
   btn.setEnabled(False);btn.setMinimumWidth(130 if filename else 138)
   btn.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Preferred)
   self.compare_open[filename]=btn;el.addWidget(btn,1)
  for label,filename in [('BOM A','BOM_A.csv'),('BOM B','BOM_B.csv'),('Zmiany CSV','ZMIANY.csv')]:
   btn=button(label,lambda checked=False,f=filename:self.open_result('compare',f))
   btn.setEnabled(False);btn.hide();self.compare_open[filename]=btn
  lay.addWidget(export)
  self.export_name=QLabel('');self.export_name.hide()
  self.legend=QLabel('');self.legend.hide()
  self.grouping_hint=QLabel('');self.grouping_hint.hide()
  self.visibility_hint=QLabel('');self.visibility_hint.hide()
  # Two progress indicators share one row; neither takes table space vertically.
  self.progress_grid=QGridLayout();self.progress_grid.setHorizontalSpacing(18);self.progress_grid.setVerticalSpacing(3)
  self.step_progress_label=QLabel('STEP · oczekuje');self.step_progress_label.setObjectName('sub')
  self.progress=QProgressBar();self.progress.setRange(0,100);self.progress.setValue(0);self.progress.setTextVisible(False)
  self.report_progress_label=QLabel('Raport / BOM · oczekuje');self.report_progress_label.setObjectName('sub')
  self.report_progress=QProgressBar();self.report_progress.setRange(0,100);self.report_progress.setValue(0);self.report_progress.setTextVisible(False)
  self.progress_grid.addWidget(self.step_progress_label,0,0);self.progress_grid.addWidget(self.report_progress_label,0,1)
  self.progress_grid.addWidget(self.progress,1,0);self.progress_grid.addWidget(self.report_progress,1,1)
  self.progress_grid.setColumnStretch(0,1);self.progress_grid.setColumnStretch(1,1)
  lay.addLayout(self.progress_grid)
  self.log=QPlainTextEdit();self.log.setReadOnly(True);self.log.document().setMaximumBlockCount(150);self.log.hide()
  foot=QHBoxLayout();foot.addStretch()
  self.reset_button=button('Nowe porównanie',self.reset_session)
  foot.addWidget(self.reset_button);lay.addLayout(foot)
 def _build_settings_options(self):
  """Keep all revision variables in Ustawienia, not in the comparison workspace."""
  self.export_colors={}
  for key,caption,default in EXPORT_COLOR_CHOICES:
   stored=str(self.store.value('export_color_'+key,default))
   self.export_colors[key]=stored if QColor(stored).isValid() else default
  self.opacity.setValue(0)
  self.color_editor=button('Kolory części w STEP…',self.edit_export_colors)
  self.color_editor.setToolTip('Własny kolor dla każdego rodzaju zmiany')
  self.output=QLineEdit(str(self.store.value('output',str(Path.home()/'Documents'/'DSCompare'))))
  folder_line=QHBoxLayout();folder_line.addWidget(self.output,1)
  self.output_button=button('Wybierz…',self.choose_output);folder_line.addWidget(self.output_button)
  self.verify_mode=QComboBox()
  for label,key in [('Automatyczna','auto'),('Szybka — struktura pliku','fast'),('Dokładna — ponowny import','full')]:self.verify_mode.addItem(label,key)
  self.verify_mode.setCurrentIndex(max(0,self.verify_mode.findData(str(self.store.value('step_verify','auto')))))
  self.verify_mode.currentIndexChanged.connect(lambda:self.store.setValue('step_verify',self.verify_mode.currentData()))
  self.verify_mode.setToolTip('Tryb dokładny sprawdza wynikowy STEP ponownym importem.')
  self.solid_limit=QSpinBox();self.solid_limit.setRange(1,50000)
  stored=int(self.store.value('solid_limit',20000))
  if not self.store.value('solid_limit_migrated_r116',False,type=bool):
   if stored==1000:stored=20000
   self.store.setValue('solid_limit_migrated_r116',True)
  self.solid_limit.setValue(max(1,min(50000,stored)))
  self.solid_limit.setButtonSymbols(QAbstractSpinBox.NoButtons)
  self.solid_limit.valueChanged.connect(lambda value:self.store.setValue('solid_limit',value))
  self.full_bom=QCheckBox('Pełny BOM A i B (grupowanie identycznych części)')
  # One-time migration: older builds had it OFF, hiding the requested BOM.
  if not self.store.value('bom_default_migrated_r119',False,type=bool):
   self.store.setValue('full_bom',True);self.store.setValue('bom_default_migrated_r119',True)
  self.full_bom.setChecked(str(self.store.value('full_bom','true')).lower()=='true')
  self.full_bom.toggled.connect(lambda checked:self.store.setValue('full_bom',checked))
  self.full_bom.setToolTip('Rozpoznaje powtarzające się części i umieszcza BOM A/B w zwijanych sekcjach raportu HTML')
  self.bom_mode=QComboBox()
  self.bom_mode.addItem('Dokładny — również kontrola B-Rep (wolniejszy)','exact')
  self.bom_mode.addItem('Szybki — tylko pewne duplikaty (może rozdzielić identyczne)','fast')
  selected=str(self.store.value('bom_mode','exact'))
  self.bom_mode.setCurrentIndex(max(0,self.bom_mode.findData(selected)))
  self.bom_mode.currentIndexChanged.connect(lambda:self.store.setValue('bom_mode',self.bom_mode.currentData()))
  self.bom_mode.setToolTip('Tryb szybki nigdy nie scala części na podstawie samej nazwy/objętości. Niektóre obrócone kopie pozostają w osobnych wierszach.')
  self.bom_csv=QCheckBox('Eksportuj także BOM A/B do CSV')
  self.bom_csv.setChecked(str(self.store.value('bom_csv','false')).lower()=='true')
  self.bom_csv.toggled.connect(lambda checked:self.store.setValue('bom_csv',checked))
  self.bom_csv.setToolTip('CSV to dodatkowy format. Jego wyłączenie nie przyspieszy znacząco grupowania geometrii.')
  self.cache_import=QCheckBox('Przyspiesz ponowny import — bezpieczny cache B-Rep')
  cache_setting=str(self.store.value('import_cache','true')).lower()=='true'
  self.cache_import.setChecked(cache_setting)
  os.environ['DSCOMPARE_IMPORT_CACHE']='auto' if cache_setting else 'off'
  self.cache_import.toggled.connect(self._set_import_cache)
  self.cache_import.setToolTip('SHA-256 całego STEP zabezpiecza przed użyciem nieaktualnych danych; cache do 3 GB, pliki mniejsze niż 2 MB bez dodatkowego zapisu.')
  self.clear_import_cache_button=button('Wyczyść cache importu',self.clear_import_cache)
  self.clear_import_cache_button.setToolTip('Usuwa jedynie pośrednie pliki DSCompare; nie zmienia modeli STEP ani raportów.')
  self.safe_export=QCheckBox('Bez pustych ABSR — płaski STEP do ZW3D')
  self.safe_export.setChecked(str(self.store.value('safe_export','true')).lower()=='true')
  self.safe_export.toggled.connect(lambda checked:self.store.setValue('safe_export',checked))
  self.safe_export.setToolTip('Każda bryła to osobna część; bez pustych kontenerów złożenia ABSR. Kategorie zmian pozostają w nazwach, bez hierarchii podzłożeń. Odznaczenie przywraca dawny eksport złożeń.')
  settings=self.pages['settings'];layout=settings.layout()
  left=settings.findChild(QFrame,'card');layout.removeWidget(left)
  right=QFrame();right.setObjectName('card');form=QFormLayout(right)
  form.setContentsMargins(17,16,17,16);form.setSpacing(12)
  heading=QLabel('Eksport i pliki wynikowe');heading.setObjectName('section');form.addRow(heading)
  folder_widget=QWidget();folder_widget.setLayout(folder_line)
  form.addRow('Folder wyników',folder_widget)
  form.addRow('Kolory',self.color_editor)
  form.addRow('Kontrola STEP',self.verify_mode)
  form.addRow('Limit brył / plik',self.solid_limit)
  form.addRow(self.full_bom)
  form.addRow('Sposób grupowania',self.bom_mode)
  form.addRow(self.bom_csv)
  form.addRow(self.safe_export)
  form.addRow(self.cache_import)
  form.addRow("Pamięć modeli",self.clear_import_cache_button)
  note=QLabel('Z3: wyeksportuj STEP obok pliku Z3 pod tą samą nazwą. Zostanie wykryty automatycznie.')
  note.setObjectName('sub');note.setWordWrap(True);form.addRow(note)
  cards=QHBoxLayout();cards.setSpacing(10);cards.addWidget(left,1);cards.addWidget(right,1)
  layout.insertLayout(2,cards)
  self._extra_settings_card=right

 def _set_import_cache(self,enabled):
  self.store.setValue('import_cache',bool(enabled))
  os.environ['DSCOMPARE_IMPORT_CACHE']='auto' if enabled else 'off'
 def clear_import_cache(self):
  from .import_cache import root_dir
  import shutil
  folder=root_dir()
  if QMessageBox.question(self,'Wyczyść cache','Usunąć zapisane dane importu DSCompare? Modele źródłowe pozostaną bez zmian.',QMessageBox.Yes|QMessageBox.No)!=QMessageBox.Yes:
   return
  try:
   if folder.exists():shutil.rmtree(folder)
   QMessageBox.information(self,'Cache wyczyszczony','Bufor B-Rep został wyczyszczony.')
  except OSError as exc:
   QMessageBox.warning(self,'Błąd czyszczenia','Nie można wyczyścić cache: '+str(exc))
 def _refresh_action_icons(self,ink,accent):
  targets=[('run_compare','run',accent),('cancel_compare','cancel',ink),('swap_button','swap',ink),
           ('reset_button','refresh',ink),('color_editor','colors',ink),('output_button','folder',ink),
           ('run_mass','mass',accent),('cancel_mass','cancel',ink),('clear_import_cache_button','trash',ink)]
  for card in (getattr(self,'a',None),getattr(self,'b',None),getattr(self,'mass_file',None)):
   if card is not None and hasattr(card,'choose_button'):
    set_action(card.choose_button,'file',ink)
  for name,key,color in targets:
   b=getattr(self,name,None)
   if b is not None:set_action(b,key,color)
  for filename,b in getattr(self,'compare_open',{}).items():
   key=('folder' if not filename else 'bom' if filename.startswith('BOM_') else
        'report' if filename.endswith('.html') else 'csv' if filename.endswith('.csv') else 'file')
   set_action(b,key,ink,18)
  for filename,b in getattr(self,'mass_open',{}).items():
   key='folder' if not filename else 'report' if filename.endswith('.html') else 'csv'
   set_action(b,key,ink,18)

 def color_overrides(self):
  return {key:[QColor(value).red()/255,QColor(value).green()/255,QColor(value).blue()/255]
          for key,value in self.export_colors.items()}

 def edit_export_colors(self):
  dlg=QDialog(self);dlg.setWindowTitle('Kolory elementów wynikowego STEP')
  dlg.setStyleSheet(self.styleSheet())
  screen=QGuiApplication.screenAt(self.mapToGlobal(self.rect().center())) or QGuiApplication.primaryScreen()
  geo=screen.availableGeometry() if screen else None
  dlg.setMinimumWidth(560)
  dlg.resize(min(740,max(560,geo.width()-60 if geo else 740)),430)
  root=QVBoxLayout(dlg);root.setContentsMargins(17,13,17,13);root.setSpacing(9)
  note=QLabel('Kolory elementów STEP — kliknij próbkę, aby zmienić kolor.')
  note.setWordWrap(True);root.addWidget(note)
  grid=QGridLayout();grid.setHorizontalSpacing(12);grid.setVerticalSpacing(8)
  pending=dict(self.export_colors);swatches={}
  def choose(key):
   color=QColorDialog.getColor(QColor(pending[key]),dlg,'Kolor elementów')
   if color.isValid():
    pending[key]=color.name()
    swatches[key].setStyleSheet('background:'+color.name()+';border:1px solid #777;border-radius:6px;')
    swatches[key].setToolTip(color.name())
  for i,(key,caption,default) in enumerate(EXPORT_COLOR_CHOICES):
   col=(i%2)*2;row=i//2
   label=QLabel(caption);label.setWordWrap(True)
   grid.addWidget(label,row,col)
   chip=QPushButton();chip.setFixedSize(62,28)
   chip.setAccessibleName('Zmień: '+caption);chip.setToolTip(pending[key])
   chip.setStyleSheet('background:'+pending[key]+';border:1px solid #777;border-radius:6px;')
   chip.clicked.connect(lambda checked=False,k=key:choose(k))
   swatches[key]=chip
   grid.addWidget(chip,row,col+1)
  grid.setColumnStretch(0,1);grid.setColumnStretch(2,1)
  root.addLayout(grid);root.addStretch(1)
  actions=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel)
  actions.button(QDialogButtonBox.Ok).setText('Zapisz')
  actions.button(QDialogButtonBox.Cancel).setText('Anuluj')
  actions.accepted.connect(dlg.accept);actions.rejected.connect(dlg.reject)
  footer=QHBoxLayout()
  reset=button('Przywróć domyślne',lambda:None)
  def defaults():
   for key,caption,default in EXPORT_COLOR_CHOICES:
    pending[key]=default
    swatches[key].setStyleSheet('background:'+default+';border:1px solid #777;border-radius:6px;')
    swatches[key].setToolTip(default)
  reset.clicked.connect(defaults)
  footer.addWidget(reset);footer.addStretch();footer.addWidget(actions)
  root.addLayout(footer)
  if dlg.exec()==QDialog.Accepted:
   self.export_colors=pending
   for key,value in pending.items():self.store.setValue('export_color_'+key,value)

 def show_color_help(self):
  self.edit_export_colors()

 def create_mass(self):
  super().create_mass()
  self.mass_summary.setText('Wybierz model i oblicz masy poszczególnych części.')
  self.pages['mass'].findChild(QLabel,'sub').setText('Oblicz masę z objętości i gęstości materiału podanej poniżej.')
  settings_form=self.pages['settings'].findChild(QFrame,'card').layout()
  density_label=settings_form.labelForField(self.density)
  if density_label:density_label.hide()
  settings_form.removeWidget(self.density)
  # Remove platform-specific spin arrow controls from density field.
  from PySide6.QtWidgets import QAbstractSpinBox
  self.density.setButtonSymbols(QAbstractSpinBox.NoButtons)
  self.tolerance.setButtonSymbols(QAbstractSpinBox.NoButtons)
  massrow=QHBoxLayout();massrow.addWidget(QLabel('Materiał'))
  self.materials=QComboBox();self.materials.setMinimumWidth(185)
  builtins={'Stal S235 / S355':7850,'Stal S690QL / S960QL':7850,
            'Hardox':7850,'Stal nierdzewna':8000,'Aluminium':2700,
            'Żeliwo':7200,'Miedź':8960,'Mosiądz':8500,'PA6':1140}
  try:
   custom=json.loads(str(self.store.value('custom_materials','{}')))
   if not isinstance(custom,dict):custom={}
  except (ValueError,TypeError):custom={}
  self.custom_materials={k:float(v) for k,v in custom.items()
       if isinstance(k,str) and isinstance(v,(int,float)) and 1<=v<=25000}
  self.materials.addItem('Własna gęstość',None)
  for name,density in {**builtins,**self.custom_materials}.items():
   self.materials.addItem(f'{name} · {density:g} kg/m³',density)
  self.materials.currentIndexChanged.connect(self.material_changed)
  massrow.addWidget(self.materials)
  massrow.addWidget(button('Dodaj…',self.add_material))
  massrow.addWidget(QLabel('Gęstość'));massrow.addWidget(self.density)
  self.density.valueChanged.connect(self.density_changed)
  saved=str(self.store.value('selected_material',''))
  selected=next((i for i in range(self.materials.count()) if self.materials.itemText(i).split(' · ')[0]==saved),-1)
  if selected>=0:self.materials.setCurrentIndex(selected)
  else:self.density_changed()
  massrow.addSpacing(14);massrow.addWidget(QLabel('Folder wyników'))
  self.mass_output=QLineEdit(self.output.text());massrow.addWidget(self.mass_output,1)
  massrow.addWidget(button('Wybierz…',self.choose_output))
  self.output.textChanged.connect(self.mass_output.setText)
  self.mass_output.textChanged.connect(self.output.setText)
  self.pages['mass'].layout().insertLayout(3,massrow)

 def material_changed(self,*args):
  self.store.setValue('selected_material',self.materials.currentText().split(' · ')[0])
  val=self.materials.currentData()
  if val is None:return
  self._material_setting=True
  try:self.density.setValue(float(val))
  finally:self._material_setting=False

 def density_changed(self,*args):
  if getattr(self,'_material_setting',False) or not hasattr(self,'materials'):return
  value=self.density.value()
  match=next((i for i in range(1,self.materials.count())
              if abs(self.materials.itemData(i)-value)<.01),0)
  self.materials.blockSignals(True)
  self.materials.setCurrentIndex(match)
  self.materials.blockSignals(False)
  self.store.setValue('selected_material',self.materials.currentText().split(' · ')[0])

 def add_material(self):
  name,ok=QInputDialog.getText(self,'Dodaj materiał','Nazwa materiału:')
  if not ok:return
  name=name.strip()
  if not name or len(name)>80:
   QMessageBox.warning(self,'Nazwa materiału','Wpisz nazwę (1–80 znaków).');return
  val,ok=QInputDialog.getDouble(self,'Dodaj materiał','Gęstość [kg/m³]:',self.density.value(),1,25000,2)
  if not ok:return
  self.custom_materials[name]=val
  self.store.setValue('custom_materials',json.dumps(self.custom_materials,ensure_ascii=False))
  old=next((i for i in range(1,self.materials.count())
            if self.materials.itemText(i).split(' · ')[0]==name),-1)
  if old>=0:self.materials.removeItem(old)
  self.materials.addItem(f'{name} · {val:g} kg/m³',val)
  self.materials.setCurrentIndex(self.materials.count()-1)

 def select_filter(self,key):
  self.filter_status=key
  self.filter_selector.blockSignals(True);self.filter_selector.setCurrentIndex(self.filter_selector.findData(key));self.filter_selector.blockSignals(False)
  for k,b in self.filter_buttons.items():b.setChecked(k==key)
  self.filter_results()
 def filter_results(self,*args):
  if not hasattr(self,'compare_table'):return
  query=self.search.text().casefold();wanted=getattr(self,'filter_status','ALL')
  for i in range(self.compare_table.rowCount()):
   status=self.row_statuses[i];text=' '.join(self.compare_table.item(i,j).text() for j in range(4))
   allowed=wanted=='ALL' or wanted==status or wanted=='CHANGES' and status in ('ADDED','REMOVED') or wanted=='SAME' and status in ('SAME','RENAMED')
   self.compare_table.setRowHidden(i,not allowed or query not in text.casefold())
 def start(self,kind):
  super().start(kind)
  if self.process is not None:
   self.started_at=time.monotonic()
   # Do not gray out settings QScrollArea: Qt hides checked indicators when disabled.
   # R11.28 disables navigation during a job instead.
  if hasattr(self,'reset_button'):self.reset_button.setEnabled(self.process is None)
  if self.process is not None:
   # A mass analysis must NEVER overwrite the comparison page.
   if kind=='compare':
    self.compare_summary.setToolTip('')
    self.compare_summary.setText('Analiza trwa…')
   elif kind=='mass':
    self.mass_summary.setToolTip('')
    self.mass_summary.setText('Trwa obliczanie masy…')
   if kind=='compare':
    self.export_name.setText('Tworzenie nowego STEP…')
    self.step_progress_label.setText('Model STEP: analiza i eksport…')
    self.report_progress_label.setText('Raport i BOM: oczekują na STEP')
    self.progress.setRange(0,0);self.report_progress.setRange(0,100);self.report_progress.setValue(0)
    for b in self.compare_open.values():b.setEnabled(False)
 def poll(self):
  super().poll()
  if self.task!='compare' or not getattr(self,'current_folder',None):return
  folder=Path(self.current_folder)
  if self.process is not None:
   elapsed=int(time.monotonic()-getattr(self,'started_at',time.monotonic()))
   status=self.log.document().lastBlock().text() or 'Uruchamianie…'
   self.compare_summary.setToolTip(status);self.compare_summary.setText(f'Analiza · {elapsed//60}:{elapsed%60:02d} · {status[-65:]}')
  stagefile=folder/'_ETAPY.json'
  if not stagefile.exists():return
  data=self._stage_data()
  if not data:return
  step=folder/'POROWNANIE_KOLORY.step'
  if data.get('step')=='gotowy' and step.is_file() and step.stat().st_size>=100 \
    and step.stat().st_size==data.get('step_bytes'):
   # Export passed its selected validation before the atomic marker.
   self.results['compare']=folder
   self.compare_open['POROWNANIE_KOLORY.step'].setEnabled(True)
   self.compare_open[''].setEnabled(True)
   self.export_name.setText('STEP gotowy — raporty w tle')
   mode='pełna' if data.get('verification')=='pelna_ponowny_import' else 'strukturalna'
   self.step_progress_label.setText(f'Model STEP: gotowy · kontrola {mode}')
   self.progress.setRange(0,100);self.progress.setValue(100)
  elif data.get('step')=='blad':
   self.progress.setRange(0,100);self.progress.setValue(0)
   self.step_progress_label.setText('Model STEP: błąd eksportu')
  report_labels={'oczekuje':'oczekują','przygotowanie':'przygotowanie danych',
   'bom_a':'grupowanie BOM starej rewizji A','bom_b':'grupowanie BOM nowej rewizji B',
   'zapisywanie_bom':'zapis BOM','html':'tworzenie HTML','finalizacja':'końcowe zestawienia','gotowe':'gotowe'}
  phase=data.get('reports','oczekuje')
  pct=int(data.get('report_percent',0))
  self.report_progress_label.setText(f"Raport i BOM: {report_labels.get(phase,phase)} · {pct}%")
  self.report_progress.setValue(max(0,min(100,pct)))
  if data.get('basic_report_ready'):
   self.results['compare']=folder
   self.compare_open['RAPORT.html'].setEnabled((folder/'RAPORT.html').is_file())
   self.compare_open['ZMIANY.csv'].setEnabled((folder/'ZMIANY.csv').is_file())
   self.compare_open[''].setEnabled(True)
  if phase=='gotowe':
   for filename in ('RAPORT.html','ZMIANY.csv','BOM_A.csv','BOM_B.csv'):
    self.compare_open[filename].setEnabled((folder/filename).exists())

 def open_result(self,kind,filename):
  super().open_result(kind,filename)
 def finished(self,code,status):
  super().finished(code,status);self.reset_button.setEnabled(True);self.pages['settings'].setEnabled(True)
  if getattr(self,'completion_ok',False) and not self.was_cancelled and self.task=='compare':
   ready=self.compare_open['POROWNANIE_KOLORY.step'].isEnabled()
   self.progress.setRange(0,100);self.progress.setValue(100 if ready else 0)
   if not ready:self.step_progress_label.setText('Model STEP: błąd eksportu')
   self.report_progress.setValue(100);self.report_progress_label.setText('Raporty HTML / BOM: gotowe · 100%')
  if self.was_cancelled:self.compare_summary.setText('Analiza anulowana.')
  elif code or not getattr(self,'completion_ok',False):self.compare_summary.setText('Analiza nie została ukończona — sprawdź komunikat błędu.')
 def load_result(self,kind,folder):
  super().load_result(kind,folder)
  self._tidy_finished_files(Path(folder))
  if kind!='compare':
   s=json.loads((Path(folder)/'PODSUMOWANIE_MASY.json').read_text(encoding='utf-8'))
   omitted=s.get('import_diagnostics',{}).get('faces_outside_solids',0)
   if omitted:self.mass_summary.setText(self.mass_summary.text()+f' · UWAGA: pominięto {omitted} powierzchni')
   return
  for i,status in enumerate(self.row_statuses):self.compare_table.item(i,0).setData(Qt.UserRole,status)
  folder=Path(folder);s=json.loads((folder/'PODSUMOWANIE.json').read_text(encoding='utf-8'));c=s['statuses']
  values=[c.get('SAME',0),c.get('UNCERTAIN',0),c.get('MOVED',0),c.get('ADDED',0),c.get('REMOVED',0),c.get('RENAMED',0)]
  for label,value in zip(self.metrics,values):label.setText(str(value))
  message=f"Porównanie gotowe · A: {s['solids_A']} → B: {s['solids_B']} · Przesunięte: {c.get('MOVED',0)}"
  if s.get('step_export_error'):message+=' · Błąd eksportu STEP — raport dostępny'
  if c.get('UNCERTAIN'):message+=f" · Do sprawdzenia: {c['UNCERTAIN']}"
  omitted=sum(v.get('faces_outside_solids',0) for v in s.get('import_diagnostics',{}).values())
  if omitted:message+=f' · UWAGA: pominięto {omitted} powierzchni poza bryłami'
  self.compare_summary.setText(message)
  ready=(folder/'POROWNANIE_KOLORY.step').is_file() and not s.get('step_export_error')
  self.export_name.setText('STEP gotowy do otwarcia' if ready else 'STEP nie został utworzony')
  self.export_name.setToolTip(s.get('step_export_error') or str(folder/'POROWNANIE_KOLORY.step'))
  self.compare_open['POROWNANIE_KOLORY.step'].setEnabled(ready)
  for name in ('RAPORT.html','BOM_A.csv','BOM_B.csv','ZMIANY.csv',''):
   self.compare_open[name].setEnabled((folder/name).exists())
  mode='pełna' if s.get('step_verification')=='pelna_ponowny_import' else 'strukturalna'
  self.progress.setRange(0,100);self.progress.setValue(100 if ready else 0)
  self.step_progress_label.setText(f'Model STEP: gotowy · kontrola {mode}' if ready else 'Model STEP: błąd eksportu')
  self.report_progress.setValue(100);self.report_progress_label.setText('Raport i BOM: gotowe · 100%')
  old=s.get('colors_hex',{}).get('REMOVED','#ff610f');alpha=round((1-s.get('old_alpha',.4))*100)
  self.legend.setText(f'<span style="color:#24aa67">● Bez zmian / zmiana nazwy</span><br><span style="color:#4b85ff">● Nowa B</span><br><span style="color:#ab73ec">● Nowe położenie B — fiolet</span><br><span style="color:#c7addf">● Stare położenie A — jasny fiolet</span><br><span style="color:{old}">● Usunięte A · {alpha}% przezr.</span><br>● Do sprawdzenia — osobna grupa STEP')

 def _tidy_finished_files(self,folder):
  # Technical files are useful when diagnosing issues, but should not clutter
  # the user-facing result directory. Move only AFTER load_result has read them.
  try:
   for obsolete in ('MINIATURA_A.json','MINIATURA_B.json','RAPORT_ZMIAN.html'):
    (folder/obsolete).unlink(missing_ok=True)
   internal=('DIAGNOSTYKA_KOLOROW.json','_POSTEP_V37.jsonl','_WYNIK_V37.json',
             'BOM_GRUPY_A.json','BOM_GRUPY_B.json','MASA_MAPA.json')
   tech=folder/'DANE_TECHNICZNE'
   for name in internal:
    source=folder/name
    if source.is_file():
     tech.mkdir(exist_ok=True)
     source.replace(tech/name)
  except OSError:
   pass
 def invalidate_comparison(self,*args):
  if self.process is not None or 'compare' not in self.results:return
  self.results.pop('compare');self.compare_table.setRowCount(0);self.row_statuses=[]
  for b in self.compare_open.values():b.setEnabled(False)
  for label in self.metrics:label.setText('—')
  self.compare_summary.setText('Modele zmienione — uruchom nowe porównanie.');self.export_name.setText('STEP: oczekuje na analizę')
 def reset_session(self):
  if self.process is not None:return
  for card in (self.a,self.b,self.mass_file):card.path.clear()
  self.results.clear();self.compare_table.setRowCount(0);self.mass_table.setRowCount(0);self.row_statuses=[]
  for b in list(self.compare_open.values())+list(self.mass_open.values()):b.setEnabled(False)
  for label in self.metrics:label.setText('—')
  self.search.clear();self.select_filter('ALL');self.only_changes.setChecked(False);self.log.clear();self.mass_log.clear();self.progress.setValue(0);self.mass_progress.setValue(0)
  self.step_progress_label.setText('Model STEP: oczekuje');self.report_progress_label.setText('Raport i BOM: oczekują')
  self.progress.setRange(0,100);self.report_progress.setRange(0,100);self.report_progress.setValue(0)
  self.compare_summary.setText('Wybierz dwa modele, aby rozpocząć.');self.mass_summary.setText('Wybierz model do obliczenia masy.');self.export_name.setText('STEP: oczekuje na analizę');self.navigate('compare')

# Production UI: keep the established engine/QProcess superclass contract.
LegacyWindow = Window
from .gui_modern import ModernWindow as Window

def main(a='',b=''):
 app=QApplication.instance() or QApplication(sys.argv);app.setStyle('Fusion');w=Window(a,b);w.show();return app.exec()
