"""Fast world-coordinate consensus with bounded B-Rep verification."""
from collections import defaultdict
from itertools import product
from math import floor
import numpy as np
from .geometry import signature,candidate,equivalent_world

def frame_support(a,b,tolerance,proofs=8,verify_all=False):
 if not a or not b:return dict(count=0,ratio=0.,proofs=0,checked=0)
 tol=max(tolerance,1.e-6);cell_size=max(tol*2,.002)
 buckets=defaultdict(list)
 for i,part in enumerate(a):
  pos=tuple(floor(float(v)/cell_size) for v in part.center)
  buckets[pos].append(i)
 occupied=set();pairs=[]
 for j,part in enumerate(b):
  pos=np.asarray(part.center)
  base=tuple(floor(float(v)/cell_size) for v in pos)
  found=None
  for steps in product((-1,0,1),repeat=3):
   loc=tuple(x+y for x,y in zip(base,steps))
   for i in buckets.get(loc,()):
    if i in occupied:continue
    if np.linalg.norm(a[i].center-pos)>tol or not candidate(a[i],part,tol):continue
    if verify_all and not equivalent_world(a[i],part,tol):continue
    found=i;break
   if found is not None:break
  if found is not None:occupied.add(found);pairs.append((found,j))
 if not pairs:return dict(count=0,ratio=0.,proofs=0,checked=0)
 if verify_all:return dict(count=len(pairs),ratio=len(pairs)/max(1,min(len(a),len(b))),proofs=len(pairs),checked=len(pairs))
 n=min(proofs,len(pairs))
 selection=[pairs[k*(len(pairs)-1)//max(1,n-1)] for k in range(n)]
 confirmed=sum(bool(equivalent_world(a[i],b[j],tol)) for i,j in selection)
 return dict(count=len(pairs),ratio=len(pairs)/max(1,min(len(a),len(b))),
             proofs=confirmed,checked=n)

def already_world_aligned(a,b,tolerance):
 r=frame_support(a,b,tolerance)
 return (r['ratio']>=.55 and r['proofs']==r['checked'] and
         r['checked']>=min(2,min(len(a),len(b))))
