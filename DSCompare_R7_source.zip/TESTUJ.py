"""Current regression gate. Historical UI tests target removed controls."""
import os,sys,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
tests=['test_r7_alignment_preview.py','test_r6_preview.py','test_r5_cleanup.py','test_r118_parallel_import.py','test_optimization_10.py','test_v43_assignment.py','test_v43_accuracy.py',
 'test_brep29.py','test_r111_geometry_registry.py','test_r112_shared_bom.py',
 'test_r1114_persistent_import.py','test_r1129_no_surplus_absr.py','test_r1117_gui_state.py',
 'test_r115_surface_negative_witness.py','test_r114_bom_boolean_fallback.py','test_mass35.py']
if __name__=='__main__':
 result=subprocess.run([sys.executable,'-m','pytest','-q',*[str(root/'tests'/p) for p in tests]],cwd=root,timeout=240)
 sys.exit(result.returncode)
