# DS Compare R11.9

See [README_R119.txt](README_R119.txt).
R11.8 parallel import, safe STEP output for ZW3D, one HTML report and grouped BOM.
