# DS Assembly Compare V2.6 SAFE / ZW3D 2019 Standard x64

**Wersja źródłowa i diagnostyczna.** Kompilacja przez GitHub Actions lub MSVC x64. Nie jest to gotowa, przetestowana w ZW3D DLL.

## Co poprawiono względem V2.5

1. **Dopasowanie wystąpień 1:1 bez skanowania wszystkich par**: indeksy referencji, cech geometrii (jeśli dostępne), nazw i położenia. Test z 3000 identycznych śrub oraz z 5000 wystąpień zakończył się prawidłowo. Algorytm nie ma limitu czasu; ma techniczne ograniczenia liczby i głębokości.
2. **Próba rozwijania podzłożeń** do 16 poziomów poprzez API ZW3D, z wyznaczaniem położenia absolutnego przez złożenie transformacji rodzica i dziecka. Odczyt niektórych podzłożeń może nie działać w danej instalacji. Brakujące gałęzie są wyraźnie oznaczane. Przy niepełnym odczycie generowanie modelu 3D jest blokowane.
3. **Zmiany nazw**: gdy geometria i położenie są pewne, w modelu występuje jeden zielony detal, a w raporcie pojawia się `ABC -> CBA`. Zmiana samej nazwy lub zgodność położenia bez dowodu geometrii **nie** jest podstawą do zielonego koloru.
4. **Wczytywanie list obiektów** jest uruchamiane komendą `~DSAC_SCAN` wewnątrz ZW3D, a nie bezpośrednio w obsłudze przycisku Win32. Podobnie porównanie odbywa się przez `~DSAC_EXEC`.
5. **Obsługa wyniku** nie wykonuje niepotrzebnego przełączania aktywnego dokumentu zaraz po zapisie; zredukowano liczbę operacji CAD przy opuszczaniu komendy. Zamknięcie DLL próbuje bezpiecznie usunąć okno.
6. **Postęp**: liczba odczytanych komponentów pojawia się w oknie i w `%TEMP%\DSAC_V26_TRACE.log`. Przy nieukończonej analizie użytkownik otrzymuje ostrzeżenie w raporcie.
7. **BOM**: rozpoznane liście z podzłożeń są uwzględnione w zestawieniach A i B; nie doliczamy ponownie masy nadrzędnego podzłożenia do mas jego części. Masy jednostkowe dostarczane są opcjonalnie przez CSV.

## Szczególnie ważne ograniczenia

**Analiza geometrii B-Rep nadal pozostaje wyłączona**, ponieważ w poprzednich wydaniach niestabilne wywołania API powodowały awarię ZW3D. Nie wolno uznawać samej nazwy, masy lub pozycji za matematyczny dowód identyczności. Wersja 2.6 **nie gwarantuje**, że wszystkie identyczne części z dwóch niezależnie zapisanych plików będą zielone. Bez mocnego dowodu pozostają szare.

Nie udało się przetestować tej DLL w ZW3D 2019 w środowisku przygotowania paczki, a jedynie niezależny algorytm C++ pod Linuksem. Rozpoznawanie podzłożeń i stabilność generowania Z3 wymagają testów na rzeczywistej instalacji. Raporty STEP zależą od importera zainstalowanego w ZW3D.

## Jak użyć

1. Wgraj **to źródłowe ZIP** do repozytorium GitHub pod dokładną nazwą `DS_Assembly_Compare_GITHUB_ACTIONS_ZW3D2019_V1_1.zip` (podmieniając dotychczasowe źródła; nie podmieniaj ZIP-a wynikowego z DLL).
2. Workflow `.github/workflows/build-ds-assembly-compare.yml` w Twoim repozytorium rozpakowuje archiwum, uruchamia `scripts/build.ps1` i publikuje DLL w `Actions > Artifacts`.
3. Po kompilacji rozpakuj artefakt, zamknij ZW3D, podmień `DSAssemblyCompare2019.dll` i uruchom `~DSAC`.
4. Wybierz A i B. Listy obiektów ładowane są komendą CAD w tle; poczekaj na zakończenie skanowania. Najpierw wykonaj **tylko raport** (bez zaznaczania opcji modelu 3D).
5. Po sprawdzeniu raportu przetestuj model 3D na **kopiach dwóch niewielkich złożeń**. Zapisujesz je na własne ryzyko do osobnego pliku, a oryginalne złożenia powinny zostać nietknięte.

### Kolory

- zielony: zgodność potwierdzona posiadanymi dowodami (w tym zmiana tylko nazwy)
- niebieskofioletowy: nowy lub zmodyfikowany/przesunięty
- pomarańczowy przezroczysty: naprawdę usunięty
- szary: brak dowodu zgodności (nie jest traktowany jako „nowy”)

Kolory zmienisz klikając próbki w legendzie. Zawsze na wierzchu można wyłączyć; przycisk „Ukryj” chowa okno ręcznie.

### Raport i log

Raport HTML, CSV, różnice nazw i BOM-y A/B: `Dokumenty\DSAssemblyCompare`.
Log: `%TEMP%\DSAC_V26_TRACE.log`. Po awarii do diagnozy potrzebne są ostatnie 50–100 wierszy logu i opcjonalnie raport błędu z ZW3D.

### Przykładowy CSV mas

```csv
Nazwa_czesci;masa_kg
PLYTA_01;2,5
PROFIL_02;7.35
```

Brak masy nie jest interpretowany jako `0 kg`; raport pokazuje `BRAK_DANYCH`.

## Komendy

- `~DSAC` — otwórz/zobacz okno
- `~DSAC_INFO` — pomoc
- `~DSAC_SCAN` — wewnętrzne wczytanie list obiektów
- `~DSAC_EXEC` — wewnętrzne wykonanie porównania

Nie uruchamiaj dwóch ostatnich samodzielnie.

## Ograniczenia techniczne

- do **15 000 rozpoznanych liści** w odczycie na złożenie
- maksymalnie **16 poziomów** zagnieżdżeń
- do **20 000 bezpośrednich wystąpień** w jednym węźle
- limit pojedynczej ścieżki przekazywanej do starego API ANSI: 255 bajtów
- brak limitu czasu analizy; długi czas lub zawieszenie nadal może wynikać z działania API CAD
- identyczność bajtowa zapisanych plików jest tylko dodatkowym dowodem, a nie uniwersalnym porównaniem geometrii

