#pragma once
// DSAC V2.6: indexed 1:1 matching, not a Cartesian N*M scan.
// No evidence from names or coordinates is ever counted as proof of B-Rep equality.
#include "compare_core.hpp"
#include <algorithm>
#include <cmath>
#include <cctype>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <string>
#include <limits>
namespace dsac {
inline std::string normName(std::string s){
 for(char &c:s){unsigned char v=static_cast<unsigned char>(c);c=char(std::tolower(v));if(c=='\\')c='/';} return s;
}
inline bool identicalReference(const Item&a,const Item&b){return normName(a.file)==normName(b.file)&&normName(a.part)==normName(b.part);}
inline std::string referenceKey(const Item&a){return normName(a.file)+"\x1f"+normName(a.part);}
inline std::string normalizePosition(const Item&v,double tolerance){
 if(!v.poseValid)return "";
 const auto quant=[&](double x){return std::llround(x/(tolerance*2));};
 return std::to_string(quant(v.pose.t[0]))+":"+std::to_string(quant(v.pose.t[1]))+":"+std::to_string(quant(v.pose.t[2]));
}
inline std::string geoKey(const Item&v){
 if(!v.geometry.valid)return "";
 std::vector<std::string> ss;
 for(const auto&s:v.geometry.solids){
  ss.push_back(std::to_string(std::llround(s.volume*10.0))+":"+
   std::to_string(std::llround(s.area*10.0))+":"+std::to_string(s.faces)+":"+std::to_string(s.edges));
 }
 std::sort(ss.begin(),ss.end());std::string out;
 for(const auto&s:ss)out+=s+"/";
 return out;
}
struct Candidate26 {int a,b,level;double distance,angle,cost;};
inline std::vector<Result> matchOccurrences(const Snapshot&a,const Snapshot&b,
                                            double toleranceMm=0.01,double angleToleranceDeg=0.05){
 const int na=static_cast<int>(a.items.size()), nb=static_cast<int>(b.items.size());
 std::unordered_map<std::string,std::vector<int>> refs,geoms,names,poses;
 std::unordered_map<std::string,int> referenceCountA,referenceCountB;
 for(const auto&x:a.items)referenceCountA[referenceKey(x)]++;
 for(const auto&y:b.items)referenceCountB[referenceKey(y)]++;
 for(int j=0;j<nb;++j){const auto&v=b.items[size_t(j)];
  refs[referenceKey(v)].push_back(j);
  if(v.geometry.valid)geoms[geoKey(v)].push_back(j);
  names[normName(v.part)].push_back(j);names["@instance:"+normName(v.name)].push_back(j);
  if(v.poseValid)poses[normalizePosition(v,toleranceMm)].push_back(j);
 }
 // For repeated fasteners, bucket entries can contain thousands of occurrences.
 // Sort by coordinate so searching candidates stays local, not quadratic.
 auto byX=[&](int lhs,int rhs){return b.items[size_t(lhs)].pose.t[0]<b.items[size_t(rhs)].pose.t[0];};
 for(auto*index : {&refs,&geoms,&names}){
  for(auto &entry:*index)if(entry.second.size()>32)
   std::sort(entry.second.begin(),entry.second.end(),byX);
 }
 std::vector<Candidate26> pairs;pairs.reserve(static_cast<size_t>(std::min(na*9,1000000)));
 for(int i=0;i<na;++i){const auto&x=a.items[size_t(i)];
  std::unordered_set<int> cand; cand.reserve(64);
  auto append=[&](const std::unordered_map<std::string,std::vector<int>>&index,const std::string&key){
   auto it=index.find(key);if(it==index.end())return;
   const auto&values=it->second;
   if(values.size()<=32){for(int j:values)cand.insert(j);return;}
   if(!x.poseValid){for(size_t k=0;k<8&&k<values.size();++k)cand.insert(values[k]);return;}
   auto pos=std::lower_bound(values.begin(),values.end(),x.pose.t[0],
     [&](int j,double coord){return b.items[size_t(j)].pose.t[0]<coord;});
   const auto offset=static_cast<std::ptrdiff_t>(pos-values.begin());
   for(std::ptrdiff_t d=-12;d<=12;++d){const auto i=offset+d;
    if(i>=0&&i<static_cast<std::ptrdiff_t>(values.size()))cand.insert(values[size_t(i)]);
   }
  };
  append(refs,referenceKey(x));
  if(x.geometry.valid)append(geoms,geoKey(x));
  append(names,normName(x.part));append(names,"@instance:"+normName(x.name));
  if(x.poseValid){
   // Adjacent position buckets handle quantization boundaries without N*M fallback.
   for(int dx=-1;dx<=1;++dx)for(int dy=-1;dy<=1;++dy)for(int dz=-1;dz<=1;++dz){
    const auto q=[&](double v,int d){return std::llround(v/(toleranceMm*2))+d;};
    const auto k=std::to_string(q(x.pose.t[0],dx))+":"+std::to_string(q(x.pose.t[1],dy))+":"+std::to_string(q(x.pose.t[2],dz));
    append(poses,k);
   }
  }
  for(int j:cand){const auto&y=b.items[size_t(j)];
   const int geo=compareGeometry(x.geometry,y.geometry);
   const bool reference=identicalReference(x,y);
   const bool named=normName(x.part)==normName(y.part)||normName(x.name)==normName(y.name);
   const bool pose=x.poseValid&&y.poseValid;
   const double dist=pose?distance(x.pose,y.pose):1e12,ang=pose?rotationDeg(x.pose,y.pose):360.0;
   const bool here=pose&&dist<=toleranceMm&&ang<=angleToleranceDeg;
   // Geometry signatures are strong evidence only for feature equivalence.
   // Name/reference can identify a modified component, but never prove its geometry.
   int level=0;
   if(geo==1)level=4;
   else if(reference)level=3;
   else if(named&&here)level=2;
   else if(here)level=1;
   if(!level)continue;
   // Geometry mismatch is meaningful even when part number has not changed.
   const double cost=(4-level)*1e10+(geo<0?1e8:0)+(!here?1e6:0)+(!named?1e4:0)+
                      std::min(dist,1e6)*5+ang;
   pairs.push_back({i,j,level,dist,ang,cost});
  }
 }
 std::sort(pairs.begin(),pairs.end(),[](const Candidate26&x,const Candidate26&y){
  if(x.cost!=y.cost)return x.cost<y.cost;
  if(x.a!=y.a)return x.a<y.a;
  return x.b<y.b;
 });
 std::vector<bool> usedA(size_t(na),false),usedB(size_t(nb),false);
 std::vector<Result> out;out.reserve(static_cast<size_t>(na+nb));
 for(const auto&p:pairs){if(usedA[size_t(p.a)]||usedB[size_t(p.b)])continue;
  const auto&x=a.items[size_t(p.a)];const auto&y=b.items[size_t(p.b)];
  Result r;r.ia=p.a;r.ib=p.b;r.geo=compareGeometry(x.geometry,y.geometry);
  r.nameChange=normName(x.name)!=normName(y.name)||normName(x.part)!=normName(y.part);
  r.referenceChange=!identicalReference(x,y);
  if(x.poseValid&&y.poseValid){
   r.dx=y.pose.t[0]-x.pose.t[0];r.dy=y.pose.t[1]-x.pose.t[1];r.dz=y.pose.t[2]-x.pose.t[2];
   r.move=p.distance;r.rotation=p.angle;r.moved=r.move>toleranceMm;r.rotated=r.rotation>angleToleranceDeg;
  }
  r.uncertain=(p.level<3&&r.geo!=1)||!x.poseValid||!y.poseValid;
  // When identical parts repeat, changed positions may have multiple equally
  // valid correspondences. Do not pretend to know which old occurrence moved.
  const std::string ref=referenceKey(x);
  if((r.moved||r.rotated)&&referenceCountA[ref]>1&&referenceCountB[ref]>1){
   r.uncertain=true;
  }
  r.status=r.geo<0?"ZMIENIONA_GEOMETRIA_CECH":r.geo==1?"ZGODNE_CECHY_GEOMETRII":
           p.level==3?"WSPOLNA_REFERENCJA":"DOPASOWANE_WARUNKOWO";
  if(r.moved)r.status+=" + PRZESUNIECIE";
  if(r.rotated)r.status+=" + OBROT";
  if(r.nameChange)r.status+=" + ZMIANA_NAZWY: "+x.name+" -> "+y.name;
  if(r.uncertain)r.status+=" [DOPASOWANIE_WYMAGA_WERYFIKACJI]";
  usedA[size_t(p.a)]=usedB[size_t(p.b)]=true;out.push_back(std::move(r));
 }
 for(int i=0;i<na;++i)if(!usedA[size_t(i)]){Result r;r.ia=i;r.status="USUNIETY_LUB_NIEDOPASOWANY";out.push_back(std::move(r));}
 for(int j=0;j<nb;++j)if(!usedB[size_t(j)]){Result r;r.ib=j;r.status="NOWY_LUB_NIEDOPASOWANY";out.push_back(std::move(r));}
 std::sort(out.begin(),out.end(),[](const Result&x,const Result&y){
  if(x.ia!=y.ia)return(x.ia<0?1000000000:x.ia)<(y.ia<0?1000000000:y.ia);
  return x.ib<y.ib;
 });
 return out;
}
}
