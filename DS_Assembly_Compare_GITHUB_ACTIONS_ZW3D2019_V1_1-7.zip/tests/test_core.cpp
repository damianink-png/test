#include "../source/match_v26.hpp"
#include "../source/overlay_policy.hpp"
#include "../source/bom_v24.hpp"
#include <cassert>
#include <iostream>
#include <cmath>
using namespace dsac;
static Item part(const char* name,const char*file,double x=0) {
 Item it;it.name=name;it.part=name;it.file=file;it.path=std::string("/")+name;
 it.pose.t[0]=x;return it;
}
static void setGeometry(Item&it,double vol=100){
 it.geometry.valid=true;SolidDescriptor d;d.volume=vol;d.area=80;d.faces=6;d.edges=12;
 it.geometry.solids.push_back(d);
}
static void matches(const Snapshot&A,const Snapshot&B,int matched,int deleted,int inserted){
 const auto v=matchOccurrences(A,B);
 int m=0,d=0,n=0;for(auto&r:v)if(r.ia>=0&&r.ib>=0)m++;else if(r.ia>=0)d++;else n++;
 assert(m==matched && d==deleted && n==inserted);
}
int main(){
 // Strong identity: same source reference, name changed, no duplicate ghost.
 Snapshot a,b;a.items.push_back(part("ABC","common.z3",10));
 b.items.push_back(part("CBA","common.z3",10));
 auto r=matchOccurrences(a,b);assert(r.size()==1 && r[0].ia==0 && r[0].ib==0);
 assert(r[0].nameChange && r[0].status.find("ABC -> CBA")!=std::string::npos);
 assert(classify(r[0],true,true)==ChangeKind::Unchanged);
 assert(!showsOld(ChangeKind::Unchanged));
 // Different references, same unique position: a tentative pair, never fake added/deleted.
 b.items[0].file="other.z3";
 r=matchOccurrences(a,b);assert(r.size()==1 && r[0].uncertain);
 assert(classify(r[0],false,true)==ChangeKind::Unverified);
 assert(!showsOld(ChangeKind::Unverified));
 // Confirmed B-Rep feature signature (not mathematically exact geometry proof).
 setGeometry(a.items[0]);setGeometry(b.items[0]);r=matchOccurrences(a,b);
 assert(r.size()==1 && r[0].geo==1);
 assert(classify(r[0],false,true)==ChangeKind::Unchanged);
 // Moved same-reference part = blue only, no old position.
 b.items[0].file="common.z3";b.items[0].pose.t[0]=15;
 r=matchOccurrences(a,b);assert(r.size()==1 && r[0].moved);
 assert(classify(r[0],true,true)==ChangeKind::Modified);
 assert(newRole(ChangeKind::Modified)==Role::Blue&&!showsOld(ChangeKind::Modified));
 // True removal and addition.
 Snapshot c,d;c.items.push_back(part("X","A.z3",0));c.items.push_back(part("Y","A.z3",120));
 d.items.push_back(part("X","A.z3",0));
 matches(c,d,1,1,0);
 d.items.push_back(part("NEW","B.z3",300));
 matches(c,d,1,1,1);
 // Repeated identical pieces matched individually, irrespective of ordering.
 Snapshot e,f;
 for(int k=0;k<5;++k)e.items.push_back(part("BOLT","bolts.z3",k*25));
 for(int k=4;k>=1;--k)f.items.push_back(part("BOLT","bolts.z3",k*25));
 matches(e,f,4,1,0);
 // Names can be different when geometry signatures match.
 Snapshot g,h;g.items.push_back(part("OLD","abc.z3",0));h.items.push_back(part("NEW","def.z3",0));
 setGeometry(g.items[0]);setGeometry(h.items[0]);
 r=matchOccurrences(g,h);assert(r.size()==1 && r[0].geo==1 && r[0].nameChange);
 assert(classify(r[0],false,true)==ChangeKind::Unchanged);
 // Geometry difference on same physical reference => change, never new/removed.
 h.items[0].file="abc.z3";h.items[0].part="OLD";h.items[0].name="OLD";
 setGeometry(h.items[0],200);
 r=matchOccurrences(g,h);assert(r.size()==1 && r[0].geo<0);
 assert(classify(r[0],true,true)==ChangeKind::Modified);
 // Two coincident but unnamed objects: quarantine ambiguity rather than create ghost overlays.
 Snapshot q,z; q.items.push_back(part("A1","aa.z3",0));q.items.push_back(part("A2","aa.z3",0));
 z.items.push_back(part("B1","bb.z3",0));z.items.push_back(part("B2","bb.z3",0));
 auto qr=matchOccurrences(q,z);assert(qr.size()==2);
 for(const auto &one:qr){assert(one.ia>=0&&one.ib>=0&&one.uncertain);
  assert(classify(one,false,true)==ChangeKind::Unverified);}
 // BOM quantity and mass, unknown mass must remain unknown.
 Snapshot bom;Item v=part("PLATE","plate.z3");v.massKnown=true;v.massKg=2.5;
 bom.items={v,v,v,part("UNWEIGHED","other.z3")};
 auto lines=makeBom(bom);assert(lines.size()==2);
 assert(knownMassOccurrences(lines)==3);
 assert(std::abs(knownMassTotalKg(lines)-7.5)<1e-12);
 // Formatting of the 3-color categories.
 assert(zw3dColor(Role::Green)==1 && zw3dColor(Role::Blue)==5);
 assert(showsOld(ChangeKind::Removed) && !showsOld(ChangeKind::Added));
 assert(isGhost(Role::Orange)&&!isGhost(Role::Green));
 // 3,000 repeats: all must be matched one-to-one without ambiguous removals.
 Snapshot largeA,largeB;
 for(int k=0;k<3000;++k){
  Item v=part("BOLT","common-fasteners.z3",(k%100)*24.0);
  v.pose.t[1]=(k/100)*24.0;
  largeA.items.push_back(v);
  largeB.items.push_back(v);
 }
 auto largeRows=matchOccurrences(largeA,largeB);
 assert(largeRows.size()==3000);
 for(const auto &row:largeRows){assert(row.ia>=0&&row.ib>=0 && !row.moved);}
 // Same pose but renamed on one side must never yield both added and removed.
 Snapshot renamedA,renamedB;
 renamedA.items.push_back(part("ABC","a-part.Z3",42));
 renamedB.items.push_back(part("CBA","b-part.Z3",42));
 auto renameRows=matchOccurrences(renamedA,renamedB);
 assert(renameRows.size()==1&&renameRows[0].ia==0&&renameRows[0].ib==0);
 assert(renameRows[0].uncertain && classify(renameRows[0],false,true)==ChangeKind::Unverified);
 std::cout<<"DSAC V2.6: indexed matching, rename, positioning, duplicates, mass, colors PASS\n";
}
// Large repeated fixtures: indexed matching must avoid an accidental N*M scan.
