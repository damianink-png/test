# DS Compare V3.0 — Geometry & Assembly Comparison

**Designed & developed by Szymczyk Damian**

Prototyp porównywania geometrii B-Rep z nowym interfejsem w ciemnym stylu DS Estimate. Dwie osobne części:

- **`DSCompareV3.exe`** — samodzielny program Windows x64, porównuje STEP/STP silnikiem Open CASCADE w *osobnym procesie*.
- **`DSAssemblyCompare2019.dll`** — *eksperymentalny* most dla ZW3D 2019 x64, bez analizy B-Rep w procesie ZW3D. Dodatek eksportuje aktywny Z3 jako STEP, a następnie uruchamia EXE.

Nie potrzeba administratora ani Pythona na komputerze użytkownika dla gotowej paczki skompilowanej na GitHubie. Program musi być jednak dopuszczony przez zabezpieczenia Windows/IT.

## Bezpieczny test — najpierw bez ZW3D

1. Rozpakuj całą paczkę z GitHub Actions do jednego folderu, np. `D:\DSCompareV3`. Folder `_internal` musi pozostać obok `DSCompareV3.exe`.
2. Uruchom `DSCompareV3.exe` i wskaż dwa STEP/STP. Przygotowane modele testowe są w `samples`.
3. Kliknij **PORÓWNAJ B-REP**, a następnie sprawdź zakładkę **Wyniki**, `RAPORT.html`, `ZMIANY.csv`, `BOM_A.csv`, `BOM_B.csv` i `POROWNANIE_KOLORY.step`.
4. Sprawdź wynikowy STEP w ZW3D, upewniając się, że import kolorów jest włączony.

## Integracja ZW3D 2019 — tryb eksperymentalny

Przed testami zapisz swoje dokumenty. Zrób kopię działającej starej DLL i **zamknij ZW3D** przed jej zamianą.

Jeśli ZW3D już ładuje starą bibliotekę `DSAssemblyCompare2019.dll` jako makro, zastąp ją biblioteką V3.0 w tym samym miejscu. Plik `DSCompareV3.exe` nie musi znajdować się w tym samym katalogu co DLL, lecz wtedy umieść **obok DLL** zwykły plik tekstowy o nazwie **`DSComparePath.txt`**, którego **pierwszy wiersz** to absolutna ścieżka do programu, np.:

```text
D:\DSCompareV3\DSCompareV3.exe
```

Alternatywnie ustaw zmienną środowiskową `DSCOMPARE_EXE` na pełną ścieżkę do EXE lub umieść cały folder programu obok DLL.

**Krok po kroku, bez zamykania/otwierania modeli przez DLL:**

1. Otwórz w ZW3D model A `.Z3`, aktywuj właściwy obiekt/korzeń i wpisz **`~DSCOMPARE_A`**. Most użyje `cvxFileExport(VX_EXPORT_TYPE_STEP, ...)` z opcją AP214 + assembly do zapisu tymczasowego STEP.
2. Aktywuj model B w ZW3D, wpisz **`~DSCOMPARE_B`**. Most zapisze jego STEP i otworzy `DSCompareV3.exe` z obiema ścieżkami już wpisanymi w oknie.
3. Kliknij **PORÓWNAJ B-REP** w zewnętrznym oknie. Program nie modyfikuje Z3. Kolorowy wynik `.step` otwórz w ZW3D ręcznie.
4. Dodatkowe komendy: **`~DSCOMPARE`** lub stara **`~DSAC`** — otwórz DS Compare z ostatnimi eksportami, **`~DSCOMPARE_INFO`** — instrukcja.

Eksport następuje **wyłącznie w callbacku polecenia ZW3D**, nie w procedurze okna dialogowego Win32. DLL nie wywołuje `cvxFileOpen`, `cvxFileClose`, `cvxFileSave` ani `cvxFileNew`. Po eksporcie uruchamia się niezależny EXE. Ślady diagnostyczne: **`%TEMP%\DSCompareV3\bridge.log`**.

**Ograniczenie:** metoda `cvxFileExport` i pola `svxSTEPData` są zgodne z dostarczonym nagłówkiem `VxApi.h` ZW3D 2019, ale nie zostały przetestowane w działającym ZW3D. Eksport całego aktywnego obiektu wymaga potwierdzenia na realnych modelach. W przypadku wielu obiektów w `.Z3` upewnij się, że jest aktywny właściwy root. Jeżeli ZW3D nie ładuje nowej DLL, jej nazwa / rejestracja może wymagać dopasowania do sposobu ładowania na Twoim stanowisku. Nie zastępuj DLL na komputerze produkcyjnym bez możliwości przywrócenia kopii.

## Kolory i BOM

- Zielony — bez zmian B-Rep, także wtedy, gdy zmieniono nazwę.
- Fioletowy — dodane, zmienione geometrycznie, przesunięte lub obrócone.
- Pomarańczowy — usunięte.
- Szary — niepewne (nie traktowane automatycznie jako identyczne).

Własne kolory wybrane w oknie wpływają na eksport STEP. BOM dotyczy **brył STEP**, a nie natywnych pozycji drzewa złożeń ZW3D. Masy szacowane są z geometrii i wspólnej, ustawianej gęstości (domyślnie 7850 kg/m³). Brak odczytu materiałów ZW3D. Wciąż obowiązują limity bezpieczeństwa w silniku V2.9 (1000 brył/plik i do 15 000 porównań B-Rep).

## Kompilacja Windows przez GitHub Actions

Wgraj do katalogu głównego repozytorium plik **`DSCompare_V3_ZRODLA.zip`**, a osobny plik **`build-dscompare-v30.yml`** do **`.github/workflows/`** (rozpakowywanie źródeł odbywa się w workflow). Następnie w GitHub Actions wybierz **`DS Compare V3.0 - EXE and ZW3D 2019 Bridge DLL`** i **Run workflow**.

Pipeline Windows 2022 x64 instaluje silnik Open CASCADE, wykonuje testy, buduje `DSCompareV3.exe` (PyInstaller `--onedir`) oraz `DSAssemblyCompare2019.dll` (MSVC C++17). Publikuje pojedynczy artefakt `DSCompare-V3-Windows-x64-EXE-and-ZW3D-DLL` z EXE, DLL, zależnościami i `SHA256.txt`.

**Status:** gotowy kod źródłowy i testy Python, ale kompilacja Windows DLL i działanie makra w rzeczywistym ZW3D **muszą zostać sprawdzone**. Skompilowanie w GitHub Actions nie dowodzi stabilności ZW3D.

## Uruchamianie z Pythona (dla programisty)

Wymagania Python 3.11 x64 i `pip install -r requirements.txt`:

```sh
python DSCompareV3.py
python DSCompareV3.py --a samples/MODEL_A.step --b samples/MODEL_B.step
python -m dsac29.cli samples/MODEL_A.step samples/MODEL_B.step -o WYNIKI
python -m pytest -q tests
```
