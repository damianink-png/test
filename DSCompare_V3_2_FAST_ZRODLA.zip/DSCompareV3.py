"""DS Compare V3.2 FAST executable entry point: GUI + isolated B-Rep worker."""
import sys
from dsac29.gui import main
if __name__ == '__main__':
    sys.exit(main())
