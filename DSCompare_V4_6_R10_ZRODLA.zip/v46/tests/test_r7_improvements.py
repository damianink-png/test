"""R7: native picker, moved-population rules, and accessible task options."""
import os
from pathlib import Path
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.TopLoc import TopLoc_Location
from OCP.gp import gp_Trsf,gp_Vec
from dsac29.geometry import describe
from dsac29.compare import Record
from dsac29.revision_rules import classify_revisions


def _part(shape,x,name='Rura'):
 tr=gp_Trsf();tr.SetTranslation(gp_Vec(x,0,0))
 return describe(shape.Located(TopLoc_Location(tr)),name,name)


def test_large_moved_native_repetitions_need_no_retesting(monkeypatch):
 from dsac29 import revision_rules
 native=BRepPrimAPI_MakeBox(7,8,9).Shape()
 a=[_part(native,i*20) for i in range(100)]
 b=[_part(native,i*20+100) for i in range(100)]
 rec=[Record(i,i,'MOVED','') for i in range(100)]
 calls=[]
 def slow(*args):calls.append(True);raise RuntimeError('unnecessary expensive retest')
 monkeypatch.setattr(revision_rules,'equivalent_rigid',slow)
 statuses=[r.status for r in classify_revisions(a,b,rec,progress=lambda x:None)]
 assert statuses==['MOVED']*100 and not calls


def test_differing_populations_never_moved():
 native=BRepPrimAPI_MakeBox(7,8,9).Shape()
 a=[_part(native,i*20) for i in range(100)]
 b=[_part(native,i*20+10) for i in range(101)]
 rec=[Record(i,i,'MOVED','') for i in range(100)] + [Record(None,100,'ADDED','')]
 r=classify_revisions(a,b,rec)
 assert not any(x.status=='MOVED' for x in r)
 assert len([x for x in r if x.status=='REMOVED'])==100
 assert len([x for x in r if x.status=='ADDED'])==101


def test_modified_geometry_is_split():
 a=[_part(BRepPrimAPI_MakeBox(1,2,3).Shape(),0)]
 b=[_part(BRepPrimAPI_MakeBox(1,2,4).Shape(),0)]
 r=classify_revisions(a,b,[Record(0,0,'CHANGED','')])
 assert sorted(x.status for x in r)==['ADDED','REMOVED']


def test_task_options_theme_and_picker(tmp_path,monkeypatch):
 os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
 from PySide6.QtWidgets import QApplication
 from dsac29.gui46 import Window
 from dsac29 import gui45
 app=QApplication.instance() or QApplication([])
 w=Window();w.show();app.processEvents()
 assert list(w.nav)==['compare','mass']
 assert w.stack.indexOf(w.pages['settings'])==-1
 assert not w.param_frame.isVisible()
 w.param_button.click();app.processEvents()
 assert w.param_frame.isVisible() and w.tolerance.isVisible() and w.old_color.isVisible()
 assert w.density.parentWidget() is not w.pages['settings']
 w.mass_output.setText(str(tmp_path));assert w.output.text()==str(tmp_path)
 before=w.theme.currentText();w.theme_button.click()
 assert w.theme.currentText()!=before and not w.theme_button.icon().isNull()
 picked=tmp_path/'A.step';picked.write_text('placeholder')
 monkeypatch.setattr(gui45,'windows_explorer_dialog',lambda *args,**kwargs:str(picked))
 w.a.choose();assert Path(w.a.path.text())==picked
 w.close()
