"""R10 acceptance: evidence, exact matching, export states and import scope."""
import json,os
from pathlib import Path
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.TopLoc import TopLoc_Location
from OCP.gp import gp_Trsf,gp_Vec
from dsac29.geometry import describe
from dsac29.compare import compare,Record
from dsac29.revision_rules import classify_revisions


def part(x=0,size=10,name='P',shape=None):
    shape=shape if shape is not None else BRepPrimAPI_MakeBox(size,7,9).Shape()
    tr=gp_Trsf();tr.SetTranslation(gp_Vec(x,0,0))
    return describe(shape.Located(TopLoc_Location(tr)),name,name)


def test_brep_failure_survives_classification_and_colored_export(tmp_path,monkeypatch):
    import importlib
    matcher=importlib.import_module('dsac29.compare')
    def broken(*args):raise RuntimeError('simulated CAD failure')
    monkeypatch.setattr(matcher,'equivalent_world',broken)
    monkeypatch.setattr(matcher,'equivalent_rigid',broken)
    a=[part()];b=[part()]
    rec=classify_revisions(a,b,compare(a,b,revision_only=True))
    assert len(rec)==2 and all(r.status=='UNCERTAIN' for r in rec)
    from dsac29.step_io import export_revision_step
    target=tmp_path/'uncertain.step'
    diag=export_revision_step(target,rec,a,b)
    assert diag['pokolorowane_etykiety']==2
    assert '06_DO_SPRAWDZENIA' in target.read_text(errors='replace')


def test_revision_shortcut_avoids_discarded_overlap_tests(monkeypatch):
    from dsac29 import geometry
    def forbidden(*args):raise AssertionError('Discarded overlap work executed')
    monkeypatch.setattr(geometry,'_common_volume',forbidden)
    result=compare([part(name='OLD')],[part(size=10.1,name='NEW')],revision_only=True)
    assert {r.status for r in result}=={'ADDED','REMOVED'}


def test_large_assignment_global_optimum_not_greedy():
    from dsac29.assignment import assign
    edges={(i,j):(0. if i==j else 1.) for i in range(65) for j in range(65)}
    edges.update({(0,0):.09,(0,1):.11,(1,0):.01,(1,1):.21})
    result=assign(edges)
    assert len(result)==65
    assert {(i,j) for i,j,_,_ in result if i<2}=={(0,1),(1,0)}
    assert abs(sum(edges[i,j] for i,j,_,_ in result)-.12)<1e-9
    assert all(uncertain for _,_,uncertain,_ in result)


@pytest.mark.parametrize('count',[10,65,120])
def test_repeated_relocations_preserve_all_occurrences(count):
    shape=BRepPrimAPI_MakeBox(10,7,9).Shape()
    a=[part(i*30,shape=shape) for i in range(count)]
    b=[part(i*30+4,shape=shape) for i in reversed(range(count))]
    records=classify_revisions(a,b,compare(a,b,revision_only=True))
    assert len(records)==count and all(r.status=='MOVED' for r in records)
    assert len({r.a_index for r in records})==len({r.b_index for r in records})==count
    assert all(abs(r.distance_mm-4)<1e-8 for r in records)


@pytest.mark.parametrize('mode,expected',[('fast','szybka_strukturalna_bez_ponownego_importu'),('full','pelna_ponowny_import')])
def test_explicit_verification_modes(tmp_path,monkeypatch,mode,expected):
    from dsac29.step_io import export_revision_step
    monkeypatch.setenv('DSCOMPARE_STEP_VERIFY',mode)
    p=part();diag=export_revision_step(tmp_path/'out.step',[Record(0,0,'SAME','')],[p],[p])
    assert diag['weryfikacja']==expected


def test_import_reports_faces_outside_solids_and_enforces_limit(tmp_path):
    from OCP.BRep import BRep_Builder
    from OCP.TopoDS import TopoDS_Compound
    from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeFace
    from OCP.gp import gp_Pln,gp_Pnt,gp_Dir
    from OCP.STEPControl import STEPControl_Writer,STEPControl_AsIs
    from dsac29.step_io import load_step
    compound=TopoDS_Compound();builder=BRep_Builder();builder.MakeCompound(compound)
    builder.Add(compound,part().shape)
    builder.Add(compound,BRepBuilderAPI_MakeFace(gp_Pln(gp_Pnt(50,0,0),gp_Dir(0,0,1)),0,10,0,10).Face())
    writer=STEPControl_Writer();writer.Transfer(compound,STEPControl_AsIs)
    file=tmp_path/'mixed.step';writer.Write(str(file));stats={}
    parts=load_step(file,diagnostics=stats)
    assert len(parts)==1 and stats['faces_outside_solids']==1
    builder.Add(compound,part(30).shape)
    writer=STEPControl_Writer();writer.Transfer(compound,STEPControl_AsIs);writer.Write(str(file))
    with pytest.raises(ValueError,match='Limit'):load_step(file,max_solids=1)
    assert len(load_step(file,max_solids=2))==2


def test_ui_material_identity_tables_and_failed_step(tmp_path,monkeypatch):
    os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
    from PySide6.QtCore import Qt,QSettings
    from PySide6.QtWidgets import QApplication,QHeaderView
    from dsac29 import gui46
    app=QApplication.instance() or QApplication([])
    settings=QSettings(str(tmp_path/'isolated.ini'),QSettings.IniFormat)
    monkeypatch.setattr('dsac29.gui45.QSettings',lambda *args:settings)
    w=gui46.Window()
    index=next(i for i in range(w.materials.count()) if w.materials.itemText(i).startswith('Hardox'))
    w.materials.setCurrentIndex(index);w.verify_mode.setCurrentIndex(w.verify_mode.findData('full'))
    w.close();w=gui46.Window()
    assert w.materials.currentText().startswith('Hardox') and w.density.value()==7850
    assert w.verify_mode.currentData()=='full'
    assert w.compare_table.verticalScrollBarPolicy()==Qt.ScrollBarAsNeeded
    assert w.compare_table.horizontalHeader().sectionResizeMode(0)==QHeaderView.Interactive
    assert 'UNCERTAIN' in w.filter_buttons
    def fake_finished(self,code,status):self.completion_ok=True
    monkeypatch.setattr(gui46.BaseWindow,'finished',fake_finished)
    w.task='compare';w.was_cancelled=False
    w.compare_open['POROWNANIE_KOLORY.step'].setEnabled(False)
    w.finished(0,None)
    assert w.progress.value()==0 and w.report_progress.value()==100
    assert 'błąd' in w.step_progress_label.text()
    w.close()
