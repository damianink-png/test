"""Worker for long-running CAD operations; isolated from the Qt event loop."""
import argparse,json,sys,traceback
from pathlib import Path

def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--worker',required=True,choices=['compare','mass','mesh','detail'])
    p.add_argument('--thumbnails',action='store_true')
    p.add_argument('--revision-style',action='store_true')
    p.add_argument('--old-alpha',type=float,default=0.4)
    p.add_argument('--no-preview',action='store_true')
    p.add_argument('--manual-review',default='')
    p.add_argument('--record',type=int,default=0)
    p.add_argument('--a',default='');p.add_argument('--b',default='')
    p.add_argument('--input',default='');p.add_argument('--output',required=True)
    p.add_argument('--tolerance',type=float,default=0.01)
    p.add_argument('--density',type=float,default=7850)
    p.add_argument('--quality',default='normalna')
    p.add_argument('--generate-step',action='store_true')
    p.add_argument('--diff-step',action='store_true')
    p.add_argument('--align',action='store_true')
    p.add_argument('--direct-scene',action='store_true')
    p.add_argument('--palette',default='{}')
    p.add_argument('--max-solids',type=int,default=1000)
    p.add_argument('--step-verify',choices=['auto','full','fast'],default='auto')
    p.add_argument('--schema',choices=['AP214IS','AP242DIS'],default='AP214IS')
    ns=p.parse_args(argv)
    folder=Path(ns.output);folder.mkdir(parents=True,exist_ok=True)
    event_file=folder/'_POSTEP_V37.jsonl'
    result_file=folder/'_WYNIK_V37.json'
    for path in (event_file,result_file):
        try:path.unlink()
        except FileNotFoundError:pass
    def emit(message):
        with event_file.open('a',encoding='utf-8') as file:
            file.write(json.dumps({'tekst':str(message)},ensure_ascii=False)+'\n');file.flush()
    try:
        if ns.worker=='compare':
            import os
            os.environ['DSCOMPARE_STEP_SCHEMA']=ns.schema
            os.environ['DSCOMPARE_STEP_VERIFY']=ns.step_verify
            from .cli import process
            palette=json.loads(ns.palette)
            output,recs,err=process(ns.a,ns.b,ns.output,ns.tolerance,ns.density,
                   max_solids=ns.max_solids,step=ns.generate_step,diff_step=ns.diff_step,preview3d=False,
                   colors=palette,progress=emit,align=ns.align,revision_style=ns.revision_style,thumbnails=ns.thumbnails,old_alpha=ns.old_alpha,direct_scene=ns.direct_scene,manual_review=json.loads(Path(ns.manual_review).read_text(encoding='utf-8')) if ns.manual_review else None)
            payload={'ok':True,'folder':str(output),'wyniki':len(recs),'blad_step':err,'step_ready':not bool(err) and (output/'POROWNANIE_KOLORY.step').is_file(),'alignment':json.loads((output/'PODSUMOWANIE.json').read_text(encoding='utf-8')).get('alignment',{})}
        elif ns.worker=='detail':
            from .scene42 import make_detail
            target=make_detail(Path(ns.input),ns.record,ns.tolerance,emit)
            payload={'ok':True,'folder':str(target)}
        elif ns.worker=='mass':
            from .single_mass import analyze_single
            output,s=analyze_single(ns.input,ns.output,ns.density,progress=emit,preview=not ns.no_preview,max_solids=ns.max_solids)
            payload={'ok':True,'folder':str(output),'podsumowanie':s}
        else:
            from .mesh_v37 import make_mesh
            info=make_mesh(ns.input,folder/'SCENA_3D.npz',ns.quality,notify=emit)
            payload={'ok':True,'folder':str(folder),'scena':info}
    except Exception:
        emit('BŁĄD: '+traceback.format_exc().splitlines()[-1])
        payload={'ok':False,'error':traceback.format_exc()}
    result_file.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    return 0 if payload['ok'] else 1
