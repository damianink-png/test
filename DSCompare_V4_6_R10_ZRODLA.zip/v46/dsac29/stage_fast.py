"""Atomic progress hand-off between Windows worker and Qt main window."""
from __future__ import annotations
import json, os
from pathlib import Path

class StageWriter:
    def __init__(self,folder):
        self.path=Path(folder)/'_ETAPY.json'
        self.values={'step':'oczekuje','reports':'oczekuje','report_percent':0}

    def update(self,**changes):
        # Update only if there is a meaningful change: avoid disk churn
        # for large BOMs and keep partial JSON unreadable to other processes.
        if all(self.values.get(k)==v for k,v in changes.items()):return
        self.values.update(changes)
        tmp=self.path.with_suffix('.json.tmp')
        tmp.write_text(json.dumps(self.values,ensure_ascii=False),encoding='utf-8')
        os.replace(tmp,self.path)
