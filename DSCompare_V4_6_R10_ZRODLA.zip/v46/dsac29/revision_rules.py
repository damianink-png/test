"""Conservative revision classification with cached part populations.

A relocated occurrence is MOVED only when the geometrically identical named
part has the same number of occurrences in both revisions. Unknown/changed
correspondences become separate old and new occurrences.
"""
from collections import defaultdict
from time import perf_counter
from .compare import Record
from .names import canonical, genuine_rename
from .geometry import candidate, equivalent_rigid


def classify_revisions(old, new, records, tolerance=0.01, progress=None):
    by_a=defaultdict(list)
    by_b=defaultdict(list)
    for p in old:by_a[canonical(p.name)].append(p)
    for p in new:by_b[canonical(p.name)].append(p)

    # Hold OCP TShape handles alive: temporary wrappers can otherwise reuse ids.
    handles={id(p):p.shape.TShape() for p in old+new}
    verified={}; populations={}; comparisons=[0]; begin=perf_counter()
    # Reuse B-Rep proofs already obtained in the main matcher. Never repeat an
    # expensive rigid transform for exactly the same native shape definitions.
    for r in records:
        if (r.a_index is not None and r.b_index is not None and
            (r.status=='MOVED' or (r.status=='UNCERTAIN' and 'B-Rep zgodna' in r.confidence))):
            ha=id(handles[id(old[r.a_index])]);hb=id(handles[id(new[r.b_index])])
            verified[ha,hb]=True

    def proof(ref, p):
        if not candidate(ref,p,tolerance):return False
        if ref.shape.IsPartner(p.shape):return True
        # Cache by shared native definition, NOT by occurrence: repeated STEP
        # instances must not trigger hundreds of equivalent_rigid Booleans.
        key=(id(handles[id(ref)]),id(handles[id(p)]))
        if key not in verified:
            comparisons[0]+=1
            if progress and comparisons[0]%8==0:
                progress(f'Weryfikacja liczby wystąpień: {comparisons[0]} różnych definicji B-Rep; {perf_counter()-begin:.1f} s')
            try:verified[key]=bool(equivalent_rigid(ref,p,tolerance)[0])
            except Exception:verified[key]=False
        return verified[key]

    def same_population(a_part,b_part):
        name=canonical(a_part.name)
        if not name or name!=canonical(b_part.name):return False
        key=(name,id(handles[id(a_part)]),id(handles[id(b_part)]))
        if key in populations:return populations[key]
        # Reject mismatched candidate counts *before* any expensive Booleans.
        # A candidate is only a cheap filter, never accepted as shape proof.
        ca=[p for p in by_a[name] if candidate(a_part,p,tolerance)]
        cb=[p for p in by_b[name] if candidate(a_part,p,tolerance)]
        if len(ca)!=len(cb) or not ca:
            populations[key]=False;return False
        # Native identical instances are common in assemblies. No extra B-Rep
        # testing is necessary for those; other definitions are verified once.
        total_a=sum(1 for p in ca if proof(a_part,p))
        total_b=sum(1 for p in cb if proof(a_part,p))
        result=total_a==total_b and total_a>0
        populations[key]=result
        return result

    output=[]
    if progress:progress(f'Po B-Rep: ustalanie przesuniętych części i liczby wystąpień ({len(records)} pozycji)...')
    for n,r in enumerate(records):
        if progress and n and n%50==0:
            progress(f'Po B-Rep: sklasyfikowano {n}/{len(records)} pozycji; dodatkowe testy {comparisons[0]}; {perf_counter()-begin:.1f} s')
        i,j=r.a_index,r.b_index
        if r.status=='UNCERTAIN' and 'B-Rep zgodna' not in r.confidence:
            output.append(r);continue
        if i is None:
            output.append(Record(None,j,'ADDED',r.note,confidence=r.confidence));continue
        if j is None:
            output.append(Record(i,None,'REMOVED',r.note,confidence=r.confidence));continue
        if r.status in ('SAME','RENAMED'):
            renamed=genuine_rename(old[i],new[j])
            output.append(Record(i,j,'RENAMED' if renamed else 'SAME',
                                 ('Zmiana nazwy: '+str(old[i].name)+' → '+str(new[j].name)) if renamed else r.note,
                                 confidence=r.confidence));continue
        if r.status in ('MOVED','UNCERTAIN'):
            proven=r.status=='MOVED' or 'B-Rep zgodna' in r.confidence
            if proven and same_population(old[i],new[j]):
                output.append(Record(i,j,'MOVED',
                    'Równa geometria i liczba wystąpień; inne położenie lub obrót',
                    r.distance_mm,r.delta_x,r.delta_y,r.delta_z,0.0,r.rotation_deg,
                    ('B-Rep; niejednoznaczna tożsamość wystąpienia — sprawdź parę' if r.status=='UNCERTAIN' else 'B-Rep; tożsamość wystąpienia wg pozycji')))
                continue
        # Geometric modifications or ambiguous matches are NOT MOVED.
        # They are represented as removed old + added new, not fake pairs.
        note='Zmiana geometrii, liczby wystąpień lub brak jednoznacznego odpowiednika'
        output.append(Record(i,None,'REMOVED',note,confidence='Rozdzielone rewizje'))
        output.append(Record(None,j,'ADDED',note,confidence='Rozdzielone rewizje'))
    output.sort(key=lambda r:(r.b_index is None,r.b_index if r.b_index is not None else r.a_index))
    assert all(r.status in ('SAME','RENAMED','MOVED','ADDED','REMOVED','UNCERTAIN') for r in output)
    assert len({r.a_index for r in output if r.a_index is not None})==len(old)
    assert len({r.b_index for r in output if r.b_index is not None})==len(new)
    if progress:progress(f'Po B-Rep: klasyfikacja ukończona w {perf_counter()-begin:.1f} s; dodatkowe testy: {comparisons[0]}.')
    return output
