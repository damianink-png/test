"""Revision workspace: empty sessions, two themes, static geometry thumbnails."""
import json,sys,time
from pathlib import Path
from PySide6.QtCore import Qt,QSize,QPointF
from PySide6.QtGui import QColor,QPainter,QPen,QIcon,QPixmap,QGuiApplication
from PySide6.QtWidgets import (QSpinBox,QApplication,QWidget,QFrame,QLabel,QPushButton,QLineEdit,
 QVBoxLayout,QHBoxLayout,QGridLayout,QStackedWidget,QComboBox,QCheckBox,QSizePolicy,
 QProgressBar,QPlainTextEdit,QHeaderView,QStyledItemDelegate,QStyle,QAbstractItemView,QMenu,QFormLayout,QInputDialog,QMessageBox)
from .gui45 import Window as BaseWindow,FileCard as BaseFileCard,button,table,icon as base_icon

def icon(key):
 pix=base_icon(key).pixmap(48,48);paint=QPainter(pix);paint.setCompositionMode(QPainter.CompositionMode_SourceIn);paint.fillRect(pix.rect(),QColor('#4b85ff'));paint.end();return QIcon(pix)

PALETTES={
 'Jasny':dict(bg='#f4f7fc',card='#ffffff',ink='#17253d',muted='#52647e',line='#b9c9de',accent='#2163ef',soft='#e6efff',field='#eaf0f9',hover='#dce9fa',green='#168953',orange='#b85814',blue='#2463eb',purple='#8353cf'),
 'Ciemny':dict(bg='#101113',card='#1d1f22',ink='#edf0f2',muted='#a1a6ad',line='#41454a',accent='#c8d0d8',soft='#303338',field='#25282c',hover='#393e44',green='#4dca8b',orange='#ffac70',blue='#78abf7',purple='#c198ff')}

def theme_style(p):
 return '''
 QWidget {background:BG;color:INK;font-family:"Segoe UI";font-size:13px;}
 QFrame#topbar,QFrame#card,QFrame#metric,QFrame#export {background:CARD;border:1px solid LINE;border-radius:9px;}
 QFrame#topbar {border-radius:0px;border-left:0;border-right:0;border-top:0;border-bottom:2px solid LINE;}
 QFrame#card,QFrame#export {border:1px solid LINE;border-radius:12px;}
 QFrame#metric {border:1px solid LINE;border-radius:9px;}
 QLabel {background:transparent;}
 QLabel#heading {font-size:23px;font-weight:700;} QLabel#sub {color:MUTED;}
 QLabel#brand {font-size:21px;font-weight:700;} QLabel#section {font-size:16px;font-weight:600;}
 QPushButton {background:FIELD;border:1px solid LINE;border-radius:7px;padding:6px 10px;min-height:21px;}
 QPushButton:hover {background:HOVER;border:1px solid ACCENT;}
 QPushButton:pressed {background:SOFT;border-color:ACCENT;}
 QPushButton:focus {border-color:ACCENT;}
 QPushButton:disabled {color:MUTED;background:FIELD;border-color:LINE;}
 QPushButton#primary {background:ACCENT;color:PRIMINK;border:1px solid ACCENT;font-weight:700;padding:8px 13px;}
 QPushButton#primary:hover {background:PRIMHOVER;color:PRIMINK;border-color:PRIMHOVER;}
 QPushButton#primary:pressed {background:SOFT;color:INK;}
 QPushButton#primary:disabled {background:SOFT;color:MUTED;border-color:LINE;}
 QPushButton#nav {background:transparent;border:1px solid transparent;border-radius:7px;padding:8px 14px;}
 QPushButton#nav:hover {background:HOVER;border-color:LINE;}
 QPushButton#nav:checked {background:SOFT;color:INK;border-bottom:2px solid ACCENT;}
 QPushButton#theme-toggle {background:transparent;border:1px solid LINE;border-radius:18px;padding:4px;min-width:30px;max-width:30px;min-height:30px;max-height:30px;}
 QPushButton#theme-toggle:hover {background:HOVER;border-color:ACCENT;}
 QPushButton#filter {padding:5px 8px;} QPushButton#filter:hover {background:HOVER;border-color:ACCENT;} QPushButton#filter:checked {background:SOFT;color:INK;border-color:ACCENT;}
 QLineEdit,QDoubleSpinBox,QSpinBox,QComboBox {background:FIELD;color:INK;border:1px solid LINE;border-radius:6px;padding:5px;min-height:19px;}
 QLineEdit:focus {border-color:ACCENT;}
 QStackedWidget {background:BG;}
 QTableWidget {background:CARD;alternate-background-color:FIELD;border:1px solid LINE;border-radius:7px;gridline-color:LINE;selection-background-color:SOFT;selection-color:INK;}
 QHeaderView::section {background:FIELD;color:INK;font-weight:600;padding:7px;border:0;border-bottom:1px solid LINE;}
 QPlainTextEdit {background:FIELD;border:1px solid LINE;border-radius:6px;color:MUTED;}
 QCheckBox {spacing:7px;padding:3px;} QProgressBar {border:0;background:LINE;border-radius:2px;max-height:4px;} QProgressBar::chunk {background:ACCENT;}
 QToolTip {background:CARD;color:INK;border:1px solid LINE;}
 '''.replace('PRIMHOVER',('#f5f7fa' if p['bg']=='#101113' else '#164fd3')).replace('PRIMINK',('#151719' if p['bg']=='#101113' else '#ffffff')).replace('BG',p['bg']).replace('CARD',p['card']).replace('INK',p['ink']).replace('MUTED',p['muted']).replace('LINE',p['line']).replace('ACCENT',p['accent']).replace('SOFT',p['soft']).replace('FIELD',p['field']).replace('HOVER',p['hover'])

def theme_icon(dark, stroke):
 """High-DPI, centered vector sun/moon. Icon indicates the TARGET mode."""
 from PySide6.QtGui import QPainterPath
 pix=QPixmap(48,48);pix.fill(Qt.transparent)
 p=QPainter(pix);p.setRenderHint(QPainter.Antialiasing)
 color=QColor(stroke)
 if dark:
  # Dark is active -> offer the light/sun appearance.
  p.setBrush(Qt.NoBrush);pen=QPen(color,3);pen.setCapStyle(Qt.RoundCap);p.setPen(pen)
  p.drawEllipse(QPointF(24,24),7.5,7.5)
  for a,b,c,d in [(24,4,24,11),(24,37,24,44),(4,24,11,24),(37,24,44,24),
                  (10,10,15,15),(33,33,38,38),(10,38,15,33),(33,15,38,10)]:
   p.drawLine(QPointF(a,b),QPointF(c,d))
 else:
  # Light is active -> offer a compact true crescent with no text/emoji.
  outer=QPainterPath();outer.addEllipse(QPointF(23,23),16,16)
  mask=QPainterPath();mask.addEllipse(QPointF(31,16),15,15)
  p.setPen(Qt.NoPen);p.fillPath(outer.subtracted(mask),color)
 p.end();pix.setDevicePixelRatio(2);return QIcon(pix)

class Thumbnail(QWidget):
 def __init__(self):
  super().__init__();self.lines=[];self.setMinimumSize(105,82);self.setMaximumWidth(155);self.ink='#7387a3'
 def set_data(self,data):self.lines=data.get('lines',[]);self.update()
 def paintEvent(self,event):
  p=QPainter(self);p.setRenderHint(QPainter.Antialiasing);p.setPen(QPen(QColor(self.ink),.85))
  if not self.lines:
   p.drawText(self.rect(),Qt.AlignCenter,'Miniatura modelu\npo analizie');return
  points=[xy for line in self.lines for xy in line];xs=[xy[0] for xy in points];ys=[xy[1] for xy in points]
  xmin,xmax,ymin,ymax=min(xs),max(xs),min(ys),max(ys);scale=min((self.width()-16)/max(xmax-xmin,.001),(self.height()-16)/max(ymax-ymin,.001))
  cx=(xmin+xmax)/2;cy=(ymin+ymax)/2
  for line in self.lines:
   for a,b in zip(line,line[1:]):
    p.drawLine(QPointF((a[0]-cx)*scale+self.width()/2,(a[1]-cy)*scale+self.height()/2),QPointF((b[0]-cx)*scale+self.width()/2,(b[1]-cy)*scale+self.height()/2))

class FileCard(BaseFileCard):
 def __init__(self,title,subtitle):
  QFrame.__init__(self);self.setObjectName('card');self.setAcceptDrops(True)
  row=QHBoxLayout(self);row.setContentsMargins(16,12,16,12);row.setSpacing(8);col=QVBoxLayout();col.setSpacing(4)
  heading=QLabel(title);heading.setObjectName('section');col.addWidget(heading)
  self.filename=QLabel('Nie wybrano modelu');self.filename.setStyleSheet('font-size:14px;font-weight:600');self.filename.setWordWrap(True);col.addWidget(self.filename)
  self.path=QLineEdit();self.path.setAcceptDrops(False);self.path.setPlaceholderText('Wybierz lub przeciągnij plik STEP / STP…');self.path.textChanged.connect(self.changed.emit);col.addWidget(self.path)
  self.caption=QLabel('Przeciągnij plik tutaj lub kliknij „Wybierz plik”');self.caption.setObjectName('sub');self.caption.setWordWrap(True);col.addWidget(self.caption)
  controls=QHBoxLayout();controls.setSpacing(5)
  choose=button('Wybierz plik',self.choose);controls.addWidget(choose)
  controls.addStretch();col.addLayout(controls);row.addLayout(col,1)
  self.thumbnail=Thumbnail();row.addWidget(self.thumbnail,1)
  self.path.textChanged.connect(self.clear_preview)
 def clear_preview(self):
  self.thumbnail.set_data({});self.caption.setText('Przeciągnij plik tutaj lub kliknij „Wybierz plik”')
  value=self.path.text().strip();self.filename.setText(Path(value).name if value else 'Nie wybrano modelu');self.path.setToolTip(value)

class StatusDelegate(QStyledItemDelegate):
 def paint(self,painter,option,index):
  painter.save()
  status=index.data(Qt.UserRole);key={'SAME':'green','RENAMED':'green','ADDED':'blue','CHANGED':'blue','REMOVED':'orange','UNCERTAIN':'orange'}.get(status,'purple')
  win=self.parent().window();palette=PALETTES.get(win.theme.currentText(),PALETTES['Jasny']);color=QColor(palette[key]);background=QColor(color);background.setAlpha(28)
  if option.state & QStyle.State_Selected:painter.fillRect(option.rect,QColor(palette['soft']))
  rect=option.rect.adjusted(6,5,-6,-5);painter.setRenderHint(QPainter.Antialiasing);painter.setPen(Qt.NoPen);painter.setBrush(background);painter.drawRoundedRect(rect,5,5);painter.setPen(color);painter.drawText(rect,Qt.AlignCenter,option.fontMetrics.elidedText(index.data(),Qt.ElideRight,rect.width()-6));painter.restore()

class Window(BaseWindow):
 generate_thumbnails=True
 def __init__(self,a='',b=''):
  super().__init__(a,b)
  self.setWindowTitle('DS Compare 4.6 R10 — porównanie rewizji')
  screen=QGuiApplication.primaryScreen();geo=screen.availableGeometry() if screen else None
  sw=geo.width() if geo else 1366;sh=geo.height() if geo else 768
  self.compact=(sh<880 or sw<1320)
  self.setMinimumSize(min(950,max(760,sw-12)),min(600,max(520,sh-12)))
  self.resize(min(1450,max(760,sw-24)),min(910,max(520,sh-24)))
  old=self.takeCentralWidget();self.stack.setParent(None)
  central=QWidget();layout=QVBoxLayout(central);layout.setContentsMargins(0,0,0,0);layout.setSpacing(0)
  bar=QFrame();bar.setObjectName('topbar');bl=QHBoxLayout(bar);bl.setContentsMargins(16,5,16,5)
  brand=QLabel('DS  Compare');brand.setObjectName('brand');bl.addWidget(brand);bl.addStretch()
  for key,label in [('compare','Porównanie'),('mass','Masa części')]:
   bnav=self.nav[key];bnav.setParent(bar);bnav.setText(label);bnav.setIconSize(QSize(22,22));bl.addWidget(bnav)
  # Old sidebar is deleted below. Never keep a stale C++ button wrapper in self.nav.
  obsolete=self.nav.pop('settings')
  obsolete.setParent(None)
  obsolete.deleteLater()
  self.stack.removeWidget(self.pages['settings'])
  bl.addStretch()
  # Theme selection is now a single click sun/moon switch, no dropdown.
  self.theme_quick=self.theme  # invisible state holder, compatibility with settings
  self.theme_button=QPushButton();self.theme_button.setObjectName('theme-toggle');self.theme_button.setFixedSize(38,38)
  self.theme_button.setAccessibleName('Przełącz motyw jasny lub ciemny')
  self.theme_button.clicked.connect(self.toggle_theme)
  bl.addWidget(self.theme_button)
  # No fixed-size workspace / no outer scroll area: page resizes with monitor.
  self.stack.setMinimumSize(0,0);self.stack.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
  layout.addWidget(bar);layout.addWidget(self.stack,1);self.setCentralWidget(central);old.deleteLater()
  for pg in self.pages.values():
   pg.layout().setContentsMargins(14,9,14,9);pg.layout().setSpacing(5 if self.compact else 9)
  self._fit_layout_to_monitor()
  self.apply_theme(self.theme.currentText());self.navigate('compare')
  for card in (self.a,self.b):card.path.textChanged.connect(self.invalidate_comparison)
 def _fit_layout_to_monitor(self):
  # Keep all controls inside the main window; wheel scrolling stays available
  # inside long result tables, without visible scroll bars.
  for key in ('compare','mass'):
   pg=self.pages[key]
   if self.compact:pg.layout().setSpacing(4)
  for card in (self.a,self.b):
   card.thumbnail.setMinimumSize(94,68) if self.compact else None
   card.thumbnail.setMaximumWidth(132 if self.compact else 155)
  self.compare_table.setMinimumHeight(95)
  self.compare_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
  self.compare_table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
  self.compare_table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
  self.compare_table.horizontalHeader().setStretchLastSection(True)
  for index,width in enumerate((145,200,200,300)):self.compare_table.setColumnWidth(index,width)
  self.compare_table.verticalHeader().setDefaultSectionSize(28 if self.compact else 32)
  self.mass_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
  self.mass_table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
  self.mass_table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
  self.mass_table.horizontalHeader().setStretchLastSection(True)
  for index,width in enumerate((240,90,150,140,150)):self.mass_table.setColumnWidth(index,width)
  self.log.setMaximumHeight(28 if self.compact else 38)
  self.log.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
  self.mass_log.setMaximumHeight(40 if self.compact else 70)
  self.mass_log.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
  self.export_box.setMinimumHeight(0)
  self.export_box.setMaximumWidth(325 if self.compact else 370)
  self.export_box.setMinimumWidth(290 if self.compact else 330)
  if self.compact:
   self.legend.hide();self.visibility_hint.hide();self.legend_button.show()
   for card in (self.a,self.b):card.caption.hide()
   self.grouping_hint.hide()
   self.compare_description.hide()
   self.settings_note.setText('Tolerancja wpływa na dopasowanie B-Rep. Wyłączone wyrównanie pozwala wykrywać przesunięcia. Przezroczystość STEP zależy też od importera ZW3D.')

 def create_settings(self):
  super().create_settings()
  self.settings_note=self.pages['settings'].findChildren(QLabel)[-1]
  self.theme=QComboBox(self);self.theme.addItems(PALETTES);self.theme.setCurrentText(str(self.store.value('theme46','Jasny')))
  self.theme.hide()  # no selector visible anywhere; keep QSettings and existing API
  self.theme.currentTextChanged.connect(self.apply_theme)
 def toggle_theme(self):
  self.theme.setCurrentText('Ciemny' if self.theme.currentText()=='Jasny' else 'Jasny')
 def apply_theme(self,name):
  p=PALETTES.get(name,PALETTES['Jasny']);self.setStyleSheet(theme_style(p));self.store.setValue('theme46',name)
  if hasattr(self,'theme_quick'):
   self.theme_quick.blockSignals(True);self.theme_quick.setCurrentText(name);self.theme_quick.blockSignals(False)
  if hasattr(self,'theme_button'):
   self.theme_button.setText('');self.theme_button.setIcon(theme_icon(name=='Ciemny',p['ink']));self.theme_button.setIconSize(QSize(24,24))
   self.theme_button.setToolTip('Włącz motyw ciemny' if name=='Jasny' else 'Włącz motyw jasny')
  for key,b in self.nav.items():b.setIcon(icon(key))
  for card in [getattr(self,'a',None),getattr(self,'b',None)]:
   if card:card.thumbnail.ink=p['muted'];card.thumbnail.update()
  if hasattr(self,'metrics'):
   for label,key in zip(self.metrics,('green','blue','purple','blue','orange','green')):label.setStyleSheet(f'font-size:28px;font-weight:700;color:{p[key]}')
 def create_compare(self):
  self.filter_status='ALL';self.metrics=[]
  lay=self.page('compare','Porównanie rewizji','Porównaj modele STEP i otwórz wynik w ZW3D.');lay.setSpacing(7)
  self.compare_description=self.pages['compare'].findChild(QLabel,'sub')
  row=QHBoxLayout();self.a=FileCard('A   Stara rewizja','');self.b=FileCard('B   Nowa rewizja','');row.addWidget(self.a,1);row.addWidget(button('⇄',self.swap));row.addWidget(self.b,1);lay.addLayout(row)
  row=QHBoxLayout();self.run_compare=button('Porównaj i utwórz STEP',lambda:self.start('compare'),True);row.addWidget(self.run_compare)
  self.cancel_compare=button('Anuluj',self.cancel);self.cancel_compare.setEnabled(False);row.addWidget(self.cancel_compare)
  self.compare_summary=QLabel('Wybierz dwa modele, aby rozpocząć.');self.compare_summary.setWordWrap(True);row.addWidget(self.compare_summary,1);  lay.addLayout(row)
  # Relevant options live inside their task, not in a third navigation tab.
  self.param_button=button('Parametry porównania  ▸',self.toggle_compare_options)
  self.param_button.setCheckable(True);self.param_button.setToolTip('Tolerancja, kolory, eksport STEP i folder zapisu')
  lay.addWidget(self.param_button)
  self.param_frame=QFrame();self.param_frame.setObjectName('card');pg=QGridLayout(self.param_frame)
  pg.setContentsMargins(12,8,12,8);pg.setHorizontalSpacing(8);pg.setVerticalSpacing(4)
  for ctrl in (self.tolerance,self.opacity,self.old_color,self.schema,self.align):
   self.pages['settings'].findChild(QFrame,'card').layout().removeWidget(ctrl)
  pg.addWidget(QLabel('Tolerancja B-Rep'),0,0);pg.addWidget(self.tolerance,0,1)
  pg.addWidget(self.align,0,2,1,3)
  pg.addWidget(QLabel('Kolor starej rewizji'),1,0);pg.addWidget(self.old_color,1,1)
  pg.addWidget(QLabel('Przezroczystość A'),1,2);pg.addWidget(self.opacity,1,3)
  pg.addWidget(QLabel('Format STEP'),2,0);pg.addWidget(self.schema,2,1)
  self.output=QLineEdit(str(self.store.value('output',str(Path.home()/'Documents'/'DSCompare'))))
  pg.addWidget(QLabel('Folder wyników'),2,2);pg.addWidget(self.output,2,3)
  pg.addWidget(button('Wybierz…',self.choose_output),2,4)
  self.verify_mode=QComboBox()
  for label,key in [('Automatyczna (pełna do 150 wystąpień)','auto'),('Szybka — struktura pliku','fast'),('Pełna — ponowny import','full')]:self.verify_mode.addItem(label,key)
  self.verify_mode.setCurrentIndex(max(0,self.verify_mode.findData(str(self.store.value('step_verify','auto')))))
  self.verify_mode.currentIndexChanged.connect(lambda:self.store.setValue('step_verify',self.verify_mode.currentData()))
  pg.addWidget(QLabel('Kontrola STEP'),3,0);pg.addWidget(self.verify_mode,3,1,1,4)
  self.verify_mode.setToolTip('Szybka kontrola sprawdza zapisy stylów. Pełna sprawdza przypisania kolorów i przezroczystości po ponownym imporcie.')
  self.solid_limit=QSpinBox();self.solid_limit.setRange(1,10000)
  self.solid_limit.setValue(int(self.store.value('solid_limit',1000)))
  self.solid_limit.valueChanged.connect(lambda value:self.store.setValue('solid_limit',value))
  self.solid_limit.setToolTip('Limit na plik, wspólny dla porównania i masy. Przekroczenie przerywa analizę zamiast obcinać model.')
  pg.addWidget(QLabel('Limit brył / plik'),4,0);pg.addWidget(self.solid_limit,4,1)
  scope=QLabel('Analiza obejmuje bryły SOLID; pominięte powierzchnie są raportowane.');scope.setWordWrap(True);pg.addWidget(scope,4,2,1,3)
  pg.setColumnStretch(3,2);self.param_frame.hide();lay.addWidget(self.param_frame)
  metricrow=QHBoxLayout()
  for title in ('Bez zmian','Do sprawdzenia','Przesunięte','Nowe','Stare','Zmiana nazwy'):
   card=QFrame();card.setObjectName('metric');ml=QVBoxLayout(card);ml.setContentsMargins(8,5,8,5);ml.setSpacing(1);count=QLabel('—');ml.addWidget(count);caption=QLabel(title);caption.setWordWrap(True);ml.addWidget(caption);self.metrics.append(count);metricrow.addWidget(card,1)
  lay.addLayout(metricrow)
  body=QHBoxLayout();left=QVBoxLayout();head=QHBoxLayout();title=QLabel('Zmiany w rewizji');title.setObjectName('section');head.addWidget(title);head.addStretch()
  self.search=QLineEdit();self.search.setPlaceholderText('Szukaj części…');self.search.textChanged.connect(self.filter_results);head.addWidget(self.search);left.addLayout(head)
  filters=QHBoxLayout();self.filter_buttons={};self.filter_selector=QComboBox();filters.addWidget(QLabel('Pokaż:'));filters.addWidget(self.filter_selector)
  for key,label in [('ALL','Wszystkie'),('SAME','Bez zmian'),('UNCERTAIN','Do sprawdzenia'),('MOVED','Przesunięte'),('ADDED','Nowe'),('REMOVED','Stare'),('RENAMED','Zmiana nazwy')]:
   b=button(label,lambda checked=False,k=key:self.select_filter(k));b.setObjectName('filter');b.setCheckable(True);b.setChecked(key=='ALL');self.filter_buttons[key]=b;b.setParent(self);b.hide();self.filter_selector.addItem(label,key)
  self.filter_selector.currentIndexChanged.connect(lambda:self.select_filter(self.filter_selector.currentData()))
  filters.addStretch();left.addLayout(filters)
  # Checkbox replaced by explicit status filters. Kept off-screen for legacy integration API.
  self.only_changes=QCheckBox();self.only_changes.setChecked(False);self.only_changes.toggled.connect(self.filter_results)
  self.compare_table=table(['Status','Stara rewizja A','Nowa rewizja B','Szczegóły']);self.compare_table.setItemDelegateForColumn(0,StatusDelegate(self.compare_table));self.compare_table.verticalHeader().setDefaultSectionSize(36);left.addWidget(self.compare_table,1);body.addLayout(left,1)
  export=QFrame();self.export_box=export;export.setObjectName('export');el=QVBoxLayout(export);el.setContentsMargins(11,9,11,9);el.setSpacing(4)
  h=QLabel('Wynik porównania');h.setObjectName('section');el.addWidget(h)
  self.export_name=QLabel('STEP: oczekuje na analizę');self.export_name.setWordWrap(True);self.export_name.setStyleSheet('font-weight:600;padding:6px 0;');el.addWidget(self.export_name)
  self.legend=QLabel('● Bez zmian — zielony\n● Nowe B — niebieski\n● Przesunięte — fiolet: stare A / nowe B\n● Usunięte A — pomarańczowy');self.legend.setWordWrap(True);self.legend.setMinimumHeight(94);el.addWidget(self.legend)
  grouping=QLabel('Model jest zapisany w grupach według rodzaju zmiany.');self.grouping_hint=grouping;grouping.setObjectName('sub');grouping.setWordWrap(True);el.addWidget(grouping)
  visibility=QLabel('Gdy elementy się pokrywają, ukryj odpowiednią grupę A lub B w drzewie ZW3D.');visibility.setObjectName('sub');visibility.setWordWrap(True);self.visibility_hint=visibility;el.addWidget(visibility);self.legend_button=button('Kolory i grupy…',self.show_color_help);el.addWidget(self.legend_button);self.legend_button.hide();el.addStretch(1)
  self.compare_open={}
  links=QGridLayout();links.setHorizontalSpacing(6);links.setVerticalSpacing(6)
  for i,(text,filename) in enumerate([('Otwórz STEP','POROWNANIE_KOLORY.step'),('Raport HTML','RAPORT.html'),('Zmiany CSV','ZMIANY.csv'),('Folder wyników','')]):
   b=button(text,lambda checked=False,f=filename:self.open_result('compare',f),filename.endswith('.step'))
   b.setEnabled(False);self.compare_open[filename]=b;links.addWidget(b,i//2,i%2)
  el.addLayout(links)
  self.compare_open['POROWNANIE_KOLORY.step'].setToolTip('Otwiera plik w domyślnej aplikacji Windows dla STEP.');body.addWidget(export);lay.addLayout(body,1)
  self.step_progress_label=QLabel('Model STEP: oczekuje')
  self.step_progress_label.setObjectName('sub');lay.addWidget(self.step_progress_label)
  self.progress=QProgressBar();self.progress.setRange(0,100);self.progress.setValue(0);self.progress.setTextVisible(False);lay.addWidget(self.progress)
  self.report_progress_label=QLabel('Raporty HTML / BOM: oczekują')
  self.report_progress_label.setObjectName('sub');lay.addWidget(self.report_progress_label)
  self.report_progress=QProgressBar();self.report_progress.setRange(0,100);self.report_progress.setValue(0)
  self.report_progress.setTextVisible(False);lay.addWidget(self.report_progress)
  self.log=QPlainTextEdit();self.log.setReadOnly(True);self.log.setMaximumHeight(35);self.log.document().setMaximumBlockCount(150);lay.addWidget(self.log)
  foot=QHBoxLayout();label=QLabel('Każdy start programu otwiera pustą sesję.');label.setObjectName('sub');foot.addWidget(label);foot.addStretch();self.reset_button=button('Nowe porównanie',self.reset_session);foot.addWidget(self.reset_button);lay.addLayout(foot)
 def show_color_help(self):
  QMessageBox.information(self,'Kolory i grupy STEP',
   'Bez zmian / zmiana nazwy: zielony.\nNowe B: niebieski.\nUsunięte A: wybrany pomarańczowy lub czerwony, przezroczysty.\nPrzesunięte: stare A jasnofioletowe, nowe B fioletowe.\nDo sprawdzenia: osobna grupa 06_DO_SPRAWDZENIA; kolory starej i nowej rewizji.\n\nW ZW3D ukryj grupę A_STARA lub B_NOWA, gdy części się pokrywają. Obsługa przezroczystości zależy od importera.')
 def toggle_compare_options(self):
  expanded=self.param_button.isChecked()
  self.param_frame.setVisible(expanded)
  self.param_button.setText('Parametry porównania  ▾' if expanded else 'Parametry porównania  ▸')
 def create_mass(self):
  super().create_mass()
  self.mass_summary.setText('Wybierz model i oblicz masy poszczególnych części.')
  self.pages['mass'].findChild(QLabel,'sub').setText('Oblicz masę z objętości i gęstości materiału podanej poniżej.')
  self.pages['settings'].findChild(QFrame,'card').layout().removeWidget(self.density)
  # Remove platform-specific spin arrow controls from density field.
  from PySide6.QtWidgets import QAbstractSpinBox
  self.density.setButtonSymbols(QAbstractSpinBox.NoButtons)
  self.opacity.setButtonSymbols(QAbstractSpinBox.NoButtons)
  self.tolerance.setButtonSymbols(QAbstractSpinBox.NoButtons)
  massrow=QHBoxLayout();massrow.addWidget(QLabel('Materiał'))
  self.materials=QComboBox();self.materials.setMinimumWidth(165)
  builtins={'Stal S235 / S355':7850,'Stal S690QL / S960QL':7850,
            'Hardox':7850,'Stal nierdzewna':8000,'Aluminium':2700,
            'Żeliwo':7200,'Miedź':8960,'Mosiądz':8500,'PA6':1140}
  try:
   custom=json.loads(str(self.store.value('custom_materials','{}')))
   if not isinstance(custom,dict):custom={}
  except (ValueError,TypeError):custom={}
  self.custom_materials={k:float(v) for k,v in custom.items()
       if isinstance(k,str) and isinstance(v,(int,float)) and 1<=v<=25000}
  self.materials.addItem('Własna gęstość',None)
  for name,density in {**builtins,**self.custom_materials}.items():
   self.materials.addItem(f'{name} · {density:g} kg/m³',density)
  self.materials.currentIndexChanged.connect(self.material_changed)
  massrow.addWidget(self.materials)
  massrow.addWidget(button('Dodaj…',self.add_material))
  massrow.addWidget(QLabel('Gęstość'));massrow.addWidget(self.density)
  self.density.valueChanged.connect(self.density_changed)
  saved=str(self.store.value('selected_material',''))
  selected=next((i for i in range(self.materials.count()) if self.materials.itemText(i).split(' · ')[0]==saved),-1)
  if selected>=0:self.materials.setCurrentIndex(selected)
  else:self.density_changed()
  massrow.addSpacing(14);massrow.addWidget(QLabel('Folder wyników'))
  self.mass_output=QLineEdit(self.output.text());massrow.addWidget(self.mass_output,1)
  massrow.addWidget(button('Wybierz…',self.choose_output))
  self.output.textChanged.connect(self.mass_output.setText)
  self.mass_output.textChanged.connect(self.output.setText)
  self.pages['mass'].layout().insertLayout(3,massrow)

 def material_changed(self,*args):
  self.store.setValue('selected_material',self.materials.currentText().split(' · ')[0])
  val=self.materials.currentData()
  if val is None:return
  self._material_setting=True
  try:self.density.setValue(float(val))
  finally:self._material_setting=False

 def density_changed(self,*args):
  if getattr(self,'_material_setting',False) or not hasattr(self,'materials'):return
  value=self.density.value()
  match=next((i for i in range(1,self.materials.count())
              if abs(self.materials.itemData(i)-value)<.01),0)
  self.materials.blockSignals(True)
  self.materials.setCurrentIndex(match)
  self.materials.blockSignals(False)
  self.store.setValue('selected_material',self.materials.currentText().split(' · ')[0])

 def add_material(self):
  name,ok=QInputDialog.getText(self,'Dodaj materiał','Nazwa materiału:')
  if not ok:return
  name=name.strip()
  if not name or len(name)>80:
   QMessageBox.warning(self,'Nazwa materiału','Wpisz nazwę (1–80 znaków).');return
  val,ok=QInputDialog.getDouble(self,'Dodaj materiał','Gęstość [kg/m³]:',self.density.value(),1,25000,2)
  if not ok:return
  self.custom_materials[name]=val
  self.store.setValue('custom_materials',json.dumps(self.custom_materials,ensure_ascii=False))
  old=next((i for i in range(1,self.materials.count())
            if self.materials.itemText(i).split(' · ')[0]==name),-1)
  if old>=0:self.materials.removeItem(old)
  self.materials.addItem(f'{name} · {val:g} kg/m³',val)
  self.materials.setCurrentIndex(self.materials.count()-1)

 def select_filter(self,key):
  self.filter_status=key
  self.filter_selector.blockSignals(True);self.filter_selector.setCurrentIndex(self.filter_selector.findData(key));self.filter_selector.blockSignals(False)
  for k,b in self.filter_buttons.items():b.setChecked(k==key)
  self.filter_results()
 def filter_results(self,*args):
  if not hasattr(self,'compare_table'):return
  query=self.search.text().casefold();wanted=getattr(self,'filter_status','ALL')
  for i in range(self.compare_table.rowCount()):
   status=self.row_statuses[i];text=' '.join(self.compare_table.item(i,j).text() for j in range(4))
   allowed=wanted=='ALL' or wanted==status or wanted=='CHANGES' and status in ('ADDED','REMOVED') or wanted=='SAME' and status in ('SAME','RENAMED')
   self.compare_table.setRowHidden(i,not allowed or query not in text.casefold())
 def start(self,kind):
  super().start(kind)
  if self.process is not None:
   self.started_at=time.monotonic()
   if hasattr(self,'param_button'):
    self.param_button.setEnabled(False);self.param_frame.setEnabled(False)
  if hasattr(self,'reset_button'):self.reset_button.setEnabled(self.process is None)
  if self.process is not None:
   self.compare_summary.setText('Analiza trwa…' if kind=='compare' else 'Obliczanie masy…')
   if kind=='compare':
    self.export_name.setText('Tworzenie nowego STEP…')
    self.step_progress_label.setText('Model STEP: analiza i eksport…')
    self.report_progress_label.setText('Raporty HTML / BOM: oczekują na STEP')
    self.progress.setRange(0,0);self.report_progress.setRange(0,100);self.report_progress.setValue(0)
    for b in self.compare_open.values():b.setEnabled(False)
 def poll(self):
  super().poll()
  if self.task!='compare' or not getattr(self,'current_folder',None):return
  folder=Path(self.current_folder)
  if self.process is not None:
   elapsed=int(time.monotonic()-getattr(self,'started_at',time.monotonic()))
   status=self.log.toPlainText().splitlines()[-1] if self.log.toPlainText() else 'Uruchamianie…'
   self.compare_summary.setText(f'Analiza w toku · {elapsed//60} min {elapsed%60:02d} s · {status[-145:]}')
  stagefile=folder/'_ETAPY.json'
  if not stagefile.exists():return
  try:
   data=json.loads(stagefile.read_text(encoding='utf-8'))
  except (OSError,ValueError):return
  step=folder/'POROWNANIE_KOLORY.step'
  if data.get('step')=='gotowy' and step.is_file() and step.stat().st_size>=100 \
    and step.stat().st_size==data.get('step_bytes'):
   # Export passed its selected validation before the atomic marker.
   self.results['compare']=folder
   self.compare_open['POROWNANIE_KOLORY.step'].setEnabled(True)
   self.compare_open[''].setEnabled(True)
   self.export_name.setText('STEP gotowy — raporty w tle')
   mode='pełna' if data.get('verification')=='pelna_ponowny_import' else 'strukturalna'
   self.step_progress_label.setText(f'Model STEP: gotowy · kontrola {mode}')
   self.progress.setRange(0,100);self.progress.setValue(100)
  elif data.get('step')=='blad':
   self.progress.setRange(0,100);self.progress.setValue(0)
   self.step_progress_label.setText('Model STEP: błąd eksportu')
  report_labels={'oczekuje':'oczekują','przygotowanie':'przygotowanie danych',
   'bom_a':'grupowanie BOM starej rewizji A','bom_b':'grupowanie BOM nowej rewizji B',
   'zapisywanie_bom':'zapis BOM','html':'tworzenie HTML','finalizacja':'końcowe zestawienia','gotowe':'gotowe'}
  phase=data.get('reports','oczekuje')
  pct=int(data.get('report_percent',0))
  self.report_progress_label.setText(f"Raporty HTML / BOM: {report_labels.get(phase,phase)} · {pct}%")
  self.report_progress.setValue(max(0,min(100,pct)))
  if phase=='gotowe':
   for filename in ('RAPORT.html','ZMIANY.csv'):
    self.compare_open[filename].setEnabled((folder/filename).exists())

 def finished(self,code,status):
  super().finished(code,status);self.reset_button.setEnabled(True);self.param_button.setEnabled(True);self.param_frame.setEnabled(True)
  if getattr(self,'completion_ok',False) and not self.was_cancelled and self.task=='compare':
   ready=self.compare_open['POROWNANIE_KOLORY.step'].isEnabled()
   self.progress.setRange(0,100);self.progress.setValue(100 if ready else 0)
   if not ready:self.step_progress_label.setText('Model STEP: błąd eksportu')
   self.report_progress.setValue(100);self.report_progress_label.setText('Raporty HTML / BOM: gotowe · 100%')
  if self.was_cancelled:self.compare_summary.setText('Analiza anulowana.')
  elif code or not getattr(self,'completion_ok',False):self.compare_summary.setText('Analiza nie została ukończona — sprawdź komunikat błędu.')
 def load_result(self,kind,folder):
  super().load_result(kind,folder)
  self._tidy_finished_files(Path(folder))
  if kind!='compare':
   s=json.loads((Path(folder)/'PODSUMOWANIE_MASY.json').read_text(encoding='utf-8'))
   omitted=s.get('import_diagnostics',{}).get('faces_outside_solids',0)
   if omitted:self.mass_summary.setText(self.mass_summary.text()+f' · UWAGA: pominięto {omitted} powierzchni')
   return
  for i,status in enumerate(self.row_statuses):self.compare_table.item(i,0).setData(Qt.UserRole,status)
  folder=Path(folder);s=json.loads((folder/'PODSUMOWANIE.json').read_text(encoding='utf-8'));c=s['statuses']
  values=[c.get('SAME',0),c.get('UNCERTAIN',0),c.get('MOVED',0),c.get('ADDED',0),c.get('REMOVED',0),c.get('RENAMED',0)]
  for label,value in zip(self.metrics,values):label.setText(str(value))
  message=f"Porównanie gotowe · A: {s['solids_A']} → B: {s['solids_B']} · Przesunięte: {c.get('MOVED',0)}"
  if s.get('step_export_error'):message+=' · Błąd eksportu STEP — raport dostępny'
  if c.get('UNCERTAIN'):message+=f" · Do sprawdzenia: {c['UNCERTAIN']}"
  omitted=sum(v.get('faces_outside_solids',0) for v in s.get('import_diagnostics',{}).values())
  if omitted:message+=f' · UWAGA: pominięto {omitted} powierzchni poza bryłami'
  self.compare_summary.setText(message)
  ready=(folder/'POROWNANIE_KOLORY.step').is_file() and not s.get('step_export_error')
  self.export_name.setText('STEP gotowy do otwarcia' if ready else 'STEP nie został utworzony')
  self.export_name.setToolTip(s.get('step_export_error') or str(folder/'POROWNANIE_KOLORY.step'))
  self.compare_open['POROWNANIE_KOLORY.step'].setEnabled(ready)
  mode='pełna' if s.get('step_verification')=='pelna_ponowny_import' else 'strukturalna'
  self.progress.setRange(0,100);self.progress.setValue(100 if ready else 0)
  self.step_progress_label.setText(f'Model STEP: gotowy · kontrola {mode}' if ready else 'Model STEP: błąd eksportu')
  self.report_progress.setValue(100);self.report_progress_label.setText('Raporty HTML / BOM: gotowe · 100%')
  old=s.get('colors_hex',{}).get('REMOVED','#ff610f');alpha=round((1-s.get('old_alpha',.4))*100)
  self.legend.setText(f'<span style="color:#24aa67">● Bez zmian / zmiana nazwy</span><br><span style="color:#4b85ff">● Nowa B</span><br><span style="color:#ab73ec">● Nowe położenie B — fiolet</span><br><span style="color:#c7addf">● Stare położenie A — jasny fiolet</span><br><span style="color:{old}">● Usunięte A · {alpha}% przezr.</span><br>● Do sprawdzenia — osobna grupa STEP')
  for role,card in [('A',self.a),('B',self.b)]:
   file=folder/f'MINIATURA_{role}.json'
   if file.exists():
    data=json.loads(file.read_text());card.thumbnail.set_data(data);card.caption.setText(f"{s['solids_'+role]} części · miniatura krawędziowa"+(' (uproszczona)' if data.get('truncated') else ''))
 def _tidy_finished_files(self,folder):
  # Technical files are useful when diagnosing issues, but should not clutter
  # the user-facing result directory. Move only AFTER load_result has read them.
  try:
   internal=('DIAGNOSTYKA_KOLOROW.json','_POSTEP_V37.jsonl','_WYNIK_V37.json',
             'BOM_GRUPY_A.json','BOM_GRUPY_B.json','MASA_MAPA.json')
   tech=folder/'DANE_TECHNICZNE'
   for name in internal:
    source=folder/name
    if source.is_file():
     tech.mkdir(exist_ok=True)
     source.replace(tech/name)
  except OSError:
   pass
 def invalidate_comparison(self,*args):
  if self.process is not None or 'compare' not in self.results:return
  self.results.pop('compare');self.compare_table.setRowCount(0);self.row_statuses=[]
  for b in self.compare_open.values():b.setEnabled(False)
  for label in self.metrics:label.setText('—')
  self.compare_summary.setText('Modele zmienione — uruchom nowe porównanie.');self.export_name.setText('STEP: oczekuje na analizę')
 def reset_session(self):
  if self.process is not None:return
  for card in (self.a,self.b,self.mass_file):card.path.clear()
  self.results.clear();self.compare_table.setRowCount(0);self.mass_table.setRowCount(0);self.row_statuses=[]
  for b in list(self.compare_open.values())+list(self.mass_open.values()):b.setEnabled(False)
  for label in self.metrics:label.setText('—')
  self.search.clear();self.select_filter('ALL');self.only_changes.setChecked(False);self.log.clear();self.mass_log.clear();self.progress.setValue(0);self.mass_progress.setValue(0)
  self.step_progress_label.setText('Model STEP: oczekuje');self.report_progress_label.setText('Raporty HTML / BOM: oczekują')
  self.progress.setRange(0,100);self.report_progress.setRange(0,100);self.report_progress.setValue(0)
  self.compare_summary.setText('Wybierz dwa modele, aby rozpocząć.');self.mass_summary.setText('Wybierz model do obliczenia masy.');self.export_name.setText('STEP: oczekuje na analizę');self.navigate('compare')

def main(a='',b=''):
 app=QApplication.instance() or QApplication(sys.argv);app.setStyle('Fusion');w=Window(a,b);w.show();return app.exec()
