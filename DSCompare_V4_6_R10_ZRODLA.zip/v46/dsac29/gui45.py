"""Three-page desktop workflow. CAD work runs in a separate process; no 3D viewer."""
import csv
import json
import sys
import base64
import subprocess
from datetime import datetime
from pathlib import Path
from PySide6.QtCore import Qt, QSize, Signal, QProcess, QTimer, QSettings, QUrl, QStandardPaths
from PySide6.QtGui import QIcon, QPixmap, QPainter, QDesktopServices
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QFrame, QLabel,
    QPushButton, QLineEdit, QVBoxLayout, QHBoxLayout, QStackedWidget, QFileDialog,
    QDoubleSpinBox, QSpinBox, QComboBox, QCheckBox, QFormLayout, QTableWidget,
    QTableWidgetItem, QHeaderView, QProgressBar, QPlainTextEdit, QMessageBox,
    QAbstractItemView, QDialog)

STYLE='''
QWidget {background:#151b24;color:#e9edf3;font-family:"Segoe UI";font-size:13px;}
QFrame#sidebar {background:#10151d;border-right:1px solid #2c3645;}
QFrame#card {background:#1c2430;border:1px solid #354153;border-radius:12px;}
QFrame#card QLabel {background:transparent;}
QLabel#heading {font-size:25px;font-weight:600;}
QLabel#sub {color:#aebccc;}
QLabel#brand {font-size:22px;font-weight:700;color:#f4ba58;}
QPushButton {background:#263244;border:1px solid #40516a;border-radius:7px;padding:9px 14px;min-height:20px;}
QPushButton:hover {background:#34445b;border-color:#7290b6;}
QPushButton:disabled {color:#6e7c90;background:#202834;border-color:#2c3645;}
QPushButton#primary {background:#edb454;color:#151b24;font-weight:700;border:0;padding:11px 22px;}
QPushButton#primary:disabled {background:#766447;color:#b8af9f;}
QPushButton#nav {text-align:left;background:transparent;border:0;padding:13px;}
QPushButton#nav:checked {background:#2d3540;color:#f4ba58;border-left:3px solid #f4ba58;}
QLineEdit,QDoubleSpinBox,QSpinBox,QComboBox {background:#101720;border:1px solid #40516a;border-radius:6px;padding:8px;min-height:20px;}
QLineEdit:focus,QComboBox:focus {border-color:#edb454;}
QTableWidget {background:#18212c;alternate-background-color:#1e2936;border:1px solid #354153;gridline-color:#2a384a;selection-background-color:#365577;}
QHeaderView::section {background:#273345;color:#dce6f2;padding:9px;border:0;border-bottom:1px solid #40516a;}
QPlainTextEdit {background:#101720;border:1px solid #354153;border-radius:6px;color:#b8c7d9;}
QProgressBar {border:0;background:#273345;border-radius:3px;max-height:5px;}
QProgressBar::chunk {background:#edb454;}
QCheckBox {spacing:8px;padding:4px;}
QToolTip {background:#263244;color:white;border:1px solid #7290b6;}
'''

def icon(key):
    paths={'compare':'M4 7h15m-4-4 4 4-4 4M20 17H5m4-4-4 4 4 4',
           'mass':'M5 7h14l2 14H3L5 7Zm4 0V5a3 3 0 0 1 6 0v2',
           'settings':'M4 6h16M4 12h16M4 18h16M8 3v6m8 0v6M10 15v6'}
    svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="{paths[key]}" fill="none" stroke="#edb454" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>'
    pix=QPixmap(48,48);pix.fill(Qt.transparent);p=QPainter(pix);QSvgRenderer(svg.encode()).render(p);p.end()
    return QIcon(pix)

def configure_cad_dialog(dialog):
    """Preserve safe Qt picker and show desktop/downloads in the places sidebar."""
    dialog.setOption(QFileDialog.DontUseNativeDialog, True)
    # Avoid Shell/COM sidebar enumeration: on managed Windows machines it
    # can block the dialog even with DontUseNativeDialog enabled.
    dialog.setMinimumSize(760, 500)
    return dialog


def windows_explorer_dialog(start_directory, previous='', folder=False):
    """Native Windows shell dialog, isolated so a shell extension cannot crash Qt.

    Returns None when the separate helper is unavailable (use Qt fallback),
    empty string on Cancel, or a selected local filesystem path.
    """
    if sys.platform != 'win32':return None
    directory=str(start_directory or Path.home())
    # Absolute paths are serialized, never interpolated into PowerShell source.
    ini="'"+directory.replace("'","''")+"'"
    old="'"+str(previous or '').replace("'","''")+"'"
    script=r"""
    $ErrorActionPreference='Stop'
    Add-Type -AssemblyName System.Windows.Forms
    [Console]::OutputEncoding=[System.Text.Encoding]::UTF8
    $directory = __DIRECTORY__
    $previous = __PREVIOUS__
    if (__FOLDER__) {
        $d=New-Object System.Windows.Forms.FolderBrowserDialog
        $d.Description='Wybierz folder zapisu wyników'
        $d.SelectedPath=$directory
        $result=$d.ShowDialog()
        if($result -eq [System.Windows.Forms.DialogResult]::OK){[Console]::WriteLine($d.SelectedPath)}
    } else {
        $d=New-Object System.Windows.Forms.OpenFileDialog
        $d.Title='Wybierz model 3D'
        $d.Filter='Modele 3D (*.step;*.stp;*.z3)|*.step;*.stp;*.z3|STEP (*.step;*.stp)|*.step;*.stp|ZW3D (*.z3)|*.z3|Wszystkie (*.*)|*.*'
        $d.CheckFileExists=$true
        $d.InitialDirectory=$directory
        if($previous -and [System.IO.File]::Exists($previous)){$d.FileName=$previous}
        $result=$d.ShowDialog()
        if($result -eq [System.Windows.Forms.DialogResult]::OK){[Console]::WriteLine($d.FileName)}
    }
    """.replace('__DIRECTORY__',ini).replace('__PREVIOUS__',old).replace('__FOLDER__','$true' if folder else '$false')
    encoded=base64.b64encode(script.encode('utf-16le')).decode('ascii')
    flags=getattr(subprocess,'CREATE_NO_WINDOW',0)
    try:
        completed=subprocess.run(['powershell.exe','-NoLogo','-NoProfile','-STA','-EncodedCommand',encoded],
                 capture_output=True,creationflags=flags,timeout=900)
        if completed.returncode!=0:return None
        selected=completed.stdout.decode('utf-8-sig',errors='replace').strip().splitlines()
        return selected[-1].strip() if selected else ''
    except (OSError,subprocess.TimeoutExpired):return None


class FileCard(QFrame):
    changed=Signal(str)
    def __init__(self,title,subtitle):
        super().__init__();self.setObjectName('card');self.setAcceptDrops(True)
        layout=QVBoxLayout(self);layout.setContentsMargins(16,12,16,12)
        name=QLabel(title);name.setStyleSheet('font-size:17px;font-weight:600');layout.addWidget(name)
        helptext=QLabel(subtitle+' · STEP / STP');helptext.setObjectName('sub');layout.addWidget(helptext)
        self.path=QLineEdit();self.path.setPlaceholderText('Przeciągnij plik tutaj lub wybierz…')
        self.path.setAcceptDrops(False);self.path.textChanged.connect(self.changed.emit)
        row=QHBoxLayout();row.addWidget(self.path);choose=QPushButton('Wybierz plik');choose.clicked.connect(self.choose);row.addWidget(choose);layout.addLayout(row)
    def choose(self):
        self.choose_at(None)

    def choose_at(self, start_directory):
        initial=self.path.text().strip()
        directory=str(start_directory) if start_directory and Path(start_directory).is_dir() else (str(Path(initial).parent) if initial and Path(initial).is_file() else str(Path.home()))
        selected=windows_explorer_dialog(directory,initial)
        if selected is not None:
            if selected:self.path.setText(selected)
            return
        dlg=QFileDialog(self,'Wybierz model 3D',directory)
        configure_cad_dialog(dlg)
        dlg.setFileMode(QFileDialog.ExistingFile)
        dlg.setAcceptMode(QFileDialog.AcceptOpen)
        dlg.setNameFilters(['Modele 3D (*.step *.stp *.z3)', 'STEP (*.step *.stp)', 'ZW3D (*.z3)', 'Wszystkie pliki (*)'])
        if initial and Path(initial).is_file():dlg.selectFile(initial)
        if dlg.exec()==QDialog.Accepted:
            paths=dlg.selectedFiles()
            if paths:self.path.setText(paths[0])
    @staticmethod
    def drop_path(mime):
        urls=mime.urls() if mime.hasUrls() else []
        if len(urls)==1 and urls[0].isLocalFile():
            path=Path(urls[0].toLocalFile())
            if path.is_file() and path.suffix.lower() in ('.step','.stp','.z3'):return str(path)
        return None
    def dragEnterEvent(self,event):
        if self.drop_path(event.mimeData()):event.acceptProposedAction()
    def dropEvent(self,event):
        path=self.drop_path(event.mimeData())
        if path:self.path.setText(path);event.acceptProposedAction()

def button(text,callback,primary=False):
    b=QPushButton(text);b.clicked.connect(callback)
    if primary:b.setObjectName('primary')
    return b

def table(headers):
    t=QTableWidget(0,len(headers));t.setHorizontalHeaderLabels(headers);t.verticalHeader().hide()
    t.setAlternatingRowColors(True);t.setEditTriggers(QAbstractItemView.NoEditTriggers)
    t.setSelectionBehavior(QAbstractItemView.SelectRows);t.setWordWrap(False)
    t.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
    t.horizontalHeader().setStretchLastSection(True);t.setMinimumHeight(140)
    return t

class Window(QMainWindow):
    def __init__(self,a='',b=''):
        super().__init__();self.setWindowTitle('DS Compare 4.5 — porównanie rewizji');self.resize(1380,900);self.setMinimumSize(1080,760)
        self.setStyleSheet(STYLE);self.store=QSettings('DSCompare','Revision45')
        self.process=None;self.task=None;self.results={};self.nav={};self.pages={};self.event_offset=0
        central=QWidget();self.setCentralWidget(central);layout=QHBoxLayout(central);layout.setContentsMargins(0,0,0,0);layout.setSpacing(0)
        side=QFrame();side.setObjectName('sidebar');side.setFixedWidth(208);sl=QVBoxLayout(side);sl.setContentsMargins(18,28,18,22)
        brand=QLabel('DS COMPARE');brand.setObjectName('brand');sl.addWidget(brand)
        subtitle=QLabel('Porównanie rewizji · 4.5');subtitle.setObjectName('sub');sl.addWidget(subtitle);sl.addSpacing(32)
        self.stack=QStackedWidget();layout.addWidget(side);layout.addWidget(self.stack,1)
        for key,label in [('compare','Porównanie'),('mass','Masa części'),('settings','Ustawienia')]:
            bnav=QPushButton(label);bnav.setObjectName('nav');bnav.setCheckable(True);bnav.setIcon(icon(key));bnav.setIconSize(QSize(24,24));bnav.clicked.connect(lambda checked=False,k=key:self.navigate(k));sl.addWidget(bnav);self.nav[key]=bnav
        sl.addStretch();foot=QLabel('A → B\nSTEP + raport zmian');foot.setObjectName('sub');sl.addWidget(foot)
        self.create_settings();self.create_compare();self.create_mass();self.navigate('compare')
        self.a.path.setText(a);self.b.path.setText(b)
        self.timer=QTimer(self);self.timer.setInterval(250);self.timer.timeout.connect(self.poll)
    def page(self,key,title,description):
        page=QWidget();lay=QVBoxLayout(page);lay.setContentsMargins(28,24,28,24);lay.setSpacing(14)
        h=QLabel(title);h.setObjectName('heading');lay.addWidget(h)
        sub=QLabel(description);sub.setObjectName('sub');sub.setWordWrap(True);lay.addWidget(sub)
        self.pages[key]=page;self.stack.addWidget(page);return lay
    def navigate(self,key):
        self.stack.setCurrentWidget(self.pages[key])
        for k,b in self.nav.items():b.setChecked(k==key)
    def create_settings(self):
        lay=self.page('settings','Ustawienia','Parametry analizy i eksportu. Ustawienia są zapamiętywane automatycznie.')
        card=QFrame();card.setObjectName('card');form=QFormLayout(card);form.setContentsMargins(24,24,24,24);form.setSpacing(18)
        self.tolerance=QDoubleSpinBox();self.tolerance.setDecimals(4);self.tolerance.setRange(.0001,1);self.tolerance.setSuffix(' mm');self.tolerance.setValue(float(self.store.value('tolerance',.01)))
        self.density=QDoubleSpinBox();self.density.setRange(1,25000);self.density.setSuffix(' kg/m³');self.density.setValue(float(self.store.value('density',7850)))
        self.opacity=QSpinBox();self.opacity.setRange(0,90);self.opacity.setSuffix(' %');self.opacity.setValue(int(self.store.value('transparency',60)))
        self.schema=QComboBox();self.schema.addItems(['AP214IS','AP242DIS']);self.schema.setCurrentText(str(self.store.value('schema','AP242DIS')))
        self.old_color=QComboBox();self.old_color.addItems(['Pomarańczowy','Czerwony']);self.old_color.setCurrentText(str(self.store.value('old_color','Pomarańczowy')))
        self.align=QCheckBox('Wyrównaj położenie całego złożenia przed analizą');self.align.setChecked(str(self.store.value('align','false')).lower()=='true')
        form.addRow('Tolerancja geometrii',self.tolerance);form.addRow('Gęstość do obliczania mas',self.density)
        form.addRow('Przezroczystość starej wersji',self.opacity);form.addRow('Kolor starej wersji A',self.old_color);form.addRow('Format kolorowego STEP',self.schema);form.addRow(self.align)
        note=QLabel('Gęstość jest jednakowa dla wszystkich części. Materiały z ZW3D nie są odczytywane.\nWyrównanie może ukryć zmianę położenia całego złożenia — domyślnie jest wyłączone.\nKolory i przezroczystość są sprawdzane po ponownym wczytaniu STEP; wygląd w ZW3D zależy także od importera.')
        note.setWordWrap(True);note.setObjectName('sub');form.addRow(note);lay.addWidget(card);lay.addStretch()
        for widget in (self.tolerance,self.density,self.opacity):widget.valueChanged.connect(self.save_settings)
        for widget in (self.schema,self.old_color):widget.currentTextChanged.connect(self.save_settings)
        self.align.toggled.connect(self.save_settings)
    def save_settings(self,*args):
        for key,value in [('tolerance',self.tolerance.value()),('density',self.density.value()),('transparency',self.opacity.value()),('schema',self.schema.currentText()),('old_color',self.old_color.currentText()),('align',self.align.isChecked())]:self.store.setValue(key,value)
    def create_compare(self):
        lay=self.page('compare','Porównaj rewizje','Wczytaj dwa modele. Otrzymasz kolorowy STEP do ZW3D oraz raport zmian względem starej rewizji.')
        row=QHBoxLayout();self.a=FileCard('A · Stara rewizja','Model odniesienia');self.b=FileCard('B · Nowa rewizja','Model do porównania')
        row.addWidget(self.a,1);swap=button('⇄',self.swap);swap.setToolTip('Zamień modele A i B');row.addWidget(swap);row.addWidget(self.b,1);lay.addLayout(row)
        self.output=QLineEdit(str(self.store.value('output',str(Path.home()/'Documents'/'DSCompare'))));row=QHBoxLayout();row.addWidget(QLabel('Zapis wyników'));row.addWidget(self.output);row.addWidget(button('Wybierz folder',self.choose_output));lay.addLayout(row)
        legend=QLabel('<span style="color:#36ca72">■ Bez zmian</span> &nbsp;&nbsp; <span style="color:#ff833f">■ Stara wersja A</span> &nbsp;&nbsp; <span style="color:#5e9eff">■ Nowa wersja B</span> &nbsp; · &nbsp; Zmienione i przesunięte części: obie wersje')
        legend.setWordWrap(True);lay.addWidget(legend);self.legend=legend
        row=QHBoxLayout();self.run_compare=button('Utwórz kolorowy STEP',lambda:self.start('compare'),True);row.addWidget(self.run_compare);self.cancel_compare=button('Anuluj',self.cancel);self.cancel_compare.setEnabled(False);row.addWidget(self.cancel_compare);row.addStretch();lay.addLayout(row)
        self.compare_summary=QLabel('Wyniki pojawią się po analizie. Każde uruchomienie zapisuje osobny folder.');self.compare_summary.setWordWrap(True);lay.addWidget(self.compare_summary)
        row=QHBoxLayout();self.search=QLineEdit();self.search.setPlaceholderText('Szukaj części, rodzaju zmiany lub uwag…');self.search.textChanged.connect(self.filter_results);row.addWidget(self.search,1)
        self.only_changes=QCheckBox('Tylko zmiany');self.only_changes.setChecked(True);self.only_changes.toggled.connect(self.filter_results);row.addWidget(self.only_changes);lay.addLayout(row)
        self.compare_table=table(['Zmiana','Stara rewizja A','Nowa rewizja B','Uwagi / pewność']);self.compare_table.setColumnWidth(0,150);self.compare_table.setColumnWidth(1,220);self.compare_table.setColumnWidth(2,220);lay.addWidget(self.compare_table,1)
        self.compare_open=self.open_buttons(lay,'compare',[('Otwórz STEP','POROWNANIE_KOLORY.step'),('Raport HTML','RAPORT.html'),('Zmiany CSV','ZMIANY.csv'),('Folder wyników','')])
        self.progress=QProgressBar();self.progress.setRange(0,1);self.progress.setValue(0);self.progress.setTextVisible(False);lay.addWidget(self.progress)
        self.log=QPlainTextEdit();self.log.setReadOnly(True);self.log.setMaximumHeight(82);self.log.document().setMaximumBlockCount(150);lay.addWidget(self.log)
    def create_mass(self):
        lay=self.page('mass','Masa części','Zestawienie części i ich mas z objętości modelu oraz gęstości podanej w ustawieniach.')
        self.mass_file=FileCard('Model do obliczenia masy','Pojedynczy model lub złożenie');lay.addWidget(self.mass_file)
        row=QHBoxLayout();self.run_mass=button('Oblicz masę',lambda:self.start('mass'),True);row.addWidget(self.run_mass);self.cancel_mass=button('Anuluj',self.cancel);self.cancel_mass.setEnabled(False);row.addWidget(self.cancel_mass);row.addStretch();lay.addLayout(row)
        self.mass_summary=QLabel('Wyniki są zapisywane w folderze ustawionym w zakładce Porównanie.');self.mass_summary.setWordWrap(True);lay.addWidget(self.mass_summary)
        self.mass_table=table(['Nazwa części','Ilość','Objętość / szt. [mm³]','Masa / szt. [kg]','Masa łączna [kg]']);self.mass_table.setColumnWidth(0,300);lay.addWidget(self.mass_table,1)
        self.mass_open=self.open_buttons(lay,'mass',[('Raport HTML','RAPORT_MASY.html'),('Zestawienie CSV','MASY_CZESCI.csv'),('Folder wyników','')])
        self.mass_progress=QProgressBar();self.mass_progress.setRange(0,1);self.mass_progress.setValue(0);self.mass_progress.setTextVisible(False);lay.addWidget(self.mass_progress)
        self.mass_log=QPlainTextEdit();self.mass_log.setReadOnly(True);self.mass_log.setMaximumHeight(100);self.mass_log.document().setMaximumBlockCount(150);lay.addWidget(self.mass_log)
    def open_buttons(self,lay,kind,items):
        row=QHBoxLayout();buttons={}
        for title,filename in items:
            b=button(title,lambda checked=False,k=kind,f=filename:self.open_result(k,f));b.setEnabled(False);buttons[filename]=b;row.addWidget(b)
        row.addStretch();lay.addLayout(row);return buttons
    def open_result(self,kind,filename):
        path=self.results[kind]/filename
        if path.exists() and not QDesktopServices.openUrl(QUrl.fromLocalFile(str(path))):QMessageBox.warning(self,'Nie można otworzyć','Otwórz plik ręcznie z folderu wyników: '+str(path))
    def swap(self):
        a,b=self.a.path.text(),self.b.path.text();self.a.path.setText(b);self.b.path.setText(a)
    def choose_output(self):
        selected=windows_explorer_dialog(self.output.text(),folder=True)
        if selected is not None:
            if selected:self.output.setText(selected);self.store.setValue('output',selected)
            return
        dlg=QFileDialog(self,'Folder wyników',self.output.text())
        configure_cad_dialog(dlg)
        dlg.setFileMode(QFileDialog.Directory)
        dlg.setOption(QFileDialog.ShowDirsOnly,True)
        if dlg.exec()==QDialog.Accepted and dlg.selectedFiles():
            value=dlg.selectedFiles()[0]
            self.output.setText(value);self.store.setValue('output',value)
    def start(self,kind):
        if self.process is not None:return
        inputs=[self.a.path.text(),self.b.path.text()] if kind=='compare' else [self.mass_file.path.text()]
        if any(not Path(value).is_file() for value in inputs):
            QMessageBox.warning(self,'Wybierz modele','Wybierz istniejące modele STEP / STP.');return
        # Native ZW3D archives are proprietary, not STEP B-Reps. Never hand them to OCC.
        if any(Path(value).suffix.lower()=='.z3' for value in inputs):
            QMessageBox.information(self,'Model ZW3D (Z3)',
                'Plik Z3 można wskazać, ale do porównania geometrii trzeba go najpierw '
                'wyeksportować w ZW3D jako STEP (.step lub .stp).\n\n'
                'Wybierz w ZW3D: Plik → Eksport → STEP (AP214 lub AP242).')
            return
        if any(Path(value).suffix.lower() not in ('.step','.stp') for value in inputs):
            QMessageBox.warning(self,'Nieobsługiwany format','Do porównania wybierz pliki STEP / STP.');return
        if not self.output.text().strip():QMessageBox.warning(self,'Folder wyników','Wybierz folder wyników.');return
        try:
            folder=Path(self.output.text()).expanduser().resolve()/(datetime.now().strftime('%Y-%m-%d_%H-%M-%S_%f')+'_'+kind);folder.mkdir(parents=True)
        except OSError as exc:QMessageBox.warning(self,'Nie można zapisać',str(exc));return
        self.store.setValue('output',self.output.text());args=['--worker',kind,'--output',str(folder),'--density',str(self.density.value())]
        if hasattr(self,'solid_limit'):args+=['--max-solids',str(self.solid_limit.value())]
        if kind=='compare':
            palette={'REMOVED':[.95,.12,.10]} if self.old_color.currentText()=='Czerwony' else {}
            args+=['--a',inputs[0],'--b',inputs[1],'--generate-step','--revision-style','--old-alpha',str(1-self.opacity.value()/100),'--schema',self.schema.currentText(),'--palette',json.dumps(palette),'--tolerance',str(self.tolerance.value())]
            if hasattr(self,'verify_mode'):args+=['--step-verify',self.verify_mode.currentData()]
            if self.align.isChecked():args+=['--align']
            if getattr(self,'generate_thumbnails',False):args+=['--thumbnails']
        else:args+=['--input',inputs[0],'--no-preview']
        if not getattr(sys,'frozen',False):args.insert(0,str(Path(__file__).resolve().parents[1]/'DSCompareV3.py'))
        self.task=kind;self.current_folder=folder;self.event_offset=0;self.was_cancelled=False;self.worker_output=''
        self.active_log=self.log if kind=='compare' else self.mass_log;self.active_log.clear();self.active_log.appendPlainText('Rozpoczynanie analizy…')
        self.active_progress=self.progress if kind=='compare' else self.mass_progress;self.active_progress.setRange(0,0)
        for control in (self.run_compare,self.run_mass,self.a,self.b,self.mass_file,self.pages['settings']):control.setEnabled(False)
        self.cancel_compare.setEnabled(kind=='compare');self.cancel_mass.setEnabled(kind=='mass')
        self.process=QProcess(self);self.process.setProcessChannelMode(QProcess.MergedChannels)
        self.process.readyReadStandardOutput.connect(self.drain);self.process.finished.connect(self.finished);self.process.errorOccurred.connect(self.process_error)
        try:
            self.process.start(sys.executable,args)
            self.timer.start()
        except Exception as exc:
            self.timer.stop()
            self.process.deleteLater();self.process=None
            for control in (self.run_compare,self.run_mass,self.a,self.b,self.mass_file,self.pages['settings']):
                control.setEnabled(True)
            self.active_log.appendPlainText('Nie udało się uruchomić analizy: '+str(exc))
            QMessageBox.warning(self,'Uruchamianie analizy',str(exc))
    def drain(self):
        if self.process:self.worker_output=(self.worker_output+bytes(self.process.readAllStandardOutput()).decode('utf-8',errors='replace'))[-12000:]
    def poll(self):
        file=self.current_folder/'_POSTEP_V37.jsonl'
        if not file.exists():return
        with file.open('rb') as inp:
            inp.seek(self.event_offset)
            while True:
                start=inp.tell();line=inp.readline()
                if not line or not line.endswith(b'\n'):self.event_offset=start;break
                try:
                    message=json.loads(line)['tekst']
                    self.active_log.appendPlainText(message)
                    # The B-Rep match is NOT the end of the work: BOM and STEP
                    # often take longer on large assemblies. Show live phase.
                    if self.task=='compare' and hasattr(self,'compare_summary'):
                        self.compare_summary.setText('Trwa analiza — '+message)
                except (ValueError,KeyError):pass
                self.event_offset=inp.tell()
    def process_error(self,error):
        if error==QProcess.FailedToStart:self.finished(-1,QProcess.CrashExit)
        elif self.process is not None and error==QProcess.Crashed:
            self.worker_output=(self.worker_output+'\nSilnik CAD zakończył działanie awaryjnie.')[-12000:]
    def cancel(self):
        if self.process:self.was_cancelled=True;self.process.kill()
    def finished(self,code,status):
        self.completion_ok=False
        if self.process is None:return
        self.timer.stop();self.poll();self.drain();process=self.process;self.process=None;process.deleteLater()
        self.active_progress.setRange(0,1);self.active_progress.setValue(0)
        for control in (self.run_compare,self.run_mass,self.a,self.b,self.mass_file,self.pages['settings']):control.setEnabled(True)
        self.cancel_compare.setEnabled(False);self.cancel_mass.setEnabled(False)
        if self.was_cancelled:self.active_log.appendPlainText('Anulowano. Poprzednie wyniki pozostają dostępne.');return
        try:
            result_path=self.current_folder/'_WYNIK_V37.json'
            if not result_path.exists():
                raise RuntimeError('Silnik porównywania nie utworzył wyniku. '+
                    ('Komunikaty: '+self.worker_output[-2500:] if self.worker_output else 'Kod wyjścia: '+str(code)))
            data=json.loads(result_path.read_text(encoding='utf-8'))
            if code or not data.get('ok'):raise RuntimeError(data.get('error','Proces zakończył się błędem.'))
            self.load_result(self.task,self.current_folder)
            self.completion_ok=True
            self.active_progress.setValue(1);self.active_log.appendPlainText('Gotowe: '+str(self.current_folder))
            if data.get('blad_step'):QMessageBox.warning(self,'Raport gotowy — błąd STEP',str(data['blad_step']))
        except Exception as exc:
            self.active_log.appendPlainText('Błąd: '+str(exc));QMessageBox.warning(self,'Analiza nie została ukończona',str(exc)+'\nPoprzednie wyniki pozostają dostępne.')
    def load_result(self,kind,folder):
        folder=Path(folder)
        if kind=='compare':
            summary=json.loads((folder/'PODSUMOWANIE.json').read_text(encoding='utf-8'))
            with (folder/'ZMIANY.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.reader(f,delimiter=';'))[1:]
            counts=summary['statuses'];self.compare_summary.setText(f"{Path(summary['source_A']).name} → {Path(summary['source_B']).name}\nBryły A: {summary['solids_A']}  →  B: {summary['solids_B']}   |   Bez zmian: {counts.get('SAME',0)}   Nowe: {counts.get('ADDED',0)}   Usunięte: {counts.get('REMOVED',0)}\nGeometria: {counts.get('CHANGED',0)}   Położenie: {counts.get('MOVED',0)}   Nazwa: {counts.get('RENAMED',0)}   Do sprawdzenia: {counts.get('UNCERTAIN',0)}")
            self.compare_table.setRowCount(len(rows))
            self.row_statuses=[r['status'] for r in summary['records']]
            labels={'SAME':'Bez zmian','RENAMED':'Zmiana nazwy','MOVED':'Zmiana położenia','CHANGED':'Zmiana geometrii','ADDED':'Nowa część','REMOVED':'Usunięta część','UNCERTAIN':'Do sprawdzenia'}
            for i,row in enumerate(rows):
                for j,value in enumerate([labels[self.row_statuses[i]],row[1],row[2],row[10]+' · '+row[12]]):
                    item=QTableWidgetItem(value);item.setToolTip(value);self.compare_table.setItem(i,j,item)
            self.filter_results();buttons=self.compare_open
            self.legend.setText('<span style="color:#36ca72">■ Bez zmian</span> &nbsp; <span style="color:#ff833f">■ Stara wersja A</span> &nbsp; <span style="color:#5e9eff">■ Nowa wersja B</span> · Zmienione i przesunięte części: obie wersje')
        else:
            summary=json.loads((folder/'PODSUMOWANIE_MASY.json').read_text(encoding='utf-8'))
            with (folder/'MASY_CZESCI.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.reader(f,delimiter=';'))[1:]
            self.mass_summary.setText(f"{Path(summary['plik']).name}   |   {summary['liczba_bryl']} brył   |   {summary['liczba_pozycji']} pozycji   |   Masa: {summary['masa_calosci_kg']:.3f} kg   |   Gęstość: {summary['gestosc_kg_m3']} kg/m³")
            self.mass_table.setRowCount(len(rows))
            for i,row in enumerate(rows):
                for j,value in enumerate(row[:5]):self.mass_table.setItem(i,j,QTableWidgetItem(value))
            buttons=self.mass_open
        if kind=='compare':
            old_rgb=summary.get('colors_hex',{}).get('REMOVED','#ff610f')
            self.legend.setText(f'<span style="color:#36ca72">■ Bez zmian</span> &nbsp; <span style="color:{old_rgb}">■ Stara wersja A</span> &nbsp; <span style="color:#5e9eff">■ Nowa wersja B</span> · Przezroczystość A: {round((1-summary.get("old_alpha",.4))*100)}% · Zmienione pary: A + B')
        self.results[kind]=folder
        for filename,b in buttons.items():b.setEnabled((folder/filename).exists())
    def filter_results(self,*args):
        if not hasattr(self,'compare_table'):return
        query=self.search.text().casefold()
        for i in range(self.compare_table.rowCount()):
            values=' '.join(self.compare_table.item(i,j).text() for j in range(self.compare_table.columnCount()))
            hidden=(self.only_changes.isChecked() and self.row_statuses[i]=='SAME') or query not in values.casefold()
            self.compare_table.setRowHidden(i,hidden)
    def closeEvent(self,event):
        if self.process:
            if QMessageBox.question(self,'Analiza trwa','Przerwać analizę i zamknąć program?')!=QMessageBox.Yes:event.ignore();return
            self.process.kill();self.process.waitForFinished(3000)
        self.save_settings();event.accept()

def main(a='',b=''):
    app=QApplication.instance() or QApplication(sys.argv);app.setStyle('Fusion');window=Window(a,b);window.show();return app.exec()
