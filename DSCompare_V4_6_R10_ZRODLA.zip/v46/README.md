# DS Compare 4.6 R10

DS Compare 4.6 R10 — źródła do kompilacji Windows x64

NAJWAŻNIEJSZE ZMIANY
- Naprawiony test workflow: sprawdza dołączony plik R10, nie nieistniejący R6.
- Błędy testów B-Rep pozostają jako „Do sprawdzenia” w tabeli, raporcie i grupie STEP.
- Tryb rewizji pomija niepotrzebne parowanie zmienionej geometrii.
- Cache filtrów kandydatów dla powtarzalnych definicji i wektorowe liczenie odległości.
- Globalne dopasowanie również dla grup ponad 60 elementów; bez zachłannego fallbacku.
  W dużych grupach jednoznaczność tożsamości wystąpienia pozostaje niezweryfikowana.
- W szczegółowym trybie starszego API ograniczono przeszukiwanie położenia kandydatów.
- Kontrola STEP do wyboru: automatyczna, szybka strukturalna, pełna po ponownym imporcie.
- STEP dostępny po udanym eksporcie, raporty mogą być nadal przygotowywane.
- Błąd STEP nie pokazuje ukończonego paska eksportu; raport ma osobny stan.
- Czytelny filtr listy, licznik „Do sprawdzenia”, ręczne szerokości kolumn i paski przewijania.
- Na małych ekranach szczegóły kolorów pod „Kolory i grupy…”, bez ścisku w panelu wyniku.
- Zapamiętywana nazwa materiału, także przy identycznej gęstości kilku materiałów.
- Liczba pominiętych powierzchni poza SOLID w logu, podsumowaniu i raporcie.
- Konfigurowalny limit brył 1–10000 na plik (domyślnie 1000). Przekroczenie przerywa
  import; model nie jest po cichu obcinany. Duże modele wymagają więcej RAM i czasu.

ZASADY PORÓWNANIA
Bez zmian / tylko nazwa: zielony. Nowe B: niebieski. Usunięte A: pomarańczowy
lub czerwony, domyślnie 60% przezroczystości. Przesunięte: stare A jasnofioletowe,
nowe B fioletowe. Przesunięcie jest potwierdzane wyłącznie przy zgodnej geometrii,
nazwie grupy i liczbie wystąpień A/B. Zmieniona geometria: stare + nowe.
Nieudany test geometrii: Do sprawdzenia, osobna grupa STEP, bez udawania rozstrzygnięcia.
Szybka kontrola eksportu nie potwierdza przypisania koloru do każdej powierzchni.
Wygląd przezroczystości i grup po otwarciu zależy od importera ZW3D.

INTERFEJS
Porównanie i Masa części; parametry w rozwijanym panelu, motyw pod ikoną słońca/księżyca.
Wybór plików lub przeciągnięcie, bez szybkich skrótów pulpitu. Każdy normalny start
ma puste modele i wyniki. Preferencje i lista materiałów są zapamiętywane.
Masa używa jednej wybranej gęstości dla całego analizowanego modelu.
„Otwórz STEP” używa skojarzenia plików Windows — ustaw ZW3D jako aplikację dla STEP.

TESTY I KOMPILACJA
Szczegóły: RAPORT_R10.md. Lokalne testy źródeł i Qt na Linux; brak lokalnej kompilacji
Windows i testu w działającym ZW3D. Workflow uruchamia testy, kompiluje EXE i DLL,
a potem sprawdza rzeczywiście spakowany EXE. DLL mostka ZW3D pozostaje eksperymentalna.
Ta paczka zawiera ŹRÓDŁA, nie gotowy EXE/DLL. Nie jest to osobny projekt DS Geometry Compare RC11.

Uruchomienie deweloperskie z katalogu v46 (Python 3.11):
python -m pip install -r requirements.txt "PySide6>=6.8,<6.10" "pytest>=8,<10"
python -m pytest -q tests
python DSCompareV3.py
