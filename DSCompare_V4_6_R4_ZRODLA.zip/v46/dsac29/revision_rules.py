"""Strict five-category revision policy for the STEP comparison UI.

No 'UNCERTAIN' output: an unproven correspondence becomes separate old/new
occurrences. A moved pair is permitted only if the count of that exact named,
congruent geometry is identical across both input assemblies.
"""
from collections import defaultdict
from .compare import Record
from .names import canonical
from .geometry import candidate, equivalent_rigid, equivalent_world


def classify_revisions(old, new, records, tolerance=0.01):
    """Return a conservative, complete one-to-one *occurrence* classification.

    SAME requires equality in assembly/world coordinates, not just equal shape.
    MOVED requires congruent B-Rep and equal population of that part definition
    in A and B (same canonical name and same shape up to rigid transform).
    """
    by_name_a=defaultdict(list);by_name_b=defaultdict(list)
    for p in old:by_name_a[canonical(p.name)].append(p)
    for p in new:by_name_b[canonical(p.name)].append(p)
    counts=[]
    verified={}

    def same_definition(ref, p):
        if not candidate(ref,p,tolerance):return False
        if ref.shape.IsPartner(p.shape):return True
        # Cache expensive proof across repeated native shape definitions.
        key=(id(ref),id(p))
        if key not in verified:
            try:verified[key]=bool(equivalent_rigid(ref,p,tolerance)[0])
            except Exception:verified[key]=False
        return verified[key]

    def population(a_part,b_part):
        # The pair is geometrically proven by the matcher, but name identity is
        # required to identify the same engineering part definition.
        ka,kb=canonical(a_part.name),canonical(b_part.name)
        if ka!=kb:return False
        for rep,result in counts:
            if canonical(rep.name)==ka and (rep.shape.IsPartner(a_part.shape) or same_definition(rep,a_part)):
                return result
        ca=sum(1 for p in by_name_a[ka] if same_definition(a_part,p))
        cb=sum(1 for p in by_name_b[kb] if same_definition(a_part,p))
        result=(ca==cb and ca>0)
        counts.append((a_part,result))
        return result

    output=[]
    for r in records:
        i,j=r.a_index,r.b_index
        if i is None:
            output.append(Record(None,j,'ADDED',r.note,confidence=r.confidence));continue
        if j is None:
            output.append(Record(i,None,'REMOVED',r.note,confidence=r.confidence));continue
        if r.status in ('SAME','RENAMED'):
            # Existing matcher has proven world B-Rep equality for both states.
            output.append(Record(i,j,'SAME',r.note,confidence=r.confidence));continue
        if r.status in ('MOVED','UNCERTAIN'):
            # UNCERTAIN may represent a fully-proven rigid B-Rep match with
            # ambiguous individual instance identities. Counts resolve the
            # revision decision without claiming a specific serial identity.
            proven=(r.status=='MOVED' or 'B-Rep zgodna' in r.confidence)
            if proven and population(old[i],new[j]):
                output.append(Record(i,j,'MOVED',
                    'Ta sama geometria, zmienione położenie/obrót; liczba wystąpień jest jednakowa',
                    r.distance_mm,r.delta_x,r.delta_y,r.delta_z,0.0,r.rotation_deg,
                    'B-Rep; przypisanie wystąpień wg położenia'))
                continue
        if r.status=='CHANGED' and canonical(old[i].name) and canonical(old[i].name)==canonical(new[j].name):
            output.append(r);continue
        # No fabricated pairing in case of count change or geometric ambiguity.
        note=('Brak jednoznacznego odpowiednika; oznaczono jako stare/nowe. '
              'Różna liczba wystąpień lub nierozstrzygnięte dopasowanie geometrii.')
        output.append(Record(i,None,'REMOVED',note,confidence='Bez wymuszonego parowania'))
        output.append(Record(None,j,'ADDED',note,confidence='Bez wymuszonego parowania'))
    output.sort(key=lambda r:(r.b_index is None, r.b_index if r.b_index is not None else r.a_index))
    assert all(r.status in ('SAME','MOVED','CHANGED','ADDED','REMOVED') for r in output)
    assert len({r.a_index for r in output if r.a_index is not None})==len(old)
    assert len({r.b_index for r in output if r.b_index is not None})==len(new)
    return output
