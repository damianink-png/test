"""User-accessible crash reports without administrator privileges."""
import os,sys,traceback,faulthandler
from datetime import datetime
from pathlib import Path

_log_file=None

def log_directory():
    base=Path(os.environ.get('LOCALAPPDATA') or Path.home()/'.local'/'share')
    target=base/'DSCompare'/'logs'
    target.mkdir(parents=True,exist_ok=True)
    return target

def install_diagnostics():
    global _log_file
    try:
        path=log_directory()/('sesja_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.log')
        _log_file=open(path,'w',encoding='utf-8',buffering=1)
        faulthandler.enable(file=_log_file,all_threads=True)
    except Exception:
        return
    previous=sys.excepthook
    def handler(cls,value,tb):
        trace=''.join(traceback.format_exception(cls,value,tb))
        try:
            _log_file.write('UNHANDLED UI EXCEPTION\n'+trace)
            _log_file.flush()
        except Exception:pass
        try:
            from PySide6.QtWidgets import QApplication,QMessageBox
            if QApplication.instance():
                QMessageBox.critical(None,'DS Compare – błąd',
                    'Wystąpił błąd interfejsu. Szczegóły zapisano w folderze:\n'+str(log_directory())+'\n\n'+str(value))
        except Exception:pass
        try:previous(cls,value,tb)
        except Exception:pass
    sys.excepthook=handler
