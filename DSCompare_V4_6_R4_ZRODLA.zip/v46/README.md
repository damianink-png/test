DS Compare 4.6 — nowy interfejs i szybsza analiza

START
Porównanie: wybierz lub przeciągnij A (starsza rewizja) i B (nowa).
Kliknij „Porównaj modele”. Po zakończeniu otwórz STEP lub raport z panelu po prawej.
„Otwórz STEP” korzysta z domyślnego programu Windows dla tego formatu.

WYGLĄD I SESJA
Motyw Jasny / Ciemny można zmienić w górnym pasku lub Ustawieniach.
Brak Historii. Normalne uruchomienie zawsze zaczyna z pustymi modelami i wynikami.
Zapamiętywane są tylko preferencje: motyw, parametry analizy i folder zapisu.
„Nowe porównanie” czyści bieżącą sesję, nie usuwa plików z dysku.
Jawne argumenty --a / --b (np. wywołanie z mostka DLL) mogą wskazać modele.
Miniatury krawędziowe są generowane po analizie z rzeczywistej geometrii. Nie jest
to interaktywny podgląd 3D. Przy bardzo dużej liczbie krawędzi tylko miniatura
jest uproszczona; analiza i eksport nadal obejmują wszystkie wczytane części.

KOLORY STEP
Zielony — geometria i położenie bez zmian, również przy zmianie samej nazwy.
Pomarańczowy / czerwony — stara geometria A, domyślnie 60% przezroczystości.
Niebieski — nowa geometria B. Zmienione i przesunięte pary mają obie wersje A+B.
Niepewne pary są oznaczone DO_SPRAWDZENIA i wymagają weryfikacji.
Filtry listy nie ograniczają zakresu porównania ani eksportu.

MASA
Obliczana z objętości i jednej gęstości ustawionej dla modelu. Nie odczytuje
materiałów z ZW3D. Wynik: CSV i HTML, bez wewnętrznego podglądu 3D.

WERYFIKACJA
119 testów lokalnych PASS; szczegóły i pomiary w RAPORT_V46.md.
Nowe cache działają tylko w ramach odczytu/analizy, bez historii plików.
Nie zmieniono tolerancji ani zasad dobierania par w celu poprawy szybkości.
W tej sesji nie wykonano kompilacji Windows ani testów w samym ZW3D.
Workflow GitHub buduje EXE/DLL i testuje gotowy EXE, dwa motywy, eksport oraz DLL.
Przezroczystość STEP potwierdzono w OpenCascade; importer ZW3D wymaga sprawdzenia.

ŹRÓDŁA
python -m pip install -r requirements.txt "PySide6>=6.8,<6.10"
python DSCompareV3.py
Testy: python -m pytest -q tests (pytest + VTK dla historycznych regresji).
Aktywny interfejs to dsac29/gui46.py, korzystający z obsługi procesów gui45.py.
Historyczne moduły są zachowane na potrzeby regresji, nie są zakładkami aplikacji.
Nazwa DSCompareV3.exe pozostaje zgodna z mostkiem DSAssemblyCompare2019.dll.
