"""DS Compare V4.6 entry. Worker mode is kept separate from the UI."""
import sys

if __name__=='__main__':
    if '--dscompare-worker' in sys.argv:
        from dsac29.gui import _worker_main
        sys.exit(_worker_main(sys.argv[1:]))
    elif '--worker' in sys.argv:
        from dsac29.worker_v37 import main
        sys.exit(main(sys.argv[1:]))
    else:
        import argparse
        p=argparse.ArgumentParser()
        p.add_argument('--a',default='')
        p.add_argument('--b',default='')
        p.add_argument('--smoke-test-ui',default='')
        p.add_argument('--smoke-test-interactions',default='')
        args=p.parse_args()
        if args.smoke_test_interactions:
            from dsac29.smoke_interactions import main as test
            sys.exit(test(args.smoke_test_interactions))
        if args.smoke_test_ui:
            import json
            from pathlib import Path
            from PySide6.QtWidgets import QApplication
            from dsac29.gui46 import Window
            app=QApplication([]);app.setStyle('Fusion')
            w=Window(args.a,args.b);w.show();app.processEvents()
            output=Path(args.smoke_test_ui);output.mkdir(parents=True,exist_ok=True)
            for theme in ('Jasny','Ciemny'):
                w.theme.setCurrentText(theme)
                for key in ('compare','mass','settings'):
                    w.navigate(key);app.processEvents();w.grab().save(str(output/(key+'_'+theme+'.png')))
            assert all(not b.icon().isNull() for b in w.nav.values())
            from PySide6.QtWidgets import QScrollArea
            assert not w.centralWidget().findChildren(QScrollArea), 'unexpected window scrollbars'
            assert w.width() <= app.primaryScreen().availableGeometry().width()
            assert w.height() <= app.primaryScreen().availableGeometry().height()
            assert not w.theme_button.icon().isNull() and not w.theme_button.text()
            old=w.theme.currentText();w.theme_button.click()
            assert old!=w.theme.currentText()
            w.theme_button.click();assert old==w.theme.currentText()
            w.close()
            (output/'UI_OK.json').write_text(json.dumps({'version':'4.6 R4','pages':3,'icons':3,'themes':2,'toggle':'PASS'}))
            sys.exit(0)
        from dsac29.diagnostics import install_diagnostics
        install_diagnostics()
        from dsac29.gui46 import main
        sys.exit(main(args.a,args.b))
