import json,os,time
from pathlib import Path
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.gp import gp_Trsf,gp_Vec
from OCP.TopLoc import TopLoc_Location
from dsac29.geometry import describe
from dsac29.compare import Record
from dsac29.step_io import export_revision_step,load_step,REVISION_COLORS

def part(name,x=0):
 shape=BRepPrimAPI_MakeBox(10,20,30).Shape();tr=gp_Trsf();tr.SetTranslation(gp_Vec(x,0,0))
 return describe(shape.Located(TopLoc_Location(tr)),name,name)

@pytest.mark.parametrize('schema',['AP214IS','AP242DIS'])
def test_revision_roles_colors_opacity_position(tmp_path,monkeypatch,schema):
 monkeypatch.setenv('DSCOMPARE_STEP_SCHEMA',schema)
 a=[part('same'),part('move',100),part('change',200),part('removed',300),part('maybe',400),part('renamed',500)]
 b=[part('same'),part('move',110),part('change',210),part('added',600),part('maybe',410),part('newname',500)]
 records=[Record(0,0,'SAME',''),Record(1,1,'MOVED',''),Record(2,2,'CHANGED',''),Record(3,None,'REMOVED',''),Record(None,3,'ADDED',''),Record(4,4,'UNCERTAIN',''),Record(5,5,'RENAMED','')]
 target=tmp_path/'compare.step';diag=export_revision_step(target,records,a,b)
 assert diag['roles']=={'SAME':2,'OLD':4,'NEW':4}
 assert diag['pokolorowane_etykiety']==10 and diag['alfy_powierzchni']==[.4,1.]
 assert diag['powierzchnie_przezroczyste']==24 and diag['rekordy_przezroczystosci_step']>0
 assert set(map(tuple,diag['kolory_wczytane_rgb']))==set(REVISION_COLORS.values())
 parts=load_step(str(target));assert len(parts)==10
 assert sum('DO_SPRAWDZENIA' in p.name for p in parts)==2
 assert sorted(round(p.center[0],5) for p in parts)==[5,105,115,205,215,305,405,415,505,605]

@pytest.mark.parametrize('alpha',[.1,1.])
def test_opacity_and_red(tmp_path,alpha):
 diag=export_revision_step(tmp_path/'red.step',[Record(0,None,'REMOVED','')],[part('old')],[],{'REMOVED':(.95,.12,.1)},alpha)
 assert diag['alfy_powierzchni']==[alpha] and diag['kolory_wczytane_rgb']==[(.95,.12,.1)]

@pytest.mark.parametrize('alpha',[-.1,1.1,float('nan')])
def test_invalid_alpha(tmp_path,alpha):
 with pytest.raises(ValueError):export_revision_step(tmp_path/'invalid.step',[Record(0,None,'REMOVED','')],[part('old')],[],old_alpha=alpha)
 assert not (tmp_path/'invalid.step').exists()

def test_reports_without_scenes(tmp_path):
 from dsac29.cli import process
 from dsac29.single_mass import analyze_single
 source=Path(__file__).resolve().parents[1]/'samples'
 folder,records,err=process(source/'MODEL_A.step',source/'MODEL_B.step',tmp_path/'compare',revision_style=True,diff_step=False,progress=None)
 assert err is None
 assert 'Stara wersja A' in (folder/'RAPORT.html').read_text()
 assert 'ROZNICE_BREP.step' not in (folder/'RAPORT.html').read_text()
 assert not list(folder.glob('SCENA*'))
 mass,_=analyze_single(source/'MODEL_A.step',tmp_path/'mass',preview=False)
 assert (mass/'MASY_CZESCI.csv').exists() and not list(mass.glob('SCENA*'))

def test_three_pages_drop_filter_and_worker(tmp_path,monkeypatch):
 os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
 from PySide6.QtCore import QMimeData,QUrl,QSettings
 from PySide6.QtWidgets import QApplication,QMessageBox
 from dsac29.gui45 import Window,FileCard
 QSettings.setDefaultFormat(QSettings.IniFormat);QSettings.setPath(QSettings.IniFormat,QSettings.UserScope,str(tmp_path/'settings'))
 errors=[];monkeypatch.setattr(QMessageBox,'warning',lambda *args:errors.append(str(args)))
 app=QApplication.instance() or QApplication([]);w=Window()
 assert set(w.nav)=={'compare','mass','settings'} and all(not b.icon().isNull() for b in w.nav.values())
 source=Path(__file__).resolve().parents[1]/'samples'
 mime=QMimeData();mime.setUrls([QUrl.fromLocalFile(str(source/'MODEL_A.step'))]);assert FileCard.drop_path(mime)
 mime.setUrls([QUrl('https://example.com/a.step')]);assert FileCard.drop_path(mime) is None
 mime.setUrls([QUrl.fromLocalFile(str(source/'MODEL_A.step')),QUrl.fromLocalFile(str(source/'MODEL_B.step'))]);assert FileCard.drop_path(mime) is None
 w.a.path.setText(str(source/'MODEL_A.step'));w.b.path.setText(str(source/'MODEL_B.step'));w.output.setText(str(tmp_path/'output'))
 w.start('compare');deadline=time.monotonic()+30
 while w.process is not None and time.monotonic()<deadline:app.processEvents();time.sleep(.01)
 assert not errors,errors
 assert w.process is None and w.compare_open['POROWNANIE_KOLORY.step'].isEnabled()
 assert w.compare_table.rowCount()==5
 w.only_changes.setChecked(False);w.search.setText('ZZZ-no-such-part')
 assert all(w.compare_table.isRowHidden(i) for i in range(5))
 w.search.clear();assert all(not w.compare_table.isRowHidden(i) for i in range(5))
 w.mass_file.path.setText(str(source/'MODEL_A.step'));w.start('mass');deadline=time.monotonic()+30
 while w.process is not None and time.monotonic()<deadline:app.processEvents();time.sleep(.01)
 assert not errors,errors
 assert w.process is None and w.mass_open['MASY_CZESCI.csv'].isEnabled()
 assert not list(w.results['mass'].glob('SCENA*'))
 w.close()
