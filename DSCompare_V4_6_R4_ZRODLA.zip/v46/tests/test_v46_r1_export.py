"""Regression coverage for optimized, grouped and alpha-styled STEP export."""
import json
from pathlib import Path
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.gp import gp_Trsf, gp_Vec
from OCP.TopLoc import TopLoc_Location
from dsac29.geometry import describe
from dsac29.compare import Record
from dsac29.step_io import export_revision_step, load_step, inspect_step_colors


def _part(source, x, name):
    tr=gp_Trsf();tr.SetTranslation(gp_Vec(x,0,0))
    return describe(source.Located(TopLoc_Location(tr)),name,name)


def test_native_repeat_reuses_geometry_without_losing_occurrences(tmp_path):
    source=BRepPrimAPI_MakeBox(5,6,7).Shape()
    a=[_part(source,i*25,str(i)) for i in range(36)]
    records=[Record(i,i,'SAME','') for i in range(len(a))]
    result=tmp_path/'groups.step'
    diag=export_revision_step(result,records,a,a)
    assert diag['definicje_unikalne']==1
    assert diag['ponownie_uzyte_definicje']==35
    assert diag['pokolorowane_etykiety']==len(a)
    assert len(load_step(str(result)))==len(a)
    assert b'01_BEZ_ZMIAN' in result.read_bytes()


def test_revision_assembly_contains_status_subassemblies_and_alpha(tmp_path):
    source=BRepPrimAPI_MakeBox(9,10,11).Shape()
    a=[_part(source,x,str(x)) for x in (0,50,100,150,200,250)]
    b=[_part(source,x,str(x)) for x in (0,52,100,154,210,260)]
    rec=[Record(0,0,'SAME',''),Record(1,1,'CHANGED',''),
         Record(2,2,'MOVED',''),Record(3,None,'REMOVED',''),
         Record(None,3,'ADDED',''),Record(4,4,'UNCERTAIN',''),
         Record(5,5,'RENAMED','')]
    result=tmp_path/'categorized.step'
    diag=export_revision_step(result,rec,a,b,old_alpha=.35)
    text=result.read_text(errors='replace')
    for name in ('01_BEZ_ZMIAN','02_ZMIENIONE','03_PRZESUNIETE',
                 '04_NOWE','05_USUNIETE','06_DO_SPRAWDZENIA',
                 'A_STARA','B_NOWA'):
        assert name in text,name
    assert diag['roles']=={'SAME':2,'OLD':4,'NEW':4}
    assert diag['alfy_powierzchni']==[.35,1.0]
    assert diag['grupowanie_zlozenia']
    assert len(load_step(str(result)))==10


def test_fast_verification_reports_limits_and_opaque_output(tmp_path,monkeypatch):
    monkeypatch.setenv('DSCOMPARE_STEP_VERIFY','fast')
    source=BRepPrimAPI_MakeBox(3,4,5).Shape()
    a=[_part(source,0,'old')]
    diag=export_revision_step(tmp_path/'fast.step',[Record(0,None,'REMOVED','')],a,[],old_alpha=.25)
    assert diag['weryfikacja']=='szybka_strukturalna_bez_ponownego_importu'
    assert diag['rekordy_przezroczystosci_step']>0
    assert diag['pokolorowane_etykiety']==1
    assert inspect_step_colors(tmp_path/'fast.step')['alfy_powierzchni']==[.25]
