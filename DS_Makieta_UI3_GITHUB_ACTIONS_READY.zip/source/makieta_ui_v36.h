// DS Makieta 2019 V36 UI2 - only the native Win32 UI. Geometry/API calls remain in DSMakieta2019.cpp.
// This file is included after build()/convertAssembly() and shares the existing Config, Plan and API globals.
#pragma once
#include <commctrl.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <math.h>

static HWND ui=nullptr, uiTip=nullptr;
static HFONT uiFont=nullptr, uiTitleFont=nullptr, uiSmallFont=nullptr;
static HBITMAP uiPreviewBmp=nullptr;
static char uiPreviewBmpPath[MAX_PATH*2]={0};
static int uiDone=0, uiAction=0, uiActiveField=-1;
static bool uiReady=false, uiValid=false, uiSettingsLoaded=false;
static Config editCfg, previewCfg;
static double uiScale=1.0;
static char uiStatus[640]={};
static int px(int n){return (int)floor(n*uiScale+0.5);}

struct Field {const char* label; const char* help; const char* symbol; double Config::*value;};
static const Field fields[]={
 {"Dlugosc do osi otworu L [mm]", "Od x=0 do osi otworu na koncowce (X=L).", "L", &Config::L},
 {"Szerokosc zewnetrzna W [mm]", "Calkowita szerokosc makiety w kierunku Y.", "W", &Config::W},
 {"Wysokosc zewnetrzna H [mm]", "Calkowita wysokosc makiety w kierunku Z.", "H", &Config::H},
 {"Dlugosc koncowki N [mm]", "Od poczatku koncowki X=L-N do osi otworu X=L.", "N", &Config::nose},
 {"Wysuniecie gorne T [mm]", "Czesc gornych pasow wysunieta za X=0 w kierunku -X.", "T", &Config::tail},
 {"Wysokosc osi otworu Z [mm]", "Polozenie srodka otworu wzgledem Z=0.", "Z", &Config::holeZ},
 {"Srednica otworu D [mm]", "Nominalna srednica otworu, pasowanie H7.", "D", &Config::holeD},
 {"Odstep miedzy rurami G [mm]", "Wymagany luz miedzy rurami w strefach docinania.", "G", &Config::gap}
};
static const int fieldCount=(int)(sizeof(fields)/sizeof(fields[0]));
static const char* profiles[]={"20x20x2","25x25x2","30x30x2","40x40x2","40x40x3","50x50x3","60x60x3","80x80x4"};
static char uiSettingsPath[MAX_PATH*2]={};

static HWND ctl(const char*cls,const char*text,DWORD style,int x,int y,int w,int h,int id){
 HWND c=CreateWindowExA(0,cls,text,WS_CHILD|WS_VISIBLE|style,px(x),px(y),px(w),px(h),ui,(HMENU)(INT_PTR)id,gModule,nullptr);
 if(c)SendMessageA(c,WM_SETFONT,(WPARAM)uiFont,TRUE);
 return c;
}
static bool parseNumber(const char*s,double&out){
 if(!s)return false;
 char b[96];strncpy(b,s,sizeof(b)-1);b[sizeof(b)-1]=0;
 for(char*p=b;*p;p++)if(*p==',')*p='.';
 errno=0;char*end=nullptr;double value=strtod(b,&end);
 if(end==b||errno)return false;
 while(*end==' '||*end=='\t')end++;
 if(*end||!isfinite(value))return false;
 out=value;return true;
}
static bool profileValue(int id,double&p,double&t){
 char s[96]={};GetWindowTextA(GetDlgItem(ui,id),s,(int)sizeof(s));
 for(char*c=s;*c;c++)if(*c==',')*c='.';
 double x=0,y=0,z=0;char extra=0;
 if(sscanf(s,"%lfx%lfx%lf %c",&x,&y,&z,&extra)!=3 || !isfinite(x)||!isfinite(y)||!isfinite(z)|| x<=0 || z<=0 || 2*z>=x ||fabs(x-y)>.00001)return false;
 p=x;t=z;return true;
}
static void normalizeLockedConfig(Config&c){
 strcpy(c.fit,"H7");c.assembly=0;
 c.angleMin=30;c.angleTarget=42;c.angleMax=60;c.blockY=5;
 c.blockX=fmax(64,c.holeD+12);c.blockZ=fmax(c.profile,c.holeD+12);
 c.tubeD=25;c.tubeWall=1.5;
}
static bool readControls(Config&c){
 c=editCfg;
 for(int i=0;i<fieldCount;i++){
  char s[96]={};GetWindowTextA(GetDlgItem(ui,100+i),s,(int)sizeof(s));
  if(!parseNumber(s,c.*fields[i].value)){snprintf(lastError,sizeof(lastError),"Nieprawidlowa liczba: %s",fields[i].label);return false;}
 }
 if(!profileValue(200,c.profile,c.wall)){failure("Profil wpisz jako np. 40x40x2 (profil kwadratowy).");return false;}
 normalizeLockedConfig(c);
 char err[256]={};
 if(!makePlan(c,plan,err)){failure(err);return false;}
 return true;
}
static void settingsFile(){
 if(uiSettingsPath[0])return;
 char app[MAX_PATH]={};DWORD n=GetEnvironmentVariableA("APPDATA",app,MAX_PATH);
 if(n>0&&n<MAX_PATH){
  snprintf(uiSettingsPath,sizeof(uiSettingsPath),"%s\\DSMakieta2019",app);
  CreateDirectoryA(uiSettingsPath,nullptr);
  strncat(uiSettingsPath,"\\settings.ini",sizeof(uiSettingsPath)-strlen(uiSettingsPath)-1);
 }else strcpy(uiSettingsPath,"DSMakieta2019_settings.ini");
}
static void loadSettings(Config&c){
 settingsFile();Config candidate=c;
 for(int i=0;i<fieldCount;i++){
  char value[96]={};GetPrivateProfileStringA("Dimensions",fields[i].symbol,"",value,96,uiSettingsPath);
  double parsed=0;if(value[0]&&parseNumber(value,parsed))candidate.*fields[i].value=parsed;
 }
 char p[96]={};GetPrivateProfileStringA("Dimensions","profile","",p,96,uiSettingsPath);
 if(p[0]){
  double x=0,y=0,z=0;char extra=0;
  if(sscanf(p,"%lfx%lfx%lf %c",&x,&y,&z,&extra)==3&&isfinite(x)&&x>0&&fabs(x-y)<1e-5&&z>0&&2*z<x){candidate.profile=x;candidate.wall=z;}
 }
 normalizeLockedConfig(candidate);
 char err[256]={};if(configValid(candidate,err))c=candidate;
}
static void saveSettings(const Config&c){
 settingsFile();char s[80];
 for(int i=0;i<fieldCount;i++){
  snprintf(s,sizeof(s),"%.6f",c.*fields[i].value);
  WritePrivateProfileStringA("Dimensions",fields[i].symbol,s,uiSettingsPath);
 }
 snprintf(s,sizeof(s),"%gx%gx%g",c.profile,c.profile,c.wall);
 WritePrivateProfileStringA("Dimensions","profile",s,uiSettingsPath);
}
static void addTip(HWND target,const char*text){
 if(!uiTip||!target)return;
 TOOLINFOA ti={};ti.cbSize=sizeof(ti);ti.uFlags=TTF_IDISHWND|TTF_SUBCLASS;
 ti.hwnd=ui;ti.uId=(UINT_PTR)target;ti.lpszText=(LPSTR)text;
 SendMessageA(uiTip,TTM_ADDTOOLA,0,(LPARAM)&ti);
}

static void previewBitmapPath(){
 if(uiPreviewBmpPath[0])return;
 char modulePath[MAX_PATH*2]={0};
 GetModuleFileNameA(gModule,modulePath,(DWORD)(sizeof(modulePath)-1));
 char*slash=strrchr(modulePath,'\\'); if(slash) *slash=0;
 snprintf(uiPreviewBmpPath,sizeof(uiPreviewBmpPath),"%s\\assets\\makieta_preview_default.bmp",modulePath);
}
static void ensurePreviewBitmap(){
 if(uiPreviewBmp) return;
 // 101 = obraz statyczny osadzony w DSMakieta2019.dll jako zasob Win32.
 // Dla kompatybilnosci ze starszymi paczkami pozostawiono fallback do pliku BMP.
 uiPreviewBmp=(HBITMAP)LoadImageA(gModule,MAKEINTRESOURCEA(101),IMAGE_BITMAP,0,0,LR_CREATEDIBSECTION);
 if(!uiPreviewBmp){
  previewBitmapPath();
  uiPreviewBmp=(HBITMAP)LoadImageA(nullptr,uiPreviewBmpPath,IMAGE_BITMAP,0,0,LR_LOADFROMFILE|LR_CREATEDIBSECTION);
 }
}
static void uiFontTo(HDC dc,HFONT f){SelectObject(dc,f?f:(HFONT)GetStockObject(DEFAULT_GUI_FONT));}
static void uiText(HDC dc,int x,int y,const char*value,COLORREF color,HFONT f){
 SetBkMode(dc,TRANSPARENT);SetTextColor(dc,color);uiFontTo(dc,f);
 TextOutA(dc,px(x),px(y),value,(int)strlen(value));
}
static void stroke(HDC dc,int x1,int y1,int x2,int y2,COLORREF c,int thickness=1,int pattern=PS_SOLID){
 HPEN pen=CreatePen(pattern,px(thickness)>0?px(thickness):1,c);
 HPEN old=(HPEN)SelectObject(dc,pen);
 MoveToEx(dc,px(x1),px(y1),nullptr);LineTo(dc,px(x2),px(y2));
 SelectObject(dc,old);DeleteObject(pen);
}
static void fillRectUI(HDC dc,int x,int y,int w,int h,COLORREF c){
 RECT r={px(x),px(y),px(x+w),px(y+h)};HBRUSH br=CreateSolidBrush(c);
 FillRect(dc,&r,br);DeleteObject(br);
}
static void circleUI(HDC dc,int cx,int cy,int r,COLORREF c,int thickness=1){
 HPEN p=CreatePen(PS_SOLID,px(thickness),c);HPEN o=(HPEN)SelectObject(dc,p);
 HBRUSH b=(HBRUSH)SelectObject(dc,GetStockObject(NULL_BRUSH));
 Ellipse(dc,px(cx-r),px(cy-r),px(cx+r),px(cy+r));
 SelectObject(dc,b);SelectObject(dc,o);DeleteObject(p);
}
static void arrowUI(HDC dc,int x,int y,int vx,int vy,COLORREF c){
 // 6-pixel open arrow. Vector (vx,vy) points toward dimension endpoint.
 stroke(dc,x,y,x-vx*6-vy*3,y-vy*6+vx*3,c);
 stroke(dc,x,y,x-vx*6+vy*3,y-vy*6-vx*3,c);
}
static void dimH(HDC dc,int a,int b,int y,const char*label,int fld){
 COLORREF color=uiActiveField==fld?RGB(0,114,170):RGB(106,124,144);
 if(a>b){int t=a;a=b;b=t;}
 stroke(dc,a,y,b,y,color);arrowUI(dc,a,y,-1,0,color);arrowUI(dc,b,y,1,0,color);
 int width=(int)strlen(label)*7;uiText(dc,(a+b-width)/2,y-18,label,color,uiSmallFont);
}
static void dimV(HDC dc,int x,int a,int b,const char*label,int fld){
 COLORREF color=uiActiveField==fld?RGB(0,114,170):RGB(106,124,144);
 if(a>b){int t=a;a=b;b=t;}
 stroke(dc,x,a,x,b,color);arrowUI(dc,x,a,0,-1,color);arrowUI(dc,x,b,0,1,color);
 uiText(dc,x+5,(a+b)/2-8,label,color,uiSmallFont);
}
static int mapX(double x,double xmin,double xmax,int left,int right){
 double t=(x-xmin)/fmax(xmax-xmin,1.0);t=fmax(0,fmin(1,t));return left+(int)floor((right-left)*t+.5);
}
static int mapZ(double z,double h,int bottom,int top){
 double t=fmax(0,fmin(1,z/fmax(h,1.0)));return bottom-(int)floor((bottom-top)*t+.5);
}
static void paintPreview(HDC dc){
 int saved=SaveDC(dc);
 const COLORREF ink=RGB(42,65,88),accent=RGB(0,114,170),muted=RGB(111,127,142);
 fillRectUI(dc,560,90,860,555,RGB(247,250,253));
 stroke(dc,560,90,1420,90,RGB(216,225,235));stroke(dc,560,90,560,645,RGB(216,225,235));
 stroke(dc,1419,90,1419,645,RGB(216,225,235));stroke(dc,560,644,1420,644,RGB(216,225,235));
 uiText(dc,578,106,"PODGLAD GEOMETRII 3D",ink,uiTitleFont);
 uiText(dc,578,135,"Statyczny obraz makiety na podstawie wartosci domyslnych; pogladowy i nieedytowalny.",muted,uiSmallFont);
 ensurePreviewBitmap();
 RECT target={px(585),px(168),px(1395),px(525)};
 if(uiPreviewBmp){
   HDC mem=CreateCompatibleDC(dc); HGDIOBJ old=SelectObject(mem,uiPreviewBmp); BITMAP bm={}; GetObject(uiPreviewBmp,sizeof(bm),&bm);
   SetStretchBltMode(dc,HALFTONE);
   StretchBlt(dc,target.left,target.top,target.right-target.left,target.bottom-target.top,mem,0,0,bm.bmWidth,bm.bmHeight,SRCCOPY);
   SelectObject(mem,old); DeleteDC(mem);
 }else{
   fillRectUI(dc,585,168,810,357,RGB(255,255,255));
   stroke(dc,585,168,1395,168,RGB(220,229,238)); stroke(dc,585,168,585,525,RGB(220,229,238));
   stroke(dc,1395,168,1395,525,RGB(220,229,238)); stroke(dc,585,525,1395,525,RGB(220,229,238));
   uiText(dc,835,340,"Brak pliku assets/makieta_preview_default.bmp",RGB(160,60,60),uiFont);
 }
 fillRectUI(dc,585,540,810,86,RGB(255,255,255));
 stroke(dc,585,540,1395,540,RGB(220,229,238)); stroke(dc,585,540,585,626,RGB(220,229,238));
 stroke(dc,1395,540,1395,626,RGB(220,229,238)); stroke(dc,585,626,1395,626,RGB(220,229,238));
 uiText(dc,600,554,"AKTYWNE PARAMETRY / OPIS",ink,uiFont);
 const Config&c=previewCfg;
 char s1[256],s2[256],s3[256],s4[256];
 snprintf(s1,sizeof(s1),"L = %.1f mm    W = %.1f mm    H = %.1f mm    N = %.1f mm",c.L,c.W,c.H,c.nose);
 snprintf(s2,sizeof(s2),"T = %.1f mm    Z = %.1f mm    D = %.1f mm    G = %.1f mm",c.tail,c.holeZ,c.holeD,c.gap);
 snprintf(s3,sizeof(s3),"Profil pasa glownego: %.0fx%.0fx%.0f",c.profile,c.profile,c.wall);
 if(uiValid) snprintf(s4,sizeof(s4),"Podzial: %d pola | %.1f mm na pole | kat krzyzulcow %.1f stopni | %d elementow",plan.fields,plan.pitch,plan.angle,plan.count);
 else snprintf(s4,sizeof(s4),"Brak poprawnego podzialu: %s",lastError);
 uiText(dc,600,580,s1,uiActiveField>=0?accent:ink,uiSmallFont);
 uiText(dc,600,602,s2,uiActiveField>=0?accent:ink,uiSmallFont);
 uiText(dc,975,580,s3,ink,uiSmallFont);
 uiText(dc,975,602,s4,uiValid?RGB(20,111,78):RGB(164,45,45),uiSmallFont);
 RestoreDC(dc,saved);
}
static void previewRect(RECT&r){r={px(560),px(90),px(1420),px(645)};}
static void showPlan(){
 if(!uiReady)return;
 Config c={};uiValid=readControls(c);
 if(uiValid){
  previewCfg=c;
  snprintf(uiStatus,sizeof(uiStatus),"GOTOWE: %d pol | %.1f mm na pole | %.1f stopni | %d elementow\r\nOs otworu: X=%.1f, Y=0, Z=%.1f mm. Krzyzulce 30-60 stopni.",plan.fields,plan.pitch,plan.angle,plan.count,c.L,c.holeZ);
 }else snprintf(uiStatus,sizeof(uiStatus),"POPRAW PARAMETRY: %.530s",lastError);
 HWND h=GetDlgItem(ui,300);if(h)SetWindowTextA(h,uiStatus);
 HWND b=GetDlgItem(ui,401);if(b)EnableWindow(b,uiValid?TRUE:FALSE);
 RECT r;previewRect(r);InvalidateRect(ui,&r,FALSE);
}
static void resetEdits(const Config&c){
 uiReady=false;editCfg=c;previewCfg=c;
 for(int i=0;i<fieldCount;i++){
  char number[64];snprintf(number,sizeof(number),"%.3f",c.*fields[i].value);
  SetWindowTextA(GetDlgItem(ui,100+i),number);
 }
 char s[80];snprintf(s,sizeof(s),"%gx%gx%g",c.profile,c.profile,c.wall);
 SetWindowTextA(GetDlgItem(ui,200),s);uiReady=true;showPlan();
}
static LRESULT CALLBACK wndProc(HWND w,UINT m,WPARAM wp,LPARAM lp){
 switch(m){
  case WM_ERASEBKGND:{RECT rc;GetClientRect(w,&rc);FillRect((HDC)wp,&rc,(HBRUSH)(COLOR_WINDOW+1));return 1;}
  case WM_PAINT:{PAINTSTRUCT p;HDC dc=BeginPaint(w,&p);
   int saved=SaveDC(dc);
   fillRectUI(dc,0,0,1450,710,RGB(255,255,255));
   fillRectUI(dc,0,0,1450,77,RGB(35,58,83));
   uiText(dc,22,16,"DS  MAKIETA  |  GENERATOR KONSTRUKCJI",RGB(245,251,255),uiTitleFont);
   uiText(dc,22,48,"ZW3D 2019 x64   -   generator + statyczny podglad 3D makiety",RGB(185,218,239),uiSmallFont);
   fillRectUI(dc,20,90,522,174,RGB(247,249,252));
   fillRectUI(dc,20,275,522,136,RGB(247,249,252));
   fillRectUI(dc,20,423,522,115,RGB(247,249,252));
   uiText(dc,35,99,"01   GABARYTY GLOWNE",RGB(44,88,123),uiFont);
   uiText(dc,35,286,"02   KONCOWKA I OTWOR",RGB(44,88,123),uiFont);
   uiText(dc,35,434,"03   KONSTRUKCJA",RGB(44,88,123),uiFont);
   paintPreview(dc);
   uiText(dc,21,545,"WYNIK WALIDACJI / PODZIAL AUTOMATYCZNY",RGB(44,88,123),uiSmallFont);
   RestoreDC(dc,saved);EndPaint(w,&p);return 0;}
  case WM_COMMAND:{int id=LOWORD(wp),notification=HIWORD(wp);
   if(id>=100&&id<100+fieldCount&&notification==EN_SETFOCUS){uiActiveField=id-100;RECT r;previewRect(r);InvalidateRect(w,&r,FALSE);return 0;}
   if(id==200&&notification==CBN_SETFOCUS){uiActiveField=-1;RECT r;previewRect(r);InvalidateRect(w,&r,FALSE);return 0;}
   if(((id>=100&&id<100+fieldCount)&&notification==EN_CHANGE)||(id==200&&(notification==CBN_SELCHANGE||notification==CBN_EDITCHANGE))){showPlan();return 0;}
   if(id==405){Config defaultsCfg=defaults();resetEdits(defaultsCfg);return 0;}
   if(id==401){Config c;if(!readControls(c)){MessageBoxA(w,lastError,"Sprawdz parametry",MB_OK|MB_ICONWARNING);return 0;}
    editCfg=c;uiAction=1;saveSettings(c);DestroyWindow(w);return 0;}
   if(id==403||id==IDCANCEL){uiAction=0;DestroyWindow(w);return 0;}
   break;}
  case WM_CTLCOLORSTATIC:{
   HWND target=(HWND)lp;
   if(GetDlgCtrlID(target)==300){HDC dc=(HDC)wp;SetTextColor(dc,uiValid?RGB(20,111,78):RGB(164,45,45));SetBkColor(dc,RGB(244,248,251));
    static HBRUSH resultBrush=CreateSolidBrush(RGB(244,248,251));return (LRESULT)resultBrush;}
   break;}
  case WM_CLOSE:uiAction=0;DestroyWindow(w);return 0;
  case WM_DESTROY:uiDone=1;return 0;
 }
 return DefWindowProcA(w,m,wp,lp);
}
static void uiRow(int n,int y){
 ctl("STATIC",fields[n].label,0,38,y+5,362,23,0);
 char s[40];snprintf(s,sizeof(s),"%.3f",editCfg.*fields[n].value);
 HWND ed=ctl("EDIT",s,WS_BORDER|WS_TABSTOP|ES_AUTOHSCROLL,414,y,107,27,100+n);
 addTip(ed,fields[n].help);
}
static int showWindow(Config&c){
 if(!uiSettingsLoaded){loadSettings(c);uiSettingsLoaded=true;}
 editCfg=c;previewCfg=c;uiDone=0;uiAction=0;uiReady=false;uiActiveField=-1;
 HDC dc=GetDC(nullptr);int dpi=dc?GetDeviceCaps(dc,LOGPIXELSX):96;if(dc)ReleaseDC(nullptr,dc);
 int sx=GetSystemMetrics(SM_CXSCREEN),sy=GetSystemMetrics(SM_CYSCREEN);
 uiScale=dpi/96.0;
 double maxW=(sx-32.0)/1200.0,maxH=(sy-72.0)/735.0;
 if(uiScale>maxW)uiScale=maxW;
 if(uiScale>maxH)uiScale=maxH;
 if(uiScale<.65)uiScale=.65;
 uiFont=CreateFontA(-px(15),0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,"Segoe UI");
 uiTitleFont=CreateFontA(-px(19),0,0,0,FW_SEMIBOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,"Segoe UI");
 uiSmallFont=CreateFontA(-px(13),0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,"Segoe UI");
 INITCOMMONCONTROLSEX ice={sizeof(ice),ICC_WIN95_CLASSES};InitCommonControlsEx(&ice);
 WNDCLASSEXA wc={};wc.cbSize=sizeof(wc);wc.lpfnWndProc=wndProc;wc.hInstance=gModule;wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
 wc.lpszClassName="DSMakieta2019V36_UIPreview";
 RegisterClassExA(&wc);HWND owner=GetForegroundWindow();
 RECT rect={0,0,px(1450),px(710)};AdjustWindowRectEx(&rect,WS_CAPTION|WS_SYSMENU,FALSE,WS_EX_DLGMODALFRAME|WS_EX_CONTROLPARENT);
 int ww=rect.right-rect.left,hh=rect.bottom-rect.top;
 ui=CreateWindowExA(WS_EX_DLGMODALFRAME|WS_EX_CONTROLPARENT,wc.lpszClassName,"DS Makieta | ZW3D 2019 | V36 UI3 Embedded Preview",WS_CAPTION|WS_SYSMENU,(sx-ww)/2,(sy-hh)/2,ww,hh,owner,nullptr,gModule,nullptr);
 if(!ui){failure("Nie mozna otworzyc okna generatora.");DeleteObject(uiFont);DeleteObject(uiTitleFont);DeleteObject(uiSmallFont);uiFont=uiTitleFont=uiSmallFont=nullptr;return -1;}
 uiTip=CreateWindowExA(WS_EX_TOPMOST,TOOLTIPS_CLASSA,nullptr,WS_POPUP|TTS_ALWAYSTIP,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,ui,nullptr,gModule,nullptr);
 if(uiTip)SendMessageA(uiTip,TTM_SETMAXTIPWIDTH,0,350);
 uiRow(0,124);uiRow(1,156);uiRow(2,188);uiRow(3,220);
 uiRow(4,309);uiRow(5,340);uiRow(6,371);
 uiRow(7,455);
 ctl("STATIC","Profil pasa glownego",0,38,495,362,24,0);
 HWND cmb=ctl("COMBOBOX","",WS_TABSTOP|CBS_DROPDOWN|WS_VSCROLL,414,490,107,190,200);
 for(const char*str:profiles)SendMessageA(cmb,CB_ADDSTRING,0,(LPARAM)str);
 char prof[64];snprintf(prof,sizeof(prof),"%gx%gx%g",c.profile,c.profile,c.wall);
 SetWindowTextA(cmb,prof);addTip(cmb,"Profil kwadratowy mm, np. 40x40x2. Rury krzyzulcow sa stale: fi25x1.5.");
 ctl("STATIC","",WS_BORDER|SS_LEFT,20,567,521,55,300);
 ctl("BUTTON","PRZYWROC DOMYSLNE",WS_TABSTOP,20,638,215,35,405);
 ctl("STATIC","Zmiany zapisujemy po kliknieciu GENERUJ.",0,253,646,370,22,0);
 ctl("BUTTON","GENERUJ",WS_TABSTOP|BS_DEFPUSHBUTTON,1096,650,153,37,401);
 ctl("BUTTON","ANULUJ",WS_TABSTOP,1261,650,154,37,403);
 uiReady=true;showPlan();
 if(owner)EnableWindow(owner,FALSE);
 ShowWindow(ui,SW_SHOW);UpdateWindow(ui);SetFocus(GetDlgItem(ui,100));
 MSG m={};int quit=0;
 while(!uiDone){int r=GetMessageA(&m,nullptr,0,0);if(r<=0){quit=r==0;break;}if(!IsDialogMessageA(ui,&m)){TranslateMessage(&m);DispatchMessageA(&m);}}
 if(!uiDone&&ui&&IsWindow(ui))DestroyWindow(ui);
 if(owner){EnableWindow(owner,TRUE);SetForegroundWindow(owner);}
 if(uiFont)DeleteObject(uiFont);if(uiTitleFont)DeleteObject(uiTitleFont);if(uiSmallFont)DeleteObject(uiSmallFont);if(uiPreviewBmp)DeleteObject(uiPreviewBmp);
 UnregisterClassA(wc.lpszClassName,gModule);
 uiFont=uiTitleFont=uiSmallFont=nullptr;uiPreviewBmp=nullptr;uiTip=nullptr;ui=nullptr;
 if(quit)PostQuitMessage((int)m.wParam);
 c=editCfg;return uiAction;
}
