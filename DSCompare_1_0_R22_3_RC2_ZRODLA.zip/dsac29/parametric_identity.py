"""Geometric STEP identity: analytic surfaces / bounded Bezier control nets,
and ALL oriented trimming edges. No meshes, volume or area establish identity.
Unsupported or inconclusive cases fall back to solid Boolean verification.
"""
import numpy as np
from OCP.BRepAdaptor import BRepAdaptor_Surface,BRepAdaptor_Curve
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_FACE,TopAbs_WIRE,TopAbs_EDGE,TopAbs_VERTEX
from OCP.TopoDS import TopoDS
from OCP.BRep import BRep_Tool
from OCP.Geom import Geom_TrimmedCurve
from OCP.GeomConvert import GeomConvert,GeomConvert_BSplineCurveToBezierCurve,GeomConvert_BSplineSurfaceToBezierSurface

def items(s,kind,cast):
 ex=TopExp_Explorer(s,kind);out=[]
 while ex.More():out.append(cast(ex.Current()));ex.Next()
 return out

def xyz(p):return np.array(p.Coord(),float)
def direction(a):return xyz(a.Direction())
def aligned(a,b):return b if np.dot(a,b)>=0 else -b

def pole_bound(a,b):
 p,w=a;q,v=b
 if p.shape!=q.shape or w.shape!=v.shape:return float('inf')
 if not all(np.all(np.isfinite(t)) for t in (p,q,w,v)) or min(w.min(),v.min())<=0:return float('inf')
 ratio=v/w
 if not np.all(np.isfinite(ratio)) or ratio.min()<=0:return float('inf')
 # Positive rational Bernstein weights: uniform bound over the ENTIRE patch.
 radius=np.linalg.norm(q-q.reshape(-1,q.shape[-1])[0],axis=-1).max()
 return np.linalg.norm(p-q,axis=-1).max()+(ratio.max()/ratio.min()-1)*radius+1e-10

def surface_equal(f,g,box,tol):
 a=BRepAdaptor_Surface(f);b=BRepAdaptor_Surface(g)
 if a.GetType()!=b.GetType():return False
 kind=str(a.GetType());center=(box[:3]+box[3:])/2;extent=np.linalg.norm(box[3:]-box[:3])/2
 if 'Plane' in kind:
  x,y=a.Plane(),b.Plane();n=direction(x.Axis());m=aligned(n,direction(y.Axis()))
  return abs(np.dot(center-xyz(x.Location()),n)-np.dot(center-xyz(y.Location()),m))+extent*np.linalg.norm(n-m)<=tol
 if 'Cylinder' in kind:
  x,y=a.Cylinder(),b.Cylinder();n=direction(x.Axis());m=aligned(n,direction(y.Axis()))
  u=xyz(x.Location());v=xyz(y.Location());u+=np.dot(center-u,n)*n;v+=np.dot(center-v,m)*m
  return np.linalg.norm(u-v)+extent*np.linalg.norm(n-m)+abs(x.Radius()-y.Radius())<=tol
 if 'Sphere' in kind:
  x,y=a.Sphere(),b.Sphere();return np.linalg.norm(xyz(x.Location())-xyz(y.Location()))+abs(x.Radius()-y.Radius())<=tol
 if 'Torus' in kind:
  x,y=a.Torus(),b.Torus();n=direction(x.Axis());m=aligned(n,direction(y.Axis()))
  return np.linalg.norm(xyz(x.Location())-xyz(y.Location()))+abs(x.MajorRadius()-y.MajorRadius())+abs(x.MinorRadius()-y.MinorRadius())+2*(x.MajorRadius()+x.MinorRadius())*np.linalg.norm(n-m)<=tol
 if 'Cone' in kind:
  x,y=a.Cone(),b.Cone();n=direction(x.Axis());m=direction(y.Axis());u=xyz(x.Apex());v=xyz(y.Apex())
  radius=np.linalg.norm(center-u)+extent;angle=max(abs(x.SemiAngle()),abs(y.SemiAngle()))
  if angle>=1.4:return False
  return np.linalg.norm(u-v)+2*radius*(np.linalg.norm(n-m)+abs(x.SemiAngle()-y.SemiAngle()))/(np.cos(angle)**2)<=tol
 if 'BSpline' in kind:
  x=GeomConvert_BSplineSurfaceToBezierSurface(a.BSpline());y=GeomConvert_BSplineSurfaceToBezierSurface(b.BSpline())
  if (x.NbUPatches(),x.NbVPatches())!=(y.NbUPatches(),y.NbVPatches()):return False
  if x.NbUPatches()*x.NbVPatches()>10000:return False
  def net(p):return np.array([[p.Pole(i,j).Coord() for j in range(1,p.NbVPoles()+1)] for i in range(1,p.NbUPoles()+1)]),np.array([[p.Weight(i,j) for j in range(1,p.NbVPoles()+1)] for i in range(1,p.NbUPoles()+1)])
  return all(pole_bound(net(x.Patch(i,j)),net(y.Patch(i,j)))<=tol for i in range(1,x.NbUPatches()+1) for j in range(1,x.NbVPatches()+1))
 return False

def edge_data(e):
 if BRep_Tool.Degenerated_s(e):
  vs=items(e,TopAbs_VERTEX,TopoDS.Vertex_s)
  return ('point',xyz(BRep_Tool.Pnt_s(vs[0])))
 a=BRepAdaptor_Curve(e);first,last=a.FirstParameter(),a.LastParameter();reverse=int(e.Orientation())==1
 start,end=xyz(a.Value(last if reverse else first)),xyz(a.Value(first if reverse else last))
 kind=str(a.GetType())
 if 'Line' in kind:return ('line',start,end)
 if 'Circle' in kind:
  c=a.Circle();axis=direction(c.Axis())*(-1 if reverse else 1)
  return ('circle',start,end,xyz(c.Location()),c.Radius(),axis,last-first)
 curve=a.Curve().Curve().Transformed(a.Trsf())
 s=GeomConvert.CurveToBSplineCurve_s(Geom_TrimmedCurve(curve,first,last))
 if reverse:s.Reverse()
 split=GeomConvert_BSplineCurveToBezierCurve(s)
 if split.NbArcs()>10000:raise ValueError('Curve budget')
 out=[]
 for k in range(1,split.NbArcs()+1):
  p=split.Arc(k);out.append((np.array([p.Pole(i).Coord() for i in range(1,p.NbPoles()+1)]),np.array([p.Weight(i) for i in range(1,p.NbPoles()+1)])))
 return ('bezier',out)

def edge_equal(a,b,tol):
 if a[0]!=b[0]:return False
 if a[0]=='point':return np.linalg.norm(a[1]-b[1])<=tol
 if a[0]=='line':return max(np.linalg.norm(a[1]-b[1]),np.linalg.norm(a[2]-b[2]))<=tol
 if a[0]=='circle':
  bound=np.linalg.norm(a[3]-b[3])+abs(a[4]-b[4])+2*max(a[4],b[4])*np.linalg.norm(a[5]-b[5])
  if bound>tol or max(a[6],b[6])>2*np.pi+1e-10:return False
  if abs(a[6]-b[6])*max(a[4],b[4])>tol:return False
  full=abs(a[6]-2*np.pi)*a[4]<=tol and abs(b[6]-2*np.pi)*b[4]<=tol
  return full or max(np.linalg.norm(a[1]-b[1]),np.linalg.norm(a[2]-b[2]))+bound<=tol
 return len(a[1])==len(b[1]) and all(pole_bound(x,y)<=tol for x,y in zip(a[1],b[1]))

def perfect(options):
 # Iterative augmenting paths also handle wires with thousands of edges.
 owner={};reverse={}
 for first in sorted(range(len(options)),key=lambda i:len(options[i])):
  queue=[first];seen_left={first};seen_right=set();parent={};free=None
  for i in queue:
   for j in options[i]:
    if j in seen_right:continue
    seen_right.add(j);parent[j]=i
    if j not in owner:free=j;break
    other=owner[j]
    if other not in seen_left:seen_left.add(other);queue.append(other)
   if free is not None:break
  if free is None:return False
  # Follow the alternating path back to the new unmatched left vertex.
  while True:
   i=parent[free];old=reverse.get(i);owner[free]=i;reverse[i]=free
   if old is None:break
   free=old
 return True

def edge_options(left,right,tol):
 """Spatial prefilter only; every accepted edge still needs edge_equal.

 Each edge type has an anchor whose distance <= tol is a NECESSARY
 condition of edge_equal, including full circles and rational Beziers.
 No sampling, rounded geometry equality or relaxed tolerance is used.
 """
 from collections import defaultdict
 from itertools import product
 from math import floor
 def anchor(d):
  if d[0] in ('point','line'):return d[1]
  if d[0]=='circle':return d[3]
  if d[0]=='bezier' and d[1]:return d[1][0][0][0]
  return None
 buckets=defaultdict(list);unindexed=[]
 for j,d in enumerate(right):
  p=anchor(d)
  if p is None or not np.isfinite(p).all():unindexed.append(j);continue
  buckets[(d[0],*(floor(float(v)/tol) for v in p))].append(j)
 options=[]
 for d in left:
  p=anchor(d)
  if p is None or not np.isfinite(p).all():candidates=range(len(right))
  else:
   cell=tuple(floor(float(v)/tol) for v in p);candidates=list(unindexed)
   for delta in product((-1,0,1),repeat=3):
    candidates.extend(buckets.get((d[0],*(cell[k]+delta[k] for k in range(3))),()))
  options.append([j for j in sorted(candidates) if edge_equal(d,right[j],tol)])
 return options

def prove(a,b,owner,face_data,tolerance):
 """Only for already validated solids; require all surfaces and boundary wires."""
 try:
  fa=items(a,TopAbs_FACE,TopoDS.Face_s);fb=items(b,TopAbs_FACE,TopoDS.Face_s);tol=tolerance/8
  if len(fa)!=len(fb) or len(owner)!=len(fa):return False
  cache={}
  def data(e):
   key=(hash(e),int(e.Orientation()))
   for saved,d in cache.get(key,()):
    if saved.IsEqual(e):return d
   d=edge_data(e);cache.setdefault(key,[]).append((e,d));return d
  def wires_equal(x,y):
   ex=items(x,TopAbs_EDGE,TopoDS.Edge_s);ey=items(y,TopAbs_EDGE,TopoDS.Edge_s)
   if len(ex)!=len(ey) or not ex:return False
   dx=[data(e) for e in ex];dy=[data(e) for e in ey]
   return perfect(edge_options(dx,dy,tol))
  for j,i in owner.items():
   if not surface_equal(fa[i],fb[j],face_data[i][4],tol):return False
   wa=items(fa[i],TopAbs_WIRE,TopoDS.Wire_s);wb=items(fb[j],TopAbs_WIRE,TopoDS.Wire_s)
   if len(wa)!=len(wb) or not wa:return False
   if not perfect([[k for k,y in enumerate(wb) if wires_equal(x,y)] for x in wa]):return False
  return True
 except Exception:return False
