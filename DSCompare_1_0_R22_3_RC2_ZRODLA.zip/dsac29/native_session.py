"""Scoped, recyclable world-proof worker. No result survives an analysis.

Only transport is reused. Each request reloads its own B-Rep and runs the same
proof. A crash, timeout or malformed answer aborts and destroys the worker.
"""
from contextlib import contextmanager
from contextvars import ContextVar
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

_current = ContextVar('dscompare_world_session', default=None)

def current():
    return _current.get()

class WorldSession:
    def __init__(self, max_requests=32):
        self.max_requests=max_requests
        self.process=None
        self.directory=None
        self.sequence=0
        self.starts=0

    def close(self):
        if self.process is not None:
            if self.process.poll() is None:
                self.process.terminate()
                try:self.process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    self.process.kill();self.process.wait()
            self.process=None
        if self.directory is not None:
            self.directory.cleanup();self.directory=None

    def _start(self):
        self.close()
        self.directory=tempfile.TemporaryDirectory(prefix='dscompare_world_session_')
        root=Path(self.directory.name)
        request=root/'session.json'
        request.write_text(json.dumps({'operation':'world_session','directory':str(root)}),encoding='utf-8')
        argv=([sys.executable,'--native-brep-compare'] if getattr(sys,'frozen',False)
              else [sys.executable,'-m','dsac29.native_guard'])
        self.process=subprocess.Popen([*argv,str(request),str(root/'unused.json')],
            stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        self.sequence=0;self.starts+=1

    def execute(self, request, reply, timeout_s):
        from .native_guard import NativeGeometryFailure
        if self.process is None or self.sequence>=self.max_requests:
            self._start()
        # A dead worker is a failed proof, never an excuse to retry as SAME.
        if self.process.poll() is not None:
            code=self.process.returncode;self.close()
            raise NativeGeometryFailure(f'Awaria procesu weryfikacji STEP: {code}')
        self.sequence+=1
        root=Path(self.directory.name)
        command=root/'command.json'
        partial=root/'command.partial'
        partial.write_text(json.dumps({'sequence':self.sequence,'request':str(request),'reply':str(reply)}),encoding='utf-8')
        partial.replace(command)
        started=time.monotonic()
        try:
            while not Path(reply).exists():
                code=self.process.poll()
                if code is not None:
                    raise NativeGeometryFailure(f'Awaria procesu weryfikacji STEP: {code}')
                if time.monotonic()-started>=timeout_s:
                    raise NativeGeometryFailure('Timeout odizolowanej weryfikacji STEP — analiza niekompletna')
                time.sleep(.01)
        except BaseException:
            self.close();raise

@contextmanager
def world_session(enabled=True):
    existing=current()
    if not enabled or existing is not None:
        yield existing
        return
    session=WorldSession();token=_current.set(session)
    try:yield session
    finally:
        _current.reset(token);session.close()

def serve(directory):
    from .native_guard import worker
    command=Path(directory)/'command.json';last=0
    while True:
        try:payload=json.loads(command.read_text(encoding='utf-8'))
        except FileNotFoundError:
            time.sleep(.01);continue
        if payload['sequence']<=last:
            time.sleep(.01);continue
        worker(payload['request'],payload['reply'])
        last=payload['sequence']
