"""Revision workspace: empty sessions, two themes, static geometry thumbnails."""
import json,sys
from pathlib import Path
from PySide6.QtCore import Qt,QSize,QPointF
from PySide6.QtGui import QColor,QPainter,QPen,QIcon,QPixmap,QGuiApplication
from PySide6.QtWidgets import (QApplication,QWidget,QFrame,QLabel,QPushButton,QLineEdit,
 QVBoxLayout,QHBoxLayout,QGridLayout,QStackedWidget,QComboBox,QCheckBox,QSizePolicy,
 QProgressBar,QPlainTextEdit,QHeaderView,QStyledItemDelegate,QStyle,QAbstractItemView)
from .gui45 import Window as BaseWindow,FileCard as BaseFileCard,button,table,icon as base_icon

def icon(key):
 pix=base_icon(key).pixmap(48,48);paint=QPainter(pix);paint.setCompositionMode(QPainter.CompositionMode_SourceIn);paint.fillRect(pix.rect(),QColor('#4b85ff'));paint.end();return QIcon(pix)

PALETTES={
 'Jasny':dict(bg='#f4f7fc',card='#ffffff',ink='#17253d',muted='#52647e',line='#b9c9de',accent='#2163ef',soft='#e6efff',field='#eaf0f9',hover='#dce9fa',green='#168953',orange='#b85814',blue='#2463eb',purple='#8353cf'),
 'Ciemny':dict(bg='#101113',card='#1d1f22',ink='#edf0f2',muted='#a1a6ad',line='#41454a',accent='#c8d0d8',soft='#303338',field='#25282c',hover='#393e44',green='#4dca8b',orange='#ffac70',blue='#78abf7',purple='#c198ff')}

def theme_style(p):
 return '''
 QWidget {background:BG;color:INK;font-family:"Segoe UI";font-size:13px;}
 QFrame#topbar,QFrame#card,QFrame#metric,QFrame#export {background:CARD;border:1px solid LINE;border-radius:9px;}
 QFrame#topbar {border-radius:0px;border-left:0;border-right:0;border-top:0;border-bottom:2px solid LINE;}
 QFrame#card,QFrame#export {border:1px solid LINE;border-radius:12px;}
 QFrame#metric {border:1px solid LINE;border-radius:9px;}
 QLabel {background:transparent;}
 QLabel#heading {font-size:23px;font-weight:700;} QLabel#sub {color:MUTED;}
 QLabel#brand {font-size:21px;font-weight:700;} QLabel#section {font-size:16px;font-weight:600;}
 QPushButton {background:FIELD;border:1px solid LINE;border-radius:7px;padding:6px 10px;min-height:21px;}
 QPushButton:hover {background:HOVER;border:1px solid ACCENT;}
 QPushButton:pressed {background:SOFT;border-color:ACCENT;}
 QPushButton:focus {border-color:ACCENT;}
 QPushButton:disabled {color:MUTED;background:FIELD;border-color:LINE;}
 QPushButton#primary {background:ACCENT;color:PRIMINK;border:1px solid ACCENT;font-weight:700;padding:8px 13px;}
 QPushButton#primary:hover {background:PRIMHOVER;color:PRIMINK;border-color:PRIMHOVER;}
 QPushButton#primary:pressed {background:SOFT;color:INK;}
 QPushButton#primary:disabled {background:SOFT;color:MUTED;border-color:LINE;}
 QPushButton#nav {background:transparent;border:1px solid transparent;border-radius:7px;padding:8px 14px;}
 QPushButton#nav:hover {background:HOVER;border-color:LINE;}
 QPushButton#nav:checked {background:SOFT;color:INK;border-bottom:2px solid ACCENT;}
 QPushButton#theme-toggle {background:FIELD;border:1px solid LINE;border-radius:19px;padding:2px;min-width:35px;max-width:35px;min-height:34px;max-height:34px;}
 QPushButton#theme-toggle:hover {background:HOVER;border-color:ACCENT;}
 QPushButton#filter {padding:5px 8px;} QPushButton#filter:hover {background:HOVER;border-color:ACCENT;} QPushButton#filter:checked {background:SOFT;color:INK;border-color:ACCENT;}
 QLineEdit,QDoubleSpinBox,QSpinBox,QComboBox {background:FIELD;color:INK;border:1px solid LINE;border-radius:6px;padding:5px;min-height:19px;}
 QLineEdit:focus {border-color:ACCENT;}
 QStackedWidget {background:BG;}
 QTableWidget {background:CARD;alternate-background-color:FIELD;border:1px solid LINE;border-radius:7px;gridline-color:LINE;selection-background-color:SOFT;selection-color:INK;}
 QHeaderView::section {background:FIELD;color:INK;font-weight:600;padding:7px;border:0;border-bottom:1px solid LINE;}
 QPlainTextEdit {background:FIELD;border:1px solid LINE;border-radius:6px;color:MUTED;}
 QCheckBox {spacing:7px;padding:3px;} QProgressBar {border:0;background:LINE;border-radius:2px;max-height:4px;} QProgressBar::chunk {background:ACCENT;}
 QToolTip {background:CARD;color:INK;border:1px solid LINE;}
 '''.replace('PRIMHOVER',('#f5f7fa' if p['bg']=='#101113' else '#164fd3')).replace('PRIMINK',('#151719' if p['bg']=='#101113' else '#ffffff')).replace('BG',p['bg']).replace('CARD',p['card']).replace('INK',p['ink']).replace('MUTED',p['muted']).replace('LINE',p['line']).replace('ACCENT',p['accent']).replace('SOFT',p['soft']).replace('FIELD',p['field']).replace('HOVER',p['hover'])

def theme_icon(dark, stroke):
 """Native crisp moon/sun vector, avoiding font-dependent glyphs or emoji."""
 from PySide6.QtGui import QPainterPath
 pix=QPixmap(48,48);pix.fill(Qt.transparent)
 painter=QPainter(pix);painter.setRenderHint(QPainter.Antialiasing)
 pen=QPen(QColor(stroke),3.0);pen.setCapStyle(Qt.RoundCap);painter.setPen(pen)
 if dark:
  # Current dark theme: display sun to switch to light.
  painter.drawEllipse(17,17,14,14)
  for x1,y1,x2,y2 in [(24,5,24,11),(24,37,24,43),(5,24,11,24),(37,24,43,24),
                      (10.5,10.5,14.5,14.5),(33.5,33.5,37.5,37.5),
                      (10.5,37.5,14.5,33.5),(33.5,14.5,37.5,10.5)]:
   painter.drawLine(QPointF(x1,y1),QPointF(x2,y2))
 else:
  # Current light theme: display crescent to switch to dark.
  path=QPainterPath();path.moveTo(30,8);path.cubicTo(13,10,9,34,25,39)
  path.cubicTo(34,41,41,35,42,29);path.cubicTo(26,34,16,21,30,8)
  painter.setPen(Qt.NoPen);painter.setBrush(QColor(stroke));painter.drawPath(path)
 painter.end();return QIcon(pix)

class Thumbnail(QWidget):
 def __init__(self):
  super().__init__();self.lines=[];self.setMinimumSize(105,82);self.setMaximumWidth(155);self.ink='#7387a3'
 def set_data(self,data):self.lines=data.get('lines',[]);self.update()
 def paintEvent(self,event):
  p=QPainter(self);p.setRenderHint(QPainter.Antialiasing);p.setPen(QPen(QColor(self.ink),.85))
  if not self.lines:
   p.drawText(self.rect(),Qt.AlignCenter,'Miniatura modelu\npo analizie');return
  points=[xy for line in self.lines for xy in line];xs=[xy[0] for xy in points];ys=[xy[1] for xy in points]
  xmin,xmax,ymin,ymax=min(xs),max(xs),min(ys),max(ys);scale=min((self.width()-16)/max(xmax-xmin,.001),(self.height()-16)/max(ymax-ymin,.001))
  cx=(xmin+xmax)/2;cy=(ymin+ymax)/2
  for line in self.lines:
   for a,b in zip(line,line[1:]):
    p.drawLine(QPointF((a[0]-cx)*scale+self.width()/2,(a[1]-cy)*scale+self.height()/2),QPointF((b[0]-cx)*scale+self.width()/2,(b[1]-cy)*scale+self.height()/2))

class FileCard(BaseFileCard):
 def __init__(self,title,subtitle):
  QFrame.__init__(self);self.setObjectName('card');self.setAcceptDrops(True)
  row=QHBoxLayout(self);row.setContentsMargins(12,9,12,9);row.setSpacing(8);col=QVBoxLayout();col.setSpacing(4)
  heading=QLabel(title);heading.setObjectName('section');col.addWidget(heading)
  self.path=QLineEdit();self.path.setAcceptDrops(False);self.path.setPlaceholderText('Wybierz STEP / STP lub Z3…');self.path.textChanged.connect(self.changed.emit);col.addWidget(self.path)
  self.caption=QLabel('STEP / STP · Z3 wymaga eksportu do STEP');self.caption.setObjectName('sub');col.addWidget(self.caption)
  choose=button('Wybierz plik',self.choose);col.addWidget(choose,0,Qt.AlignLeft);row.addLayout(col,1)
  self.thumbnail=Thumbnail();row.addWidget(self.thumbnail,1)
  self.path.textChanged.connect(self.clear_preview)
 def clear_preview(self):self.thumbnail.set_data({});self.caption.setText('STEP / STP · Z3 wymaga eksportu do STEP')

class StatusDelegate(QStyledItemDelegate):
 def paint(self,painter,option,index):
  painter.save()
  status=index.data(Qt.UserRole);key={'SAME':'green','ADDED':'blue','REMOVED':'orange','UNCERTAIN':'orange'}.get(status,'purple')
  win=self.parent().window();palette=PALETTES.get(win.theme.currentText(),PALETTES['Jasny']);color=QColor(palette[key]);background=QColor(color);background.setAlpha(28)
  if option.state & QStyle.State_Selected:painter.fillRect(option.rect,QColor(palette['soft']))
  rect=option.rect.adjusted(6,5,-6,-5);painter.setRenderHint(QPainter.Antialiasing);painter.setPen(Qt.NoPen);painter.setBrush(background);painter.drawRoundedRect(rect,5,5);painter.setPen(color);painter.drawText(rect,Qt.AlignCenter,index.data());painter.restore()

class Window(BaseWindow):
 generate_thumbnails=True
 def __init__(self,a='',b=''):
  super().__init__(a,b)
  self.setWindowTitle('DS Compare 4.6 R5 — porównanie rewizji')
  screen=QGuiApplication.primaryScreen();geo=screen.availableGeometry() if screen else None
  sw=geo.width() if geo else 1366;sh=geo.height() if geo else 768
  self.compact=(sh<880 or sw<1320)
  self.setMinimumSize(min(950,max(760,sw-12)),min(600,max(520,sh-12)))
  self.resize(min(1450,max(760,sw-24)),min(910,max(520,sh-24)))
  old=self.takeCentralWidget();self.stack.setParent(None)
  central=QWidget();layout=QVBoxLayout(central);layout.setContentsMargins(0,0,0,0);layout.setSpacing(0)
  bar=QFrame();bar.setObjectName('topbar');bl=QHBoxLayout(bar);bl.setContentsMargins(16,5,16,5)
  brand=QLabel('DS  Compare');brand.setObjectName('brand');bl.addWidget(brand);bl.addStretch()
  for key,label in [('compare','Porównanie'),('mass','Masa części'),('settings','Ustawienia')]:
   bnav=self.nav[key];bnav.setParent(bar);bnav.setText(label);bnav.setIconSize(QSize(22,22));bl.addWidget(bnav)
  bl.addStretch()
  # Theme selection is now a single click sun/moon switch, no dropdown.
  self.theme_quick=self.theme  # invisible state holder, compatibility with settings
  self.theme_button=QPushButton();self.theme_button.setObjectName('theme-toggle')
  self.theme_button.setAccessibleName('Przełącz motyw jasny lub ciemny')
  self.theme_button.clicked.connect(self.toggle_theme)
  bl.addWidget(self.theme_button)
  # No fixed-size workspace / no outer scroll area: page resizes with monitor.
  self.stack.setMinimumSize(0,0);self.stack.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding)
  layout.addWidget(bar);layout.addWidget(self.stack,1);self.setCentralWidget(central);old.deleteLater()
  for pg in self.pages.values():
   pg.layout().setContentsMargins(14,9,14,9);pg.layout().setSpacing(5 if self.compact else 9)
  self._fit_layout_to_monitor()
  self.apply_theme(self.theme.currentText());self.navigate('compare')
  for card in (self.a,self.b):card.path.textChanged.connect(self.invalidate_comparison)
 def _fit_layout_to_monitor(self):
  # Keep all controls inside the main window; wheel scrolling stays available
  # inside long result tables, without visible scroll bars.
  for key in ('compare','mass','settings'):
   pg=self.pages[key]
   if self.compact:pg.layout().setSpacing(4)
  for card in (self.a,self.b):
   card.thumbnail.setMinimumSize(94,68) if self.compact else None
   card.thumbnail.setMaximumWidth(132 if self.compact else 155)
  self.compare_table.setMinimumHeight(95)
  self.compare_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  self.compare_table.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  self.compare_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
  self.compare_table.verticalHeader().setDefaultSectionSize(28 if self.compact else 32)
  self.mass_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  self.mass_table.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  self.mass_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
  self.log.setMaximumHeight(28 if self.compact else 38)
  self.log.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  self.mass_log.setMaximumHeight(40 if self.compact else 70)
  self.mass_log.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
  self.export_box.setMinimumHeight(0)
  self.export_box.setMaximumWidth(257 if self.compact else 283)
  self.export_box.setMinimumWidth(235 if self.compact else 265)
  if self.compact:
   self.grouping_hint.hide()
   self.compare_description.hide()
   self.settings_note.setText('Tolerancja wpływa na dopasowanie B-Rep. Wyłączone wyrównanie pozwala wykrywać przesunięcia. Przezroczystość STEP zależy też od importera ZW3D.')

 def create_settings(self):
  super().create_settings()
  self.settings_note=self.pages['settings'].findChildren(QLabel)[-1]
  self.theme=QComboBox(self);self.theme.addItems(PALETTES);self.theme.setCurrentText(str(self.store.value('theme46','Jasny')))
  self.theme.hide()  # no selector visible anywhere; keep QSettings and existing API
  self.theme.currentTextChanged.connect(self.apply_theme)
 def toggle_theme(self):
  self.theme.setCurrentText('Ciemny' if self.theme.currentText()=='Jasny' else 'Jasny')
 def apply_theme(self,name):
  p=PALETTES.get(name,PALETTES['Jasny']);self.setStyleSheet(theme_style(p));self.store.setValue('theme46',name)
  if hasattr(self,'theme_quick'):
   self.theme_quick.blockSignals(True);self.theme_quick.setCurrentText(name);self.theme_quick.blockSignals(False)
  if hasattr(self,'theme_button'):
   self.theme_button.setText('');self.theme_button.setIcon(theme_icon(name=='Ciemny',p['ink']));self.theme_button.setIconSize(QSize(23,23))
   self.theme_button.setToolTip('Włącz motyw ciemny' if name=='Jasny' else 'Włącz motyw jasny')
  for key,b in self.nav.items():b.setIcon(icon(key))
  for card in [getattr(self,'a',None),getattr(self,'b',None)]:
   if card:card.thumbnail.ink=p['muted'];card.thumbnail.update()
  if hasattr(self,'metrics'):
   for label,key in zip(self.metrics,('green','blue','purple','blue','orange')):label.setStyleSheet(f'font-size:28px;font-weight:700;color:{p[key]}')
 def create_compare(self):
  self.filter_status='ALL';self.metrics=[]
  lay=self.page('compare','Porównanie rewizji','Porównaj modele STEP i otwórz wynik w ZW3D.');lay.setSpacing(7)
  self.compare_description=self.pages['compare'].findChild(QLabel,'sub')
  row=QHBoxLayout();self.a=FileCard('A   Stara rewizja','');self.b=FileCard('B   Nowa rewizja','');row.addWidget(self.a,1);row.addWidget(button('⇄',self.swap));row.addWidget(self.b,1);lay.addLayout(row)
  row=QHBoxLayout();self.run_compare=button('Porównaj modele',lambda:self.start('compare'),True);row.addWidget(self.run_compare)
  self.cancel_compare=button('Anuluj',self.cancel);self.cancel_compare.setEnabled(False);row.addWidget(self.cancel_compare)
  self.compare_summary=QLabel('Wybierz dwa modele, aby rozpocząć.');self.compare_summary.setWordWrap(True);row.addWidget(self.compare_summary,1);lay.addLayout(row)
  metricrow=QHBoxLayout()
  for title in ('Bez zmian','Zmienione','Przesunięte','Nowe','Stare'):
   card=QFrame();card.setObjectName('metric');ml=QHBoxLayout(card);ml.setContentsMargins(10,6,10,6);count=QLabel('—');ml.addWidget(count);ml.addWidget(QLabel(title));ml.addStretch();self.metrics.append(count);metricrow.addWidget(card,1)
  lay.addLayout(metricrow)
  body=QHBoxLayout();left=QVBoxLayout();head=QHBoxLayout();title=QLabel('Zmiany w rewizji');title.setObjectName('section');head.addWidget(title);head.addStretch()
  self.search=QLineEdit();self.search.setPlaceholderText('Szukaj części…');self.search.textChanged.connect(self.filter_results);head.addWidget(self.search);left.addLayout(head)
  filters=QHBoxLayout();self.filter_buttons={}
  for key,label in [('ALL','Wszystkie'),('SAME','Bez zmian'),('CHANGES','Zmienione'),('MOVED','Przesunięte'),('ADDED','Nowe'),('REMOVED','Stare')]:
   b=button(label,lambda checked=False,k=key:self.select_filter(k));b.setObjectName('filter');b.setCheckable(True);b.setChecked(key=='ALL');self.filter_buttons[key]=b;filters.addWidget(b)
  filters.addStretch();left.addLayout(filters)
  self.only_changes=QCheckBox('Ukryj pozycje bez zmian');self.only_changes.setChecked(True);self.only_changes.toggled.connect(self.filter_results);left.addWidget(self.only_changes)
  self.compare_table=table(['Status','Stara rewizja A','Nowa rewizja B','Szczegóły']);self.compare_table.setItemDelegateForColumn(0,StatusDelegate(self.compare_table));self.compare_table.verticalHeader().setDefaultSectionSize(36);left.addWidget(self.compare_table,1);body.addLayout(left,1)
  export=QFrame();self.export_box=export;export.setObjectName('export');el=QVBoxLayout(export);el.setContentsMargins(11,9,11,9);el.setSpacing(4)
  h=QLabel('Wynik porównania');h.setObjectName('section');el.addWidget(h)
  self.export_name=QLabel('Kolorowy model STEP');self.export_name.setWordWrap(True);el.addWidget(self.export_name)
  self.legend=QLabel('● Bez zmian — zielony\n● Zmienione — niebieski\n● Przesunięte — fioletowy\n● Stare — pomarańczowy');self.legend.setWordWrap(True);el.addWidget(self.legend)
  grouping=QLabel('Eksport STEP: podzłożenia według statusu; widoczność grup zależy od importera ZW3D.');self.grouping_hint=grouping;grouping.setObjectName('sub');grouping.setWordWrap(True);el.addWidget(grouping);el.addStretch(1)
  self.compare_open={}
  for text,filename in [('Otwórz STEP','POROWNANIE_KOLORY.step'),('Raport zmian','RAPORT.html'),('Eksport CSV','ZMIANY.csv'),('Pokaż folder wyników','')]:
   b=button(text,lambda checked=False,f=filename:self.open_result('compare',f),filename.endswith('.step'));b.setEnabled(False);self.compare_open[filename]=b;el.addWidget(b)
  self.compare_open['POROWNANIE_KOLORY.step'].setToolTip('Otwiera plik w domyślnej aplikacji Windows dla STEP.');body.addWidget(export);lay.addLayout(body,1)
  self.progress=QProgressBar();self.progress.setRange(0,1);self.progress.setValue(0);self.progress.setTextVisible(False);lay.addWidget(self.progress)
  self.log=QPlainTextEdit();self.log.setReadOnly(True);self.log.setMaximumHeight(35);self.log.document().setMaximumBlockCount(150);lay.addWidget(self.log)
  foot=QHBoxLayout();label=QLabel('Każdy start programu otwiera pustą sesję.');label.setObjectName('sub');foot.addWidget(label);foot.addStretch();self.reset_button=button('Nowe porównanie',self.reset_session);foot.addWidget(self.reset_button);lay.addLayout(foot)
  self.output=QLineEdit(str(self.store.value('output',str(Path.home()/'Documents'/'DSCompare'))))
  outputrow=QWidget();ol=QHBoxLayout(outputrow);ol.setContentsMargins(0,0,0,0);ol.addWidget(self.output);ol.addWidget(button('Wybierz folder',self.choose_output))
  self.pages['settings'].findChild(QFrame,'card').layout().addRow('Folder zapisu wyników',outputrow)
 def create_mass(self):
  super().create_mass();self.mass_summary.setText('Wybierz model. Folder zapisu oraz gęstość ustawisz w Ustawieniach.')
 def select_filter(self,key):
  self.filter_status=key
  for k,b in self.filter_buttons.items():b.setChecked(k==key)
  self.filter_results()
 def filter_results(self,*args):
  if not hasattr(self,'compare_table'):return
  query=self.search.text().casefold();wanted=getattr(self,'filter_status','ALL')
  for i in range(self.compare_table.rowCount()):
   status=self.row_statuses[i];text=' '.join(self.compare_table.item(i,j).text() for j in range(4))
   allowed=wanted=='ALL' or wanted==status or wanted=='CHANGES' and status=='CHANGED' or wanted=='SAME' and status in ('SAME','RENAMED')
   self.compare_table.setRowHidden(i,not allowed or query not in text.casefold() or self.only_changes.isChecked() and status=='SAME')
 def start(self,kind):
  super().start(kind)
  if hasattr(self,'reset_button'):self.reset_button.setEnabled(self.process is None)
  if self.process is not None:self.compare_summary.setText('Analiza trwa…' if kind=='compare' else 'Obliczanie masy…')
 def finished(self,code,status):
  super().finished(code,status);self.reset_button.setEnabled(True)
  if self.was_cancelled:self.compare_summary.setText('Analiza anulowana.')
  elif code:self.compare_summary.setText('Analiza nie została ukończona — sprawdź komunikat błędu.')
 def load_result(self,kind,folder):
  super().load_result(kind,folder)
  if kind!='compare':return
  for i,status in enumerate(self.row_statuses):self.compare_table.item(i,0).setData(Qt.UserRole,status)
  folder=Path(folder);s=json.loads((folder/'PODSUMOWANIE.json').read_text(encoding='utf-8'));c=s['statuses']
  values=[c.get('SAME',0)+c.get('RENAMED',0),c.get('CHANGED',0),c.get('MOVED',0),c.get('ADDED',0),c.get('REMOVED',0)]
  for label,value in zip(self.metrics,values):label.setText(str(value))
  message=f"Porównanie gotowe · A: {s['solids_A']} → B: {s['solids_B']} · Przesunięte: {c.get('MOVED',0)}"
  if s.get('step_export_error'):message+=' · Błąd eksportu STEP — raport dostępny'
  self.compare_summary.setText(message);self.export_name.setText('POROWNANIE_KOLORY.step')
  old=s.get('colors_hex',{}).get('REMOVED','#ff610f');alpha=round((1-s.get('old_alpha',.4))*100)
  self.legend.setText(f'<span style="color:#24aa67">● Bez zmian</span><br><span style="color:#4b85ff">● Zmienione / nowe</span><br><span style="color:#ab73ec">● Przesunięte</span><br><span style="color:{old}">● Stare · {alpha}% przezr.</span>')
  for role,card in [('A',self.a),('B',self.b)]:
   file=folder/f'MINIATURA_{role}.json'
   if file.exists():
    data=json.loads(file.read_text());card.thumbnail.set_data(data);card.caption.setText(f"{s['solids_'+role]} części · miniatura krawędziowa"+(' (uproszczona)' if data.get('truncated') else ''))
 def invalidate_comparison(self,*args):
  if self.process is not None or 'compare' not in self.results:return
  self.results.pop('compare');self.compare_table.setRowCount(0);self.row_statuses=[]
  for b in self.compare_open.values():b.setEnabled(False)
  for label in self.metrics:label.setText('—')
  self.compare_summary.setText('Modele zmienione — uruchom nowe porównanie.');self.export_name.setText('Kolorowy model STEP')
 def reset_session(self):
  if self.process is not None:return
  for card in (self.a,self.b,self.mass_file):card.path.clear()
  self.results.clear();self.compare_table.setRowCount(0);self.mass_table.setRowCount(0);self.row_statuses=[]
  for b in list(self.compare_open.values())+list(self.mass_open.values()):b.setEnabled(False)
  for label in self.metrics:label.setText('—')
  self.search.clear();self.select_filter('ALL');self.only_changes.setChecked(True);self.log.clear();self.mass_log.clear();self.progress.setValue(0);self.mass_progress.setValue(0)
  self.compare_summary.setText('Wybierz dwa modele, aby rozpocząć.');self.mass_summary.setText('Wybierz model do obliczenia masy.');self.export_name.setText('Kolorowy model STEP');self.navigate('compare')

def main(a='',b=''):
 app=QApplication.instance() or QApplication(sys.argv);app.setStyle('Fusion');w=Window(a,b);w.show();return app.exec()
