"""Exercise the real frozen GUI path: file chooser and QProcess to finished compare."""
import json,os,time,sys
from pathlib import Path
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication,QFileDialog
from .gui46 import Window

def main(output):
    dest=Path(output).resolve();dest.mkdir(parents=True,exist_ok=True)
    app=QApplication.instance() or QApplication([])
    app.setStyle('Fusion')
    w=Window();w.show();app.processEvents()
    sample=(Path(sys.executable).resolve().parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parents[1])/'samples'
    # On the actual frozen EXE, file selection must never invoke a native COM dialog.
    modal=[]
    def dismiss_picker():
        candidates=[x for x in app.topLevelWidgets() if isinstance(x,QFileDialog)]
        if candidates:
            d=candidates[0]
            modal.append(bool(d.testOption(QFileDialog.DontUseNativeDialog)))
            d.reject()
    QTimer.singleShot(250,dismiss_picker)
    w.a.choose();app.processEvents()
    assert modal==[True],f'Unexpected dialog type: {modal}'
    from .gui45 import file_chooser_shortcuts
    assert w.a.quick_menu.actions(), 'Quick access menu is empty'
    favorites=[action.text() for action in w.a.quick_menu.actions()]
    for p in file_chooser_shortcuts()[:3]:
        assert any(str(p) in text for text in favorites), f'Missing quick access folder: {p}'
    w.a.path.setText(str(sample/'MODEL_A.step'))
    w.b.path.setText(str(sample/'MODEL_B.step'))
    assert w.a.path.text().lower().endswith('.step')
    assert w.b.path.text().lower().endswith('.step')
    w.output.setText(str(dest));w.run_compare.click()
    deadline=time.monotonic()+150
    while w.process is not None and time.monotonic()<deadline:
        app.processEvents();time.sleep(.03)
    assert w.process is None,'Compare worker stalled'
    assert 'compare' in w.results, ('UI did not load compare result: '+w.log.toPlainText()[-1500:])
    assert w.isVisible(), 'UI closed while comparing'
    assert (w.results['compare']/'PODSUMOWANIE.json').exists()
    assert (w.results['compare']/'POROWNANIE_KOLORY.step').exists()
    assert w.compare_table.rowCount()>0
    w.close()
    (dest/'UI_INTERACTIONS_PASS.json').write_text(json.dumps({
        'file_picker_non_native':True,'quick_access_places':favorites,'selected_step':True,
        'compare_clicked':True,'worker_finished':True,'main_window_alive':True,
        'model_file_type':'.step','native_z3':'requires STEP export'
    },indent=2),encoding='utf8')
    return 0
