// DS Assembly 2019 V15 - ZW3D 2019 x64 portable add-in
// V9 workflow: detect equal solids -> create ONE MASTER per group with cvxPartGeomExport(AddComponent=1)
// -> erase original master body -> copy the ready MASTER component with cvxPartCopyTransform -> erase duplicate source bodies.
// Goal: A/A/B/B -> exactly 2 part definitions and 4 component occurrences.
// No CRT / no zw3d.lib import: ZW3D API resolved from already loaded modules.

static unsigned long long __readgsqword(unsigned long){unsigned long long p;__asm__("movq %%gs:0x60,%0":"=r"(p));return p;}
extern "C" int _fltused = 0;

typedef char vxName[32];
typedef char vxPath[256];
typedef char vxLongName[256];

struct svxLimit { double min,max; };
struct svxBndBox { svxLimit X,Y,Z; };
struct svxPoint { double x,y,z; };
struct svxVector { double x,y,z; };
struct svxTriangle { svxPoint Pnt[3]; svxVector Normal; };
struct svxMatrix {
    char identity;
    double xx,yx,zx,xt;
    double xy,yy,zy,yt;
    double xz,yz,zz,zt;
};

enum evxNumType { VX_UNDEF=0, VX_NUM=1, VX_DST=2, VX_ANG=3, VX_MASS=4, VX_DENSITY=5, VX_AREA=6, VX_VOLUME=7, VX_MASS_MOMENT=8 };
enum evxPntType { VX_PNT3_ABS=0, VX_PNT3_ENT=1, VX_PNT3_ON=2, VX_PNT3_TO=3, VX_PNT3_MID=4, VX_PNT3_NUM=5, VX_PNT3_DST=6, VX_PNT3_ANG=7, VX_PNT3_TAN=8, VX_PNT3_FRAC=9, VX_PNT3_REL=10, VX_PNT3_DATA=11, VX_PNT3_ABS_COMP=12 };
enum evxResponse { VX_CANCEL=-1, VX_NO=0, VX_YES=1, VX_YES_ALL=2 };

struct svxData {
    char isPoint,isEntity,isNumber,isDirection,isText,isPntOnCrv,isEndPnt,isPntOnFace;
    int idEntity;
    int idParent;
    evxNumType NumType;
    double Num;
    evxPntType PntType;
    svxPoint Pnt;
    svxVector Dir;
    double Param[3];
    char Text[256];
};

struct svxCompData {
    vxPath Dir;
    vxLongName File;
    vxLongName Part;
    vxLongName Comp;
    svxMatrix Frame;
    int Anchor;
    int AutoRegen;
    int AutoDelete;
    int Copy;
    vxLongName CopyName;
    int Overwrite;
    vxLongName DestFile;
    int Align;
    svxData AlignData;
};

struct svxGeomExport {
    int numEnts;
    int *idEnts;
    vxLongName File;
    vxLongName Part;
    svxMatrix Frame;
    int Option;
    int AddComponent;
    int NoExportOp;
    int Unblank;
};

struct svxMassProp {
    double Density;
    double Area;
    double Volume;
    double Mass;
    svxPoint Center;
    svxVector Axis[3];
    double Im[6];
    double Ip[3];
    double Rad[3];
};

typedef int  (*PFN_cvxCmdFunc)(const vxName, void*, double);
typedef int  (*PFN_cvxCmdFuncUnload)(const vxName);
typedef void (*PFN_cvxMsgDisp)(char*);
typedef void (*PFN_cvxMemFree)(void**);
typedef int  (*PFN_cvxPartInqShapes)(vxLongName,vxLongName,int*,int**);
typedef int  (*PFN_cvxPartInqShapeMass)(int,double,svxMassProp*);
typedef int  (*PFN_cvxPartInqShapeFaces)(int,int*,int**);
typedef int  (*PFN_cvxPartInqShapeEdges)(int,int*,int**);
typedef int  (*PFN_cvxPartInqFaceFacets)(int,int*,svxTriangle**);
typedef int  (*PFN_cvxPartInqShapeBox)(int,svxMatrix*,svxBndBox*);
typedef int  (*PFN_cvxPartGeomExport)(svxGeomExport*);
typedef int  (*PFN_cvxCompInqPart)(int,char*,int,char*,int);
typedef int  (*PFN_cvxPartCopyTransform)(int,const svxMatrix*,int*);
typedef int (*PFN_displayFacets)(int,int*,int,int,double);
typedef int (*PFN_showEntity)(int,int,int*);
static PFN_displayFacets pDisplayFacets=0;static PFN_showEntity pShowEntity=0;
typedef int (*PFN_cvxCompIns)(svxCompData*,int*);
typedef void (*PFN_sdkPntTransform)(svxMatrix*,svxPoint*);
typedef void (*PFN_sdkMatInvert)(svxMatrix*,svxMatrix*);
typedef int (*PFN_faceProjection)(int,svxPoint*,double*,double*);
typedef int (*PFN_faceLocation)(int,double,double,int*);
static PFN_sdkPntTransform pSdkPnt=0;static PFN_sdkMatInvert pSdkInverse=0;
static PFN_faceProjection pFaceProjection=0;static PFN_faceLocation pFaceLocation=0;
typedef int (*PFN_cvxPntIsOn)(svxPoint*,int);
static PFN_cvxCompIns pCompIns=0;static PFN_cvxPntIsOn pPntIsOn=0;
typedef int  (*PFN_cvxPartErase)(int,int*);
typedef void (*PFN_cvxFileInqActive)(char*,int);
typedef int  (*PFN_cvxRootDel)(vxLongName);
typedef int  (*PFN_cvxEntNameSet)(int,const char*);
typedef int  (*PFN_cvxPartInqEntLabel)(int,int**);
typedef int  (*PFN_cvxPartInqEntByLabel)(int*,int,int*);
typedef int  (*PFN_cvxPartInqComps)(vxLongName,vxLongName,int*,int**);
typedef int  (*PFN_cvxEntMatrix)(int,svxMatrix*);
typedef int  (*PFN_cvxEntMatrixSet)(int,svxMatrix*);
typedef int  (*PFN_cvxRootId)(vxLongName,int*,int*);
typedef int  (*PFN_cvxHistBackup)(void);
typedef void (*PFN_cvxRootInqActive)(char*,int);

static PFN_cvxCmdFunc pCmdFunc=0; static PFN_cvxCmdFuncUnload pCmdFuncUnload=0;
static PFN_cvxMsgDisp pMsg=0; static PFN_cvxMemFree pMemFree=0;
static PFN_cvxPartInqShapes pShapes=0; static PFN_cvxPartInqShapeMass pMass=0;
static PFN_cvxPartInqShapeFaces pFaces=0; static PFN_cvxPartInqShapeEdges pEdges=0;
static PFN_cvxPartInqFaceFacets pFaceFacets=0; static PFN_cvxPartInqShapeBox pShapeBox=0;
static PFN_cvxPartGeomExport pGeomExport=0; static PFN_cvxCompInqPart pCompPart=0; static PFN_cvxPartCopyTransform pCopyTransform=0; static PFN_cvxPartErase pErase=0;
static PFN_cvxFileInqActive pFileActive=0; static PFN_cvxRootDel pRootDel=0; static PFN_cvxEntNameSet pNameSet=0;
static PFN_cvxPartInqEntLabel pEntLabel=0; static PFN_cvxPartInqEntByLabel pEntByLabel=0; static PFN_cvxPartInqComps pPartComps=0; static PFN_cvxEntMatrix pEntMatrix=0; static PFN_cvxEntMatrixSet pEntMatrixSet=0; static PFN_cvxRootId pRootId=0; static PFN_cvxHistBackup pHistBackup=0; static PFN_cvxRootInqActive pRootActive=0;

extern "C" void* memset(void* dst,int v,unsigned long long n){unsigned char*d=(unsigned char*)dst;for(unsigned long long i=0;i<n;++i)d[i]=(unsigned char)v;return dst;}
extern "C" void* memcpy(void* dst,const void* src,unsigned long long n){unsigned char*d=(unsigned char*)dst;const unsigned char*s=(const unsigned char*)src;for(unsigned long long i=0;i<n;++i)d[i]=s[i];return dst;}
static int streq(const char*a,const char*b){if(!a||!b)return 0;while(*a&&*b){if(*a!=*b)return 0;++a;++b;}return *a==*b;}
static void copystr(char*d,const char*s,int cap){if(!d||cap<1)return;int i=0;if(s)for(;i<cap-1&&s[i];++i)d[i]=s[i];d[i]=0;}
static double dabs(double x){return x<0?-x:x;}
static double dmax(double a,double b){return a>b?a:b;}
static double dsqrt(double x){if(x<=0)return 0;double r=x>1?x:1;for(int i=0;i<28;++i)r=.5*(r+x/r);return r;}
static double dotv(const svxVector&a,const svxVector&b){return a.x*b.x+a.y*b.y+a.z*b.z;}
static svxVector crossv(const svxVector&a,const svxVector&b){svxVector r={a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};return r;}
static svxVector negv(svxVector a){a.x=-a.x;a.y=-a.y;a.z=-a.z;return a;}
static int normv(svxVector&v){double l=dsqrt(dotv(v,v));if(l<1e-12)return 0;v.x/=l;v.y/=l;v.z/=l;return 1;}
static int nearv(double a,double b,double rel,double absTol){double d=dabs(a-b),s=dmax(dabs(a),dabs(b));return d<=dmax(absTol,rel*s);}

struct LIST_ENTRY_X { void* Flink; void* Blink; };
static void* exportInModule(unsigned char*base,const char*w){
    if(!base||base[0]!='M'||base[1]!='Z')return 0;unsigned int peoff=*(unsigned int*)(base+0x3c);unsigned char*nt=base+peoff;
    if(nt[0]!='P'||nt[1]!='E'||nt[2]!=0||nt[3]!=0)return 0;unsigned char*opt=nt+24;unsigned short magic=*(unsigned short*)opt;
    if(magic!=0x20b&&magic!=0x10b)return 0;unsigned int er=*(unsigned int*)(opt+(magic==0x20b?0x70:0x60));unsigned int es=*(unsigned int*)(opt+(magic==0x20b?0x74:0x64));if(!er)return 0;
    unsigned char*e=base+er;unsigned int nn=*(unsigned int*)(e+0x18),fr=*(unsigned int*)(e+0x1c),nr=*(unsigned int*)(e+0x20),orr=*(unsigned int*)(e+0x24);
    unsigned int*funcs=(unsigned int*)(base+fr);unsigned int*names=(unsigned int*)(base+nr);unsigned short*ords=(unsigned short*)(base+orr);
    for(unsigned int i=0;i<nn;++i){const char*nm=(const char*)(base+names[i]);if(streq(nm,w)){unsigned int rv=funcs[ords[i]];if(rv>=er&&rv<er+es)return 0;return(void*)(base+rv);}}
    return 0;
}
static void* findExport(const char*name){
#if defined(_M_X64) || defined(__x86_64__)
    unsigned char*peb=(unsigned char*)__readgsqword(0x60);if(!peb)return 0;unsigned char*ldr=*(unsigned char**)(peb+0x18);if(!ldr)return 0;
    LIST_ENTRY_X*head=(LIST_ENTRY_X*)(ldr+0x20);LIST_ENTRY_X*cur=(LIST_ENTRY_X*)head->Flink;int guard=0;
    while(cur&&cur!=head&&guard++<256){unsigned char*entry=(unsigned char*)cur-0x10;unsigned char*base=*(unsigned char**)(entry+0x30);void*p=exportInModule(base,name);if(p)return p;cur=(LIST_ENTRY_X*)cur->Flink;}
#endif
    return 0;
}
static void msg(const char*s){if(pMsg)pMsg((char*)s);}
static int resolveCoreApi(){pCmdFunc=(PFN_cvxCmdFunc)findExport("cvxCmdFunc");pCmdFuncUnload=(PFN_cvxCmdFuncUnload)findExport("cvxCmdFuncUnload");pMsg=(PFN_cvxMsgDisp)findExport("cvxMsgDisp");pMemFree=(PFN_cvxMemFree)findExport("cvxMemFree");return pCmdFunc&&pMsg&&pMemFree;}
static int appendStr(char*b,int&n,int cap,const char*s){if(!b||!s)return 0;while(*s&&n<cap-1)b[n++]=*s++;b[n]=0;return 1;}
static void appendInt(char*b,int&n,int cap,int v){if(v<0){if(n<cap-1)b[n++]='-';v=-v;}char t[16];int k=0;do{t[k++]=(char)('0'+(v%10));v/=10;}while(v&&k<15);while(k&&n<cap-1)b[n++]=t[--k];b[n]=0;}
static void appendLL(char*b,int&n,int cap,long long v){if(v<0){if(n<cap-1)b[n++]='-';v=-v;}char t[32];int k=0;do{t[k++]=(char)('0'+(v%10));v/=10;}while(v&&k<31);while(k&&n<cap-1)b[n++]=t[--k];b[n]=0;}
static void appendFixed2(char*b,int&n,int cap,double v){long long q=(long long)(v*100.0+(v>=0?0.5:-0.5));long long whole=q/100;long long frac=q<0?-(q%100):(q%100);appendLL(b,n,cap,whole);if(n<cap-1)b[n++]='.';if(frac<10&&n<cap-1)b[n++]='0';appendLL(b,n,cap,frac);b[n]=0;}
static int need(void**slot,const char*name){if(!*slot)*slot=findExport(name);if(!*slot){char b[180];int n=0;b[0]=0;appendStr(b,n,180,"DS Assembly V15: brak API ZW3D 2019: ");appendStr(b,n,180,name);msg(b);return 0;}return 1;}
static int resolveAssemblyApi(){
    if(!need((void**)&pShapes,"cvxPartInqShapes"))return 0;
    if(!need((void**)&pMass,"cvxPartInqShapeMass"))return 0;
    if(!need((void**)&pFaces,"cvxPartInqShapeFaces"))return 0;
    if(!need((void**)&pEdges,"cvxPartInqShapeEdges"))return 0;
    if(!need((void**)&pFaceFacets,"cvxPartInqFaceFacets"))return 0;
    if(!need((void**)&pShapeBox,"cvxPartInqShapeBox"))return 0;
    if(!need((void**)&pGeomExport,"cvxPartGeomExport"))return 0;
    if(!need((void**)&pCopyTransform,"cvxPartCopyTransform"))return 0;
    if(!need((void**)&pErase,"cvxPartErase"))return 0;
    if(!need((void**)&pFileActive,"cvxFileInqActive"))return 0;
    if(!need((void**)&pCompPart,"cvxCompInqPart"))return 0;
    if(!pRootDel)pRootDel=(PFN_cvxRootDel)findExport("cvxRootDel");
    if(!pNameSet)pNameSet=(PFN_cvxEntNameSet)findExport("cvxEntNameSet");
    if(!pEntLabel)pEntLabel=(PFN_cvxPartInqEntLabel)findExport("cvxPartInqEntLabel");
    if(!pEntByLabel)pEntByLabel=(PFN_cvxPartInqEntByLabel)findExport("cvxPartInqEntByLabel");
    if(!need((void**)&pPartComps,"cvxPartInqComps"))return 0;
    if(!need((void**)&pEntMatrix,"cvxEntMatrix"))return 0;
    if(!need((void**)&pEntMatrixSet,"cvxEntMatrixSet"))return 0;
    if(!need((void**)&pRootId,"cvxRootId"))return 0;
    if(!pHistBackup)pHistBackup=(PFN_cvxHistBackup)findExport("cvxHistBackup");
    if(!pRootActive)pRootActive=(PFN_cvxRootInqActive)findExport("cvxRootInqActive");
    return 1;
}

static void append2digits(char*d,int&n,int v){d[n++]=(char)('0'+((v/10)%10));d[n++]=(char)('0'+(v%10));d[n]=0;}
static void makeMasterBase(char*d,int g){copystr(d,"DSA15_PART_",256);int n=11;d[n++]=(char)('0'+((g/100)%10));d[n++]=(char)('0'+((g/10)%10));d[n++]=(char)('0'+(g%10));d[n]=0;}
static void makeOccName(char*d,int g,int j){copystr(d,"DSA15_PART_",256);int n=11;d[n++]=(char)('0'+((g/100)%10));d[n++]=(char)('0'+((g/10)%10));d[n++]=(char)('0'+(g%10));d[n++]='_';append2digits(d,n,j);}

#define MAX_SHAPES 256
#define MAX_FACES 512
#define MAX_LABEL 256
#define MAX_SAMPLES 384
struct ShapeInfo {int id;int label[MAX_LABEL];int hasLabel;svxMassProp mass;int faceCount;int edgeCount;double faceAreas[MAX_FACES];svxPoint faceCtr[MAX_FACES];svxVector faceNrm[MAX_FACES];int sampleCount;svxPoint samples[MAX_SAMPLES];svxMatrix frame;double axisLen[3];double axisSkew[3];};
struct Group {int count;int members[MAX_SHAPES];};
#define MAX_COMPS 2048
static ShapeInfo g_shapes[MAX_SHAPES];
static Group g_groups[MAX_SHAPES];
static ShapeInfo g_tmpShape;
static char g_partNames[MAX_SHAPES][256];
static int g_compBefore[MAX_COMPS];
static int g_compAfter[MAX_COMPS];
static double g_areaA[MAX_FACES];
static double g_areaB[MAX_FACES];

static void sortDouble(double*a,int n){for(int i=1;i<n;++i){double x=a[i];int j=i-1;while(j>=0&&a[j]>x){a[j+1]=a[j];--j;}a[j+1]=x;}}
static svxMatrix mkFrame(const svxPoint&o,const svxVector&x,const svxVector&y,const svxVector&z){svxMatrix m;memset(&m,0,sizeof(m));m.identity=0;m.xx=x.x;m.yx=x.y;m.zx=x.z;m.xt=o.x;m.xy=y.x;m.yy=y.y;m.zy=y.z;m.yt=o.y;m.xz=z.x;m.yz=z.y;m.zz=z.z;m.zt=o.z;return m;}
static svxMatrix identityMatrix(){svxMatrix m;memset(&m,0,sizeof(m));m.identity=1;m.xx=m.yy=m.zz=1.0;return m;}
static svxMatrix rigidRelative(const svxMatrix&from,const svxMatrix&to){
    // D = TO * inverse(FROM), for orthonormal rigid frames.
    double A[3][3]={{from.xx,from.xy,from.xz},{from.yx,from.yy,from.yz},{from.zx,from.zy,from.zz}};
    double B[3][3]={{to.xx,to.xy,to.xz},{to.yx,to.yy,to.yz},{to.zx,to.zy,to.zz}};
    double R[3][3];
    for(int i=0;i<3;++i)for(int j=0;j<3;++j){R[i][j]=0;for(int k=0;k<3;++k)R[i][j]+=B[i][k]*A[j][k];}
    double of[3]={from.xt,from.yt,from.zt};double ot[3]={to.xt,to.yt,to.zt};double t[3];
    for(int i=0;i<3;++i)t[i]=ot[i]-(R[i][0]*of[0]+R[i][1]*of[1]+R[i][2]*of[2]);
    svxMatrix m;memset(&m,0,sizeof(m));m.identity=0;
    m.xx=R[0][0];m.xy=R[0][1];m.xz=R[0][2];m.xt=t[0];
    m.yx=R[1][0];m.yy=R[1][1];m.yz=R[1][2];m.yt=t[1];
    m.zx=R[2][0];m.zy=R[2][1];m.zz=R[2][2];m.zt=t[2];
    return m;
}
static svxMatrix rigidMul(const svxMatrix&a,const svxMatrix&b){
    // C = A * B.
    double A[3][3]={{a.xx,a.xy,a.xz},{a.yx,a.yy,a.yz},{a.zx,a.zy,a.zz}};
    double B[3][3]={{b.xx,b.xy,b.xz},{b.yx,b.yy,b.yz},{b.zx,b.zy,b.zz}};
    double R[3][3];for(int i=0;i<3;++i)for(int j=0;j<3;++j){R[i][j]=0;for(int k=0;k<3;++k)R[i][j]+=A[i][k]*B[k][j];}
    double tb[3]={b.xt,b.yt,b.zt};double ta[3]={a.xt,a.yt,a.zt};double t[3];
    for(int i=0;i<3;++i)t[i]=A[i][0]*tb[0]+A[i][1]*tb[1]+A[i][2]*tb[2]+ta[i];
    svxMatrix m;memset(&m,0,sizeof(m));m.identity=0;
    m.xx=R[0][0];m.xy=R[0][1];m.xz=R[0][2];m.xt=t[0];
    m.yx=R[1][0];m.yy=R[1][1];m.yz=R[1][2];m.yt=t[1];
    m.zx=R[2][0];m.zy=R[2][1];m.zz=R[2][2];m.zt=t[2];
    return m;
}
static double triArea(const svxTriangle&t){svxVector a={t.Pnt[1].x-t.Pnt[0].x,t.Pnt[1].y-t.Pnt[0].y,t.Pnt[1].z-t.Pnt[0].z};svxVector b={t.Pnt[2].x-t.Pnt[0].x,t.Pnt[2].y-t.Pnt[0].y,t.Pnt[2].z-t.Pnt[0].z};svxVector c=crossv(a,b);return 0.5*dsqrt(dotv(c,c));}
static void addSample(svxPoint*pts,int&n,const svxPoint&p){
    if(n>=MAX_SAMPLES)return;
    for(int i=0;i<n;++i){double dx=pts[i].x-p.x,dy=pts[i].y-p.y,dz=pts[i].z-p.z;if(dx*dx+dy*dy+dz*dz<1e-12)return;}
    pts[n++]=p;
}
static double faceGeom2019(int idFace,svxPoint&ctr,svxVector&nrm,svxPoint*samplePts,int&sampleCount){
    ctr.x=ctr.y=ctr.z=0;nrm.x=nrm.y=nrm.z=0;
    int n=0;svxTriangle*tris=0;if(pFaceFacets(idFace,&n,&tris)||n<=0||!tris){if(tris)pMemFree((void**)&tris);return 0;}
    double a=0;int faceSamples=0;
    for(int i=0;i<n;++i){
        double ar=triArea(tris[i]);if(ar<=0)continue;
        svxPoint q={(tris[i].Pnt[0].x+tris[i].Pnt[1].x+tris[i].Pnt[2].x)/3.0,(tris[i].Pnt[0].y+tris[i].Pnt[1].y+tris[i].Pnt[2].y)/3.0,(tris[i].Pnt[0].z+tris[i].Pnt[1].z+tris[i].Pnt[2].z)/3.0};
        ctr.x+=ar*q.x;ctr.y+=ar*q.y;ctr.z+=ar*q.z;nrm.x+=ar*tris[i].Normal.x;nrm.y+=ar*tris[i].Normal.y;nrm.z+=ar*tris[i].Normal.z;a+=ar;
        // Limit each face so large planar faces cannot consume the whole cloud.
        if(faceSamples<24){addSample(samplePts,sampleCount,tris[i].Pnt[0]);addSample(samplePts,sampleCount,tris[i].Pnt[1]);addSample(samplePts,sampleCount,tris[i].Pnt[2]);faceSamples+=3;}
    }
    pMemFree((void**)&tris);
    if(a>1e-18){ctr.x/=a;ctr.y/=a;ctr.z/=a;normv(nrm);addSample(samplePts,sampleCount,ctr);}return a;
}

static void captureLabel(ShapeInfo&s){s.hasLabel=0;for(int i=0;i<MAX_LABEL;++i)s.label[i]=0;if(!pEntLabel)return;int*lab=0;if(pEntLabel(s.id,&lab)||!lab){if(lab)pMemFree((void**)&lab);return;}int i=0;for(;i<MAX_LABEL-1&&lab[i];++i)s.label[i]=lab[i];s.hasLabel=lab[i]==0;s.label[i]=0;pMemFree((void**)&lab);}
static int currentShapeId(const ShapeInfo&s){if(s.hasLabel&&pEntByLabel){int id=0;if(!pEntByLabel((int*)s.label,1,&id)&&id>0)return id;}return s.id;}

static double skewAlong(int idShape,const svxPoint&c,const svxVector&a){int nf=0,*fa=0;if(pFaces(idShape,&nf,&fa)||!fa)return 0;double sum=0,scale=0;for(int f=0;f<nf;++f){int nt=0;svxTriangle*tr=0;if(!pFaceFacets(fa[f],&nt,&tr)&&tr){for(int i=0;i<nt;++i){double ar=triArea(tr[i]);svxPoint q={(tr[i].Pnt[0].x+tr[i].Pnt[1].x+tr[i].Pnt[2].x)/3.0,(tr[i].Pnt[0].y+tr[i].Pnt[1].y+tr[i].Pnt[2].y)/3.0,(tr[i].Pnt[0].z+tr[i].Pnt[1].z+tr[i].Pnt[2].z)/3.0};svxVector d={q.x-c.x,q.y-c.y,q.z-c.z};double p=dotv(d,a);sum+=ar*p*p*p;scale+=ar*dabs(p*p*p);}pMemFree((void**)&tr);}}pMemFree((void**)&fa);if(scale<1e-18)return 0;if(dabs(sum)<scale*1e-8)return 0;return sum;}

// Build an intrinsic local frame. Axes are ordered by projected body extent, not by
// arbitrary Axis[] order. Signs are disambiguated by area-weighted third moments.
// If a body is exactly symmetric, remaining sign ambiguity is a true geometry symmetry.
static int canonicalFrame(ShapeInfo&s){
    svxVector raw[3]={s.mass.Axis[0],s.mass.Axis[1],s.mass.Axis[2]};for(int i=0;i<3;++i)if(!normv(raw[i]))return 0;
    if(dotv(crossv(raw[0],raw[1]),raw[2])<0)raw[2]=negv(raw[2]);
    // Project every facet vertex ourselves; a local-frame box query can fail on native members.
    double low[3]={1e100,1e100,1e100},high[3]={-1e100,-1e100,-1e100};int points=0,nf=0,*faces=0;
    if(pFaces(s.id,&nf,&faces)||!faces)return 0;
    for(int f=0;f<nf;f++){int nt=0;svxTriangle*tr=0;if(!pFaceFacets(faces[f],&nt,&tr)&&tr){for(int t=0;t<nt;t++)for(int v=0;v<3;v++){svxVector d={tr[t].Pnt[v].x-s.mass.Center.x,tr[t].Pnt[v].y-s.mass.Center.y,tr[t].Pnt[v].z-s.mass.Center.z};for(int a=0;a<3;a++){double q=dotv(d,raw[a]);if(q<low[a])low[a]=q;if(q>high[a])high[a]=q;}points++;}}if(tr)pMemFree((void**)&tr);}pMemFree((void**)&faces);if(!points)return 0;
    double len[3]={high[0]-low[0],high[1]-low[1],high[2]-low[2]};
    int ord[3]={0,1,2};for(int i=0;i<2;++i)for(int j=i+1;j<3;++j){int swap=0;if(len[ord[j]]>len[ord[i]]+1e-8)swap=1;else if(nearv(len[ord[j]],len[ord[i]],1e-8,1e-7)&&s.mass.Ip[ord[j]]<s.mass.Ip[ord[i]])swap=1;if(swap){int t=ord[i];ord[i]=ord[j];ord[j]=t;}}
    svxVector X=raw[ord[0]],Y=raw[ord[1]],Z=raw[ord[2]];if(dotv(crossv(X,Y),Z)<0)Z=negv(Z);
    double sx=skewAlong(s.id,s.mass.Center,X);if(sx<0)X=negv(X);
    double sy=skewAlong(s.id,s.mass.Center,Y);if(sy<0)Y=negv(Y);
    Z=crossv(X,Y);if(!normv(Z))return 0;Y=crossv(Z,X);if(!normv(Y))return 0;
    s.frame=mkFrame(s.mass.Center,X,Y,Z);s.axisLen[0]=len[ord[0]];s.axisLen[1]=len[ord[1]];s.axisLen[2]=len[ord[2]];s.axisSkew[0]=sx;s.axisSkew[1]=sy;s.axisSkew[2]=skewAlong(s.id,s.mass.Center,Z);return 1;
}


static double pDist2(const svxPoint&a,const svxPoint&b){double dx=a.x-b.x,dy=a.y-b.y,dz=a.z-b.z;return dx*dx+dy*dy+dz*dz;}
static const char* analysisStage="";
static int analyzeShape(int id,ShapeInfo&s){
    analysisStage="masa/objetosc";
    memset(&s,0,sizeof(s));s.id=id;if(pMass(id,7.85e-6,&s.mass))return 0;analysisStage="lista scian/krawedzi";int*fa=0,*ed=0;int nf=0,ne=0;
    if(pFaces(id,&nf,&fa))return 0;if(pEdges(id,&ne,&ed)){if(fa)pMemFree((void**)&fa);return 0;}s.faceCount=nf;s.edgeCount=ne;
    if(nf>MAX_FACES){if(fa)pMemFree((void**)&fa);if(ed)pMemFree((void**)&ed);return 0;}
    s.sampleCount=0;for(int i=0;i<nf;++i)s.faceAreas[i]=faceGeom2019(fa[i],s.faceCtr[i],s.faceNrm[i],s.samples,s.sampleCount);
    if(fa)pMemFree((void**)&fa);if(ed)pMemFree((void**)&ed);captureLabel(s);analysisStage="osie lub obwiednia lokalna";
    if(!(s.mass.Volume>0)||!(s.mass.Volume<1e90)||nf<=0)return 0;
    if(canonicalFrame(s))return 1;
    // Principal axes are optional for export. Fall back to a global orthonormal frame;
    // congruence still needs exact kernel overlap, so this cannot merge unequal parts.
    s.mass.Axis[0]={1,0,0};s.mass.Axis[1]={0,1,0};s.mass.Axis[2]={0,0,1};return canonicalFrame(s);
}
static int sameGeom(const ShapeInfo&a,const ShapeInfo&b){
    if(a.faceCount!=b.faceCount||a.edgeCount!=b.edgeCount)return 0;
    if(!nearv(a.mass.Volume,b.mass.Volume,1.5e-3,5e-2))return 0;
    if(!nearv(a.mass.Area,b.mass.Area,1.5e-3,5e-2))return 0;
    for(int i=0;i<a.faceCount;++i){g_areaA[i]=a.faceAreas[i];g_areaB[i]=b.faceAreas[i];}sortDouble(g_areaA,a.faceCount);sortDouble(g_areaB,b.faceCount);
    int compared=0,matched=0;for(int i=0;i<a.faceCount;++i){if(g_areaA[i]<=1e-8||g_areaB[i]<=1e-8)continue;++compared;if(nearv(g_areaA[i],g_areaB[i],7.5e-3,2e-1))++matched;}if(compared>0&&matched<compared-1)return 0;return 1;
}

static svxPoint xformP(const svxMatrix&m,const svxPoint&p){svxPoint q={m.xx*p.x+m.xy*p.y+m.xz*p.z+m.xt,m.yx*p.x+m.yy*p.y+m.yz*p.z+m.yt,m.zx*p.x+m.zy*p.y+m.zz*p.z+m.zt};return q;}
static svxVector xformV(const svxMatrix&m,const svxVector&v){svxVector q={m.xx*v.x+m.xy*v.y+m.xz*v.z,m.yx*v.x+m.yy*v.y+m.yz*v.z,m.zx*v.x+m.zy*v.y+m.zz*v.z};return q;}
static int permParity(const int p[3]){int inv=0;for(int i=0;i<3;++i)for(int j=i+1;j<3;++j)if(p[i]>p[j])++inv;return (inv&1)?-1:1;}
static svxMatrix candidateTransform(const ShapeInfo&a,const ShapeInfo&b,const int perm[3],int sx,int sy,int sz){
    svxVector A[3]={a.mass.Axis[0],a.mass.Axis[1],a.mass.Axis[2]},B0[3]={b.mass.Axis[0],b.mass.Axis[1],b.mass.Axis[2]};for(int i=0;i<3;++i){normv(A[i]);normv(B0[i]);}
    if(dotv(crossv(A[0],A[1]),A[2])<0)A[2]=negv(A[2]);if(dotv(crossv(B0[0],B0[1]),B0[2])<0)B0[2]=negv(B0[2]);
    int sg[3]={sx,sy,sz};svxVector B[3];for(int j=0;j<3;++j){B[j]=B0[perm[j]];if(sg[j]<0)B[j]=negv(B[j]);}
    double AM[3][3]={{A[0].x,A[1].x,A[2].x},{A[0].y,A[1].y,A[2].y},{A[0].z,A[1].z,A[2].z}};
    double BM[3][3]={{B[0].x,B[1].x,B[2].x},{B[0].y,B[1].y,B[2].y},{B[0].z,B[1].z,B[2].z}};
    double R[3][3];for(int i=0;i<3;++i)for(int j=0;j<3;++j){R[i][j]=0;for(int k=0;k<3;++k)R[i][j]+=BM[i][k]*AM[j][k];}
    double ca[3]={a.mass.Center.x,a.mass.Center.y,a.mass.Center.z},cb[3]={b.mass.Center.x,b.mass.Center.y,b.mass.Center.z};double t[3];for(int i=0;i<3;++i)t[i]=cb[i]-(R[i][0]*ca[0]+R[i][1]*ca[1]+R[i][2]*ca[2]);
    svxMatrix m;memset(&m,0,sizeof(m));m.identity=0;m.xx=R[0][0];m.xy=R[0][1];m.xz=R[0][2];m.xt=t[0];m.yx=R[1][0];m.yy=R[1][1];m.yz=R[1][2];m.yt=t[1];m.zx=R[2][0];m.zy=R[2][1];m.zz=R[2][2];m.zt=t[2];return m;
}
static double cloudScore(const ShapeInfo&a,const ShapeInfo&b,const svxMatrix&m){
    if(a.sampleCount<4||b.sampleCount<4)return 1e50;
    double scale=1.0;for(int k=0;k<3;++k)if(a.axisLen[k]>scale)scale=a.axisLen[k];double inv=1.0/(scale*scale+1e-18);
    double sumAB=0,maxAB=0;
    for(int i=0;i<a.sampleCount;++i){svxPoint q=xformP(m,a.samples[i]);double best=1e100;for(int j=0;j<b.sampleCount;++j){double dx=q.x-b.samples[j].x,dy=q.y-b.samples[j].y,dz=q.z-b.samples[j].z;double d2=(dx*dx+dy*dy+dz*dz)*inv;if(d2<best)best=d2;}sumAB+=best;if(best>maxAB)maxAB=best;}
    double sumBA=0,maxBA=0;
    for(int j=0;j<b.sampleCount;++j){double best=1e100;for(int i=0;i<a.sampleCount;++i){svxPoint q=xformP(m,a.samples[i]);double dx=q.x-b.samples[j].x,dy=q.y-b.samples[j].y,dz=q.z-b.samples[j].z;double d2=(dx*dx+dy*dy+dz*dz)*inv;if(d2<best)best=d2;}sumBA+=best;if(best>maxBA)maxBA=best;}
    double mean=(sumAB/a.sampleCount+sumBA/b.sampleCount)*0.5;
    double mx=maxAB>maxBA?maxAB:maxBA;
    // Max term is important for mitres/corners: one wrong end must not be hidden by long coincident faces.
    return mean+8.0*mx;
}
static double transformScore(const ShapeInfo&a,const ShapeInfo&b,const svxMatrix&m){
    if(a.faceCount!=b.faceCount)return 1e100;char used[MAX_FACES];memset(used,0,sizeof(used));double scale=1.0;for(int k=0;k<3;++k)if(a.axisLen[k]>scale)scale=a.axisLen[k];double score=0;
    for(int step=0;step<a.faceCount;++step){int i=step;
        svxPoint pc=xformP(m,a.faceCtr[i]);svxVector pn=xformV(m,a.faceNrm[i]);normv(pn);int best=-1;double bestCost=1e100;
        for(int j=0;j<b.faceCount;++j){if(used[j])continue;if(!nearv(a.faceAreas[i],b.faceAreas[j],7.5e-3,2e-1))continue;double dx=pc.x-b.faceCtr[j].x,dy=pc.y-b.faceCtr[j].y,dz=pc.z-b.faceCtr[j].z;double d2=(dx*dx+dy*dy+dz*dz)/(scale*scale);double nd=dotv(pn,b.faceNrm[j]);if(nd>1)nd=1;if(nd<-1)nd=-1;double nc=(1.0-nd)*(1.0-nd);double c=d2+0.05*nc;if(c<bestCost){bestCost=c;best=j;}}
        if(best<0)return 1e100;used[best]=1;score+=bestCost*(1.0+a.faceAreas[i]/(a.mass.Area+1e-9));
    }
    double cs=cloudScore(a,b,m);if(cs>=1e49)return 1e100;
    return cs*1000.0+score;
}
static svxMatrix bestRigidTransform(const ShapeInfo&a,const ShapeInfo&b,double&bestScore){
    static const int perms[6][3]={{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};svxMatrix best=rigidRelative(a.frame,b.frame);bestScore=1e100;
    for(int pi=0;pi<6;++pi){int parity=permParity(perms[pi]);for(int sx=-1;sx<=1;sx+=2)for(int sy=-1;sy<=1;sy+=2)for(int sz=-1;sz<=1;sz+=2){if(parity*sx*sy*sz<0)continue;svxMatrix c=candidateTransform(a,b,perms[pi],sx,sy,sz);double sc=transformScore(a,b,c);if(sc<bestScore){bestScore=sc;best=c;}}}return best;
}

static double pointDist(const svxPoint&a,const svxPoint&b){return dsqrt(pDist2(a,b));}
static double triSpread(const svxPoint&a,const svxPoint&b,const svxPoint&c){
    svxVector u={b.x-a.x,b.y-a.y,b.z-a.z};svxVector v={c.x-a.x,c.y-a.y,c.z-a.z};svxVector w=crossv(u,v);return dsqrt(dotv(w,w));
}
static int frameFrom3(const svxPoint&p0,const svxPoint&p1,const svxPoint&p2,svxMatrix&f){
    svxVector X={p1.x-p0.x,p1.y-p0.y,p1.z-p0.z};if(!normv(X))return 0;
    svxVector V={p2.x-p0.x,p2.y-p0.y,p2.z-p0.z};svxVector Z=crossv(X,V);if(!normv(Z))return 0;
    svxVector Y=crossv(Z,X);if(!normv(Y))return 0;f=mkFrame(p0,X,Y,Z);return 1;
}
// Compute MASTER -> duplicate directly from the two ORIGINAL bodies, before either body is changed.
// Face centroids are stable B-Rep landmarks.  A wide triangle of MASTER faces is selected and all
// geometrically compatible face triples on the duplicate are tested.  The complete body cloud then
// decides which candidate is the real pose.  This avoids independently invented local frames.
static int directPairTransform(const ShapeInfo&a,const ShapeInfo&b,svxMatrix&best,double&bestScore){
    bestScore=1e100;if(a.faceCount<3||b.faceCount<3||a.faceCount!=b.faceCount)return 0;
    int i0=-1,i1=-1,i2=-1;double spread=-1;
    for(int i=0;i<a.faceCount;++i)for(int j=i+1;j<a.faceCount;++j)for(int k=j+1;k<a.faceCount;++k){
        double q=triSpread(a.faceCtr[i],a.faceCtr[j],a.faceCtr[k]);if(q>spread){spread=q;i0=i;i1=j;i2=k;}
    }
    if(i0<0||spread<1e-8)return 0;
    double ad01=pointDist(a.faceCtr[i0],a.faceCtr[i1]),ad02=pointDist(a.faceCtr[i0],a.faceCtr[i2]),ad12=pointDist(a.faceCtr[i1],a.faceCtr[i2]);
    int found=0;
    for(int u=0;u<b.faceCount;++u){if(!nearv(a.faceAreas[i0],b.faceAreas[u],7.5e-3,2e-1))continue;
      for(int v=0;v<b.faceCount;++v){if(v==u||!nearv(a.faceAreas[i1],b.faceAreas[v],7.5e-3,2e-1))continue;
        double bd01=pointDist(b.faceCtr[u],b.faceCtr[v]);if(!nearv(ad01,bd01,2e-3,2e-2))continue;
        for(int w=0;w<b.faceCount;++w){if(w==u||w==v||!nearv(a.faceAreas[i2],b.faceAreas[w],7.5e-3,2e-1))continue;
            double bd02=pointDist(b.faceCtr[u],b.faceCtr[w]),bd12=pointDist(b.faceCtr[v],b.faceCtr[w]);
            if(!nearv(ad02,bd02,2e-3,2e-2)||!nearv(ad12,bd12,2e-3,2e-2))continue;
            svxMatrix A,B;if(!frameFrom3(a.faceCtr[i0],a.faceCtr[i1],a.faceCtr[i2],A))continue;if(!frameFrom3(b.faceCtr[u],b.faceCtr[v],b.faceCtr[w],B))continue;
            svxMatrix T=rigidRelative(A,B);
            svxPoint mc=xformP(T,a.mass.Center);double ce=pDist2(mc,b.mass.Center);double scale=1.0;for(int z=0;z<3;++z)if(a.axisLen[z]>scale)scale=a.axisLen[z];
            double sc=transformScore(a,b,T)+10000.0*ce/(scale*scale+1e-18);
            if(sc<bestScore){bestScore=sc;best=T;found=1;}
        }
      }
    }
    if(!found){best=bestRigidTransform(a,b,bestScore);found=bestScore<1e90;}
    return found;
}
static int getComps(int*out,int cap){
    if(!pPartComps)return -1;int n=0,*ids=0;if(pPartComps(0,0,&n,&ids)){if(ids)pMemFree((void**)&ids);return -1;}
    if(n>cap){if(ids)pMemFree((void**)&ids);return -2;}
    for(int i=0;i<n;++i)out[i]=ids[i];if(ids)pMemFree((void**)&ids);return n;
}
static int findNewComp(const int*before,int nb,const int*after,int na){for(int i=0;i<na;++i){int found=0;for(int j=0;j<nb;++j)if(after[i]==before[j]){found=1;break;}if(!found)return after[i];}return -1;}
static int sameText(const char*a,const char*b){return streq(a,b);}
static double shapeScale(const ShapeInfo&s){double q=1.0;for(int i=0;i<3;++i)if(s.axisLen[i]>q)q=s.axisLen[i];return q;}
// Stabilna walidacja pary nie korzysta z wierzcholkow siatki fasetowania jako warunku akceptacji.
// ZW3D moze sfacetowac ten sam B-Rep nieco inaczej po obrocie, dlatego V14 odrzucalo prawdziwe duplikaty.
// Tutaj sprawdzamy srodki odpowiadajacych sobie scian + pola + kierunki normalnych + srodek masy.
static __declspec(noinline) double pairFaceResidual(const ShapeInfo&a,const ShapeInfo&b,const svxMatrix&t,double&worstNormal){
    char used[MAX_FACES];memset(used,0,sizeof(used));double worst=0;worstNormal=0;
    for(int i=0;i<a.faceCount;++i){
        svxPoint pc=xformP(t,a.faceCtr[i]);svxVector pn=xformV(t,a.faceNrm[i]);double nla=dsqrt(dotv(pn,pn));if(nla>1e-12){pn.x/=nla;pn.y/=nla;pn.z/=nla;}
        int best=-1;double bestD=1e100,bestNE=0;
        for(int j=0;j<b.faceCount;++j){if(used[j])continue;if(!nearv(a.faceAreas[i],b.faceAreas[j],7.5e-3,2e-1))continue;
            double d=pointDist(pc,b.faceCtr[j]);double ne=0;double nlb=dsqrt(dotv(b.faceNrm[j],b.faceNrm[j]));
            if(nla>0.5&&nlb>0.5){double nd=dotv(pn,b.faceNrm[j])/nlb;if(nd>1)nd=1;if(nd<-1)nd=-1;ne=1.0-nd;}
            // Pozycja dominuje, normalna tylko rozstrzyga sciany o podobnym polozeniu/polu.
            double cost=d+shapeScale(a)*0.02*ne;if(cost<bestD){bestD=cost;best=j;bestNE=ne;}
        }
        if(best<0)return 1e100;used[best]=1;double d=pointDist(pc,b.faceCtr[best]);if(d>worst)worst=d;if(bestNE>worstNormal)worstNormal=bestNE;
    }
    svxPoint mc=xformP(t,a.mass.Center);double cd=pointDist(mc,b.mass.Center);if(cd>worst)worst=cd;return worst;
}
static double pairTolerance(const ShapeInfo&s){double v=shapeScale(s)*0.0005;if(v<0.35)v=0.35;if(v>2.0)v=2.0;return v;}
static __declspec(noinline) int pairTransformAccept(const ShapeInfo&a,const ShapeInfo&b,svxMatrix&t,double&score,double&residual){
    if(!directPairTransform(a,b,t,score))return 0;double normalErr=0;residual=pairFaceResidual(a,b,t,normalErr);
    // normalErr 0.08 ~= dot > 0.92. Zerowe/niestabilne normalne powierzchni krzywych sa pomijane.
    return residual<=pairTolerance(a)&&normalErr<=0.08;
}
static double matrixPosError(const svxMatrix&a,const svxMatrix&b){double dx=a.xt-b.xt,dy=a.yt-b.yt,dz=a.zt-b.zt;return dsqrt(dx*dx+dy*dy+dz*dz);}
static double matrixRotError(const svxMatrix&a,const svxMatrix&b){double e=0;double av[9]={a.xx,a.xy,a.xz,a.yx,a.yy,a.yz,a.zx,a.zy,a.zz};double bv[9]={b.xx,b.xy,b.xz,b.yx,b.yy,b.yz,b.zx,b.zy,b.zz};for(int i=0;i<9;++i){double d=dabs(av[i]-bv[i]);if(d>e)e=d;}return e;}
static int matrixVerified(const svxMatrix&a,const svxMatrix&b){svxMatrix aa=a.identity?identityMatrix():a,bb=b.identity?identityMatrix():b;return matrixPosError(aa,bb)<=0.01&&matrixRotError(aa,bb)<=1e-5;}
static void cleanupEntity(int id){if(id>0&&pErase)pErase(1,&id);}
static int rootExists(const char*name){if(!pRootId||!name||!name[0])return 0;vxLongName n;copystr(n,name,256);int id=0,type=0;return pRootId(n,&id,&type)==0&&id>0;}
static int prepareUniquePartNames(int ng){
    for(int g=0;g<ng;++g){char base[256];makeMasterBase(base,g+1);copystr(g_partNames[g],base,256);if(!rootExists(g_partNames[g]))continue;int ok=0;for(int k=1;k<=99;++k){copystr(g_partNames[g],base,256);int n=0;while(g_partNames[g][n]&&n<250)++n;g_partNames[g][n++]='_';append2digits(g_partNames[g],n,k);if(!rootExists(g_partNames[g])){ok=1;break;}}if(!ok){msg("DS Assembly V15: nie znaleziono wolnej nazwy MASTER (01..99). BUILD przerwany.");return 0;}}
    return 1;
}
static int collect(ShapeInfo*shapes,int&ns,Group*groups,int&ng){
    ns=0;ng=0;int cnt=0,*ids=0;if(pShapes(0,0,&cnt,&ids)||cnt<=0||!ids){msg("DS Assembly: brak bryl w aktywnej czesci.");if(ids)pMemFree((void**)&ids);return 0;}
    if(cnt>MAX_SHAPES){msg("DS Assembly V15: za duzo bryl (limit 256).");pMemFree((void**)&ids);return 0;}
    int analysisFail=0;for(int i=0;i<cnt;++i){if(analyzeShape(ids[i],g_tmpShape))shapes[ns++]=g_tmpShape;else ++analysisFail;}pMemFree((void**)&ids);
    if(analysisFail||ns!=cnt){char b[220];int n=0;b[0]=0;appendStr(b,n,220,"DS Assembly V15: BUILD/CHECK zablokowany - nie przeanalizowano bryl: ");appendInt(b,n,220,analysisFail);appendStr(b,n,220," z ");appendInt(b,n,220,cnt);msg(b);return 0;}
    // Grupowanie korzysta tylko z niezmiennikow geometrii (jak w stabilnych V4-V13).
    // Walidacja sztywnej transformacji 3D jest wykonywana dopiero w preflight Build.
    // Dzięki temu tessellacja/fasety nie moga rozbic prawdziwych duplikatow na osobne grupy.
    for(int i=0;i<ns;++i){int found=-1;for(int g=0;g<ng;++g){int m=groups[g].members[0];if(sameGeom(shapes[m],shapes[i])){found=g;break;}}
        if(found<0){found=ng++;groups[found].count=0;}groups[found].members[groups[found].count++]=i;}
    return 1;
}
static void report(int ns,Group*groups,int ng){char b[256];int n=0;b[0]=0;appendStr(b,n,256,"DS Assembly: ");appendInt(b,n,256,ns);appendStr(b,n,256," bryl -> ");appendInt(b,n,256,ng);appendStr(b,n,256," unikalnych detali.");msg(b);for(int g=0;g<ng;++g){n=0;b[0]=0;appendStr(b,n,256,"  DSA15_PART_");appendInt(b,n,256,g+1);appendStr(b,n,256,"  x");appendInt(b,n,256,groups[g].count);msg(b);}}

extern "C" __declspec(dllexport) void DSAssemblyDebug(void){
    if(!resolveAssemblyApi())return;int ns=0,ng=0;if(!collect(g_shapes,ns,g_groups,ng))return;report(ns,g_groups,ng);
    for(int i=0;i<ns;++i){char b[320];int n=0;b[0]=0;appendStr(b,n,320," Shape ");appendInt(b,n,320,i+1);appendStr(b,n,320,": V=");appendFixed2(b,n,320,g_shapes[i].mass.Volume);appendStr(b,n,320," A=");appendFixed2(b,n,320,g_shapes[i].mass.Area);appendStr(b,n,320," L=");appendFixed2(b,n,320,g_shapes[i].axisLen[0]);appendStr(b,n,320,"/");appendFixed2(b,n,320,g_shapes[i].axisLen[1]);appendStr(b,n,320,"/");appendFixed2(b,n,320,g_shapes[i].axisLen[2]);msg(b);}
    for(int g=0;g<ng;++g){int mi=g_groups[g].members[0];for(int j=1;j<g_groups[g].count;++j){int si=g_groups[g].members[j];svxMatrix d;double sc=1e100,res=1e100;int ok=pairTransformAccept(g_shapes[mi],g_shapes[si],d,sc,res);char b[320];int n=0;b[0]=0;appendStr(b,n,320," Pair G");appendInt(b,n,320,g+1);appendStr(b,n,320," #1->#");appendInt(b,n,320,j+1);appendStr(b,n,320," 3D=");appendStr(b,n,320,ok?"OK":"FAIL");appendStr(b,n,320," residual_mm=");appendFixed2(b,n,320,res);msg(b);}}
    msg("DS Assembly V15 DEBUG: grupowanie uzywa niezmiennikow geometrii; walidacja 3D jest wykonywana dopiero przed Build. Residual opiera sie na srodkach scian/polach, nie na identycznosci siatki fasetowania.");
}
extern "C" __declspec(dllexport) void DSAssemblyInfo(void){msg("DS Assembly V35: nazwane czesci, wspolne definicje identycznych bryl, oddzielne utwierdzone wystapienia. Polozenia sprawdzane po przebudowie.");}
extern "C" __declspec(dllexport) void DSAssemblyCheck(void){if(!resolveAssemblyApi())return;int ns=0,ng=0;if(collect(g_shapes,ns,g_groups,ng))report(ns,g_groups,ng);}

extern "C" __declspec(dllexport) void DSAssemblyBuildLegacy(void){
    if(!resolveAssemblyApi())return;
    int ns=0,ng=0;if(!collect(g_shapes,ns,g_groups,ng))return;report(ns,g_groups,ng);
    if(!prepareUniquePartNames(ng))return;

    // Freeze every MASTER->duplicate transform before ANY model mutation and reject uncertain matches.
    static svxMatrix savedDelta[MAX_SHAPES];static char deltaOk[MAX_SHAPES];for(int i=0;i<MAX_SHAPES;++i)deltaOk[i]=0;
    int poseFail=0;
    for(int g=0;g<ng;++g){int mi=g_groups[g].members[0];savedDelta[mi]=identityMatrix();deltaOk[mi]=1;
        for(int j=1;j<g_groups[g].count;++j){int si=g_groups[g].members[j];double sc=1e100,res=1e100;svxMatrix d;
            if(!pairTransformAccept(g_shapes[mi],g_shapes[si],d,sc,res)){poseFail=1;char q[260];int qn=0;q[0]=0;appendStr(q,qn,260,"DS Assembly V15: niepewna pozycja duplikatu. grupa=");appendInt(q,qn,260,g+1);appendStr(q,qn,260," szt=");appendInt(q,qn,260,j+1);appendStr(q,qn,260," residual_mm=");appendFixed2(q,qn,260,res);msg(q);continue;}
            savedDelta[si]=d;deltaOk[si]=1;char q[280];int qn=0;q[0]=0;appendStr(q,qn,280,"DS Assembly V15: zapisano MASTER->duplikat grupa=");appendInt(q,qn,280,g+1);appendStr(q,qn,280," szt=");appendInt(q,qn,280,j+1);appendStr(q,qn,280," residual_mm=");appendFixed2(q,qn,280,res);msg(q);
        }
    }
    if(poseFail){msg("DS Assembly V15: BUILD przerwany PRZED zmianami modelu - co najmniej jedna transformacja nie przeszla walidacji geometrii.");return;}

    char activeFile[256]={0};pFileActive(activeFile,256);char parentRoot[256]={0};if(pRootActive)pRootActive(parentRoot,256);
    if(!activeFile[0]){msg("DS Assembly V15: nie mozna odczytac aktywnego pliku.");return;}
    int initialCount=getComps(g_compBefore,MAX_COMPS);if(initialCount==-2){msg("DS Assembly V15: za duzo komponentow (limit 2048). BUILD przerwany.");return;}if(initialCount<0)initialCount=0;
    if(pHistBackup)pHistBackup();
    int masterCount=0,occurrenceCount=0,erasedCount=0,failed=0;

    for(int g=0;g<ng;++g){
        const char*sharedPart=g_partNames[g];int masterIndex=g_groups[g].members[0];int masterSid=currentShapeId(g_shapes[masterIndex]);
        if(masterSid<=0){++failed;msg("DS Assembly V15: nie znaleziono bryly MASTER.");continue;}

        int nb=getComps(g_compBefore,MAX_COMPS);if(nb==-2){++failed;msg("DS Assembly V15: limit komponentow przekroczony przed MASTER.");break;}if(nb<0)nb=0;
        svxGeomExport ex;memset(&ex,0,sizeof(ex));ex.numEnts=1;ex.idEnts=&masterSid;ex.File[0]=0;copystr(ex.Part,sharedPart,256);ex.Frame=identityMatrix();ex.Option=1;ex.AddComponent=1;ex.NoExportOp=0;ex.Unblank=1;
        int erc=pGeomExport(&ex);int na=getComps(g_compAfter,MAX_COMPS);if(na==-2){++failed;msg("DS Assembly V15: limit komponentow przekroczony po MASTER.");break;}int masterCid=(na>=0?findNewComp(g_compBefore,nb,g_compAfter,na):-1);
        if(erc||masterCid<0||na!=nb+1){++failed;char b[280];int n=0;b[0]=0;appendStr(b,n,280,"DS Assembly V15: MASTER export/komponent FAIL grupa=");appendInt(b,n,280,g+1);appendStr(b,n,280," rc=");appendInt(b,n,280,erc);appendStr(b,n,280," comp before/after=");appendInt(b,n,280,nb);appendStr(b,n,280,"/");appendInt(b,n,280,na);msg(b);continue;}
        ++masterCount;++occurrenceCount;char occ1[256];makeOccName(occ1,g+1,1);if(pNameSet)pNameSet(masterCid,occ1);

        char refFile[256]={0},refPart[256]={0};if(pCompPart(masterCid,refFile,256,refPart,256)){++failed;msg("DS Assembly V15: nie mozna odczytac File/Part komponentu MASTER.");continue;}
        svxMatrix masterM;if(pEntMatrix(masterCid,&masterM)){++failed;msg("DS Assembly V15: nie mozna odczytac macierzy MASTER. Bryla MASTER pozostaje.");continue;}
        int eraseMaster=currentShapeId(g_shapes[masterIndex]);if(eraseMaster>0&&!pErase(1,&eraseMaster))++erasedCount;else{++failed;msg("DS Assembly V15: MASTER utworzony, ale nie usunieto oryginalnej bryly.");}

        for(int j=1;j<g_groups[g].count;++j){
            int si=g_groups[g].members[j];int sid=currentShapeId(g_shapes[si]);if(sid<=0){++failed;msg("DS Assembly V15: nie znaleziono bryly duplikatu.");continue;}
            char nowRoot[256]={0};if(pRootActive){pRootActive(nowRoot,256);if(parentRoot[0]&&!sameText(nowRoot,parentRoot)){++failed;msg("DS Assembly V15: aktywny obiekt zmienil sie po eksporcie MASTER. Duplikat pozostaje.");continue;}}
            if(!deltaOk[si]){++failed;msg("DS Assembly V15: brak zweryfikowanej macierzy duplikatu.");continue;}

            int ncb=getComps(g_compBefore,MAX_COMPS);if(ncb==-2){++failed;msg("DS Assembly V15: limit komponentow przekroczony przed kopia.");continue;}if(ncb<0)ncb=0;
            // Copy the real MASTER occurrence WITHOUT movement, then assign an ABSOLUTE local->world matrix.
            svxMatrix idm=identityMatrix();int copyCid=-1;int crc=pCopyTransform(masterCid,&idm,&copyCid);
            int nca=getComps(g_compAfter,MAX_COMPS);if(nca==-2){++failed;msg("DS Assembly V15: limit komponentow przekroczony po kopii.");continue;}int actualCid=(nca>=0?findNewComp(g_compBefore,ncb,g_compAfter,nca):-1);if(actualCid<0&&copyCid>0)actualCid=copyCid;
            if(crc||actualCid<=0||nca!=ncb+1){++failed;char b[300];int n=0;b[0]=0;appendStr(b,n,300,"DS Assembly V15: kopiowanie MASTER nie utworzylo komponentu. grupa=");appendInt(b,n,300,g+1);appendStr(b,n,300," szt=");appendInt(b,n,300,j+1);appendStr(b,n,300," rc=");appendInt(b,n,300,crc);msg(b);continue;}
            char cf[256]={0},cp[256]={0};if(pCompPart(actualCid,cf,256,cp,256)||!sameText(cf,refFile)||!sameText(cp,refPart)){++failed;cleanupEntity(actualCid);msg("DS Assembly V15: kopia nie wskazuje na ten sam MASTER. Kopia usunieta, bryla zrodlowa pozostaje.");continue;}

            // savedDelta maps MASTER world geometry -> duplicate world geometry.
            // masterM maps component local -> MASTER world. Therefore targetM = savedDelta * masterM.
            svxMatrix targetM=rigidMul(savedDelta[si],masterM);
            int mrc=pEntMatrixSet(actualCid,&targetM);svxMatrix actualM;int grc=pEntMatrix(actualCid,&actualM);
            if(mrc||grc||!matrixVerified(actualM,targetM)){++failed;char b[320];int n=0;b[0]=0;appendStr(b,n,320,"DS Assembly V15: walidacja macierzy kopii FAIL grupa=");appendInt(b,n,320,g+1);appendStr(b,n,320," szt=");appendInt(b,n,320,j+1);appendStr(b,n,320," set/get=");appendInt(b,n,320,mrc);appendStr(b,n,320,"/");appendInt(b,n,320,grc);if(!grc){appendStr(b,n,320," posErr=");appendFixed2(b,n,320,matrixPosError(actualM,targetM));}msg(b);cleanupEntity(actualCid);continue;}

            ++occurrenceCount;char occ[256];makeOccName(occ,g+1,j+1);if(pNameSet)pNameSet(actualCid,occ);
            int eraseId=currentShapeId(g_shapes[si]);if(eraseId>0&&!pErase(1,&eraseId))++erasedCount;else{++failed;msg("DS Assembly V15: kopia zweryfikowana, ale nie usunieto bryly zrodlowej.");}
        }
    }
    int finalCount=getComps(g_compBefore,MAX_COMPS);if(finalCount==-2)finalCount=MAX_COMPS;
    char b[380];int n=0;b[0]=0;appendStr(b,n,380,"DS Assembly V15: MASTER=");appendInt(b,n,380,masterCount);appendStr(b,n,380,"/");appendInt(b,n,380,ng);appendStr(b,n,380,", wystapienia=");appendInt(b,n,380,occurrenceCount);appendStr(b,n,380,"/");appendInt(b,n,380,ns);appendStr(b,n,380,", skasowane bryly=");appendInt(b,n,380,erasedCount);appendStr(b,n,380,"/");appendInt(b,n,380,ns);appendStr(b,n,380,", komponenty przed/po=");appendInt(b,n,380,initialCount);appendStr(b,n,380,"/");appendInt(b,n,380,finalCount);appendStr(b,n,380,", bledy=");appendInt(b,n,380,failed);msg(b);
    if(masterCount==ng&&occurrenceCount==ns&&erasedCount==ns&&finalCount==initialCount+ns&&failed==0)msg("DS Assembly V15: BUILD OK - definicje MASTER i wszystkie wystapienia przeszly walidacje macierzy.");else msg("DS Assembly V15: wynik nie przeszedl pelnej kontroli. Uzyj Cofnij; zrodlo jest kasowane dopiero po zweryfikowaniu komponentu.");
}
extern "C" __declspec(dllexport) void DSAssemblyBuild(void);
extern "C" __declspec(dllexport) void DSAssemblyCheckGeneric(void);
extern "C" __declspec(dllexport) int DSAssembly2019Init(int format,void*data){(void)format;(void)data;if(!resolveCoreApi())return 1;pCmdFunc("DSAssemblyInfo",(void*)DSAssemblyInfo,0);pCmdFunc("DSAssemblyDebug",(void*)DSAssemblyCheckGeneric,0);pCmdFunc("DSAssemblyCheck",(void*)DSAssemblyCheckGeneric,0);pCmdFunc("DSAssemblyBuild",(void*)DSAssemblyBuild,0);msg("DS Assembly V35 zaladowany. ~DSAssemblyBuild: gotowe bryly -> nazwane wspolne czesci i utwierdzone wystapienia.");return 0;}
extern "C" __declspec(dllexport) int DSAssembly2019Exit(void){if(pCmdFuncUnload){pCmdFuncUnload("DSAssemblyInfo");pCmdFuncUnload("DSAssemblyDebug");pCmdFuncUnload("DSAssemblyCheck");pCmdFuncUnload("DSAssemblyBuild");}return 0;}
extern "C" void* volatile DSAssemblyRelocAnchor = (void*)&DSAssembly2019Init;

// Makieta V20: checked shared definitions and balanced target-object stack.
typedef int (*PFN_marker)(vxName);typedef int (*PFN_undo)(int,vxName);typedef int (*PFN_activate)(vxLongName,vxLongName);
typedef int (*PFN_bool)(int,int,int*,int,int*,int*,int**);
static char bridgeError[256];
extern "C" __declspec(dllexport) int DSAssemblyMakietaVersion(){return 34;}
extern "C" __declspec(dllexport) const char* DSAssemblyMakietaError(){return bridgeError;}
static int bridgeFail(const char*s){copystr(bridgeError,s,256);msg(s);return 1;}
static int bridgeValidBox(const svxBndBox&b){return b.X.max>b.X.min&&b.Y.max>b.Y.min&&b.Z.max>b.Z.min&&dabs(b.X.min)<1e90&&dabs(b.X.max)<1e90&&dabs(b.Y.min)<1e90&&dabs(b.Y.max)<1e90&&dabs(b.Z.min)<1e90&&dabs(b.Z.max)<1e90;}
static int bridgeBox(int id,svxBndBox&b){
 if(!pShapeBox(id,0,&b)&&bridgeValidBox(b))return 1;
 svxMatrix m=identityMatrix();if(!pShapeBox(id,&m,&b)&&bridgeValidBox(b))return 1;
 typedef int(*FaceBox)(int,svxBndBox*);FaceBox box=(FaceBox)findExport("cvxPartInqFaceBox");if(!box)return 0;
 int n=0,*faces=0;if(pFaces(id,&n,&faces)||!faces)return 0;int good=n>0;
 for(int i=0;i<n;i++){svxBndBox q;if(box(faces[i],&q)){good=0;break;}if(i==0)b=q;else{if(q.X.min<b.X.min)b.X.min=q.X.min;if(q.X.max>b.X.max)b.X.max=q.X.max;if(q.Y.min<b.Y.min)b.Y.min=q.Y.min;if(q.Y.max>b.Y.max)b.Y.max=q.Y.max;if(q.Z.min<b.Z.min)b.Z.min=q.Z.min;if(q.Z.max>b.Z.max)b.Z.max=q.Z.max;}}
 pMemFree((void**)&faces);return good&&bridgeValidBox(b);
}
static int equalBox(const svxBndBox&a,const svxBndBox&b){return dabs(a.X.min-b.X.min)<.05&&dabs(a.X.max-b.X.max)<.05&&dabs(a.Y.min-b.Y.min)<.05&&dabs(a.Y.max-b.Y.max)<.05&&dabs(a.Z.min-b.Z.min)<.05&&dabs(a.Z.max-b.Z.max)<.05;}
// Matching math uses conventional row matrices; API stores xx,yx,zx as its first row.
static svxMatrix bridgeApiMatrix(svxMatrix m){double q=m.xy;m.xy=m.yx;m.yx=q;q=m.xz;m.xz=m.zx;m.zx=q;q=m.yz;m.yz=m.zy;m.zy=q;return m;}
// Compare mass properties and sampled B-Rep boundaries, not nominal lengths.
// 1=equal, 0=not confirmed, -1=undo failed (stop).
// Read-only boundary comparison: never create Boolean/copy history during grouping.
// Check distributed tessellation vertices against actual target B-Rep faces.
static int bridgeBoundary(const ShapeInfo&a,const ShapeInfo&b,const svxMatrix&pose){
 int na=0,nb=0,*fa=0,*fb=0;int sa=currentShapeId(a),sb=currentShapeId(b);
 if(sa<=0||sb<=0||pFaces(sa,&na,&fa)||pFaces(sb,&nb,&fb)||na<=0||nb<=0||!fa||!fb){if(fa)pMemFree((void**)&fa);if(fb)pMemFree((void**)&fb);return 0;}
 int good=1,checked=0;
 for(int i=0;i<na&&good;i++){
  int nt=0;svxTriangle*tris=0;
  if(pFaceFacets(fa[i],&nt,&tris)||nt<=0||!tris)good=0;
  // Include samples across each face, including the two ends of long faces.
  for(int k=0;k<nt&&good;k+=nt>32?nt/32:1)for(int v=0;v<3&&good;v++){
   svxPoint q=tris[k].Pnt[v];svxMatrix native=pose;pSdkPnt(&native,&q);int on=0;
   for(int j=0;j<nb&&!on;j++)if(pPntIsOn(&q,fb[j])==1){
    double u=0,vv=0;int loc=-2;
    // Surface membership alone does not prove membership in the trimmed face.
    if(!pFaceProjection(fb[j],&q,&u,&vv)&&!pFaceLocation(fb[j],u,vv,&loc)&&(loc==0||loc==1))on=1;
   }
   if(!on)good=0;else checked++;
  }
  if(tris)pMemFree((void**)&tris);
 }
 pMemFree((void**)&fa);pMemFree((void**)&fb);return good&&checked>=3;
}
static int bridgeOverlap(const ShapeInfo&a,const ShapeInfo&b,const svxMatrix&pose,PFN_marker,PFN_undo,PFN_bool){
 svxMatrix native=pose,inv=identityMatrix();pSdkInverse(&native,&inv);
 return bridgeBoundary(a,b,pose)&&bridgeBoundary(b,a,inv);
}
static svxMatrix bridgeCompose(svxMatrix a,svxMatrix b){
 if(a.identity)a=identityMatrix();if(b.identity)b=identityMatrix();
 svxMatrix rowA=bridgeApiMatrix(a),rowB=bridgeApiMatrix(b);
 svxMatrix out=bridgeApiMatrix(rigidMul(rowA,rowB));out.identity=0;return out;
}
// Try actual rigid alternatives; scoring and face tessellation may differ between
// identical native members. Every accepted transform needs bidirectional boundary checks.
static svxMatrix bridgeRotationAtCenters(svxMatrix row,const ShapeInfo&a,const ShapeInfo&b){
 row.identity=0;row.xt=row.yt=row.zt=0;svxPoint c=xformP(row,a.mass.Center);
 row.xt=b.mass.Center.x-c.x;row.yt=b.mass.Center.y-c.y;row.zt=b.mass.Center.z-c.z;return bridgeApiMatrix(row);
}
static int bridgePoseMatchesAxis(const svxMatrix&api,const svxMatrix&fa,const svxMatrix&fb,int axial){
 if(!axial)return 1;
 svxMatrix row=bridgeApiMatrix(api);svxVector a={fa.zx,fa.zy,fa.zz},b={fb.zx,fb.zy,fb.zz};
 svxMatrix native=api;native.xt=native.yt=native.zt=0;native.identity=0;
 svxPoint q={a.x,a.y,a.z};pSdkPnt(&native,&q);return dabs(q.x*b.x+q.y*b.y+q.z*b.z)>1.0-1e-7;
}
static int bridgeAcceptPose(const ShapeInfo&a,const ShapeInfo&b,const svxMatrix&c,const svxMatrix&fa,const svxMatrix&fb,int axial,PFN_marker marker,PFN_undo undo,PFN_bool boolean){
 if(!bridgePoseMatchesAxis(c,fa,fb,axial))return 0;
 svxPoint mc=a.mass.Center;svxMatrix native=c;pSdkPnt(&native,&mc);
 if(pointDist(mc,b.mass.Center)>.01)return 0;
 return bridgeOverlap(a,b,c,marker,undo,boolean);
}
static int bridgeCongruent(const ShapeInfo&a,const ShapeInfo&b,svxMatrix&out,const svxMatrix&fa,const svxMatrix&fb,int axial,PFN_marker marker,PFN_undo undo,PFN_bool boolean){
 if(!nearv(a.mass.Volume,b.mass.Volume,1e-5,.02)||!nearv(a.mass.Area,b.mass.Area,7.5e-3,.1))return 0;
 // Use the member frames used to construct the source geometry first.
 svxMatrix ar=bridgeApiMatrix(fa),br=bridgeApiMatrix(fb),inv=ar;
 inv.xy=ar.yx;inv.yx=ar.xy;inv.xz=ar.zx;inv.zx=ar.xz;inv.yz=ar.zy;inv.zy=ar.yz;
 inv.xt=inv.yt=inv.zt=0;ar.identity=br.identity=inv.identity=0;br.xt=br.yt=br.zt=0;
 svxMatrix c=bridgeRotationAtCenters(rigidMul(br,inv),a,b);
 if(bridgeAcceptPose(a,b,c,fa,fb,axial,marker,undo,boolean)){out=c;return 1;}
 static const int perms[6][3]={{0,1,2},{0,2,1},{1,0,2},{1,2,0},{2,0,1},{2,1,0}};
 // Global orthogonal alternatives do not depend on unstable principal axes of plates.
 for(int pi=0;pi<6;pi++)for(int sx=-1;sx<=1;sx+=2)for(int sy=-1;sy<=1;sy+=2)for(int sz=-1;sz<=1;sz+=2){
  if(permParity(perms[pi])*sx*sy*sz<0)continue;
  double R[3][3]={{0}};R[0][perms[pi][0]]=sx;R[1][perms[pi][1]]=sy;R[2][perms[pi][2]]=sz;
  svxMatrix row=identityMatrix();row.identity=0;row.xx=R[0][0];row.xy=R[0][1];row.xz=R[0][2];row.yx=R[1][0];row.yy=R[1][1];row.yz=R[1][2];row.zx=R[2][0];row.zy=R[2][1];row.zz=R[2][2];
  c=bridgeRotationAtCenters(row,a,b);
  if(bridgeAcceptPose(a,b,c,fa,fb,axial,marker,undo,boolean)){out=c;return 1;}
  c=bridgeApiMatrix(candidateTransform(a,b,perms[pi],sx,sy,sz));c.identity=0;
  if(bridgeAcceptPose(a,b,c,fa,fb,axial,marker,undo,boolean)){out=c;return 1;}
 }
 double score=0,residual=0;
 if(pairTransformAccept(a,b,c,score,residual)){c=bridgeApiMatrix(c);c.identity=0;if(bridgeAcceptPose(a,b,c,fa,fb,axial,marker,undo,boolean)){out=c;return 1;}}
 return 0;
}
// IDs can change when export closes history. Resolve by actual referenced definition
// and verified pose; never trust an old numeric ID or label without checking it.
static int bridgeComponent(const char*file,const char*part,const svxMatrix&expected){
 int list[MAX_COMPS];int n=getComps(list,MAX_COMPS),found=0;if(n<0)return 0;
 for(int i=0;i<n;i++){char f[256]={},p[256]={};svxMatrix m=identityMatrix();
  if(!pCompPart(list[i],f,256,p,256)&&streq(f,file)&&streq(p,part)&&!pEntMatrix(list[i],&m)&&matrixVerified(m,expected)){if(found)return 0;found=list[i];}}
 return found;
}
extern "C" __declspec(dllexport) int DSAssemblyBuildMakietaPosed(int count,const int*source,const char (*names)[256],const svxMatrix*frames,const int*kinds){
 bridgeError[0]=0;if(count<=0||count>MAX_SHAPES||!source||!names||!frames||!kinds)return bridgeFail("DS Assembly V35: nieprawidlowa lista bryl.");
 if(!resolveCoreApi()||!resolveAssemblyApi()||!pNameSet||!pEntLabel||!pEntByLabel||!pRootActive)return bridgeFail("DS Assembly V35: brak wymaganych API.");
 PFN_marker marker=(PFN_marker)findExport("cvxUndoRedoMarker");PFN_undo undo=(PFN_undo)findExport("cvxUndoRedoTo");PFN_activate activate=(PFN_activate)findExport("cvxRootActivate2");PFN_bool boolean=(PFN_bool)findExport("cvxPartBool2");
 pCompIns=(PFN_cvxCompIns)findExport("cvxCompIns");pPntIsOn=(PFN_cvxPntIsOn)findExport("cvxPntIsOn");
 pDisplayFacets=(PFN_displayFacets)findExport("cvxPartRegenFacets");pShowEntity=(PFN_showEntity)findExport("cvxEntBlank");
 pSdkPnt=(PFN_sdkPntTransform)findExport("cvxPntTransform");pSdkInverse=(PFN_sdkMatInvert)findExport("cvxMatInvert");
 pFaceProjection=(PFN_faceProjection)findExport("cvxFacePntProj");pFaceLocation=(PFN_faceLocation)findExport("cvxFacePntLoc");
 if(!findExport("cvxPartAnchor")||!marker||!undo||!activate||!pCompIns||!pPntIsOn||!pDisplayFacets||!pShowEntity||!pSdkPnt||!pSdkInverse||!pFaceProjection||!pFaceLocation)return bridgeFail("DS Assembly V35: brak transakcji, aktywacji lub porownania bryl.");
 char parent[256]={},file[256]={};pRootActive(parent,256);pFileActive(file,256);if(!parent[0]||!file[0])return bridgeFail("DS Assembly V35: brak aktywnego pliku lub czesci.");
 static svxBndBox boxes[MAX_SHAPES];static char parts[MAX_SHAPES][256];static int masters[MAX_SHAPES],component[MAX_SHAPES],compLabels[MAX_SHAPES][MAX_LABEL];static svxMatrix delta[MAX_SHAPES],masterPose[MAX_SHAPES],expectedPose[MAX_SHAPES];
 int unique=0;
 for(int i=0;i<count;i++){
  int valid=analyzeShape(source[i],g_shapes[i]);const char*stage=analysisStage;
  if(valid&&!g_shapes[i].hasLabel){valid=0;stage="etykieta bryly";}
  if(valid&&!bridgeBox(source[i],boxes[i])){valid=0;stage="obwiednia globalna";}
  if(!valid){char detail[256];int pos=0;detail[0]=0;appendStr(detail,pos,256,"DS Assembly V35: element ");appendInt(detail,pos,256,i+1);appendStr(detail,pos,256," (");appendStr(detail,pos,256,names[i]);appendStr(detail,pos,256,"): ");appendStr(detail,pos,256,stage);return bridgeFail(detail);}
 }
 for(int i=0;i<count;i++){
  masters[i]=i;delta[i]=identityMatrix();
  for(int j=0;j<i;j++)if(masters[j]==j&&kinds[j]==kinds[i]){
   svxMatrix candidate;int match=bridgeCongruent(g_shapes[j],g_shapes[i],candidate,frames[j],frames[i],kinds[i]!=2&&kinds[j]!=2,marker,undo,boolean);
   if(match<0)return bridgeFail("DS Assembly V35: nie mozna cofnac porownania bryl.");
   if(match){masters[i]=j;delta[i]=candidate;break;}
  }
  if(masters[i]!=i){copystr(parts[i],parts[masters[i]],256);continue;}
  unique++;copystr(parts[i],names[i],256);int suffix=1;
  while(true){int used=rootExists(parts[i]);for(int j=0;j<i;j++)if(masters[j]==j&&streq(parts[i],parts[j]))used=1;if(!used)break;
   if(++suffix>999)return bridgeFail("DS Assembly V35: brak wolnej nazwy czesci.");copystr(parts[i],names[i],230);int n=0;while(parts[i][n])n++;appendStr(parts[i],n,256,"_");appendInt(parts[i],n,256,suffix);
  }
 }
 int initial=getComps(g_compBefore,MAX_COMPS);if(initial<0||initial+count>MAX_COMPS)return bridgeFail("DS Assembly V35: limit lub blad odczytu komponentow.");
 vxName mark={};if(marker(mark))return bridgeFail("DS Assembly V35: brak punktu cofania konwersji.");
 int failed=0;static int created[MAX_SHAPES];memset(created,0,sizeof(created));
 for(int i=0;i<count&&!failed;i++){
  int sid=currentShapeId(g_shapes[i]);if(sid<=0){failed=1;bridgeFail("DS Assembly V35: utracono bryle zrodlowa.");break;}
  int before=getComps(g_compBefore,MAX_COMPS),rc=0,cid=0;svxMatrix target=delta[i];
  if(masters[i]==i){
   svxGeomExport ex;memset(&ex,0,sizeof(ex));ex.numEnts=1;ex.idEnts=&sid;copystr(ex.Part,parts[i],256);ex.Frame=identityMatrix();ex.Option=1;ex.AddComponent=0;ex.NoExportOp=1;ex.Unblank=1;
   rc=pGeomExport(&ex);created[i]=rootExists(parts[i]);
  }else{
   int mi=masters[i];target=bridgeCompose(delta[i],masterPose[mi]);
  }
  // Independent insertion; Copy=0 means shared definition, not a cloned part.
  // Frame is persisted at insertion, with no later matrix-only override.
  svxCompData ins;memset(&ins,0,sizeof(ins));copystr(ins.File,file,256);copystr(ins.Part,parts[i],256);copystr(ins.Comp,parts[i],256);
  ins.Frame=target;ins.Anchor=1;ins.AutoRegen=1;ins.Copy=0;ins.AutoDelete=0;
  if(!rc)rc=pCompIns(&ins,&cid);
  int after=getComps(g_compAfter,MAX_COMPS);
  if(rc||before<0||after!=before+1||cid<=0){failed=1;bridgeFail("DS Assembly V35: nie powstal jeden niezalezny komponent.");break;}
  char rf[256]={},rp[256]={};svxMatrix pose=identityMatrix();
  int refRc=pCompPart(cid,rf,256,rp,256),poseRc=0;const char*reason=0;
  if(refRc)reason="odczyt referencji";else if(!streq(rf,file))reason="plik referencji";else if(!streq(rp,parts[i]))reason="nazwa referencji";
  else{poseRc=pEntMatrix(cid,&pose);if(poseRc)reason="odczyt macierzy";else if(!matrixVerified(pose,target))reason="macierz pozycji";}
  if(reason){failed=1;char detail[256];int pos=0;detail[0]=0;appendStr(detail,pos,256,"DS Assembly V35: element ");appendInt(detail,pos,256,i+1);appendStr(detail,pos,256,": ");appendStr(detail,pos,256,reason);appendStr(detail,pos,256,"; czesc=");appendStr(detail,pos,256,parts[i]);appendStr(detail,pos,256,"; odczyt=");appendStr(detail,pos,256,rp);appendStr(detail,pos,256,"; rc=");appendInt(detail,pos,256,refRc?refRc:poseRc);bridgeFail(detail);break;}
  if(masters[i]==i){
   masterPose[i]=pose;
   if(activate(rf,rp)){failed=1;bridgeFail("DS Assembly V35: nie mozna wejsc do czesci komponentu.");break;}
   int n=0,*solids=0;svxBndBox actual;svxMassProp mass;memset(&mass,0,sizeof(mass));
   int good=pShapes(0,0,&n,&solids)==0&&n==1&&solids&&bridgeBox(solids[0],actual)&&equalBox(boxes[i],actual)&&pMass(solids[0],7.85e-6,&mass)==0&&nearv(mass.Volume,g_shapes[i].mass.Volume,1e-7,.02);
   // Unblank the body in its definition and rebuild fine facets there.
   // Assembly cache refresh alone can retain hidden/coarse exported display data.
   if(good&&(pShowEntity(1,-n,solids)||pDisplayFacets(0,0,0,0,.01)))good=0;
   if(solids)pMemFree((void**)&solids);
   // Restore the previous target: DO NOT activate parent again (pushes stack).
   if(activate(0,0)){bridgeFail("DS Assembly V35: nie mozna zamknac wejscia do czesci; przerwano bez kolejnej aktywacji.");return 1;}
   if(!good){failed=1;bridgeFail("DS Assembly V35: geometria wyprowadzonej czesci niezgodna.");break;}
  }
  typedef int(*AnchorFn)(int);AnchorFn anchor=(AnchorFn)findExport("cvxPartAnchor");
  if(!anchor||anchor(cid)){failed=1;bridgeFail("DS Assembly V35: nie mozna utwierdzic komponentu.");break;}
  if(pShowEntity(1,1,&cid)){failed=1;bridgeFail("DS Assembly V35: nie mozna pokazac komponentu.");break;}
  if(pNameSet(cid,parts[i])){failed=1;bridgeFail("DS Assembly V35: nie mozna nazwac wystapienia.");break;}
  expectedPose[i]=target;component[i]=cid;int*label=0;memset(compLabels[i],0,sizeof(compLabels[i]));
  if(pEntLabel(cid,&label)||!label){failed=1;bridgeFail("DS Assembly V35: brak etykiety komponentu.");break;}
  int k=0;for(;k<MAX_LABEL-1&&label[k];k++)compLabels[i][k]=label[k];int good=label[k]==0;pMemFree((void**)&label);if(!good){failed=1;bridgeFail("DS Assembly V35: zbyt dluga etykieta komponentu.");break;}
 }
 if(!failed){static int eraseIds[MAX_SHAPES];int ready=1;
  for(int i=0;i<count;i++){eraseIds[i]=currentShapeId(g_shapes[i]);if(eraseIds[i]<=0)ready=0;}
  if(!ready||pErase(count,eraseIds)){failed=1;bridgeFail("DS Assembly V35: nie mozna usunac bryl po weryfikacji zlozenia.");}
 }
 if(!failed&&pDisplayFacets(0,0,1,0,.01)){failed=1;bridgeFail("DS Assembly V35: przebudowa zlozenia nie powiodla sie.");}
 if(!failed){static int resolved[MAX_SHAPES];
  for(int i=0;i<count;i++){
   int cid=bridgeComponent(file,parts[i],expectedPose[i]);
   if(!cid){failed=1;bridgeFail("DS Assembly V35: po przebudowie utracono referencje lub pozycje wystapienia.");break;}
   for(int j=0;j<i;j++)if(resolved[j]==cid){failed=1;bridgeFail("DS Assembly V35: dwa wystapienia wskazuja ten sam komponent.");break;}
   if(failed)break;resolved[i]=cid;
   typedef int(*AnchorFn)(int);AnchorFn anchor=(AnchorFn)findExport("cvxPartAnchor");
   if(!anchor||anchor(cid)){failed=1;bridgeFail("DS Assembly V35: nie mozna utwierdzic komponentu po przebudowie.");break;}
   svxMatrix check=identityMatrix();if(pEntMatrix(cid,&check)||!matrixVerified(check,expectedPose[i])){failed=1;bridgeFail("DS Assembly V35: po utwierdzeniu zmienila sie pozycja.");break;}
  }
 }
 int final=getComps(g_compAfter,MAX_COMPS),n=0,*solids=0;int rc=pShapes(0,0,&n,&solids);if(solids)pMemFree((void**)&solids);
 if(!failed&&(rc||n!=0||final!=initial+count)){failed=1;bridgeFail("DS Assembly V35: wynik nie jest pelnym zlozeniem.");}
 if(failed){char original[256];copystr(original,bridgeError,256);if(undo(1,mark)){copystr(bridgeError,"DS Assembly V35: cofniecie nieudane. Pierwszy blad: ",256);int pos=0;while(bridgeError[pos])pos++;appendStr(bridgeError,pos,256,original);msg(bridgeError);}else if(pRootDel)for(int i=0;i<count;i++)if(created[i]&&masters[i]==i&&rootExists(parts[i]))pRootDel(parts[i]);return 1;}
 char result[256];int pos=0;result[0]=0;appendStr(result,pos,256,"DS Assembly V35: ");appendInt(result,pos,256,unique);appendStr(result,pos,256," unikalnych czesci, ");appendInt(result,pos,256,count);appendStr(result,pos,256," wystapien. Zlozenie zweryfikowane.");msg(result);return 0;
}

#include "assembly_generic.h"

extern "C" __declspec(dllexport) int DSAssemblyBuildPosed(int count,const int*source,const char (*names)[256],const svxMatrix*frames,const int*kinds){return DSAssemblyBuildMakietaPosed(count,source,names,frames,kinds);}
