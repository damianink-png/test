# DS Makieta 2019 V36 UI3 — wbudowany podgląd statyczny

Jedno szersze okno z parametrami po lewej i **wbudowanym obrazem poglądowym makiety** po prawej. Geometria generatora pozostaje z poprzedniej wersji, a obraz 3D jest statyczną ilustracją dla wartości domyślnych, nie jest generowany na żywo z CAD.

Podgląd BMP jest kompilowany jako zasób nr 101 do DSMakieta2019.dll; dzięki temu plik BMP nie jest potrzebny przy uruchamianiu DLL. W tej paczce dołączono pliki źródłowe i instalator do GitHub Actions lub kompilacji lokalnej; NIE ma nowej, skompilowanej DLL Makiety.

Instrukcja GitHub: `GITHUB_START_TUTAJ.md`. Lokalnie: `KOMPILUJ_MAKIETE.bat`.

Przed uruchomieniem wyłącz ZW3D i zachowaj kopię poprzedniej DLL. Ładuj razem `DSMakieta2019.dll` i dołączoną `DSAssembly2019.dll`.
