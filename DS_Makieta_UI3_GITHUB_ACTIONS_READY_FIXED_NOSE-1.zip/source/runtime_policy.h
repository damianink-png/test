#pragma once
#include <math.h>
static bool massFromVolume(int rc,double volume,double&kg){
 kg=0;if(rc!=0||!isfinite(volume)||volume<=0)return false;
 kg=volume*7.85e-6;return isfinite(kg)&&kg>0;
}
static bool uniqueReplacement(const int*before,int nb,const int*after,int na,int&id){
 if(nb!=na||nb<1||!before||!after)return false;
 int changed=0,candidate=0;
 for(int j=0;j<na;j++){bool old=false;for(int k=0;k<nb;k++)if(after[j]==before[k]){old=true;break;}if(!old){candidate=after[j];changed++;}}
 if(changed!=1||candidate<=0)return false;id=candidate;return true;
}

static bool finiteBounds(double xmin,double xmax,double ymin,double ymax,double zmin,double zmax,bool solid){
 const double vals[]={xmin,xmax,ymin,ymax,zmin,zmax};
 for(double v:vals)if(!isfinite(v))return false;
 if(xmax<xmin||ymax<ymin||zmax<zmin)return false;
 return !solid||(xmax-xmin>1e-7&&ymax-ymin>1e-7&&zmax-zmin>1e-7);
}
