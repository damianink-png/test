# DS Makieta V36 UI2 R2 — poprawka kompilacji

W logu R1: `makieta_ui_v36.h(326): error C3861: TranslateMessageA`.
Zmieniono na WinAPI `TranslateMessage(&m)` (ta funkcja nie ma wariantow A/W).
Pozostawiono stabilny MSVC_WORKER.cmd, ktory w poprzednim teście prawidlowo
uruchomil `vcvars64.bat`, `cl.exe` i `link.exe`.
Kod geometrii, szablony i nazwy polecen pozostaly bez zmian.

Uruchom `KOMPILUJ_MAKIETE.bat`, wynik w `output/DSMakieta2019.dll`.
Zewnetrzna `DSAssembly2019.dll` kopiowana jest z `compatible_partner/`.

Nie twierdzimy, ze kod przeszedl kompilacje MSVC: na tym serwerze
nie jest zainstalowany Windows SDK ani MSVC. Test w ZW3D 2019 wymagany.
