@echo off
setlocal
cd /d "%~dp0"
if not exist output mkdir output
>"output\START_BAT.log" echo START DS Makieta V36 UI3 EMBEDDED
>>"output\START_BAT.log" echo Date=%DATE% %TIME%
>>"output\START_BAT.log" echo Folder=%CD%
echo.
echo DS Makieta 2019 V36 UI3 EMBEDDED - kompilacja MSVC x64
where powershell.exe >nul 2>&1
if errorlevel 1 goto :NoPowerShell
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0KOMPILUJ_MAKIETE.ps1" >>"output\START_BAT.log" 2>&1
set "DS_RC=%errorlevel%"
if "%DS_RC%"=="0" goto :Success
echo BLAD: zobacz output\KOMPILACJA_MAKIETA.log, output\START_BAT.log
exit /b %DS_RC%
:NoPowerShell
>>"output\START_BAT.log" echo ERROR=POWERSHELL_NOT_FOUND
pause
exit /b 21
:Success
echo.
echo SUKCES: output\DSMakieta2019.dll
 echo W tym samym folderze: output\DSAssembly2019.dll
 echo Najpierw test: ~DSMakietaUITest
pause
exit /b 0
