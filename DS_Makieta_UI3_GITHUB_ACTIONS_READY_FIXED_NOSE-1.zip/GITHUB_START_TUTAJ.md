# DS Makieta UI3 — kompilacja bez lokalnego Visual Studio

Repozytorium na GitHubie: na stronie repozytorium **Add file -> Upload files**.
Prześlij zawartość tego rozpakowanego folderu, **nie sam plik ZIP**. Folder `.github` musi się znaleźć w repozytorium (w nim plik `.github/workflows/build-ds-makieta-ui3.yml`).

Po `Commit changes` otwórz zakładkę **Actions** i wybierz zadanie `Build DS Makieta UI3 DLL (Windows x64)`.
Jeżeli nie wystartowało automatycznie, naciśnij **Run workflow**.

Po zakończeniu otwórz przebieg (zielony znacznik) i z sekcji **Artifacts** pobierz `DS-Makieta-UI3-Windows-x64-DLL`.

W środku powinny być:
- `DSMakieta2019.dll` (kompilowana w chmurze)
- `DSAssembly2019.dll` (wersja zgodna z paczką)

Statyczny obraz makiety jest teraz **wewnątrz DLL**, osadzony przez kompilator zasobów Windows (`rc.exe`), więc nie trzeba kopiować folderu `assets` do ZW3D.

Powyższe zadanie nie sprawdza kompatybilności z ZW3D 2019/2025. Pierwszy test wykonaj na kopii części.

**Uwaga:** jeśli repozytorium jest publiczne, te pliki źródłowe i obraz również będą publiczne. Dla prywatnego projektu lepiej użyć repozytorium Private.
