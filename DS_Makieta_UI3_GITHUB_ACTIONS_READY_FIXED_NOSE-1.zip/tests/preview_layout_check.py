# Independent geometry-level bounds check for screen-space preview.
from math import floor

def mapx(x, xmin, xmax, left=654, right=1126):
    t=max(0,min(1,(x-xmin)/max(xmax-xmin,1)))
    return left+round((right-left)*t)

def mapz(z,h,bottom=307,top=178):
    t=max(0,min(1,z/max(h,1)))
    return bottom-round((bottom-top)*t)

cnt=0
for L in (600,800,1600,2600,3600,5000,12000,20000):
 for nose in (100,L*.2,L*.5,L-110):
  for tail in (0,50,300,L*.8):
   for H in (200,390,950,3000):
    for Z in (0,H/5,H/2,H):
     xmin=min(-tail,0)
     for v in (0,L-nose,L,-tail):
      assert 654<=mapx(v,xmin,L)<=1126
     for v in (0,Z,H):
      assert 178<=mapz(v,H)<=307
     cnt+=1
print(f'PASS preview coordinates bounded in {cnt} scenarios')
