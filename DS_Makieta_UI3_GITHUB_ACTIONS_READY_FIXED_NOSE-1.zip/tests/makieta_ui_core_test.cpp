#include "../source/makieta_core.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
static bool approx(double a,double b){return fabs(a-b)<1e-8;}
int main(){
 Config c=defaults();Plan p={};char err[256]={};
 assert(configValid(c,err));assert(makePlan(c,p,err));
 assert(p.count>20 && p.count<=1800);
 assert(p.fields>=1 && p.fields<=80);
 assert(p.angle>=30 && p.angle<=60);
 assert(approx(p.mainLen,c.L-c.nose));
 bool hasHole=false;for(int i=0;i<p.count;i++){
  if(p.m[i].hole)hasHole=true;
  assert(isfinite(p.m[i].a.x) && isfinite(p.m[i].b.z));
 }
 assert(hasHole);
 Config wrong=c;wrong.gap=-1;assert(!configValid(wrong,err));
 wrong=c;wrong.holeZ=c.H+10;assert(!configValid(wrong,err));
 wrong=c;wrong.holeD=c.profile;assert(!configValid(wrong,err));
 wrong=c;wrong.nose=c.L;assert(!configValid(wrong,err));
 printf("PASS core geometry: %d parts, %d fields, angle=%.2f deg\n",p.count,p.fields,p.angle);
 return 0;
}
