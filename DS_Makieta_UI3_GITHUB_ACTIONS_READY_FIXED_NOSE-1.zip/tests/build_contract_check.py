from pathlib import Path
r=Path(__file__).resolve().parents[1]
u=(r/'source/makieta_ui_v36.h').read_text(encoding='utf-8')
p=(r/'KOMPILUJ_MAKIETE.ps1').read_text(encoding='utf-8-sig')
w=(r/'MSVC_WORKER.cmd').read_text(encoding='ascii')
assert 'TranslateMessageA' not in u
assert u.count('TranslateMessage(&m)')==1
assert '& $worker 2>&1' in p and 'vcvars64.bat' in p
assert 'DSMakieta2019.dll' in w and 'comctl32.lib' in w
print('PASS R2 build script and WinAPI regression checks (no MSVC execution)')
