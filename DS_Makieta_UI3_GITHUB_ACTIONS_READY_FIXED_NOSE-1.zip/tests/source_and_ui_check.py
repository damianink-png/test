from pathlib import Path
import hashlib,re
base=Path(__file__).resolve().parents[1]
src=(base/'source/DSMakieta2019.cpp').read_text(encoding='utf-8')
ui=(base/'source/makieta_ui_v36.h').read_text(encoding='utf-8')
core=(base/'source/makieta_core.h').read_bytes()
assert '#include "makieta_ui_v36.h"' in src
assert 'DSAssemblyMakietaVersion' not in ui
assert 'loadAssembly()' in src and 'convertAssembly()' in src
assert 'DSMakieta2019Init' in src and 'DSMakieta2019Exit' in src
assert 'InitCommonControlsEx' in ui
assert 'paintPreview' in ui and 'showPlan' in ui
assert 'TTM_ADDTOOLA' in ui
assert 'saveSettings(c)' in ui and 'loadSettings(c)' in ui
assert 'case WM_PAINT:' in ui
assert all(f'"{s}"' in ui for s in ('L','W','H','N','T','Z','D','G'))
assert len(re.findall(r'&Config::(?:L|W|H|nose|tail|holeZ|holeD|gap)\b',ui))==8
original=Path('/mnt/data/makieta_work/v35/makieta_assembly/makieta_core.h')
if original.exists(): assert original.read_bytes()==core, 'CAD geometry modified unexpectedly'
print('PASS UI integration and unchanged geometry; core_sha256='+hashlib.sha256(core).hexdigest())

# Win32 TranslateMessage has no ANSI/Wide suffix; reject old regression.
ui=(base/'source'/'makieta_ui_v36.h').read_text(encoding='utf-8')
assert 'TranslateMessageA' not in ui
assert 'TranslateMessage(&m)' in ui
