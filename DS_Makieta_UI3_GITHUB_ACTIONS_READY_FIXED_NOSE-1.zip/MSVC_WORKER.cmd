@echo off
setlocal EnableExtensions DisableDelayedExpansion
echo STAGE=WORKER_STARTED
cd /d "%DS_ROOT%"
if not exist "%DS_VCVARS%" goto :MissingVcvars
call "%DS_VCVARS%"
if errorlevel 1 goto :InitFailed
echo STAGE=VCVARS_RETURNED
where cl.exe
if errorlevel 1 goto :MissingCl
where link.exe
if errorlevel 1 goto :MissingLink
echo STAGE=COMPILE_RESOURCE
where rc.exe
if errorlevel 1 goto :MissingRc
rc.exe /nologo /fo "%DS_OUT%\makieta_preview.res" "%DS_ROOT%\source\makieta_preview.rc"
if errorlevel 1 goto :RcFailed
if not exist "%DS_OUT%\makieta_preview.res" goto :RcFailed
echo STAGE=COMPILE_AND_LINK
cl.exe /nologo /std:c++17 /EHsc /O2 /W3 /MD /LD /D_CRT_SECURE_NO_WARNINGS /DWINVER=0x0601 /D_WIN32_WINNT=0x0601 /Fo"%DS_OUT%\DSMakieta2019.obj" /Fe"%DS_OUT%\DSMakieta2019.dll" "%DS_ROOT%\source\DSMakieta2019.cpp" /link /MACHINE:X64 "%DS_OUT%\makieta_preview.res" /IMPLIB:"%DS_OUT%\DSMakieta2019.lib" user32.lib gdi32.lib comctl32.lib kernel32.lib
if errorlevel 1 goto :CompileFailed
if not exist "%DS_OUT%\DSMakieta2019.dll" goto :MissingDll
where dumpbin.exe >nul 2>&1
if errorlevel 1 goto :Success
dumpbin.exe /exports "%DS_OUT%\DSMakieta2019.dll" >"%DS_OUT%\exports.txt" 2>&1
if errorlevel 1 goto :BadExports
findstr /L /C:"DSMakieta2019Init" "%DS_OUT%\exports.txt" >nul
if errorlevel 1 goto :BadExports
findstr /L /C:"DSMakieta2019Exit" "%DS_OUT%\exports.txt" >nul
if errorlevel 1 goto :BadExports
:Success
echo BUILD_OK
exit /b 0
:MissingVcvars
echo ERROR=VCVARS64_NOT_FOUND
exit /b 10
:InitFailed
echo ERROR=VCVARS64_FAILED
exit /b 11
:MissingCl
echo ERROR=CL_EXE_NOT_FOUND
exit /b 12
:MissingLink
echo ERROR=LINK_EXE_NOT_FOUND
exit /b 13
:CompileFailed
echo ERROR=CPP_COMPILATION_FAILED
exit /b 14
:MissingDll
echo ERROR=COMPILE_SUCCEEDED_BUT_NO_DLL
exit /b 15
:BadExports
echo ERROR=INIT_EXIT_EXPORTS_NOT_FOUND
exit /b 16

:MissingRc
echo ERROR=RC_EXE_NOT_FOUND
exit /b 17
:RcFailed
echo ERROR=RESOURCE_COMPILATION_FAILED
exit /b 18
