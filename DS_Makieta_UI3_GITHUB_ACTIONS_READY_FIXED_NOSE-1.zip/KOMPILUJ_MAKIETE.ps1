$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$out = Join-Path $root 'output'
New-Item -Path $out -ItemType Directory -Force | Out-Null
$log = Join-Path $out 'KOMPILACJA_MAKIETA.log'
$status = Join-Path $out 'STATUS_KOMPILACJI.txt'
$worker = Join-Path $root 'MSVC_WORKER.cmd'
$dll = Join-Path $out 'DSMakieta2019.dll'
$cpp = Join-Path $root 'source\DSMakieta2019.cpp'
Set-Content -LiteralPath $log -Value 'DS Makieta V36 UI3 - embedded preview MSVC x64 build log' -Encoding UTF8
Set-Content -LiteralPath $status -Value 'STARTED' -Encoding ASCII
function Log([string]$line) {
  Add-Content -LiteralPath $log -Value $line -Encoding UTF8
  Write-Host $line
}
function Fail([string]$reason, [int]$code) {
  Log ('ERROR=' + $reason)
  Set-Content -LiteralPath $status -Value ('ERROR=' + $reason) -Encoding ASCII
  exit $code
}
try {
  Log ('DATE=' + [DateTime]::Now.ToString('yyyy-MM-dd HH:mm:ss'))
  Log ('ROOT=' + $root)
  Log ('PSVERSION=' + $PSVersionTable.PSVersion.ToString())
  if (!(Test-Path -LiteralPath $cpp)) { Fail 'SOURCE_NOT_FOUND' 31 }
  if (!(Test-Path -LiteralPath $worker)) { Fail 'WORKER_NOT_FOUND' 32 }
  if (!(Test-Path -LiteralPath (Join-Path $root 'compatible_partner\DSAssembly2019.dll'))) { Fail 'PARTNER_DLL_NOT_FOUND' 33 }
  $pf86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
  $pf = [Environment]::GetEnvironmentVariable('ProgramFiles')
  $installations = New-Object 'System.Collections.Generic.List[string]'
  foreach ($base in @($pf86,$pf)) {
    if ([string]::IsNullOrWhiteSpace($base)) { continue }
    $whereExe = Join-Path $base 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (Test-Path -LiteralPath $whereExe) {
      Log ('VSWHERE=' + $whereExe)
      $res = @(& $whereExe -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath)
      foreach ($item in $res) { if (![string]::IsNullOrWhiteSpace($item)) { $installations.Add($item.Trim()) } }
    }
    foreach ($year in @('2026','2022','2019','2017')) {
      foreach ($edition in @('BuildTools','Community','Professional','Enterprise')) {
        $candidate = Join-Path $base ('Microsoft Visual Studio\' + $year + '\' + $edition)
        if (Test-Path -LiteralPath $candidate) { $installations.Add($candidate) }
      }
    }
  }
  $vcvars = $null
  foreach ($instance in $installations) {
    $candidate = Join-Path $instance 'VC\Auxiliary\Build\vcvars64.bat'
    if (Test-Path -LiteralPath $candidate) { $vcvars = $candidate; break }
  }
  if (!$vcvars) { Fail 'MSVC_CPP_X64_COMPONENT_MISSING' 34 }
  Log ('VCVARS=' + $vcvars)
  if (Test-Path -LiteralPath $dll) {
    try { Remove-Item -LiteralPath $dll -Force -ErrorAction Stop }
    catch { Fail 'OLD_DLL_LOCKED_CLOSE_ZW3D' 35 }
  }
  $env:DS_ROOT = $root
  $env:DS_OUT = $out
  $env:DS_VCVARS = $vcvars
  Log 'STAGE=RUN_WORKER'
  $ErrorActionPreference = 'Continue'
  & $worker 2>&1 | ForEach-Object { Log ([string]$_) }
  $rc = $LASTEXITCODE
  $ErrorActionPreference = 'Stop'
  Log ('WORKER_EXIT_CODE=' + $rc)
  if ($rc -ne 0) { Fail ('WORKER_FAILED_' + $rc) 36 }
  if (!(Test-Path -LiteralPath $dll)) { Fail 'OUTPUT_DLL_MISSING' 37 }
  $bytes = [IO.File]::ReadAllBytes($dll)
  if ($bytes.Length -lt 256 -or $bytes[0] -ne 77 -or $bytes[1] -ne 90) { Fail 'DLL_NOT_PE_FILE' 38 }
  $offset = [BitConverter]::ToInt32($bytes, 0x3c)
  if ($offset -lt 64 -or ($offset+6) -ge $bytes.Length) { Fail 'PE_OFFSET_INVALID' 39 }
  if ($bytes[$offset] -ne 0x50 -or $bytes[$offset+1] -ne 0x45) { Fail 'PE_SIGNATURE_INVALID' 40 }
  $machine = [BitConverter]::ToUInt16($bytes, $offset+4)
  if ($machine -ne 0x8664) { Fail ('INVALID_ARCH_' + $machine) 41 }
  Copy-Item -LiteralPath (Join-Path $root 'compatible_partner\DSAssembly2019.dll') -Destination (Join-Path $out 'DSAssembly2019.dll') -Force
  Log ('MAKIETA_DLL_SHA256=' + (Get-FileHash -LiteralPath $dll -Algorithm SHA256).Hash)
  Log 'BUILD_OK_DLL_X64_UNTESTED_IN_ZW3D'
  Set-Content -LiteralPath $status -Value 'BUILD_OK' -Encoding ASCII
  exit 0
} catch {
  Log ('POWERSHELL_EXCEPTION=' + $_.Exception.ToString())
  Set-Content -LiteralPath $status -Value 'ERROR=POWERSHELL_EXCEPTION' -Encoding ASCII
  exit 42
}
