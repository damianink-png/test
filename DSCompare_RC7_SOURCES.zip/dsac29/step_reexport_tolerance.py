"""Numerical STEP re-export equivalence, restricted to an independently proven frame.

This verifies actual CAD face types, topology counts, world face bounds, areas
and face centroids. Names and STEP labels NEVER establish equivalence.
Only enabled *after* a strong global-translation consensus. It does not replace
ordinary strict Boolean B-Rep comparison for unchanged CAD frames.
"""
from __future__ import annotations
from collections import defaultdict
from math import floor, sqrt
import numpy as np
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.BRepBndLib import BRepBndLib
from OCP.BRepGProp import BRepGProp
from OCP.Bnd import Bnd_Box
from OCP.GProp import GProp_GProps
from OCP.TopExp import TopExp_Explorer
from OCP.TopAbs import TopAbs_FACE
from OCP.TopoDS import TopoDS


def coarse_candidate(a,b,tol):
    """Only a hypothesis prefilter, never proof of identity."""
    if min(a.volume,b.volume)<=0:return False
    if abs(a.volume-b.volume)>max(1e-3,1e-4*max(a.volume,b.volume)):return False
    if abs(a.area-b.area)>max(1e-3,1e-4*max(a.area,b.area)):return False
    return bool(np.allclose(a.eigenvalues,b.eigenvalues,rtol=2.e-4,atol=.1))


def world_candidate(a,b,tol):
    """Permissive search filter, NEVER identity proof.

    STEP p-curve reconstruction changes integrated properties even when all
    original 3-D surfaces and oriented trims agree within the requested tol.
    These margins only admit candidates for the full geometric proof below.
    """
    if min(a.volume,b.volume)<=0:return False
    return (abs(a.volume-b.volume)<=max(1.,.02*max(a.volume,b.volume))
            and abs(a.area-b.area)<=max(1.,.02*max(a.area,b.area)))

def search_radius(tolerance):
    # Integrated centroids are not geometric bounds. This radius is only for
    # candidate lookup; exact solid/face bounds retain the user's tolerance.
    return max(float(tolerance),.1)


def _faces(part):
    result=[]
    ex=TopExp_Explorer(part.shape,TopAbs_FACE)
    while ex.More():
        f=TopoDS.Face_s(ex.Current())
        p=GProp_GProps();BRepGProp.SurfaceProperties_s(f,p)
        center=p.CentreOfMass()
        bound=Bnd_Box();BRepBndLib.AddOptimal_s(f,bound,False,False)
        result.append((str(BRepAdaptor_Surface(f).GetType()),int(f.Orientation()),float(p.Mass()),
                       np.array([center.X(),center.Y(),center.Z()]),np.array(bound.Get())))
        ex.Next()
    return result


def reexport_equivalent_world(a,b,tolerance=.01, *, allow_boolean=True, progress=None):
    """Face prefilter followed by independent solid Boolean verification.

    Small STEP round-trip fluctuations are permitted only within the supplied
    coordinate tolerance; a truly added/removed feature changes the face set
    or fails an original-face geometry requirement. A positive result does not
    mean byte-identical STEP files.
    """
    report=progress or (lambda phase: None)
    report('prefilter')
    if not world_candidate(a,b,tolerance):return False
    # SolidInfo.bbox uses a conservative, triangulation-inflated bounding box.
    # STEP retransfers can change its deflection by millimetres for the SAME
    # analytic surface. Exact OCP bounds below are the geometric test instead.
    report('exact_bounds')
    exact_a=Bnd_Box();BRepBndLib.AddOptimal_s(a.shape,exact_a,False,False)
    exact_b=Bnd_Box();BRepBndLib.AddOptimal_s(b.shape,exact_b,False,False)
    if np.max(np.abs(np.asarray(exact_a.Get())-np.asarray(exact_b.Get())))>tolerance:return False
    report('face_descriptors')
    fa=_faces(a);fb=_faces(b)
    if len(fa)!=len(fb) or not fa:return False
    # Spatially indexed CAD face matching handles STEP face ordering changes.
    cell=max(.03,3*tolerance)
    buckets=defaultdict(list)
    for i,(typ,ori,area,c,box) in enumerate(fb):
        key=(typ,ori,*(floor(float(v)/cell) for v in c))
        buckets[key].append(i)
    from itertools import product
    options=[]
    for typ,ori,area,c,box in fa:
        index=tuple(floor(float(v)/cell) for v in c)
        available=[]
        for d in product((-1,0,1),repeat=3):
            for j in buckets.get((typ,ori,*(index[k]+d[k] for k in range(3))),()):
                _,_,area_b,cb,bb=fb[j]
                dc=float(np.linalg.norm(c-cb))
                if dc>tolerance:continue
                da=abs(area-area_b)
                area_lim=max(.1,2*tolerance*sqrt(max(1.,area,area_b)))
                if da>area_lim:continue
                db=float(np.max(np.abs(box-bb)))
                if db>tolerance:continue
                score=dc/max(tolerance,1e-6)+da/area_lim+db/max(tolerance,1e-6)
                available.append((score,j))
        if not available:return False
        options.append([j for score,j in sorted(available)])
    # Perfect face correspondence: repeated coplanar surfaces can have several
    # equally good partners, so greedy matching alone gives false negatives.
    owner={}
    def assign(i,visited):
        for j in options[i]:
            if j in visited:continue
            visited.add(j)
            if j not in owner or assign(owner[j],visited):
                owner[j]=i
                return True
        return False
    import sys
    if len(fa)+100>sys.getrecursionlimit():sys.setrecursionlimit(len(fa)+100)
    for i in sorted(range(len(fa)),key=lambda x:len(options[x])):
        if not assign(i,set()):return False
    if len(owner)!=len(fa):return False
    report('solid_validity')
    if not shape_valid(a.shape) or not shape_valid(b.shape):return False
    from .parametric_identity import prove
    report('surface_and_trim_proof')
    if prove(a.shape,b.shape,owner,fa,tolerance):return True
    report('boolean_residual' if allow_boolean else 'inconclusive')
    return _verified_difference_empty(a.shape,b.shape,tolerance) if allow_boolean else False


def shape_valid(shape):
    from OCP.BRepCheck import BRepCheck_Analyzer
    return not shape.IsNull() and BRepCheck_Analyzer(shape).IsValid()


def _verified_difference_empty(a,b,tolerance):
    """Build intersections once, then verify both independent residual regions."""
    from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
    from OCP.BOPAlgo import BOPAlgo_PaveFiller
    from OCP.TopTools import TopTools_ListOfShape
    from .material_deltas import volume
    if not np.isfinite(tolerance) or tolerance<=0:return False
    arguments=TopTools_ListOfShape();arguments.Append(a);arguments.Append(b)
    filler=BOPAlgo_PaveFiller();filler.SetArguments(arguments)
    filler.SetNonDestructive(True);filler.SetFuzzyValue(float(tolerance));filler.Perform()
    if filler.HasErrors():return False
    for first,second in ((a,b),(b,a)):
        left=TopTools_ListOfShape();left.Append(first)
        right=TopTools_ListOfShape();right.Append(second)
        op=BRepAlgoAPI_Cut(filler)
        try:
            op.SetArguments(left);op.SetTools(right)
            op.SetNonDestructive(True);op.SetFuzzyValue(float(tolerance));op.Build()
            if not op.IsDone():return False
            residual=op.Shape()
            if not shape_valid(residual):return False
            if volume(residual)>tolerance**3:return False
        finally:
            # The operator borrows the native filler; destroy it first.
            del op
    return True
