// DS Assembly Compare V2.2 Preview — ZW3D 2019 Standard x64
// Native Win32 file picker + non-destructive colored assembly overlay.
// ABI definitions adapted from ZW3D 2019 API (VxApi.h supplied by the user).
// No ZW3D SDK/lib dependency during CI; API functions are resolved at runtime.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define PSAPI_VERSION 1
#include <windows.h>
#include <psapi.h>
#include <commdlg.h>
#include <shlobj.h>
#include <shellapi.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cwchar>
#include <ctime>
#include <map>
#include <memory>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <fstream>
#include "compare_core.hpp"
#include "overlay_policy.hpp"
#include "root_picker_policy.hpp"

namespace {
// ZW3D ABI layout; checked against VxApi.h (svxMatrix 104,
// svxData 368, svxCompData 2032 bytes on x64 MSVC).
struct Point {double x,y,z;};
struct Matrix {char identity; double xx,yx,zx,xt,xy,yy,zy,yt,xz,yz,zz,zt;};
struct NumberInput {char flags[8]; int idEntity,idParent,numberType; double number; int pointType; Point point,dir; double params[3];char text[256];};
struct CompData {char dir[256],file[256],part[256],comp[256];Matrix frame; int anchor,regen,autoDelete,copy;char copyName[256];int overwrite;char destFile[256];int align;NumberInput alignData;};
struct MassProp {double density,area,volume,mass;Point center;Point axes[3];double im[6],ip[3],radii[3];};
static_assert(sizeof(Matrix)==104,"ZW3D matrix layout mismatch");
static_assert(sizeof(NumberInput)==368,"ZW3D data layout mismatch");
static_assert(sizeof(CompData)==2032,"ZW3D component layout mismatch");
using FnCmd=int(*)(const char*,void*,double);
using FnUnload=int(*)(const char*);
using FnMsg=void(*)(char*);
using FnFree=void(*)(void**);
using FnFileOpen=int(*)(char*);
using FnFileNew=int(*)(char*);
using FnFileSave=int(*)(int);
using FnFileActivate=int(*)(char*);
using FnActive=void(*)(char*,int);
using FnRootList=int(*)(char*,int*,char(**)[256]);
using FnRootIsAsm=int(*)(char*,char*,int*);
using FnRootActivate2=int(*)(char*,char*);
using FnRootAdd=int(*)(int,char*,const char*);
using FnComps=int(*)(char*,char*,int*,int**);
using FnPart=int(*)(int,char*,int,char*,int);
using FnName=int(*)(int,char*,int);
using FnMatrix=int(*)(int,Matrix*);
using FnCompIns=int(*)(CompData*,int*);
using FnColor=int(*)(int,int,int*);
using FnTransparency=int(*)(int,int,int*);
using FnEntityName=int(*)(int,const char*);
using FnEntityLayer=int(*)(int,char*);
using FnShapes=int(*)(char*,char*,int*,int**);
using FnMass=int(*)(int,double,MassProp*);
using FnShapeList=int(*)(int,int*,int**);
struct Api {
  FnCmd cmd=nullptr;FnUnload unload=nullptr;FnMsg msg=nullptr;FnFree freeMem=nullptr;
  FnFileOpen open=nullptr;FnFileNew makeFile=nullptr;FnFileSave save=nullptr;
  FnFileActivate activateFile=nullptr;FnActive activeFile=nullptr,activeRoot=nullptr;
  FnRootList roots=nullptr;FnRootIsAsm isAsm=nullptr;FnRootActivate2 activateRoot=nullptr;FnRootAdd addRoot=nullptr;
  FnComps comps=nullptr;FnPart compPart=nullptr;FnName name=nullptr;FnMatrix matrix=nullptr;
  FnCompIns insert=nullptr;FnColor color=nullptr;FnTransparency transparency=nullptr;
  FnEntityName rename=nullptr;FnEntityLayer layer=nullptr;
  FnShapes shapes=nullptr;FnMass mass=nullptr;FnShapeList faces=nullptr,edges=nullptr;
} api;

std::wstring g_logFile;
std::wstring g_lastHtml;
std::string g_issue;
HMODULE g_module=nullptr;
HINSTANCE g_instance=nullptr;
HWND g_dialog=nullptr;
std::wstring g_docA,g_docB,g_out,g_rootA,g_rootB;
bool g_checkedGeometry=false;
bool g_generate3D=true;

std::wstring toWide(const std::string&s){ if(s.empty())return L"";int n=MultiByteToWideChar(CP_ACP,0,s.c_str(),-1,nullptr,0);if(n<=1)return L"";std::wstring w(size_t(n),L'\0');MultiByteToWideChar(CP_ACP,0,s.c_str(),-1,&w[0],n);w.pop_back();return w; }
std::string ansi(const std::wstring&w){ if(w.empty())return {};int n=WideCharToMultiByte(CP_ACP,WC_NO_BEST_FIT_CHARS,w.c_str(),-1,nullptr,0,nullptr,nullptr);if(n<=1)return {};std::string s(size_t(n),0);BOOL fallback=FALSE;WideCharToMultiByte(CP_ACP,WC_NO_BEST_FIT_CHARS,w.c_str(),-1,&s[0],n,nullptr,&fallback);if(fallback)return {};s.pop_back();return s; }
std::string utf8(const std::wstring&w){if(w.empty())return {};int n=WideCharToMultiByte(CP_UTF8,0,w.c_str(),int(w.size()),nullptr,0,nullptr,nullptr);std::string s(size_t(n),0);if(n)WideCharToMultiByte(CP_UTF8,0,w.c_str(),int(w.size()),&s[0],n,nullptr,nullptr);return s;}
std::wstring widenAnsi(const char*s){if(!s||!*s)return {};int n=MultiByteToWideChar(CP_ACP,0,s,-1,nullptr,0);std::wstring w(size_t(n),0);MultiByteToWideChar(CP_ACP,0,s,-1,&w[0],n);w.pop_back();return w;}
std::wstring dirOf(const std::wstring&f){auto p=f.find_last_of(L"\\/");return p==std::wstring::npos?L"":f.substr(0,p);}
std::wstring baseOf(const std::wstring&f){auto p=f.find_last_of(L"\\/");return p==std::wstring::npos?f:f.substr(p+1);}
std::wstring stemOf(const std::wstring&f){auto s=baseOf(f);auto p=s.find_last_of(L'.');return p==std::wstring::npos?s:s.substr(0,p);}
std::string quote(const std::string&s){std::string o="\"";for(char c:s){if(c=='\"')o+='\"';o+=c;}return o+'\"';}
std::string escapeHtml(const std::string&s){std::string o;for(char c:s){if(c=='&')o+="&amp;";else if(c=='<')o+="&lt;";else if(c=='>')o+="&gt;";else if(c=='\"')o+="&quot;";else o+=c;}return o;}
std::string num(double n){std::ostringstream s;s<<std::fixed<<std::setprecision(3)<<n;return s.str();}

void logLine(const std::string&s){
 if(g_logFile.empty()){wchar_t tmp[MAX_PATH]={};if(GetTempPathW(MAX_PATH,tmp))g_logFile=std::wstring(tmp)+L"DSAC_V22_TRACE.log";}
 if(g_logFile.empty())return;
 HANDLE fd=CreateFileW(g_logFile.c_str(),FILE_APPEND_DATA,FILE_SHARE_READ|FILE_SHARE_WRITE,nullptr,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
 if(fd==INVALID_HANDLE_VALUE)return;
 SYSTEMTIME st;GetLocalTime(&st);char clock[64]={};sprintf_s(clock,"%02u:%02u:%02u.%03u ",st.wHour,st.wMinute,st.wSecond,st.wMilliseconds);
 std::string ln=std::string(clock)+s+"\r\n";DWORD n=0;WriteFile(fd,ln.data(),(DWORD)ln.size(),&n,nullptr);FlushFileBuffers(fd);CloseHandle(fd);
}
void showErr(HWND hwnd,const std::string&s){logLine("ERROR: "+s);MessageBoxW(hwnd,toWide(s).c_str(),L"DS Assembly Compare",MB_ICONERROR|MB_OK);}
void showNotice(HWND hwnd,const std::wstring&s){MessageBoxW(hwnd,s.c_str(),L"DS Assembly Compare",MB_ICONINFORMATION|MB_OK);}
void* symbol(const char*s){HMODULE modules[2048]={};DWORD bytes=0;
 if(!EnumProcessModules(GetCurrentProcess(),modules,sizeof(modules),&bytes))return nullptr;
 const DWORD count=std::min<DWORD>(2048,bytes/sizeof(HMODULE));
 for(DWORD i=0;i<count;++i)if(modules[i]){auto fn=GetProcAddress(modules[i],s);if(fn)return reinterpret_cast<void*>(fn);}return nullptr;}
template<typename T>void get(T&fn,const char*s){fn=reinterpret_cast<T>(symbol(s));}
void loadApi(){
 get(api.cmd,"cvxCmdFunc");get(api.unload,"cvxCmdFuncUnload");get(api.msg,"cvxMsgDisp");get(api.freeMem,"cvxMemFree");
 get(api.open,"cvxFileOpen");get(api.makeFile,"cvxFileNew");get(api.save,"cvxFileSave");get(api.activateFile,"cvxFileActivate");
 get(api.activeFile,"cvxFileInqActive");get(api.activeRoot,"cvxRootInqActive");get(api.roots,"cvxRootList");
 get(api.isAsm,"cvxRootIsAsm");get(api.activateRoot,"cvxRootActivate2");get(api.addRoot,"cvxRootAdd");
 get(api.comps,"cvxPartInqComps");get(api.compPart,"cvxCompInqPart");get(api.name,"cvxEntName");get(api.matrix,"cvxEntMatrix");
 get(api.insert,"cvxCompIns");get(api.color,"cvxEntColorSet");get(api.transparency,"cvxEntTransSet");
 get(api.rename,"cvxEntNameSet");get(api.layer,"cvxEntLayer");get(api.shapes,"cvxPartInqShapes");get(api.mass,"cvxPartInqShapeMass");
 get(api.faces,"cvxPartInqShapeFaces");get(api.edges,"cvxPartInqShapeEdges");
}
void freeApi(void*p){if(p&&api.freeMem)api.freeMem(&p);}
void activeNames(char*file,char*root){file[0]=root[0]=0;if(api.activeFile)api.activeFile(file,256);if(api.activeRoot)api.activeRoot(root,256);file[255]=root[255]=0;}
void field(char*to,const std::string&text){strncpy_s(to,256,text.c_str(),_TRUNCATE);}
Matrix fromPose(const dsac::Pose&p){Matrix m={};m.identity=0;
 m.xx=p.r[0];m.xy=p.r[1];m.xz=p.r[2];m.yx=p.r[3];m.yy=p.r[4];m.yz=p.r[5];m.zx=p.r[6];m.zy=p.r[7];m.zz=p.r[8];m.xt=p.t[0];m.yt=p.t[1];m.zt=p.t[2];return m;}
dsac::Pose asPose(const Matrix&m){dsac::Pose p;if(m.identity)return p;
 p.r[0]=m.xx;p.r[1]=m.xy;p.r[2]=m.xz;p.r[3]=m.yx;p.r[4]=m.yy;p.r[5]=m.yz;p.r[6]=m.zx;p.r[7]=m.zy;p.r[8]=m.zz;
 p.t[0]=m.xt;p.t[1]=m.yt;p.t[2]=m.zt;return p;}
bool goodPose(const dsac::Pose&p){for(double v:p.t)if(!std::isfinite(v)||fabs(v)>1e12)return false;for(double v:p.r)if(!std::isfinite(v)||fabs(v)>2)return false;return true;}

// Optional only: compare inexpensive per-body invariants; NOT exact B-Rep.
dsac::Geometry readGeometry(const std::string&f,const std::string&part){
 dsac::Geometry result; result.issue="Geometria niezweryfikowana";
 if(!api.shapes||!api.mass||!api.freeMem)return result;
 int n=0,*shapes=nullptr;char ff[256]={},pp[256]={};field(ff,f);field(pp,part);
 logLine("GEOM cvxPartInqShapes BEGIN part="+part);
 int rc=api.shapes(ff,pp,&n,&shapes);
 logLine("GEOM cvxPartInqShapes rc="+std::to_string(rc)+" n="+std::to_string(n));
 if(rc!=0||n<=0||n>256||!shapes){freeApi(shapes);return result;}
 std::vector<int> ids(shapes,shapes+n);freeApi(shapes);
 result.valid=true;result.issue.clear();
 for(int id:ids){MassProp m={};logLine("GEOM cvxPartInqShapeMass BEGIN");
  if(api.mass(id,1.0,&m)!=0||!std::isfinite(m.area)||!std::isfinite(m.volume)){
   result.valid=false;result.issue="Mass props API failed";result.solids.clear();return result;}
  dsac::SolidDescriptor d;d.volume=m.volume;d.area=m.area;
  for(int i=0;i<3;i++)d.moments[i]=m.ip[i];std::sort(d.moments,d.moments+3);
  // Topology counts are optional; both can only be reported as verified if acquired.
  int nf=0,ne=0,*faces=nullptr,*edges=nullptr;
  if(!api.faces||!api.edges||api.faces(id,&nf,&faces)!=0||api.edges(id,&ne,&edges)!=0){
   freeApi(faces);freeApi(edges);result.valid=false;result.issue="Topology not available";result.solids.clear();return result;}
  d.faces=nf;d.edges=ne;freeApi(faces);freeApi(edges);result.solids.push_back(d);
 }
 return result;
}

struct ReadResult {dsac::Snapshot snap;std::wstring selectedPath;std::string activeFile;};
// We never retain ZW3D entity handles between opening files A and B.
bool readAssembly(const std::wstring&filepath,const std::wstring&preferredRoot,ReadResult&result,bool geometry){
 if(!api.open||!api.roots||!api.comps||!api.compPart||!api.matrix||!api.freeMem||!api.activateRoot){
  g_issue="Brakuje wymaganej funkcji ZW3D API (otwieranie/odczyt zlozen).";return false;}
 const std::string full=ansi(filepath);
 if(full.empty()||full.size()>255){g_issue="Sciezka pliku jest za dluga (>255) lub nieobslugiwana w ZW3D 2019 ANSI.";return false;}
 char filename[256]={};field(filename,full);
 logLine("OPEN begin: "+full);
 if(api.open(filename)!=0){g_issue="ZW3D nie otworzyl pliku: "+full;return false;}
 char active[256]={},ignored[256]={};activeNames(active,ignored);
 if(!active[0]){g_issue="Brak nazwy aktywnego pliku po otwarciu.";return false;}
 std::string root=ansi(preferredRoot);
 if(root.empty()){
  int count=0;char(*roots)[256]=nullptr;
  logLine("ROOTLIST begin file="+std::string(active));
  int rc=api.roots(active,&count,&roots);
  logLine("ROOTLIST status="+std::to_string(rc)+" count="+std::to_string(count));
  if(rc||count<=0||count>200||!roots){freeApi(roots);g_issue="Nie znaleziono obiektow w pliku: "+full;return false;}
  std::vector<std::string> matches;
  for(int i=0;i<count;i++){
   char p[256]={};strncpy_s(p,roots[i],_TRUNCATE);
   int isAsm=0;if(api.isAsm&&api.isAsm(active,p,&isAsm)==0&&isAsm)matches.emplace_back(p);
  }
  if(matches.size()==1)root=matches.front();
  else if(matches.empty()&&count==1)root=roots[0];
  freeApi(roots);
  if(root.empty()){
   g_issue="W pliku jest kilka obiektow. Wroc do okna i wybierz zlozenie z listy A/B (przycisk Wczytaj liste).";return false;
  }
 }
 if(root.size()>255){g_issue="Nazwa obiektu jest za dluga.";return false;}
 char f[256]={},p[256]={};field(f,active);field(p,root);
 logLine("ACTIVATEROOT " + std::string(active) + " : " + root);
 if(api.activateRoot(f,p)!=0){g_issue="Nie mozna aktywowac zlozenia "+root;return false;}
 int count=0,*ids=nullptr;
 logLine("COMPONENTS cvxPartInqComps BEGIN root="+root);
 const int rc=api.comps(f,p,&count,&ids);
 logLine("COMPONENTS returned rc="+std::to_string(rc)+" count="+std::to_string(count));
 if(rc!=0||count<0||count>3000||(count>0&&!ids)){
  freeApi(ids);g_issue="Blad enumeracji komponentow. Log: %TEMP%/DSAC_V22_TRACE.log";return false;}
 // Reject an ordinary solid/part root with no components instead of silently
 // producing an empty comparison. Empty assembly roots remain supported.
 if(count==0&&api.isAsm){int assemblyFlag=0;
  if(api.isAsm(f,p,&assemblyFlag)==0&&!assemblyFlag){
   freeApi(ids);g_issue="Wybrany obiekt "+root+" jest czescia bez komponentow. Wybierz obiekt typu [ZLOZENIE].";return false;
  }
 }
 std::vector<int> handles;if(count)handles.assign(ids,ids+count);freeApi(ids);
 result.snap.file=full;result.snap.root=root;
 result.selectedPath=filepath;result.activeFile=active;
 std::map<std::string,dsac::Geometry> geomCache;
 for(size_t k=0;k<handles.size();++k){
  const int id=handles[k];char ff[256]={},pp[256]={},nn[256]={};
  logLine("INSTANCE "+std::to_string(k)+" cvxCompInqPart BEGIN");
  if(api.compPart(id,ff,256,pp,256)!=0){g_issue="cvxCompInqPart zwrocil blad komponentu #"+std::to_string(k);return false;}
  ff[255]=pp[255]=0;
  if(!pp[0]){g_issue="Pusta nazwa komponentu w indeksie "+std::to_string(k);return false;}
  logLine("INSTANCE "+std::to_string(k)+" cvxEntName BEGIN");
  if(!api.name||api.name(id,nn,256)!=0||!nn[0])strncpy_s(nn,pp,_TRUNCATE);
  logLine("INSTANCE "+std::to_string(k)+" cvxEntMatrix BEGIN");
  Matrix matrix={};matrix.identity=1;
  const bool matrixOk=(api.matrix(id,&matrix)==0);
  logLine("INSTANCE "+std::to_string(k)+" cvxEntMatrix return="+std::to_string((int)matrixOk));
  dsac::Item item;
  item.name=utf8(widenAnsi(nn));item.part=utf8(widenAnsi(pp));item.file=utf8(widenAnsi(ff));
  item.path="/"+item.name+"#"+std::to_string(k+1);
  item.poseValid=matrixOk;
  if(matrixOk){item.pose=asPose(matrix);item.poseValid=goodPose(item.pose);}
  if(geometry){
    auto it=geomCache.find(std::string(ff)+"/"+pp);
    if(it==geomCache.end())it=geomCache.emplace(std::string(ff)+"/"+pp,readGeometry(ff,pp)).first;
    item.geometry=it->second;
  } else item.geometry.issue="V2 SAFE: odczyt bryl wylaczony";
  result.snap.items.push_back(std::move(item));
 }
 logLine("READ OK count="+std::to_string(result.snap.items.size()));
 return true;
}

// Absolute source file paths are passed to cvxCompIns without altering source files.
std::pair<std::string,std::string> resolveComponent(const ReadResult&source,const dsac::Item&item){
 std::wstring referenced=widenAnsi(item.file.c_str());
 if(referenced.empty())referenced=baseOf(source.selectedPath);
 std::wstring folder=dirOf(referenced);
 if(folder.empty())folder=dirOf(source.selectedPath);
 std::string aFolder=ansi(folder),aFile=ansi(baseOf(referenced));
 return {aFolder,aFile};
}
std::wstring documentDir(){wchar_t dir[MAX_PATH]={};
 if(SHGetFolderPathW(nullptr,CSIDL_PERSONAL,nullptr,SHGFP_TYPE_CURRENT,dir)!=S_OK){GetTempPathW(MAX_PATH,dir);}
 std::wstring path=std::wstring(dir)+L"\\DSAssemblyCompare";
 CreateDirectoryW(path.c_str(),nullptr);return path;
}
std::wstring timeStamp(){SYSTEMTIME t;GetLocalTime(&t);wchar_t v[90]={};
 swprintf_s(v,L"%04u%02u%02u_%02u%02u%02u",t.wYear,t.wMonth,t.wDay,t.wHour,t.wMinute,t.wSecond);return v;}
bool saveText(const std::wstring&file,const std::string&utf8str){HANDLE h=CreateFileW(file.c_str(),GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);if(h==INVALID_HANDLE_VALUE)return false;
 DWORD done=0;bool ok=WriteFile(h,utf8str.data(),(DWORD)utf8str.size(),&done,nullptr)&&done==utf8str.size();CloseHandle(h);return ok;}

// A conservative pairing pass: no fabricated geometry equivalence.
// It relies on exact source paths for 'same reference', and on part/name + nearest pose otherwise.
std::vector<dsac::Result> compare(const ReadResult&a,const ReadResult&b){
 struct Candidate{int i,j,category;double score;};std::vector<Candidate> c;
 for(size_t i=0;i<a.snap.items.size();++i){const auto&x=a.snap.items[i];
  for(size_t j=0;j<b.snap.items.size();++j){const auto&y=b.snap.items[j];
   auto rx=resolveComponent(a,x), ry=resolveComponent(b,y);
   bool sameRef=(_stricmp(rx.first.c_str(),ry.first.c_str())==0&&_stricmp(rx.second.c_str(),ry.second.c_str())==0&&x.part==y.part);
   bool sameName=x.name==y.name, samePart=x.part==y.part;
   int geo=dsac::compareGeometry(x.geometry,y.geometry);
   if(!sameRef&&!samePart&&!sameName&&geo!=1)continue;
   int category=sameRef?0:(geo==1?1:(samePart?2:3));
   double dist=x.poseValid&&y.poseValid?dsac::distance(x.pose,y.pose):1e6;
   double rotation=x.poseValid&&y.poseValid?dsac::rotationDeg(x.pose,y.pose):360;
   double score=category*1e9 +(sameName?0:1e6)+std::min(dist,1e6)*10+rotation;
   c.push_back({int(i),int(j),category,score});
  }
 }
 std::sort(c.begin(),c.end(),[](const auto&x,const auto&y){if(x.score!=y.score)return x.score<y.score;if(x.i!=y.i)return x.i<y.i;return x.j<y.j;});
 std::vector<bool> useA(a.snap.items.size(),false),useB(b.snap.items.size(),false);
 std::vector<dsac::Result> result;
 for(const auto&p:c){if(useA[p.i]||useB[p.j])continue;
  const auto&x=a.snap.items[size_t(p.i)];const auto&y=b.snap.items[size_t(p.j)];
  dsac::Result r;r.ia=p.i;r.ib=p.j;r.geo=dsac::compareGeometry(x.geometry,y.geometry);
  r.dx=y.pose.t[0]-x.pose.t[0];r.dy=y.pose.t[1]-x.pose.t[1];r.dz=y.pose.t[2]-x.pose.t[2];
  if(x.poseValid&&y.poseValid){r.move=dsac::distance(x.pose,y.pose);r.rotation=dsac::rotationDeg(x.pose,y.pose);
   r.moved=r.move>0.01;r.rotated=r.rotation>0.05;}
  r.nameChange=x.name!=y.name||x.part!=y.part;
  auto rx=resolveComponent(a,x),ry=resolveComponent(b,y);
  r.referenceChange=(_stricmp(rx.first.c_str(),ry.first.c_str())!=0||_stricmp(rx.second.c_str(),ry.second.c_str())!=0||x.part!=y.part);
  r.uncertain=(p.category>=2)||(r.geo==0&&r.referenceChange)||(!x.poseValid||!y.poseValid);
  r.status=(r.geo<0?"ZMIENIONA_GEOMETRIA":r.geo>0?"GEOMETRIA_CECHY_ZGODNE":"GEOMETRIA_NIEZWERYFIKOWANA");
  if(r.moved)r.status+=" + PRZESUNIECIE";
  if(r.rotated)r.status+=" + OBROT";
  if(r.nameChange)r.status+=" + NAZWA";
  if(r.referenceChange)r.status+=" + REFERENCJA";
  if(r.uncertain)r.status+=" + NIEPEWNE";
  result.push_back(r);useA[size_t(p.i)]=useB[size_t(p.j)]=true;
 }
 for(size_t i=0;i<useA.size();i++)if(!useA[i]){dsac::Result r;r.ia=int(i);r.status="USUNIETY";result.push_back(r);}
 for(size_t j=0;j<useB.size();j++)if(!useB[j]){dsac::Result r;r.ib=int(j);r.status="DODANY";result.push_back(r);}
 return result;
}

// All classification/roles/ZW3D palette indices are centralized in overlay_policy.hpp.
// Distinct name prefixes facilitate filtering in the assembly tree without creating duplicate unchanged parts.
bool samePhysicalRef(const ReadResult&a,const dsac::Item&x,const ReadResult&b,const dsac::Item&y){
 auto left=resolveComponent(a,x),right=resolveComponent(b,y);
 return _stricmp(left.first.c_str(),right.first.c_str())==0 &&
        _stricmp(left.second.c_str(),right.second.c_str())==0 && x.part==y.part;
}
dsac::ChangeKind kindFor(const ReadResult&a,const ReadResult&b,const dsac::Result&r){
 if(r.ia<0)return dsac::ChangeKind::Added;
 if(r.ib<0)return dsac::ChangeKind::Removed;
 const auto&x=a.snap.items[size_t(r.ia)],&y=b.snap.items[size_t(r.ib)];
 return dsac::classify(r,samePhysicalRef(a,x,b,y),x.poseValid&&y.poseValid);
}
std::string nameFor(dsac::Role role,const dsac::Item&item,int index){
 std::string p=dsac::rolePrefix(role);
 p+=std::to_string(index+1)+"_";
 for(unsigned char ch:item.name)if(p.size()<110 && ((ch>='A'&&ch<='Z')||(ch>='a'&&ch<='z')||(ch>='0'&&ch<='9')||ch=='_'))p+=char(ch);
 return p;
}
std::string makeOutput(const ReadResult&a,const ReadResult&b,const std::vector<dsac::Result>&rows,
                      const std::wstring&requestedPath,bool emit3D,std::string&warning){
 if(!emit3D)return "NOT_REQUESTED";
 if(!api.makeFile||!api.addRoot||!api.insert||!api.color||!api.save){warning="Brak API potrzebnego do modelu 3D";return "FAILED";}
 const std::string file=ansi(requestedPath);
 if(file.empty()||file.size()>255){warning="Sciezka wyniku przekracza limit API ZW3D";return "FAILED";}
 // Never overwrite an existing project. Prevent accidental deletion of earlier result.
 if(GetFileAttributesW(requestedPath.c_str())!=INVALID_FILE_ATTRIBUTES){warning="Plik wyniku juz istnieje";return "FAILED";}
 char path[256]={};field(path,file);
 logLine("OUTPUT FILE NEW: "+file);
 if(api.makeFile(path)!=0){warning="cvxFileNew: cannot create output project";return "FAILED";}
 char root[256]={};field(root,"DSAC_WYNIK");
 logLine("OUTPUT ROOT ADD BEGIN");
 if(api.addRoot(89,root,nullptr)!=0){warning="cvxRootAdd: no assembly root";return "FAILED";}
 // The parent root should already be active after creation. Activate explicitly if possible.
 char active[256]={},activeRoot[256]={};activeNames(active,activeRoot);
 if(api.activateRoot){char ff[256]={};field(ff,active);api.activateRoot(ff,root);}
 int inserted=0,failed=0;
 auto append=[&](const ReadResult&src,int index,dsac::Role role){
  const auto&item=src.snap.items[size_t(index)];
  auto pathPair=resolveComponent(src,item);
  CompData data={};field(data.dir,pathPair.first);field(data.file,pathPair.second);field(data.part,item.part);
  field(data.comp,nameFor(role,item,index));data.frame=fromPose(item.pose);data.anchor=1;
  data.regen=0;data.autoDelete=0;data.copy=0;data.overwrite=0;data.align=0;
  int id=0;logLine("COMPINS BEGIN role="+std::to_string((int)role)+" file="+pathPair.second+" part="+item.part);
  int rc=api.insert(&data,&id);logLine("COMPINS END rc="+std::to_string(rc)+" entity="+std::to_string(id));
  if(rc!=0||id<=0){failed++;return;}
  inserted++;
  const int color=dsac::zw3dColor(role);
  int cr=api.color(color,1,&id);
  if(cr!=0)logLine("WARNING: cvxEntColorSet palette="+std::to_string(color)+" rc="+std::to_string(cr));
  if(dsac::isGhost(role)&&api.transparency){
   const int tr=api.transparency(65,1,&id);
   if(tr!=0)logLine("WARNING: cvxEntTransSet rc="+std::to_string(tr));
  }
  // NOTE: cvxEntLayer is a GETTER in the ZW3D 2019 API. Never call it as a setter.
  // Instead the category is encoded in each instance name (rolePrefix).

 };
 for(const auto&r:rows){
  const dsac::ChangeKind kind=kindFor(a,b,r);
  // A/B are identical => insert exactly ONE occurrence (from B). Same for rename-only.
  if(kind!=dsac::ChangeKind::Removed && r.ib>=0){
    append(b,r.ib,dsac::newRole(kind));
  }
  // OLD ghost is only used when the part was moved, changed geometrically, or removed.
  // This deliberately prevents two coincident copies of unchanged components.
  if(dsac::showsOld(kind)&&r.ia>=0){
    append(a,r.ia,dsac::oldRole(kind));
  }
 }
 logLine("OUTPUT COMPONENTS inserted="+std::to_string(inserted)+" failed="+std::to_string(failed));
 if(failed)warning=std::to_string(failed)+" komponentow nie udalo sie wstawic; wynik NIEPELNY";
 logLine("OUTPUT SAVE BEGIN");const int rc=api.save(0);logLine("OUTPUT SAVE END rc="+std::to_string(rc));
 if(rc!=0){warning+="; cvxFileSave failed";return "FAILED";}
 return failed?"PARTIAL":"OK";
}

std::string csvReport(const ReadResult&a,const ReadResult&b,const std::vector<dsac::Result>&rows){
 std::ostringstream o;
 o<<"\xef\xbb\xbfLp;Klasyfikacja;Szczegoly;Detal_A;Detal_B;Plik_A;Plik_B;DX_mm;DY_mm;DZ_mm;Obrot_stopnie;Zmiana_nazwy;Zmiana_referencji;Geometria;Pewna_zgodnosc\r\n";
 for(size_t i=0;i<rows.size();i++){
  const auto&r=rows[i];
  const auto*x=r.ia>=0?&a.snap.items[size_t(r.ia)]:nullptr;
  const auto*y=r.ib>=0?&b.snap.items[size_t(r.ib)]:nullptr;
  const dsac::ChangeKind k=kindFor(a,b,r);
  const bool confirmed=(x&&y&&(r.geo==1||samePhysicalRef(a,*x,b,*y)));
  o<<i+1<<';'<<dsac::kindCode(k)<<';'<<quote(r.status)<<';'
   <<quote(x?x->name:"")<<';'<<quote(y?y->name:"")<<';'
   <<quote(x?x->file:"")<<';'<<quote(y?y->file:"")<<';'
   <<(x&&y?num(r.dx):"")<<';'<<(x&&y?num(r.dy):"")<<';'<<(x&&y?num(r.dz):"")<<';'
   <<(x&&y?num(r.rotation):"")<<';'
   <<(r.nameChange?"TAK":"NIE")<<';'<<(r.referenceChange?"TAK":"NIE")<<';'
   <<(r.geo==1?"CECHY_ZGODNE":r.geo<0?"ROZNE":"NIEZWERYFIKOWANA")<<';'
   <<(confirmed?"TAK":"NIE")<<"\r\n";
 }
 return o.str();
}
std::string htmlReport(const ReadResult&a,const ReadResult&b,const std::vector<dsac::Result>&rows,const std::string&status,const std::string&warning){
 std::array<int,7> counts{};
 for(const auto&r:rows)counts[static_cast<size_t>(kindFor(a,b,r))]++;
 const char *cls[]={"green","blue","violet","yellow","red","amber","gray"};
 std::ostringstream s;
 s<<"<!doctype html><html lang='pl'><head><meta charset='utf-8'><title>DS Assembly Compare V2.2</title>"
 "<style>body{font:14px Segoe UI,Arial;background:#f3f5f9;color:#192332;margin:30px}main{max-width:1350px;margin:auto}"
 "h1{font-size:27px}p{line-height:1.5}.info{color:#64748b}.stats{display:flex;gap:12px;flex-wrap:wrap;margin:20px 0}"
 ".box{background:white;border:1px solid #d9dfe7;border-radius:9px;padding:16px;min-width:115px}"
 ".box strong{font-size:25px;display:block}.tbl{overflow:auto;background:white;border-radius:9px;border:1px solid #d9dfe7}"
 "table{border-collapse:collapse;width:100%;min-width:1100px}th,td{text-align:left;border-bottom:1px solid #e8ecf2;padding:9px}th{background:#edf1f7}"
 ".green{color:#128642}.blue{color:#2563a6}.red{color:#c73333}.amber{color:#9d660f}.gray{color:#718096}"
 ".yellow{color:#986b00}.violet{color:#7547b5}.brown{color:#805233}.legend{display:flex;flex-wrap:wrap;gap:11px;background:white;padding:15px;border-radius:9px}"
 ".legend span{white-space:nowrap}.dot{display:inline-block;width:13px;height:13px;border-radius:3px;margin-right:6px;vertical-align:middle;border:1px solid #aaa}"
 "input{padding:11px;margin:15px 0;width:350px;border:1px solid #bdc8d4;border-radius:8px}</style></head><body><main>"
 "<h1>DS Assembly Compare V2.2</h1>"
 "<div class='legend'>"
 "<span><i class='dot' style='background:#2da44e'></i>Bez zmian</span>"
 "<span><i class='dot' style='background:#377bc4'></i>Inna nazwa</span>"
 "<span><i class='dot' style='background:#d93a3a'></i>Dodany</span>"
 "<span><i class='dot' style='background:#9958c9'></i>Nowe polozenie</span>"
 "<span><i class='dot' style='background:#edb36a'></i>Stare polozenie (65% transparent)</span>"
 "<span><i class='dot' style='background:#efd34b'></i>Nowa geometria</span>"
 "<span><i class='dot' style='background:#b98e71'></i>Stara geometria (65% transparent)</span>"
 "<span><i class='dot' style='background:#edb36a'></i>Usuniety (65% transparent)</span>"
 "<span><i class='dot' style='background:#a8afb8'></i>Niezweryfikowany</span></div>";
 s<<"<p><b>Model A:</b> "<<escapeHtml(utf8(a.selectedPath))<<" / "<<escapeHtml(a.snap.root)<<"<br><b>Model B:</b> "<<escapeHtml(utf8(b.selectedPath))<<" / "<<escapeHtml(b.snap.root)<<"</p>";
 s<<"<p><b>Model wynikowy:</b> "<<escapeHtml(status)<<" "<<escapeHtml(warning)<<"</p>";
 s<<"<p class='info'>UWAGA: Zielony oznacza zgodnosc cech geometrii lub identyczna referencje do tej samej czesci. "
 "Przy dwoch roznych plikach, gdy geometria nie jest dostepna, element bedzie szary nawet jesli nazwa i pozycja sa zgodne. "
 "Zmiana nazwy przy niezbadanej geometrii nie moze byc uznana za pewna.</p>";
 s<<"<div class='stats'>";
 s<<"<div class='box'><strong>"<<a.snap.items.size()<<"</strong>Wystapienia A</div>";
 s<<"<div class='box'><strong>"<<b.snap.items.size()<<"</strong>Wystapienia B</div>";
 for(size_t k=0;k<counts.size();++k)s<<"<div class='box'><strong>"<<counts[k]<<"</strong>"<<dsac::kindCode(static_cast<dsac::ChangeKind>(k))<<"</div>";
 s<<"</div><input id='find' oninput='searchRows()' placeholder='Filtruj detale...'>"
 "<div class='tbl'><table id='data'><thead><tr><th>Lp</th><th>Klasyfikacja</th><th>Szczegoly</th><th>Detal A</th><th>Detal B</th><th>DX mm</th><th>DY mm</th><th>DZ mm</th><th>Obrot deg</th></tr></thead><tbody>";
 for(size_t i=0;i<rows.size();++i){
  const auto&r=rows[i];const auto*x=r.ia>=0?&a.snap.items[size_t(r.ia)]:nullptr;
  const auto*y=r.ib>=0?&b.snap.items[size_t(r.ib)]:nullptr;
  const auto kind=kindFor(a,b,r);const auto idx=static_cast<size_t>(kind);
  s<<"<tr><td>"<<i+1<<"</td><td class='"<<cls[idx]<<"'>"<<dsac::kindCode(kind)<<"</td><td>"<<escapeHtml(r.status)<<"</td>"
   <<"<td>"<<escapeHtml(x?x->name:"")<<"</td><td>"<<escapeHtml(y?y->name:"")<<"</td>"
   <<"<td>"<<(x&&y?num(r.dx):"")<<"</td><td>"<<(x&&y?num(r.dy):"")<<"</td>"
   <<"<td>"<<(x&&y?num(r.dz):"")<<"</td><td>"<<(x&&y?num(r.rotation):"")<<"</td></tr>";
 }
 s<<"</tbody></table></div><p class='info'>To jest wersja testowa. Analiza geometrii (opcjonalna) nie dowodzi dokladnej zgodnosci B-Rep. "
 "Podzlozenia nie sa jeszcze rozwijane. Brak pewnosci = szary, nie zielony. "
 "Obiekty o tej samej nazwie moga miec rozna geometrie.</p>"
 "<script>function searchRows(){let x=document.getElementById('find').value.toLowerCase();document.querySelectorAll('#data tbody tr').forEach(r=>r.style.display=r.innerText.toLowerCase().includes(x)?'':'none')}</script></main></body></html>";
 return s.str();
}

bool runComparison(HWND parent,const std::wstring&pathA,const std::wstring&pathB,
                   const std::wstring&rootA,const std::wstring&rootB,bool geometry,bool model){
 if(pathA.empty()||pathB.empty()){showErr(parent,"Wskaz plik A i B.");return false;}
 if(_wcsicmp(pathA.c_str(),pathB.c_str())==0&&_wcsicmp(rootA.c_str(),rootB.c_str())==0){
  showErr(parent,"Wybrales identyczne pliki i obiekty. Wskaz dwa modele lub dwa rozne obiekty.");return false;}
 if(GetFileAttributesW(pathA.c_str())==INVALID_FILE_ATTRIBUTES||GetFileAttributesW(pathB.c_str())==INVALID_FILE_ATTRIBUTES){
  showErr(parent,"Nie mozna znalezc wskazanego pliku A lub B.");return false;}
 if(geometry){
  int ans=MessageBoxW(parent,L"Zaawansowany odczyt geometrii w ZW3D 2019 nie przeszedl jeszcze testu stabilnosci. "
   L"Poprzednia wersja makra zamykala ZW3D. Czy na pewno wlaczyc odczyt bryl?\n\n"
   L"Zalecane: Nie — najpierw przetestuj porownanie pozycji i model 3D.",L"Testowe API geometrii",MB_ICONWARNING|MB_YESNO|MB_DEFBUTTON2);
  if(ans!=IDYES)geometry=false;
 }
 ReadResult a,b;g_issue.clear();
 if(!readAssembly(pathA,rootA,a,geometry)){showErr(parent,"A: "+g_issue);return false;}
 if(!readAssembly(pathB,rootB,b,geometry)){showErr(parent,"B: "+g_issue);return false;}
 auto results=compare(a,b);
 std::wstring folder=documentDir();std::wstring base=folder+L"\\DSAC_V22_"+timeStamp();
 std::wstring html=base+L".html",csv=base+L".csv",modelPath=base+L"_WYNIK.Z3";
 std::string warning;
 std::string status=makeOutput(a,b,results,modelPath,model,warning);
 if(!geometry){
  if(!warning.empty())warning+="; ";
  warning+="Geometria nie byla analizowana. Szare = niezweryfikowane; nie jest to blad kolorowania.";
 }
 if(!saveText(html,htmlReport(a,b,results,status,warning))||!saveText(csv,csvReport(a,b,results))){
  showErr(parent,"Porownanie wykonano, ale zapis raportu HTML/CSV nie udal sie.");return false;}
 g_lastHtml=html;
 logLine("REPORT " + utf8(html) + " 3D=" + status + " warning=" + warning);
 ShellExecuteW(parent,L"open",html.c_str(),nullptr,nullptr,SW_SHOWNORMAL);
 std::wstring m=L"Porownanie zakonczone.\nRaport: "+html;
 if(model){m+=L"\nModel 3D: "+modelPath+L"\nStatus: "+toWide(status);
  if(!warning.empty())m+=L"\nUWAGA: "+toWide(warning);}
 showNotice(parent,m);
 return true;
}

// Root names are deliberately resolved by the ZW3D 2019 API, never guessed from
// the filename. The user selects which object is the intended assembly.
struct RootChoice {std::wstring name;bool isAssembly=false;};
std::vector<RootChoice> g_rootChoicesA,g_rootChoicesB;
std::wstring g_loadedPathA,g_loadedPathB;

bool queryRootChoices(const std::wstring&path,std::vector<RootChoice>&out,std::string&reason){
 out.clear();
 if(path.empty()){reason="Najpierw wskaz plik .Z3.";return false;}
 if(GetFileAttributesW(path.c_str())==INVALID_FILE_ATTRIBUTES){reason="Nie znaleziono pliku .Z3.";return false;}
 if(!api.open||!api.roots||!api.freeMem){reason="Brakuje cvxFileOpen, cvxRootList lub cvxMemFree w API ZW3D.";return false;}
 const std::string full=ansi(path);
 if(full.empty()||full.size()>255){reason="Zbyt dluga sciezka lub znaki nieobslugiwane przez ANSI API (limit 255 bajtow).";return false;}
 char input[256]={};field(input,full);
 logLine("ROOT PICKER FILE OPEN BEGIN: "+full);
 const int openStatus=api.open(input);
 logLine("ROOT PICKER FILE OPEN END rc="+std::to_string(openStatus));
 if(openStatus!=0){reason="ZW3D nie moze otworzyc wybranego pliku.";return false;}
 char active[256]={},unused[256]={};activeNames(active,unused);
 if(!active[0]){reason="ZW3D nie zwrocil nazwy aktywnego pliku.";return false;}
 char (*names)[256]=nullptr;int n=0;
 logLine("ROOT PICKER ROOTLIST BEGIN: "+std::string(active));
 const int rc=api.roots(active,&n,&names);
 logLine("ROOT PICKER ROOTLIST END rc="+std::to_string(rc)+" count="+std::to_string(n));
 if(rc!=0||n<=0||n>2000||!names){freeApi(names);reason="Nie udalo sie pobrac listy obiektow z pliku.";return false;}
 std::vector<std::string> roots;
 roots.reserve(size_t(n));
 for(int i=0;i<n;++i){
  names[i][255]=0;
  if(names[i][0])roots.emplace_back(names[i]);
 }
 freeApi(names);
 for(const auto&name:roots){
  char f[256]={},r[256]={};field(f,active);field(r,name);
  int isAssembly=0;bool ok=api.isAsm&&api.isAsm(f,r,&isAssembly)==0;
  out.push_back({widenAnsi(name.c_str()),ok&&isAssembly!=0});
 }
 if(out.empty()){reason="Plik nie zawiera obiektow do wyboru.";return false;}
 logLine("ROOT PICKER READY: "+std::to_string(out.size())+" objects");
 return true;
}

enum ControlId {AEdit=101,ABrowse,ARoot,BEdit,BBrowse,BRoot,GeoCheck,OutputCheck,Start,OpenReport,Close,ALoadRoots,BLoadRoots,
                  LegendSwatch1=400,LegendSwatch9=408};
struct LegendEntry {const wchar_t*name;COLORREF color;};
static const LegendEntry legend[] = {
 {L"Bez zmian",RGB(45,164,78)},
 {L"Zmiana nazwy",RGB(55,123,196)},
 {L"Nowy detal",RGB(217,58,58)},
 {L"Nowe polozenie",RGB(153,88,201)},
 {L"Stare polozenie (65% przezr.)",RGB(237,179,106)},
 {L"Nowa geometria",RGB(239,211,75)},
 {L"Stara geometria (65% przezr.)",RGB(185,142,113)},
 {L"Usuniety (65% przezr.)",RGB(237,179,106)},
 {L"Niezweryfikowany",RGB(168,175,184)}
};
HWND ctl(HWND h,int id){return GetDlgItem(h,id);}
std::wstring getEdit(HWND h,int id){int n=GetWindowTextLengthW(ctl(h,id));std::wstring s(size_t(n+1),0);GetWindowTextW(ctl(h,id),&s[0],n+1);s.resize(wcslen(s.c_str()));return s;}
void setEdit(HWND h,int id,const std::wstring&s){SetWindowTextW(ctl(h,id),s.c_str());}
void makeControl(HWND p,const wchar_t*kind,const wchar_t*txt,DWORD style,int id,int x,int y,int w,int h){
 HWND c=CreateWindowExW(0,kind,txt,WS_CHILD|WS_VISIBLE|style,x,y,w,h,p,(HMENU)(INT_PTR)id,g_instance,nullptr);
 if(c)SendMessageW(c,WM_SETFONT,(WPARAM)GetStockObject(DEFAULT_GUI_FONT),TRUE);
}
void resetRootPicker(HWND h,bool isA){
 const int id=isA?ARoot:BRoot;
 SendMessageW(ctl(h,id),CB_RESETCONTENT,0,0);
 SendMessageW(ctl(h,id),CB_SETCURSEL,(WPARAM)-1,0);
 if(isA){g_rootChoicesA.clear();g_loadedPathA.clear();}
 else {g_rootChoicesB.clear();g_loadedPathB.clear();}
}
void loadRootPicker(HWND h,bool isA,bool showErrors){
 const int fileCtrl=isA?AEdit:BEdit,rootCtrl=isA?ARoot:BRoot;
 const std::wstring path=getEdit(h,fileCtrl);
 auto& choices=isA?g_rootChoicesA:g_rootChoicesB;
 auto& loaded=isA?g_loadedPathA:g_loadedPathB;
 resetRootPicker(h,isA);
 std::string issue;
 EnableWindow(ctl(h,isA?ALoadRoots:BLoadRoots),FALSE);
 SetCursor(LoadCursor(nullptr,IDC_WAIT));
 const bool ok=queryRootChoices(path,choices,issue);
 SetCursor(LoadCursor(nullptr,IDC_ARROW));
 EnableWindow(ctl(h,isA?ALoadRoots:BLoadRoots),TRUE);
 if(!ok){if(showErrors)showErr(h,std::string(isA?"A: ":"B: ")+issue);return;}
 loaded=path;
 int autoIndex=-1,assemblyCount=0;
 for(size_t i=0;i<choices.size();++i){
  const auto&choice=choices[i];
  const std::wstring label=(choice.isAssembly?L"[ZLOZENIE]  ":L"[OBIEKT]  ")+choice.name;
  SendMessageW(ctl(h,rootCtrl),CB_ADDSTRING,0,(LPARAM)label.c_str());
  if(choice.isAssembly)assemblyCount++;
 }
 std::vector<bool> types;for(const auto&c:choices)types.push_back(c.isAssembly);
 autoIndex=dsac::autoRootIndex(types);
 SendMessageW(ctl(h,rootCtrl),CB_SETCURSEL,(WPARAM)autoIndex,0);
 logLine(std::string(isA?"A":"B")+" ROOT PICKER options="+std::to_string(choices.size())+
         " detected_assemblies="+std::to_string(assemblyCount)+" selected="+std::to_string(autoIndex));
}
bool selectedRoot(HWND h,bool isA,std::wstring&result){
 const int rootCtrl=isA?ARoot:BRoot,fileCtrl=isA?AEdit:BEdit;
 auto& choices=isA?g_rootChoicesA:g_rootChoicesB;
 auto& loaded=isA?g_loadedPathA:g_loadedPathB;
 const std::wstring path=getEdit(h,fileCtrl);
 if(loaded!=path){loadRootPicker(h,isA,true);}
 if(loaded!=path)return false;
 LRESULT i=SendMessageW(ctl(h,rootCtrl),CB_GETCURSEL,0,0);
 if(i==CB_ERR||i<0||static_cast<size_t>(i)>=choices.size()){
  showNotice(h,isA?L"Wybierz z listy obiekt zlozenia A. Gdy widzisz kilka zlozen, wskaz wlasciwe."
                  :L"Wybierz z listy obiekt zlozenia B. Gdy widzisz kilka zlozen, wskaz wlasciwe.");
  return false;
 }
 result=choices[size_t(i)].name;
 return true;
}
std::wstring pickFile(HWND owner){wchar_t file[32768]={};OPENFILENAMEW o={};o.lStructSize=sizeof(o);o.hwndOwner=owner;o.lpstrFile=file;o.nMaxFile=_countof(file);
 o.lpstrTitle=L"Wybierz zlozenie ZW3D 2019";o.lpstrFilter=L"Pliki ZW3D (*.Z3)\0*.z3;*.Z3\0Wszystkie pliki (*.*)\0*.*\0\0";
 o.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_HIDEREADONLY|OFN_EXPLORER;
 return GetOpenFileNameW(&o)?std::wstring(file):L"";}
LRESULT CALLBACK windowProc(HWND h,UINT msg,WPARAM w,LPARAM l){
 switch(msg){
 case WM_DRAWITEM:{
   const DRAWITEMSTRUCT* p=reinterpret_cast<const DRAWITEMSTRUCT*>(l);
   if(p && p->CtlID>=LegendSwatch1 && p->CtlID<=LegendSwatch9){
     const int index=int(p->CtlID)-LegendSwatch1;
     const HBRUSH brush=CreateSolidBrush(legend[index].color);
     FillRect(p->hDC,&p->rcItem,brush);
     DeleteObject(brush);
     FrameRect(p->hDC,&p->rcItem,(HBRUSH)GetStockObject(GRAY_BRUSH));
     return TRUE;
   }
   break;
 }
 case WM_CREATE:{
   makeControl(h,L"STATIC",L"DS Assembly Compare V2.2",SS_LEFT,0,22,12,580,30);
   makeControl(h,L"STATIC",L"Wskaz dwie wersje zlozenia. ZW3D otworzy je podczas analizy — nie musza byc wczesniej otwarte.",SS_LEFT,0,22,45,740,23);
   makeControl(h,L"STATIC",L"MODEL A — STARA WERSJA",SS_LEFT,0,22,87,500,22);
   makeControl(h,L"EDIT",L"",WS_BORDER|ES_AUTOHSCROLL,AEdit,22,111,616,27);
   makeControl(h,L"BUTTON",L"Przegladaj...",BS_PUSHBUTTON,ABrowse,647,111,110,27);
   makeControl(h,L"STATIC",L"Obiekt w pliku A:",SS_LEFT,0,22,145,220,21);
   makeControl(h,L"COMBOBOX",L"",CBS_DROPDOWNLIST|WS_VSCROLL|WS_TABSTOP,ARoot,263,143,304,230);
   makeControl(h,L"BUTTON",L"Wczytaj liste",BS_PUSHBUTTON,ALoadRoots,575,143,182,25);
   makeControl(h,L"STATIC",L"MODEL B — NOWA WERSJA",SS_LEFT,0,22,190,500,22);
   makeControl(h,L"EDIT",L"",WS_BORDER|ES_AUTOHSCROLL,BEdit,22,214,616,27);
   makeControl(h,L"BUTTON",L"Przegladaj...",BS_PUSHBUTTON,BBrowse,647,214,110,27);
   makeControl(h,L"STATIC",L"Obiekt w pliku B:",SS_LEFT,0,22,247,220,21);
   makeControl(h,L"COMBOBOX",L"",CBS_DROPDOWNLIST|WS_VSCROLL|WS_TABSTOP,BRoot,263,245,304,230);
   makeControl(h,L"BUTTON",L"Wczytaj liste",BS_PUSHBUTTON,BLoadRoots,575,245,182,25);
   makeControl(h,L"BUTTON",L"Utworz nowy, kolorowy model 3D (.Z3)",BS_AUTOCHECKBOX,OutputCheck,22,297,420,24);
   SendMessageW(ctl(h,OutputCheck),BM_SETCHECK,BST_CHECKED,0);
   makeControl(h,L"BUTTON",L"Zaawansowana analiza geometrii (testowa)",BS_AUTOCHECKBOX,GeoCheck,22,329,450,24);
   makeControl(h,L"STATIC",L"LEGENDA KOLOROW W MODELU WYNIKOWYM",SS_LEFT,0,22,364,740,23);
   for(int i=0;i<9;++i){
     const int col=i/5, row=i%5;
     const int x=22+col*382,y=394+row*30;
     makeControl(h,L"STATIC",L"",SS_OWNERDRAW,LegendSwatch1+i,x,y+2,19,19);
     makeControl(h,L"STATIC",legend[i].name,SS_LEFT,0,x+27,y,350,26);
   }
   makeControl(h,L"STATIC",L"UWAGA: Jesli geometria jest nieznana, program oznaczy element jako niezweryfikowany (szary).",SS_LEFT,0,22,555,740,23);
   makeControl(h,L"BUTTON",L"POROWNAJ I UTWORZ RAPORT",BS_DEFPUSHBUTTON,Start,22,590,330,40);
   makeControl(h,L"BUTTON",L"Ostatni raport",BS_PUSHBUTTON,OpenReport,480,590,132,40);
   makeControl(h,L"BUTTON",L"Zamknij",BS_PUSHBUTTON,Close,629,590,127,40);
   setEdit(h,AEdit,g_docA);setEdit(h,BEdit,g_docB);
   SendMessageW(ctl(h,GeoCheck),BM_SETCHECK,g_checkedGeometry?BST_CHECKED:BST_UNCHECKED,0);
   SendMessageW(ctl(h,OutputCheck),BM_SETCHECK,g_generate3D?BST_CHECKED:BST_UNCHECKED,0);
   return 0;
 }
 case WM_COMMAND:{
   const int id=LOWORD(w);
   if(id==ABrowse||id==BBrowse){
    auto f=pickFile(h);if(!f.empty()){
      const bool isA=id==ABrowse;
      setEdit(h,isA?AEdit:BEdit,f);
      if(isA)g_rootA.clear();else g_rootB.clear();
      resetRootPicker(h,isA);
      loadRootPicker(h,isA,true);
    }
    return 0;
   }
   if(id==ALoadRoots||id==BLoadRoots){loadRootPicker(h,id==ALoadRoots,true);return 0;}
   if(id==Close){DestroyWindow(h);return 0;}
   if(id==OpenReport){if(!g_lastHtml.empty())ShellExecuteW(h,L"open",g_lastHtml.c_str(),nullptr,nullptr,SW_SHOWNORMAL);else showNotice(h,L"Nie ma jeszcze raportu w tej sesji.");return 0;}
   if(id==Start){
    g_docA=getEdit(h,AEdit);g_docB=getEdit(h,BEdit);
    if(g_docA.empty()||g_docB.empty()){showNotice(h,L"Najpierw wskaz pliki A i B.");return 0;}
    if(!selectedRoot(h,true,g_rootA))return 0;
    if(!selectedRoot(h,false,g_rootB))return 0;
    g_checkedGeometry=SendMessageW(ctl(h,GeoCheck),BM_GETCHECK,0,0)==BST_CHECKED;
    g_generate3D=SendMessageW(ctl(h,OutputCheck),BM_GETCHECK,0,0)==BST_CHECKED;
    EnableWindow(ctl(h,Start),FALSE);SetCursor(LoadCursor(nullptr,IDC_WAIT));
    runComparison(h,g_docA,g_docB,g_rootA,g_rootB,g_checkedGeometry,g_generate3D);
    SetCursor(LoadCursor(nullptr,IDC_ARROW));EnableWindow(ctl(h,Start),TRUE);
    return 0;
   }
   return 0;
 }
 case WM_CLOSE:DestroyWindow(h);return 0;
 case WM_DESTROY:g_dialog=nullptr;return 0;
 }
 return DefWindowProcW(h,msg,w,l);
}
void openDialog(){
 if(g_dialog){SetForegroundWindow(g_dialog);return;}
 if(!g_instance)g_instance=(HINSTANCE)GetModuleHandleW(nullptr);
 static bool registered=false;
 if(!registered){WNDCLASSEXW wc={};wc.cbSize=sizeof(wc);wc.lpfnWndProc=windowProc;wc.hInstance=g_instance;
  wc.lpszClassName=L"DSAC_V2_MAIN";wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);
  if(!RegisterClassExW(&wc)){showErr(nullptr,"Nie mozna zarejestrowac okna Win32");return;}registered=true;}
 g_dialog=CreateWindowExW(WS_EX_APPWINDOW,L"DSAC_V2_MAIN",L"DS Assembly Compare V2.2 | ZW3D 2019 x64",
  WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX|WS_VISIBLE,
  CW_USEDEFAULT,CW_USEDEFAULT,795,682,nullptr,nullptr,g_instance,nullptr);
 if(!g_dialog)return;
 ShowWindow(g_dialog,SW_SHOW);UpdateWindow(g_dialog);
 MSG msg={};while(g_dialog&&GetMessageW(&msg,nullptr,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}
}
void showInfo(){showNotice(nullptr,L"DS Assembly Compare V2.2 (ZW3D 2019 Standard x64)\n\nKomenda: ~DSAC\nPomoc: ~DSAC_INFO\n\n"
 L"Po wyborze pliku pojawia sie lista jego obiektow. Wybierz wlasciwe zlozenie A/B.\n"
 L"Tworzy nowy plik wynikowy z 9 kolorami i legenda w oknie.\n"
 L"Bez zmian = tylko jedna zielona kopia. Zmiana nazwy = niebieski. Nowa pozycja = fiolet, stara = pomarancz (65%).\n"
 L"Wersja testowa: analiza tylko bezposrednich wystapien. Kolorowanie przez API wymaga sprawdzenia w ZW3D.\n"
 L"Odczyt geometrii domyslnie wylaczony po awarii w poprzedniej wersji.\n\n"
 L"Raporty: Dokumenty\\DSAssemblyCompare\nLog: %%TEMP%%\\DSAC_V22_TRACE.log");}
} // namespace

extern "C" __declspec(dllexport) int DSAssemblyCompare2019Init(int,void*){
 logLine("PLUGIN V2.2 INIT");loadApi();
 if(!api.cmd){MessageBoxW(nullptr,L"Nie odnaleziono cvxCmdFunc w procesie ZW3D.",L"DSAC V2.2",MB_ICONERROR);return 1;}
 // Do not initialize reader nor access current assembly on plugin load.
 const int r1=api.cmd("DSAC",reinterpret_cast<void*>(&openDialog),0);
 const int r2=api.cmd("DSAC_INFO",reinterpret_cast<void*>(&showInfo),0);
 logLine("REGISTER DSAC="+std::to_string(r1)+" DSAC_INFO="+std::to_string(r2));
 return (r1||r2)?1:0;
}
extern "C" __declspec(dllexport) int DSAssemblyCompare2019Exit(){
 logLine("PLUGIN V2.2 EXIT");if(api.unload){api.unload("DSAC");api.unload("DSAC_INFO");}return 0;
}
