# DS Assembly Compare V2.2 — ZW3D 2019 Standard x64

**Status:** źródła do kompilacji w GitHub Actions; nie jest to gotowa DLL. Silnik i zasady kolorowania zostały przetestowane offline, natomiast załadowanie biblioteki i tworzenie modelu w ZW3D trzeba sprawdzić na komputerze z ZW3D 2019.

## Zmiany względem V2.1

1. Rozdzielono statusy na: bez zmian, zmiana nazwy, zmiana położenia/obrotu, zmiana geometrii, nowy, usunięty, niezweryfikowany. Samo różne źródło pliku nie oznacza już automatycznie czerwonego modelu.
2. Części bez zmian oraz części o zmienionej wyłącznie nazwie pojawiają się **raz**, z nowego złożenia B. Dotychczasowe dublowanie wystąpień A i B dla zgodnych części jest wyłączone.
3. Dla części przesuniętej pokazane są dwa wystąpienia: **fioletowy** detal w nowym położeniu oraz **pomarańczowy półprzezroczysty** w starym.
4. Dla zmienionej geometrii: **żółta** nowa wersja, **brązowa półprzezroczysta** stara wersja.
5. Zmiana samej nazwy: **niebieski** detal w wynikowym modelu i obie nazwy w raporcie. Nazwę i referencję pokazujemy osobno.
6. Dodane części są czerwone, usunięte pomarańczowe, niezweryfikowane szare.
7. **Kolorowa legenda widoczna w głównym oknie** i w raporcie HTML.
8. Nazwy nowych wystąpień w drzewie mają prefiksy `B_BEZ_ZMIAN_`, `B_NAZWA_`, `B_NOWA_POZYCJA_`, `A_STARA_POZYCJA_`, `B_NOWA_GEOMETRIA_`, `A_STARA_GEOMETRIA_`, `B_DODANY_`, `A_USUNIETY_`, `B_NIEZWERYFIKOWANY_`. To są prefiksy nazw, nie prawdziwe osobne podzłożenia/grupy.

## Ważne ograniczenie — zgodność geometrii

**Weryfikacja geometrii jest nadal domyślnie wyłączona** ze względu na wcześniejszą awarię ZW3D podczas odczytu danych bryły. Pozostaje opcjonalna i wymaga potwierdzenia ostrzeżenia.

- Zielony/niebieski jest nadawany tylko po stwierdzeniu zgodności cech geometrycznych albo przy dokładnie tej samej referencji części (kiedy odczytana pozycja też się zgadza).
- Jeśli modele pochodzą z dwóch różnych plików i brak danych geometrycznych, taka sama nazwa i pozycja **nie dowodzą** tego samego kształtu. Aby nie dawać fałszywie zielonych wyników, taki element będzie szary (niezweryfikowany).
- Jeżeli istnieją zmiany położenia, ale nie uda się potwierdzić odpowiadających sobie geometrii, element będzie szary, a jego `DX/DY/DZ` i kąt pozostaną w raporcie.
- Porównanie cech geometrycznych **nie jest ścisłym testem identyczności B-Rep**. Zagnieżdżone podzłożenia nie są jeszcze rozwijane.

## Paleta (zweryfikowana z VxApi.h ZW3D 2019)

| Kolor | Znaczenie | Wartość evxColor |
|---|---|---:|
| Zielony | bez zmian | 1 |
| Niebieski | inna nazwa | 5 |
| Czerwony | dodany | 2 |
| Fioletowy | nowe położenie / obrót | 9 |
| Złoto-pomarańczowy półprzezroczysty | stare położenie | 4 |
| Żółty | nowa geometria | 17 |
| Brązowy półprzezroczysty | stara geometria | 3 |
| Złoto-pomarańczowy półprzezroczysty | usunięty | 4 |
| Szary | niezweryfikowany | 18 |

Przezroczystość starych pozycji ustawiana jest na 65%. Konkretne barwy na ekranie wynikają z palety ZW3D, a nie z kodów RGB użytych jako podgląd w legendzie HTML/Win32.

## Kompilacja przez GitHub Actions

**Dla aktualnego repozytorium `damianink-png/test`:** należy podmienić **zawartość pliku**
`DS_Assembly_Compare_GITHUB_ACTIONS_ZW3D2019_V1_1.zip` (nazwa musi pozostać dokładnie taka sama).
Repozytorium używa workflow `.github/workflows/build-ds-assembly-compare.yml`, który rozpakowuje ten ZIP, wywołuje `scripts/build.ps1` i publikuje artefakt z DLL.

1. Prześlij paczkę do gałęzi `main` pod powyższą nazwą.
2. Po kompilacji w **Actions** pobierz artefakt `DSAssemblyCompare2019-Windows-x64`.
3. Zamknij ZW3D, podmień DLL i ponownie uruchom ZW3D.
4. Uruchom polecenie `~DSAC`; `~DSAC_INFO` otworzy skróconą instrukcję.
5. Wskaż pliki A (stary) i B (nowy), wybierz obiekty z list i kliknij `POROWNAJ I UTWORZ RAPORT`.

W repo ZIP zawiera `source/`, `scripts/`, `tests/` i plik `README.md` oraz workflow. Jest też BAT do kompilacji lokalnej. Można najpierw przetestować V2.2 na małym modelu, zanim uruchomisz na dużym przyrządzie.

## Wynik

- `Dokumenty/DSAssemblyCompare/DSAC_V22_*.html` — kolorowa legenda i raport klasyfikacji.
- `Dokumenty/DSAssemblyCompare/DSAC_V22_*.csv` — detale A/B, nazwy, przesunięcia, obroty, różnice.
- `Dokumenty/DSAssemblyCompare/DSAC_V22_*_WYNIK.Z3` — model wynikowy (jeśli zaznaczono opcję utworzenia).
- `%TEMP%\DSAC_V22_TRACE.log` — log diagnostyczny.

Oryginalne pliki nie są celowo modyfikowane. Nie używaj tej wersji na jedynej kopii ważnego projektu bez wcześniejszego testu.
