#include "../source/overlay_policy.hpp"
#include "../source/root_picker_policy.hpp"
#include <cassert>
#include <iostream>
#include <cmath>
using namespace dsac;
static Item item(const std::string&name,double x){Item v;v.name=name;v.part=name;v.file="model.Z3";v.path="/"+name;v.pose.t[0]=x;return v;}
static Result row(){Result r;r.ia=0;r.ib=0;return r;}
int main(){
 // Matching and pose metadata
 Snapshot a,b;a.items.push_back(item("P1",0));b.items.push_back(item("P1",150));
 auto rows=compare(a,b);assert(rows.size()==1&&rows[0].moved);assert(std::abs(rows[0].dx-150)<1e-8);
 auto r=rows[0];assert(classify(r,true,true)==ChangeKind::Moved);
 assert(newRole(ChangeKind::Moved)==Role::Violet&&oldRole(ChangeKind::Moved)==Role::OldPosition);
 assert(showsOld(ChangeKind::Moved));
 // A and B identical: precisely one green, no old shape.
 r=row();r.geo=1;assert(classify(r,false,true)==ChangeKind::Unchanged);
 assert(newRole(ChangeKind::Unchanged)==Role::Green&&!showsOld(ChangeKind::Unchanged));
 r.geo=0;assert(classify(r,true,true)==ChangeKind::Unchanged);
 // Geometry unknown and different referenced file => gray, never red or green.
 assert(classify(r,false,true)==ChangeKind::Unverified);
 // Renamed but verified same component: blue only, no duplicate.
 r.nameChange=true;assert(classify(r,true,true)==ChangeKind::Renamed);
 assert(newRole(ChangeKind::Renamed)==Role::Blue&&!showsOld(ChangeKind::Renamed));
 assert(classify(r,false,true)==ChangeKind::Unverified);
 r.geo=1;assert(classify(r,false,true)==ChangeKind::Renamed);
 // Rename and movement => movement wins, rename remains a report flag.
 r.moved=true;assert(classify(r,false,true)==ChangeKind::Moved);
 // Geometry changed takes precedence even if also displaced.
 r.geo=-1;assert(classify(r,false,true)==ChangeKind::GeometryChanged);
 assert(newRole(ChangeKind::GeometryChanged)==Role::Yellow&&oldRole(ChangeKind::GeometryChanged)==Role::OldGeometry);
 r=row();r.geo=0;r.moved=true;assert(classify(r,false,true)==ChangeKind::Unverified);
 assert(classify(r,true,true)==ChangeKind::Moved);
 assert(classify(r,true,false)==ChangeKind::Unverified);
 r=row();r.ia=-1;assert(classify(r,false,true)==ChangeKind::Added);
 assert(newRole(ChangeKind::Added)==Role::Red&&!showsOld(ChangeKind::Added));
 r=row();r.ib=-1;assert(classify(r,false,true)==ChangeKind::Removed);
 assert(showsOld(ChangeKind::Removed)&&oldRole(ChangeKind::Removed)==Role::Removed);
 assert(isGhost(Role::OldPosition)&&isGhost(Role::OldGeometry)&&isGhost(Role::Removed));
 assert(!isGhost(Role::Green)&&!isGhost(Role::Violet));
 assert(zw3dColor(Role::Green)==1 && zw3dColor(Role::Violet)==9 && zw3dColor(Role::Yellow)==17);
 assert(zw3dColor(Role::OldPosition)==4 && zw3dColor(Role::OldGeometry)==3);
 Geometry g1,g2;g1.valid=true;g2.valid=true;SolidDescriptor so;so.area=123;so.volume=345;so.faces=6;so.edges=12;
 g1.solids.push_back(so);g2.solids.push_back(so);
 assert(compareGeometry(g1,g2)==1);g2.solids[0].faces=7;assert(compareGeometry(g1,g2)==-1);
 Snapshot c,d;c.items.push_back(item("ABC",0));d.items.push_back(item("ABC",0));d.items.push_back(item("NEW",0));
 assert(compare(c,d).size()==2);
 assert(autoRootIndex({true})==0);assert(autoRootIndex({false,false,false})==-1);
 assert(autoRootIndex({false,true,false})==1);assert(autoRootIndex({true,true,false})==-1);
 std::cout<<"DSAC V2.2: classification, rename, pose, old/new colors, geometry guards PASS\n";
}
