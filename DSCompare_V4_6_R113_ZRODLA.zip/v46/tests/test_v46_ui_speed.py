import os,time,json
from pathlib import Path
import numpy as np
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from OCP.gp import gp_Trsf,gp_Vec,gp_Ax1,gp_Pnt,gp_Dir
from OCP.TopLoc import TopLoc_Location
from dsac29.geometry import describe,DescriptionCache

@pytest.mark.parametrize('rotation',[0,.4,1.5707963267948966])
def test_cached_properties_equal_direct_properties(rotation):
 shape=BRepPrimAPI_MakeBox(20,30,7).Shape();cache=DescriptionCache()
 for i in range(8):
  tr=gp_Trsf();tr.SetRotation(gp_Ax1(gp_Pnt(0,0,0),gp_Dir(0,0,1)),rotation);tr.SetTranslationPart(gp_Vec(i*80,-i*25,11))
  instance=shape.Located(TopLoc_Location(tr));cached=cache.describe(instance,'P',str(i));direct=describe(instance,'P',str(i))
  for key in ('volume','area','center','inertia','eigenvalues','bbox'):assert np.allclose(getattr(cached,key),getattr(direct,key),rtol=1e-8,atol=1e-7),key
  assert cached.shape.IsSame(instance) and cached.path==str(i)
 assert cache.hits==(7 if rotation==0 else 0)

def test_bom_native_repeats_serialized_once(monkeypatch):
 from dsac29.report import geometry_groups
 from OCP.BRepTools import BRepTools
 shape=BRepPrimAPI_MakeBox(2,3,4).Shape();parts=[]
 for i in range(12):
  tr=gp_Trsf();tr.SetTranslation(gp_Vec(i*10,0,0));parts.append(describe(shape.Located(TopLoc_Location(tr)),str(i),str(i)))
 calls=[];original=BRepTools.Write_s
 def wrapped(*args):calls.append(1);return original(*args)
 monkeypatch.setattr(BRepTools,'Write_s',wrapped)
 assert geometry_groups(parts)==[list(range(12))]
 assert len(calls)<=1  # R11.1 R2: native STEP definition needs no serialization

def test_real_thumbnail_and_limit(tmp_path):
 from dsac29.thumbnails46 import make_thumbnail
 parts=[describe(BRepPrimAPI_MakeBox(2,3,4).Shape(),'P','P')]
 data=make_thumbnail(parts,tmp_path/'thumb.json');assert len(data['lines'])==12 and not data['truncated']
 assert data['parts']==1 and not data['edge_errors']
 limited=make_thumbnail(parts,tmp_path/'limited.json',max_edges=3);assert limited['truncated'] and len(limited['lines'])==3

def test_session_theme_filters_real_worker_and_reset(tmp_path,monkeypatch):
 os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
 from PySide6.QtCore import QSettings
 from PySide6.QtWidgets import QApplication,QMessageBox
 from dsac29.gui46 import Window
 QSettings.setDefaultFormat(QSettings.IniFormat);QSettings.setPath(QSettings.IniFormat,QSettings.UserScope,str(tmp_path/'settings'))
 errors=[];monkeypatch.setattr(QMessageBox,'warning',lambda *args:errors.append(str(args)))
 app=QApplication.instance() or QApplication([]);w=Window();w.show();app.processEvents()
 assert list(w.nav)==['compare','mass'] and not w.results and not w.a.path.text()
 w.theme.setCurrentText('Ciemny');assert '#101113' in w.styleSheet() and w.theme_quick.currentText()=='Ciemny'
 source=Path(__file__).resolve().parents[1]/'samples'
 w.a.path.setText(str(source/'MODEL_A.step'));w.b.path.setText(str(source/'MODEL_B.step'));w.output.setText(str(tmp_path/'out'));w.start('compare');deadline=time.monotonic()+30
 while w.process is not None and time.monotonic()<deadline:app.processEvents();time.sleep(.01)
 assert not errors,errors
 assert w.process is None and w.a.thumbnail.lines and w.b.thumbnail.lines
 assert w.compare_table.rowCount()==6 and w.compare_open['POROWNANIE_KOLORY.step'].isEnabled()
 w.select_filter('ADDED');assert sum(not w.compare_table.isRowHidden(i) for i in range(6))==2
 result=w.results['compare'];assert (result/'POROWNANIE_KOLORY.step').exists()
 w.close();w=Window()
 assert w.theme.currentText()=='Ciemny' and not w.results and w.compare_table.rowCount()==0
 assert not w.a.path.text() and not w.b.path.text() and not w.mass_file.path.text()
 assert not w.compare_open['POROWNANIE_KOLORY.step'].isEnabled()
 w.load_result('compare',result);w.reset_session();assert not w.results and w.compare_table.rowCount()==0
 assert (result/'POROWNANIE_KOLORY.step').exists()
 w.theme.setCurrentText('Jasny');assert '#f4f7fc' in w.styleSheet();w.close()
