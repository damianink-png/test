# DS Compare 4.6 R11.3

DS Compare 4.6 R11.3 — źródła i kompilacja Windows

Zmiany względem R112 R1:
- Kompletny raport zmian RAPORT_ZMIAN.html powstaje po eksporcie STEP,
  przed opcjonalnym grupowaniem BOM. Można go otworzyć podczas pracy.
- Parametry porównania: opcja „Pełny BOM”. Domyślnie wyłączona w GUI.
  Wyłączenie pomija grupowanie jednakowych części, nie porównanie geometrii.
  Wszystkie części, zmiany i łączna masa pozostają uwzględnione.
- Potwierdzona zgodność geometrii jest współdzielona między etapami analizy.
- Pełny BOM B może wykorzystać potwierdzone grupy A również przy częściowych
  zmianach rewizji. Nierozstrzygnięte pary nie są przenoszone.
- Błędy grupowania generują UWAGI_BOM.txt i ostrzeżenie w raporcie.
  Błąd sprawdzania populacji części pozostaje wynikiem „Do sprawdzenia”.
- CZASY_ANALIZY.json: czas importu, dopasowania, BOM, całego procesu,
  statystyki pamięci podręcznej i do 50 najwolniejszych sprawdzeń BOM/populacji.
- Ponowne użycie folderu wyników usuwa nieaktualne raporty i BOM.
- Zachowane dwa widoki: Porównanie i Masa części, jasny/ciemny motyw,
  wybór/przeciąganie plików i pusta sesja po uruchomieniu.

Raporty:
RAPORT_ZMIAN.html — wczesny raport wszystkich zmian z wyszukiwaniem.
RAPORT.html — końcowy raport, zawiera również ostrzeżenia BOM.
ZMIANY.csv — lista zmian; BOM_A/B.csv tylko przy włączonym pełnym BOM.
POROWNANIE_KOLORY.step — kolorowy model porównania.
Masa jest liczona dla brył SOLID ze wspólną wybraną gęstością.
Powierzchnie poza bryłami nie są porównywane; raport ujawnia ich liczbę.

API process(..., full_bom=True) zachowuje wcześniejsze zachowanie.
Worker: --no-bom wyłącza pełny BOM. Preferencja GUI jest zapamiętywana.
Optymalizacja nie zmienia tolerancji porównania. Nie deklarujemy procentowego
przyspieszenia bez ponownego pomiaru na tych samych dużych modelach.

Kompilacja GitHub:
1. Wgraj DSCompare_V4_6_R113_ZRODLA.zip do głównego katalogu repozytorium.
2. Wgraj build-dscompare-v46-r113.yml do .github/workflows/.
3. Actions → DS Compare V4.6 R113 → Run workflow.
4. Po sukcesie pobierz artefakt DSCompare-V4.6-R113-Windows-x64-EXE-DLL.
   W nim znajduje się ZIP programu. Rozpakuj całość, zachowując _internal.
Nie wystarczy wgrać zewnętrznej paczki GITHUB.zip bez jej rozpakowania.
Nie zmieniaj nazwy archiwum źródeł — workflow używa jej dosłownie.

Workflow: Windows 2022 x64, Python 3.11, testy, PyInstaller, MSVC DLL,
sprawdzenie gotowego EXE, AP214/AP242, wariantu bez BOM, masy, GUI i eksportów DLL.
DLL jest eksperymentalnym mostkiem dla ZW3D 2019. Samo załadowanie DLL
nie potwierdza zgodności z działającym ZW3D ani wyświetlania przezroczystości.
Aktualna paczka zawiera źródła, nie gotowy EXE. Nie uruchomiono dla niej
kompilacji Windows na GitHub i nie przeprowadzono testu w ZW3D.
