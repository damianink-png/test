from __future__ import annotations
import argparse,sys,traceback
from time import perf_counter
from pathlib import Path
from .step_io import load_step
from .compare import compare
from .report import produce


def process(a_path,b_path,output,tolerance=0.01,density=7850.,step=True,progress=print,cancelled=None,colors=None,diff_step=True,preview3d=False,align=False,direct_scene=False,manual_review=None,revision_style=False,old_alpha=0.4,thumbnails=False):
    ts=perf_counter()
    from .manual_pairs import fingerprint
    fingerprints={'A':fingerprint(a_path),'B':fingerprint(b_path)}
    if manual_review and manual_review['fingerprints']!=fingerprints:raise ValueError('Pliki źródłowe zmieniły się od analizy; pary ręczne nie zostały zastosowane')
    if progress:progress('Wczytywanie starszej wersji modelu…')
    a=load_step(a_path,progress=progress)
    if progress:progress(f'Wczytywanie A: {perf_counter()-ts:.1f} s; brył: {len(a)}')
    tb=perf_counter()
    b=load_step(b_path,progress=progress)
    if progress:progress(f'Wczytywanie B: {perf_counter()-tb:.1f} s; brył: {len(b)}')
    alignment={'requested':bool(align),'enabled':False}
    (Path(output)/'OSTRZEZENIA.txt').unlink(missing_ok=True)
    if align:
        from .alignment import align_assembly, AlignmentUnavailable
        try:b,alignment=align_assembly(a,b,tolerance,progress)
        except AlignmentUnavailable as exc:
            warning='Nie zastosowano wyrównania: '+str(exc)+' Porównano oryginalne położenia modeli.'
            alignment={'requested':True,'enabled':False,'warning':warning}
            if progress:progress('UWAGA: '+warning)
    tc=perf_counter()
    rec=compare(a,b,tolerance,progress=progress,cancelled=cancelled)
    if manual_review:
        from .manual_pairs import apply_pairs
        rec=apply_pairs(a,b,rec,manual_review['pairs'],tolerance)
    if progress:progress(f'Dopasowanie geometrii: {perf_counter()-tc:.1f} s')
    if progress:progress('Zapis raportów CSV/HTML i modelu porównawczego STEP...')
    folder,err=produce(output,a,b,rec,density,generate_step=step,colors=colors,
                       diff_step=diff_step,tolerance=tolerance,progress=progress,preview3d=preview3d,revision_style=revision_style,old_alpha=old_alpha)
    import json
    summary_path=folder/'PODSUMOWANIE.json'
    summary=json.loads(summary_path.read_text(encoding='utf-8'))
    summary.update(source_fingerprints=fingerprints,manual_pairs=manual_review['pairs'] if manual_review else [],alignment=alignment,source_A=str(Path(a_path).resolve()),source_B=str(Path(b_path).resolve()),tolerance_mm=tolerance)
    if alignment.get('warning'):
        warning=alignment['warning']
        (folder/'OSTRZEZENIA.txt').write_text(warning+'\n',encoding='utf-8')
        import html
        report=folder/'RAPORT.html'
        report.write_text(report.read_text(encoding='utf-8').replace('<body>','<body><p role=alert><strong>'+html.escape(warning)+'</strong></p>',1),encoding='utf-8')
    if revision_style:
        import html
        report=folder/'RAPORT.html'
        provenance=f'<div class="panel"><b>A — stara rewizja:</b> {html.escape(Path(a_path).name)}<br><b>B — nowa rewizja:</b> {html.escape(Path(b_path).name)}<br>Tolerancja: {tolerance} mm</div>'
        if err:provenance+='<p role="alert"><b>Eksport STEP nie powiódł się:</b> '+html.escape(err)+'</p>'
        report.write_text(report.read_text(encoding='utf-8').replace('<body>','<body>'+provenance,1),encoding='utf-8')
        summary.update(export_style='revision_A_B',old_alpha=old_alpha)
    summary_path.write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    if thumbnails:
        from .thumbnails46 import make_thumbnail
        for role,parts in [('A',a),('B',b)]:
            try:make_thumbnail(parts,folder/f'MINIATURA_{role}.json')
            except Exception as exc:
                if progress:progress('Miniatura niedostępna: '+str(exc))
    if direct_scene:
        from .scene42 import make_result_scene
        try:
            info=make_result_scene(a,b,rec,folder,colors,progress)
            if not info['complete']:
                warning=f"Niepełny podgląd: {info['rendered_records']}/{info['expected_records']} pozycji. Zobacz SCENA_DIAGNOSTYKA.json."
                (folder/'UWAGI_SCENA.txt').write_text(warning,encoding='utf-8')
                if progress:progress(warning)
        except Exception as exc:
            (folder/'UWAGI_SCENA.txt').write_text(str(exc),encoding='utf-8')
            if progress:progress('Podgląd niedostępny: '+str(exc))
    if progress:progress(f'Łączny czas przetwarzania: {perf_counter()-ts:.1f} s')
    if progress:progress('Gotowe: '+str(folder)+((' (UWAGA eksport STEP: '+err+')') if err else ''))
    return folder,rec,err


def main(argv=None):
    p=argparse.ArgumentParser(description='DS Assembly Compare V2.9 B-Rep STEP prototype')
    p.add_argument('a',help='Model A, STEP/STP')
    p.add_argument('b',help='Model B, STEP/STP')
    p.add_argument('-o','--output',default='DSAC_V29_WYNIKI')
    p.add_argument('--tolerance',type=float,default=0.01,help='mm, default 0.01')
    p.add_argument('--density',type=float,default=7850.,help='kg/m³; default steel 7850')
    p.add_argument('--no-step',action='store_true',help='Do not create colored STEP')
    ns=p.parse_args(argv)
    try:
        if ns.density<=0 or ns.density>25000:raise ValueError('Nieprawidlowa gestosc')
        folder,recs,err=process(ns.a,ns.b,ns.output,ns.tolerance,ns.density,not ns.no_step)
        print('\nRAPORT:',folder/'RAPORT.html')
        return 0 if err is None else 2
    except Exception:
        traceback.print_exc()
        return 1
if __name__=='__main__':sys.exit(main())
