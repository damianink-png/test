# DS Makieta V36 UI5 R1 – poprawa nosa | ZW3D 2019 x64

## Zmiany

1. **Płytki przy otworze** – geometria nosa ma dokładnie tę samą oś (L, Y=0, Z=holeZ) co płytki. Płaszczyzna końcowa profilu nosowego jest wyznaczana jako połowa długości płytki `blockX/2` wzdłuż osi nosa. Płytki i profil kończą się zatem w jednej płaszczyźnie; ich przekroje XZ mają te same wymiary oraz orientację.
2. **Wystawanie profilu nosa na górze** – usunięte wcześniejsze sztuczne podniesienie o P/2. Zamiast tego nachylenie profilu obliczane jest tak, aby jego górna płaszczyzna w miejscu połączenia była zgodna z górną płaszczyzną pasa `PAS_GORA`.
3. Zachowane docinanie `NOS_GORA` do pionowej płaszczyzny końcowej `PAS_GORA` (z poprzedniej poprawki) i ten sam obraz 3D z wymiarami literowymi.

## Kompilacja bez GitHuba

1. Rozpakuj **całą paczkę** do zwykłego folderu na Windows 10 lub 11, np. `C:\DS_Makieta_UI5`. Nie uruchamiaj BAT z wnętrza ZIP.
2. Potrzebujesz Visual Studio 2022 lub Build Tools z komponentem **Desktop development with C++**, narzędziami MSVC x64 i **Windows SDK**. Uprawnienia administratora są zwykle potrzebne do ich instalacji, ale nie do kompilacji.
3. Kliknij dwukrotnie **`KOMPILUJ.bat`**. Skrypt szuka środowiska MSVC, kompiluje zasób graficzny oraz DLL, weryfikuje format x64 i tworzy ZIP.
4. Po sukcesie znajdziesz w folderze `output`:
   - `DSMakieta2019.dll`
   - `DSAssembly2019.dll`
   - `DS_Makieta_UI5_DLL_GOTOWE.zip` (obie DLL razem)
5. Zamknij ZW3D, zrób kopię wcześniejszych DLL. Wczytaj nowe DLL z **tego samego folderu**.
6. Testuj najpierw `~DSMakietaUITest`, później `~DSMakieta` na pustej, testowej części.

## Diagnostyka

Gdy kompilacja zgłosi błąd, prześlij pliki `output/KOMPILACJA_MAKIETA.log`, `output/START_BAT.log` oraz `output/STATUS_KOMPILACJI.txt`.

**Status:** geometria obliczeniowa przeszła testy offline dla czterech konfiguracji. Nie uruchamiałem tej kompilacji w Windows ani w ZW3D. Fizyczne wyniki `FtSolidTrim`, przyleganie ścian i poprawność złożenia wymagają sprawdzenia w ZW3D.
