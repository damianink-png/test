#include "../source/makieta_core.h"
#include <cstdio>
#include <cassert>
#include <cstring>
#include <cmath>
#include <algorithm>
static Member* findMember(Plan& p,const char* name,int occurrence=0){
 for(int i=0;i<p.count;i++)if(!strncmp(p.m[i].name,name,strlen(name))){if(!occurrence--)return &p.m[i];}return nullptr;
}
static void test(Config c){
 Plan plan={};char err[512]={};if(!makePlan(c,plan,err)){fprintf(stderr,"makePlan failed: %s\n",err);assert(false);}
 Member* top=findMember(plan,"NOS_GORA");Member* plateL=findMember(plan,"NAKLADKA_OTWOR",0),*plateR=findMember(plan,"NAKLADKA_OTWOR",1);
 assert(top&&plateL&&plateR);
 const double main=c.L-c.nose;
 const double hi=c.H-2*c.blockY-c.profile/2;
 const double mainTop=hi+c.profile/2;
 Vec w=unit(vsub(top->b,top->a));
 double slope=w.z/w.x;
 double noseCentreAtJunction=top->a.z+(main-top->a.x)*slope;
 double noseUpperAtJunction=noseCentreAtJunction+c.profile/2*sqrt(1+slope*slope);
 assert(fabs(noseUpperAtJunction-mainTop)<1e-8);
 double noseCentreAtHole=top->a.z+(c.L-top->a.x)*slope;
 assert(fabs(noseCentreAtHole-c.holeZ)<1e-8);
 Vec plateCentre={c.L,0,c.holeZ};
 Vec plateFront=vadd(plateCentre,vmul(w,c.blockX/2));
 assert(length(vsub(plateFront,top->b))<1e-8);
 assert(fabs(plateL->b.y+c.profile/2)<1e-9); // flush with -Y face of nose
 assert(fabs(plateR->a.y-c.profile/2)<1e-9); // flush with +Y face of nose
 assert(fabs(plateL->b.y-plateL->a.y-c.blockY)<1e-9);
 assert(fabs(plateR->b.y-plateR->a.y-c.blockY)<1e-9);
 assert(fabs(top->width-plateL->depth)<1e-9); // no plate edge projects beyond the 40x40 XZ section
 printf("PASS %d members; P=%g, L=%g, N=%g, nose slope=%g, top z=%.6f, plate front x=%.3f\n",plan.count,c.profile,c.L,c.nose,slope,noseUpperAtJunction,top->b.x);
}
int main(){
 Config c=defaults();test(c);
 c.L=4000;c.nose=1000;c.W=240;c.H=650;c.holeZ=350;test(c);
 c=defaults();c.profile=50;c.wall=3;c.W=220;c.H=450;c.blockZ=c.profile;c.blockX=64;test(c);
 c=defaults();c.nose=500;c.L=2200;c.holeZ=200;test(c);
 puts("UI5_GEOMETRY_TESTS_PASS");
}
