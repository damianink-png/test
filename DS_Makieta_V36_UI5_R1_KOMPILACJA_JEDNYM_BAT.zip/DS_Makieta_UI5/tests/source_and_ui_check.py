from pathlib import Path
import hashlib,re
base=Path(__file__).resolve().parents[1]
src=(base/'source/DSMakieta2019.cpp').read_text(encoding='utf-8')
ui=(base/'source/makieta_ui_v36.h').read_text(encoding='utf-8')
core=(base/'source/makieta_core.h').read_bytes()
assert '#include "makieta_ui_v36.h"' in src
assert 'DSAssemblyMakietaVersion' not in ui
assert 'loadAssembly()' in src and 'convertAssembly()' in src
assert 'DSMakieta2019Init' in src and 'DSMakieta2019Exit' in src
assert 'InitCommonControlsEx' in ui
assert 'paintPreview' in ui and 'showPlan' in ui
assert 'TTM_ADDTOOLA' in ui
assert 'saveSettings(c)' in ui and 'loadSettings(c)' in ui
assert 'case WM_PAINT:' in ui
assert all(f'"{s}"' in ui for s in ('L','W','H','N','T','Z','D','G'))
assert len(re.findall(r'&Config::(?:L|W|H|nose|tail|holeZ|holeD|gap)\b',ui))==8
assert b'const double noseStartX=main-P*.75;' in core
assert b'const double noseCentreAtJunction' not in core
assert b'Vec end=vadd(Vec{c.L,0,c.holeZ},vmul(along,c.blockX/2))' in core
assert b'c.holeZ+(x-c.L)*slope-P/(2*along.x)' in core
print('PASS UI integration and UI5 corrected nose geometry; core_sha256='+hashlib.sha256(core).hexdigest())

# Win32 TranslateMessage has no ANSI/Wide suffix; reject old regression.
ui=(base/'source'/'makieta_ui_v36.h').read_text(encoding='utf-8')
assert 'TranslateMessageA' not in ui
assert 'TranslateMessage(&m)' in ui
