@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
if not exist "output" mkdir "output"
>"output\START_BAT.log" echo START DS Makieta V36 UI5 - local Visual Studio x64
>>"output\START_BAT.log" echo Date=%DATE% %TIME%
>>"output\START_BAT.log" echo Folder=%CD%
echo.
echo DS Makieta V36 UI5 - kompilacja x64 bez GitHuba
echo.
where powershell.exe >nul 2>&1
if errorlevel 1 goto :NoPowerShell
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0KOMPILUJ_MAKIETE.ps1" >>"output\START_BAT.log" 2>&1
set "DS_RC=%errorlevel%"
if not "%DS_RC%"=="0" goto :Failure
echo.
echo SUKCES - gotowe pliki sa w folderze output:
echo   DSMakieta2019.dll
echo   DSAssembly2019.dll
echo   DS_Makieta_UI5_DLL_GOTOWE.zip
echo.
echo Test w ZW3D: ~DSMakietaUITest, potem ~DSMakieta
echo.
pause
exit /b 0
:NoPowerShell
echo ERROR: Brak Windows PowerShell.
>>"output\START_BAT.log" echo ERROR=POWERSHELL_NOT_FOUND
pause
exit /b 21
:Failure
echo.
echo BLAD KOMPILACJI - kod %DS_RC%
echo Zachowaj i przeslij logi: output\KOMPILACJA_MAKIETA.log oraz output\START_BAT.log
echo Sprawdz, czy zainstalowano Visual Studio z Desktop development with C++
echo i Windows SDK. Zamknij ZW3D przed ponowna proba.
echo.
pause
exit /b %DS_RC%
