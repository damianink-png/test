// DS Makieta 2019 V36 UI5 AUTO. ZW3D API resolved from the host. No zw3d.lib required.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include "VxApi.h"
#include "makieta_core.h"
#include "runtime_policy.h"
#include <stdlib.h>
#include <errno.h>
static_assert(sizeof(svxMatrix)==104,"ZW3D x64 matrix ABI");
static_assert(sizeof(svxBoxData)==88,"ZW3D x64 box ABI");
static_assert(sizeof(svxCylData)==80,"ZW3D x64 cylinder ABI");
static_assert(sizeof(svxGeomExport)==648,"ZW3D x64 export ABI");
#define API(name) static decltype(&name) p_##name=nullptr
API(cvxPartInqFtrList);API(cvxPartInqFtrTemplate);API(cvxPartInqFtrData);API(cvxDataGetList);API(cvxDataGetOpt);API(cvxDataGet);API(cvxDataFree);API(cvxPartLine2pt);API(cvxCmdFunc);API(cvxCmdFuncUnload);API(cvxMsgDisp);API(cvxMemFree);
API(cvxPartInqFaceFacets);API(cvxFaceEval);API(cvxFaceParam);API(cvxDataDel);API(cvxEntBlank);API(cvxDataInit);API(cvxDataSet);API(cvxCmdExec);API(cvxPartCir3pt);API(cvxPartCrvList);API(cvxPartExtrude);API(cvxPartBox);API(cvxPartCyl);API(cvxPartBool2);API(cvxPartCopyTransform);
API(cvxPartMoveTransform);API(cvxPartErase);API(cvxPartInqShapes);
API(cvxPartInqCurves);API(cvxPartInqComps);API(cvxCompInqPart);API(cvxPartGeomExport);API(cvxEntNameSet);
API(cvxEntBndBox);API(cvxPartInqFaceBox);API(cvxPartInqShapeMass);API(cvxPartInqShapeBox);API(cvxPartInqShapeFaces);API(cvxPartInqEntLabel);API(cvxPartInqEntByLabel);API(cvxUndoRedoMarker);API(cvxUndoRedoTo);
API(cvxGetExternalPick);API(cvxPartIsectShpChk);API(cvxRootList);
static HMODULE gModule;static Config cfg=defaults();static Plan plan;
static int ids[1800];static double masses[1800];static bool massKnown[1800];static int shapeLabels[1800][256];static int massUnavailable=0;static char massDiagnostics[8192];static char lastError[512];
static FARPROC findApi(const char*name){
 HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPMODULE,GetCurrentProcessId());
 if(snap==INVALID_HANDLE_VALUE)return nullptr;
 MODULEENTRY32 e={};e.dwSize=sizeof(e);FARPROC p=nullptr;
 if(Module32First(snap,&e))do{p=GetProcAddress(e.hModule,name);if(p)break;}while(Module32Next(snap,&e));
 CloseHandle(snap);return p;
}
static bool resolveApi(){
#define GET(n) p_##n=(decltype(p_##n))findApi(#n);if(!p_##n){snprintf(lastError,sizeof(lastError),"Brak funkcji API: %s",#n);return false;}
 p_cvxPartInqFtrList=(decltype(p_cvxPartInqFtrList))findApi("cvxPartInqFtrList");
 p_cvxPartInqFtrTemplate=(decltype(p_cvxPartInqFtrTemplate))findApi("cvxPartInqFtrTemplate");
 p_cvxPartInqFtrData=(decltype(p_cvxPartInqFtrData))findApi("cvxPartInqFtrData");
 p_cvxDataGetList=(decltype(p_cvxDataGetList))findApi("cvxDataGetList");
 p_cvxDataGetOpt=(decltype(p_cvxDataGetOpt))findApi("cvxDataGetOpt");
 p_cvxDataGet=(decltype(p_cvxDataGet))findApi("cvxDataGet");
 p_cvxDataFree=(decltype(p_cvxDataFree))findApi("cvxDataFree");
 p_cvxEntBlank=(decltype(p_cvxEntBlank))findApi("cvxEntBlank");
 GET(cvxPartInqFaceFacets);GET(cvxFaceEval);GET(cvxFaceParam);GET(cvxDataDel);GET(cvxDataInit);GET(cvxDataSet);GET(cvxCmdExec);GET(cvxDataFree);GET(cvxPartCrvList);GET(cvxPartExtrude);GET(cvxPartLine2pt);GET(cvxCmdFunc);GET(cvxCmdFuncUnload);GET(cvxMsgDisp);GET(cvxMemFree);GET(cvxPartBox);GET(cvxPartCyl);
 GET(cvxPartCir3pt);GET(cvxPartBool2);GET(cvxPartCopyTransform);GET(cvxPartMoveTransform);GET(cvxPartErase);
 GET(cvxPartInqCurves);GET(cvxPartInqShapes);GET(cvxPartInqComps);GET(cvxCompInqPart);GET(cvxPartGeomExport);
 GET(cvxEntNameSet);GET(cvxPartInqShapeBox);GET(cvxPartInqShapeFaces);GET(cvxPartInqEntLabel);GET(cvxPartInqEntByLabel);
 p_cvxEntBndBox=(decltype(p_cvxEntBndBox))findApi("cvxEntBndBox");
 p_cvxPartInqFaceBox=(decltype(p_cvxPartInqFaceBox))findApi("cvxPartInqFaceBox");
 p_cvxPartInqShapeMass=(decltype(p_cvxPartInqShapeMass))findApi("cvxPartInqShapeMass");GET(cvxUndoRedoMarker);GET(cvxUndoRedoTo);
 GET(cvxPartIsectShpChk);GET(cvxRootList);
#undef GET
 return true;
}
static void msg(const char*s){if(p_cvxMsgDisp)p_cvxMsgDisp((char*)s);}
static void failure(const char*s){strncpy(lastError,s,sizeof(lastError)-1);lastError[sizeof(lastError)-1]=0;}
static svxMatrix identity(){svxMatrix m={};m.identity=1;m.xx=m.yy=m.zz=1;return m;}
static svxMatrix frame(const Member&m){Vec u,v,w;memberFrame(m,u,v,w);svxMatrix f={};f.xx=u.x;f.yx=v.x;f.zx=w.x;f.xt=m.a.x;f.xy=u.y;f.yy=v.y;f.zy=w.y;f.yt=m.a.y;f.xz=u.z;f.yz=v.z;f.zz=w.z;f.zt=m.a.z;return f;}
static bool activeShape(int id){
 int n=0,*list=nullptr;int rc=p_cvxPartInqShapes(nullptr,nullptr,&n,&list);bool found=false;
 if(rc==0&&list)for(int i=0;i<n;i++)if(list[i]==id){found=true;break;}
 if(list)p_cvxMemFree((void**)&list);return found;
}
static bool storeLabel(int id,int*out){
 memset(out,0,256*sizeof(int));int*label=nullptr;
 if(p_cvxPartInqEntLabel(id,&label)||!label){if(label)p_cvxMemFree((void**)&label);return false;}
 int i=0;for(;i<255&&label[i];i++)out[i]=label[i];bool ok=label[i]==0;out[i]=0;p_cvxMemFree((void**)&label);return ok;
}
static bool refresh(int&id,const int*label){
 int current=0;if(label&&label[0]&&p_cvxPartInqEntByLabel((int*)label,1,&current)==0&&current>0&&activeShape(current)){id=current;return true;}
 return activeShape(id);
}
static bool moveTracked(int&id,const svxMatrix&f){
 int label[256]={};storeLabel(id,label);
 int count=0,*before=nullptr;if(p_cvxPartInqShapes(nullptr,nullptr,&count,&before))return false;
 int rc=p_cvxPartMoveTransform(id,&f);
 bool ok=rc==0&&refresh(id,label);
 if(rc==0&&!ok){
  int n=0,*after=nullptr;if(p_cvxPartInqShapes(nullptr,nullptr,&n,&after)==0){
   int candidate=0;if(uniqueReplacement(before,count,after,n,candidate)){id=candidate;ok=true;}
  }if(after)p_cvxMemFree((void**)&after);
 }
 if(before)p_cvxMemFree((void**)&before);
 if(!ok)failure("Nie potwierdzono aktualnego identyfikatora bryly po przesunieciu.");return ok;
}
// Never use output from a failed query. Some 2019 tube bodies reject ShapeBox;
// retry the explicit frame, then use generic entity/complete face bounds.
static bool boundsValid(const svxBndBox&b,bool solid){
 return finiteBounds(b.X.min,b.X.max,b.Y.min,b.Y.max,b.Z.min,b.Z.max,solid);
}
static bool readBounds(int id,svxBndBox&out){
 svxBndBox b={};
 if(p_cvxPartInqShapeBox(id,nullptr,&b)==0&&boundsValid(b,true)){out=b;return true;}
 b={};svxMatrix f=identity();
 if(p_cvxPartInqShapeBox(id,&f,&b)==0&&boundsValid(b,true)){out=b;return true;}
 b={};if(p_cvxEntBndBox&&p_cvxEntBndBox(id,&b)==0&&boundsValid(b,true)){out=b;return true;}
 if(!p_cvxPartInqFaceBox)return false;
 int n=0,*faces=nullptr;int rc=p_cvxPartInqShapeFaces(id,&n,&faces);
 bool ok=rc==0&&n>=4&&faces;svxBndBox all={};
 for(int i=0;i<n&&ok;i++){
  b={};if(p_cvxPartInqFaceBox(faces[i],&b)!=0||!boundsValid(b,false)){ok=false;break;}
  if(i==0)all=b;else{all.X.min=fmin(all.X.min,b.X.min);all.X.max=fmax(all.X.max,b.X.max);all.Y.min=fmin(all.Y.min,b.Y.min);all.Y.max=fmax(all.Y.max,b.Y.max);all.Z.min=fmin(all.Z.min,b.Z.min);all.Z.max=fmax(all.Z.max,b.Z.max);}
 }
 if(faces)p_cvxMemFree((void**)&faces);
 if(ok&&boundsValid(all,true)){out=all;return true;}return false;
}
// A shared face is a weld contact, not a material overlap. Never boolean-cut it.
static bool materialIntersection(int a,int b){
 svxBndBox x={},y={};
 if(!readBounds(a,x)||!readBounds(b,y))return p_cvxPartIsectShpChk(a,b)==1;
 const double tol=1e-5;
 if(fmin(x.X.max,y.X.max)-fmax(x.X.min,y.X.min)<=tol||
    fmin(x.Y.max,y.Y.max)-fmax(x.Y.min,y.Y.min)<=tol||
    fmin(x.Z.max,y.Z.max)-fmax(x.Z.min,y.Z.min)<=tol)return false;
 return p_cvxPartIsectShpChk(a,b)==1;
}
static bool shapeGeometry(int id){
 if(!activeShape(id)){failure("Identyfikator elementu nie wskazuje na aktualna bryle.");return false;}
 svxBndBox b={};int n=0,*faces=nullptr;
 int rb=readBounds(id,b)?0:1;int rf=p_cvxPartInqShapeFaces(id,&n,&faces);if(faces)p_cvxMemFree((void**)&faces);
 if(rb||rf||n<4||!isfinite(b.X.min)||!isfinite(b.X.max)||!isfinite(b.Y.min)||!isfinite(b.Y.max)||!isfinite(b.Z.min)||!isfinite(b.Z.max)||b.X.max-b.X.min<1e-7||b.Y.max-b.Y.min<1e-7||b.Z.max-b.Z.min<1e-7){
 char detail[420];snprintf(detail,sizeof(detail),"Kontrola bryly: id=%d, Box_rc=%d, Faces_rc=%d, sciany=%d, rozmiar=(%.9g,%.9g,%.9g).",id,rb,rf,n,b.X.max-b.X.min,b.Y.max-b.Y.min,b.Z.max-b.Z.min);failure(detail);return false;}return true;
}
static void readMass(int index){
 massKnown[index]=false;masses[index]=0;svxMassProp mass={};
 int rc=p_cvxPartInqShapeMass?p_cvxPartInqShapeMass(ids[index],7.85e-6,&mass):-1;
 double kg=0;if(massFromVolume(rc,mass.Volume,kg)){massKnown[index]=true;masses[index]=kg;return;}
 massUnavailable++;char row[256];snprintf(row,sizeof(row),"%s: id=%d, API_rc=%d, Volume=%.9g, Mass=%.9g, Density=%.9g\r\n",plan.m[index].name,ids[index],rc,mass.Volume,mass.Mass,mass.Density);
 size_t used=strlen(massDiagnostics);if(used+strlen(row)<sizeof(massDiagnostics))strcat(massDiagnostics,row);
}
static bool subtract(int&base,int tool,bool preserve){
 int op=tool;if(preserve){svxMatrix m=identity();if(p_cvxPartCopyTransform(tool,&m,&op)||op<=0){failure("Nie mozna skopiowac narzedzia docinania.");return false;}}
 int n=0,*result=nullptr;int rc=p_cvxPartBool2(VX_BOOL_REMOVE,1,&base,1,&op,&n,&result);
 bool ok=rc==0&&n==1&&result&&result[0]>0;
 if(ok)base=result[0];if(result)p_cvxMemFree((void**)&result);
 if(!ok){char detail[256];snprintf(detail,sizeof(detail),"Odejmowanie: API_rc=%d, liczba wynikow=%d, baza=%d, narzedzie=%d.",rc,n,base,tool);failure(detail);}return ok;
}
static bool box(double x,double y,double z,svxPoint center,int&id){svxBoxData b={};b.Combine=VX_BOOL_NONE;b.Center=center;b.X=x;b.Y=y;b.Z=z;return p_cvxPartBox(&b,&id)==0&&id>0;}
static bool cylinder(double radius,double h,double z,int&id){svxCylData b={};b.Combine=VX_BOOL_NONE;b.Center={0,0,z};b.Radius=radius;b.Length=h;return p_cvxPartCyl(&b,&id)==0&&id>0;}
// Hole plates are built directly in their final global frame as well.
static bool buildHolePlate(const Member&m,int&id){
 Vec u,v,w;memberFrame(m,u,v,w);int edges[4]={},profile=0;
 const double x[4]={-m.width/2,m.width/2,m.width/2,-m.width/2};
 const double y[4]={-m.depth/2,-m.depth/2,m.depth/2,m.depth/2};
 svxPoint pts[4];for(int k=0;k<4;k++){Vec q=vadd(m.a,vadd(vmul(u,x[k]),vmul(v,y[k])));pts[k]={q.x,q.y,q.z};}
 for(int k=0;k<4;k++)if(p_cvxPartLine2pt(&pts[k],&pts[(k+1)%4],&edges[k])||edges[k]<=0)return false;
 if(p_cvxPartCrvList(4,edges,&profile)||profile<=0)return false;
 svxExtrudeData e={};e.Combine=VX_BOOL_NONE;e.idProfile=profile;e.Start=0;e.End=length(vsub(m.b,m.a));e.UseDirection=1;e.Direction={w.x,w.y,w.z};e.iKeep=0;
 if(p_cvxPartExtrude(&e,&id)||id<=0)return false;
 return p_cvxEntNameSet(id,m.name)==0;
}
static bool buildMember(const Member&m,int&id){
 double len=length(vsub(m.b,m.a));id=0;int tool=0;
 if(m.kind==TUBE){if(!cylinder(m.width/2,len,0,id)||!cylinder(m.width/2-m.wall,len+2,-1,tool)||!subtract(id,tool,false))return false;}
 else {if(!box(m.width,m.depth,len,{0,0,len/2},id))return false;
  if(m.kind==PROFILE&&(!box(m.width-2*m.wall,m.depth-2*m.wall,len+2,{0,0,len/2},tool)||!subtract(id,tool,false)))return false;}
 svxMatrix f=frame(m);if(moveTracked(id,f)==false){failure("Nie mozna ustawic elementu w przestrzeni.");return false;}
 if(p_cvxEntNameSet(id,m.name)){failure("Nie mozna nazwac elementu.");return false;}return true;
}
// Use solid envelopes when fitting a member to a hollow support. Cutting only the
// support wall would leave detached plugs inside its cavity.
static bool trimToSupport(int&base,int support,const Member&m){
 int tool=0;double len=length(vsub(m.b,m.a));
 if(!(m.kind==TUBE?cylinder(m.width/2,len,0,tool):box(m.width,m.depth,len,{0,0,len/2},tool))){failure("Nie mozna utworzyc obwiedni podpory.");return false;}
 svxMatrix f=frame(m);if(moveTracked(tool,f)==false){failure("Nie mozna ustawic obwiedni podpory.");return false;}
 return subtract(base,tool,false); // Do not silently skip a planned cut on IsectShpChk error.
}
static bool addHole(int&id){
 svxMassProp before={},after={};
 if(!p_cvxPartInqShapeMass||p_cvxPartInqShapeMass(id,7.85e-6,&before)||!isfinite(before.Volume)||before.Volume<=0){failure("Nie mozna sprawdzic bryly przed otworem.");return false;}
 svxBndBox bounds={};if(!readBounds(id,bounds)){failure("Nie mozna sprawdzic polozenia bryly otworu.");return false;}
 const double radius=cfg.holeD/2;
 const double y0=fmin(bounds.Y.min,-cfg.profile/2-cfg.blockY)-2;
 const double y1=fmax(bounds.Y.max,cfg.profile/2+cfg.blockY)+2;
 // Circle lies in the world XZ plane. Extrusion has an explicit world +Y direction.
 svxPoint pts[3]={{cfg.L+radius,y0,cfg.holeZ},{cfg.L,y0,cfg.holeZ+radius},{cfg.L-radius,y0,cfg.holeZ}};
 int curve=0,tool=0;
 if(p_cvxPartCir3pt(&pts[0],&pts[1],&pts[2],&curve)||curve<=0){failure("Nie mozna utworzyc okregu otworu.");return false;}
 svxExtrudeData e={};e.Combine=VX_BOOL_NONE;e.idProfile=curve;e.Start=0;e.End=y1-y0;e.UseDirection=1;e.Direction={0,1,0};e.iKeep=0;
 if(p_cvxPartExtrude(&e,&tool)||tool<=0){failure("Nie mozna utworzyc narzedzia otworu wzdluz osi Y.");return false;}
 svxBndBox tb={};
 if(!readBounds(tool,tb)||fabs(tb.X.min-(cfg.L-radius))>.02||fabs(tb.X.max-(cfg.L+radius))>.02||fabs(tb.Z.min-(cfg.holeZ-radius))>.02||fabs(tb.Z.max-(cfg.holeZ+radius))>.02||tb.Y.min>bounds.Y.min-.5||tb.Y.max<bounds.Y.max+.5){failure("Narzedzie otworu nie ma prawidlowej osi lub polozenia.");return false;}
 if(!subtract(id,tool,false))return false;
 if(p_cvxPartInqShapeMass(id,7.85e-6,&after)||!isfinite(after.Volume)||after.Volume<=0||before.Volume-after.Volume<=.1){char detail[300];snprintf(detail,sizeof(detail),"Otwor: brak ubytku materialu; V_przed=%.9g, V_po=%.9g, baza=(X %.3f..%.3f, Y %.3f..%.3f, Z %.3f..%.3f).",before.Volume,after.Volume,bounds.X.min,bounds.X.max,bounds.Y.min,bounds.Y.max,bounds.Z.min,bounds.Z.max);failure(detail);return false;}
 return true;
}
static bool emptyPart(){
 int n=0,*a=nullptr;int rc=p_cvxPartInqShapes(nullptr,nullptr,&n,&a);if(a)p_cvxMemFree((void**)&a);
 if(rc||n!=0){failure("Otworz nowa, pusta czesc w ZW3D. Generator nie dopisuje do istniejacego modelu.");return false;}
 n=0;a=nullptr;rc=p_cvxPartInqComps(nullptr,nullptr,&n,&a);if(a)p_cvxMemFree((void**)&a);
 if(rc||n!=0){failure("Aktywna czesc zawiera komponenty. Otworz pusta czesc.");return false;}
 n=0;a=nullptr;rc=p_cvxPartInqCurves(&n,&a);if(a)p_cvxMemFree((void**)&a);
 if(rc||n!=0){failure("Aktywna czesc zawiera krzywe. Otworz nowa pusta czesc.");return false;}return true;
}
static bool rootExists(const char*name){int n=0;vxLongName*list=nullptr;if(p_cvxRootList(nullptr,&n,&list)){failure("Nie mozna sprawdzic nazw czesci.");return true;}bool found=false;for(int i=0;i<n;i++)if(strcmp(list[i],name)==0){found=true;break;}if(list)p_cvxMemFree((void**)&list);return found;}
static bool exportComponent(int id,const char*name){
 if(rootExists(name)){failure("Konflikt nazwy czesci. Uzyj nowego pliku ZW3D.");return false;}
 int before=0,*list=nullptr;if(p_cvxPartInqComps(nullptr,nullptr,&before,&list))return false;if(list)p_cvxMemFree((void**)&list);
 svxGeomExport e={};e.numEnts=1;e.idEnts=&id;strncpy(e.Part,name,sizeof(e.Part)-1);e.Frame=identity();e.Option=1;e.AddComponent=1;e.NoExportOp=1;e.Unblank=1;
 if(p_cvxPartGeomExport(&e)){failure("Nie mozna wyprowadzic bryly jako komponentu.");return false;}
 int after=0;list=nullptr;bool verified=false;
 if(p_cvxPartInqComps(nullptr,nullptr,&after,&list)==0&&after==before+1){
  for(int j=0;j<after;j++){char file[256]={},part[256]={};if(p_cvxCompInqPart(list[j],file,256,part,256)==0&&strcmp(part,name)==0){verified=true;break;}}
 }
 if(list)p_cvxMemFree((void**)&list);
 if(!verified){failure("Nie potwierdzono wstawienia komponentu. Bryla nie zostala usunieta.");return false;}
 if(p_cvxPartErase(1,&id)){failure("Komponent utworzony, ale nie mozna usunac zrodlowej bryly.");return false;}return true;
}
static bool buildChamferedPlate(const Member&m,int&id){
 PlatePoint pts[12];int n=platePolygon(cfg,m,pts),curves[12]={},profile=0;
 if(n<3||n>10){failure("Nieprawidlowy przekroj fazowanej blachy.");return false;}
 for(int i=0;i<n;i++){
  svxPoint a={m.a.x-m.width/2,pts[i].y,pts[i].z},b={a.x,pts[(i+1)%n].y,pts[(i+1)%n].z};
  if(p_cvxPartLine2pt(&a,&b,&curves[i])||curves[i]<=0){failure("Nie mozna utworzyc konturu blachy.");return false;}
 }
 if(p_cvxPartCrvList(n,curves,&profile)||profile<=0){failure("Nie mozna zamknac konturu blachy.");return false;}
 svxExtrudeData e={};e.Combine=VX_BOOL_NONE;e.idProfile=profile;e.Start=0;e.End=m.width;e.UseDirection=1;e.Direction={1,0,0};e.iKeep=0;
 if(p_cvxPartExtrude(&e,&id)||id<=0){failure("Nie mozna wyciagnac fazowanej blachy.");return false;}
 if(p_cvxEntNameSet(id,m.name)){failure("Nie mozna nazwac blachy.");return false;}return true;
}
// Field numbers and profile strings verified from user's evaluated CdWeldStruct data.
static bool createNativeMember(const Member&m,int axis,int&id){
 int beforeCount=0,*before=nullptr;
 if(p_cvxPartInqShapes(nullptr,nullptr,&beforeCount,&before)){failure("Nie mozna odczytac bryl przed czlonem.");return false;}
 vxName tpl="CdWeldStruct";int data=0;
 if(p_cvxDataInit(tpl,&data)||data<=0){if(before)p_cvxMemFree((void**)&before);failure("Nie mozna zainicjowac CdWeldStruct.");return false;}
 char profile[256];if(m.kind==TUBE)strcpy(profile,"DIN_Okragly-Konstrukcyjny formowany na zimno.Z3,25x1.5");
 else snprintf(profile,sizeof(profile),"DIN_Kwadratowy-Konstrukcyjny formowany na zimno.Z3,%gx%gx%g",m.width,m.depth,m.wall);
 svxData d={};d.isText=1;strncpy(d.Text,profile,sizeof(d.Text)-1);bool ok=p_cvxDataSet(data,1,&d)==0;
 d={};d.isEntity=1;d.idEntity=axis;if(ok)ok=p_cvxDataSet(data,2,&d)==0;
 d={};d.isText=1;strncpy(d.Text,m.name,sizeof(d.Text)-1);if(ok)ok=p_cvxDataSet(data,5,&d)==0;
 const int fields[]={6};for(int f:fields){d={};d.isNumber=1;d.NumType=f==6?VX_ANG:VX_NUM;d.Num=0;if(ok)ok=p_cvxDataSet(data,f,&d)==0;}
 int rc=-1;if(ok){rc=p_cvxCmdExec(data);data=0;ok=rc==0;} // CmdExec consumes data, even on failure.
 else p_cvxDataFree(data);
 int afterCount=0,*after=nullptr,newCount=0;id=0;
 if(ok&&p_cvxPartInqShapes(nullptr,nullptr,&afterCount,&after)==0){
  for(int i=0;i<afterCount;i++){bool old=false;for(int j=0;j<beforeCount;j++)if(after[i]==before[j]){old=true;break;}if(!old){id=after[i];newCount++;}}
  ok=afterCount==beforeCount+1&&newCount==1&&id>0;
 }else ok=false;
 if(before)p_cvxMemFree((void**)&before);if(after)p_cvxMemFree((void**)&after);
 if(!ok){char e[450];snprintf(e,sizeof(e),"CdWeldStruct: rc=%d, nowe bryly=%d, profil=%.180s, os=%d. Sprawdz biblioteke DIN.",rc,newCount,profile,axis);failure(e);return false;}
 if(p_cvxEntNameSet(id,m.name))return false;return shapeGeometry(id);
}
static bool verifiedVolume(int id,double&v){
 svxMassProp mass={};int rc=p_cvxPartInqShapeMass?p_cvxPartInqShapeMass(id,7.85e-6,&mass):-1;
 v=mass.Volume;return rc==0&&isfinite(v)&&v>0;
}
static char cutReport[16000];
static void appendCutReport(const char*name,int count,double before,double after){
 char row[256];snprintf(row,sizeof(row),"%s: operacje=%d, V_przed=%.12g, V_po=%.12g\r\n",name,count,before,after);
 if(strlen(cutReport)+strlen(row)<sizeof(cutReport))strcat(cutReport,row);
}
struct CutFace {int cutters[32]={};int cutterCount=0;int face=0;int support=-1;Vec point={},normal={};bool planar=false;double score=1e100;};
static double boxDistance(Vec p,const svxBndBox&b){
 double x=fmax(b.X.min-p.x,fmax(0,p.x-b.X.max)),y=fmax(b.Y.min-p.y,fmax(0,p.y-b.Y.max)),z=fmax(b.Z.min-p.z,fmax(0,p.z-b.Z.max));return sqrt(x*x+y*y+z*z);
}
static bool chooseCutFace(const Member&m,int end,CutFace&best){
 Vec endpoint=end?m.b:m.a,mid=vmul(vadd(m.a,m.b),.5);
 const bool noseTopStart=(strncmp(m.name,"NOS_GORA",8)==0&&end==0);
 for(int j=0;j<plan.count;j++){
  const Member&t=plan.m[j];if(strcmp(t.name,m.name)==0)continue;
  bool use=t.kind==PROFILE;
  if((strncmp(m.name,"NOS_DOL",7)==0||strncmp(m.name,"KRZYZULEC_CZOLO",14)==0)&&strncmp(t.name,"SLUPEK_RURA",11)==0)use=true;
  if(strncmp(m.name,"NOS_DOL",7)==0){
    if(end) use=(strncmp(t.name,"NAKLADKA_OTWOR",14)==0||strncmp(t.name,"NOS_GORA",8)==0);
    else use=strncmp(t.name,"SLUPEK_RURA",11)==0;
  }
  if(noseTopStart)use=(strncmp(t.name,"PAS_GORA",8)==0);
  if(strncmp(m.name,"KRZYZULEC_CZOLO",14)==0)use=strncmp(t.name,"SLUPEK_RURA",11)==0;
  if(!use)continue;
  if(!refresh(ids[j],shapeLabels[j]))continue;
  svxBndBox bounds={};if(!readBounds(ids[j],bounds)||boxDistance(endpoint,bounds)>m.width*2)continue;
  int n=0,*faces=nullptr;if(p_cvxPartInqShapeFaces(ids[j],&n,&faces))continue;
  for(int k=0;k<n;k++){
   svxLimit u={},v={};svxPoint p={},p2={};svxVector normal={},normal2={};
   if(p_cvxFaceParam(faces[k],&u,&v)||p_cvxFaceEval(faces[k],(u.min+u.max)/2,(v.min+v.max)/2,&p,&normal)||p_cvxFaceEval(faces[k],u.min*.75+u.max*.25,v.min*.75+v.max*.25,&p2,&normal2))continue;
   Vec q={p.x,p.y,p.z},nv=unit({normal.x,normal.y,normal.z}),nv2=unit({normal2.x,normal2.y,normal2.z});
   bool planar=dot(nv,nv2)>.999999&&fabs(dot(vsub({p2.x,p2.y,p2.z},q),nv))<.001;
   svxBndBox fb={};if(!p_cvxPartInqFaceBox||p_cvxPartInqFaceBox(faces[k],&fb))continue;
   double score=boxDistance(endpoint,fb);
   if(planar){
    Vec ta=unit(vsub(t.b,t.a));double len=length(vsub(t.b,t.a)),along=dot(vsub(q,t.a),ta);
    if(along>.01&&along<len-.01){
     Vec radial=vsub(vsub(q,t.a),vmul(ta,along));
     if(dot(radial,nv)<=0)continue; // Interior walls face the hollow cavity.
    }
    double de=dot(vsub(endpoint,q),nv),dm=dot(vsub(mid,q),nv);
    // Outward face must face the body of the tube; reject inner/end faces.
    if(dm<=.001||fabs(de)>m.width*2||fabs(dot(unit(vsub(mid,endpoint)),nv))<.05)continue;
    if(noseTopStart){
     double axisAlign=fabs(dot(nv,ta));
     bool nearFrontEnd=along>len-m.width*2.5;
     if(axisAlign<.95||!nearFrontEnd)continue; // Nose top must trim to the vertical end face of PAS_GORA.
     score-=m.width*10;
    }
    score+=fabs(de);
   }else{
    if(t.kind!=TUBE)continue;
    Vec ax=unit(vsub(t.b,t.a)),rad=vsub(vsub(q,t.a),vmul(ax,dot(vsub(q,t.a),ax)));
    if(fabs(length(rad)-t.width/2)>.1||dot(rad,nv)<=0)continue;
    score+=m.width*.1;
   }
   if(score<best.score){best.face=faces[k];best.support=j;best.point=q;best.normal=nv;best.planar=planar;best.score=score;}
  }
  if(faces)p_cvxMemFree((void**)&faces);
 }
 return best.face>0;
}
static bool noseProfileFaces(const Member&m,CutFace&cut){
 if(strncmp(m.name,"NOS_DOL",7)!=0||!cut.planar)return true;
 if(strncmp(plan.m[cut.support].name,"NOS_GORA",8)!=0) return true;
 const Member&t=plan.m[cut.support];Vec axis=unit(vsub(t.b,t.a));
 int n=0,*faces=nullptr;if(p_cvxPartInqShapeFaces(ids[cut.support],&n,&faces))return false;
 cut.cutters[0]=cut.face;cut.cutterCount=1;
 int planes=1;
 for(int i=0;i<n;i++){
  if(faces[i]==cut.face)continue;
  svxLimit u={},v={};svxPoint q={},q2={};svxVector a={},b={};
  if(p_cvxFaceParam(faces[i],&u,&v)||p_cvxFaceEval(faces[i],(u.min+u.max)/2,(v.min+v.max)/2,&q,&a)||p_cvxFaceEval(faces[i],u.min*.75+u.max*.25,v.min*.75+v.max*.25,&q2,&b))continue;
  Vec nv=unit({a.x,a.y,a.z}),nv2=unit({b.x,b.y,b.z});
  if(fabs(dot(nv,axis))>.01||fabs(dot(nv2,axis))>.01)continue;
  Vec d=vsub({q.x,q.y,q.z},t.a);Vec radial=vsub(d,vmul(axis,dot(d,axis)));
  if(dot(radial,nv)<=0)continue; // no inner hollow walls
  bool planar=dot(nv,nv2)>.999999&&fabs(dot(vsub({q2.x,q2.y,q2.z},{q.x,q.y,q.z}),nv))<.001;
  double facing=dot(nv,cut.normal),facing2=dot(nv2,cut.normal);
  bool sidePlane=planar&&fabs(facing)<.01;
  bool connectingCorner=!planar&&facing>.01&&facing2>=-.001;
  if(!sidePlane&&!connectingCorner)continue;
  if(cut.cutterCount>=32){p_cvxMemFree((void**)&faces);failure("Zbyt wiele scian docinania nosa.");return false;}
  cut.cutters[cut.cutterCount++]=faces[i];if(sidePlane)planes++;
 }
 if(faces)p_cvxMemFree((void**)&faces);
 if(planes!=3){failure("Nie znaleziono trzech zewnetrznych scian profilu nosa.");return false;}return true;
}
static bool refreshDisplay(int assembly){
 auto regen=(decltype(&cvxPartRegenFacets))findApi("cvxPartRegenFacets");
 auto update=(decltype(&cvxDispDataUpdate))findApi("cvxDispDataUpdate");
 auto redraw=(decltype(&cvxDispRedraw))findApi("cvxDispRedraw");
 if(!regen||!update||!redraw||regen(0,nullptr,assembly,0,0.01)){failure("Nie udalo sie przebudowac wyswietlania modelu.");return false;}
 update();redraw();return true;
}
static bool completeCut(int base,const CutFace&cut,const Member&m){
 int n=0,*faces=nullptr;if(p_cvxPartInqShapeFaces(base,&n,&faces))return false;
 bool ok=true;int points=0;const Member&t=plan.m[cut.support];Vec ax=unit(vsub(t.b,t.a));
 for(int i=0;i<n&&ok;i++){
  int count=0;svxTriangle*tri=nullptr;
  if(p_cvxPartInqFaceFacets(faces[i],&count,&tri)||!tri||count<=0)ok=false;
  for(int j=0;j<count&&ok;j++)for(int k=0;k<3;k++){
   Vec q={tri[j].Pnt[k].x,tri[j].Pnt[k].y,tri[j].Pnt[k].z};points++;
   if(cut.planar){
    bool finiteNose=strncmp(m.name,"NOS_DOL",7)==0;
    Vec u,v,w;memberFrame(t,u,v,w);Vec d=vsub(q,t.a);
    bool within=dot(d,w)>=-.05&&dot(d,w)<=length(vsub(t.b,t.a))+.05&&fabs(dot(d,u))<=t.width/2+.05&&fabs(dot(d,v))<=t.depth/2+.05;
    if(!finiteNose&&dot(vsub(q,cut.point),cut.normal)<-.05)ok=false;
   }
   else{Vec v=vsub(q,t.a);if(length(vsub(v,vmul(ax,dot(v,ax))))<t.width/2-.05)ok=false;}
  }
  if(tri)p_cvxMemFree((void**)&tri);
 }
 if(faces)p_cvxMemFree((void**)&faces);return ok&&points>0;
}
static bool noseSupportClear(int base,const Member&m,const CutFace&cut){
 if(strncmp(m.name,"NOS_DOL",7)!=0||!cut.planar)return true;
 int support=ids[cut.support];if(!refresh(support,shapeLabels[cut.support]))return false;
 vxName mark={};if(p_cvxUndoRedoMarker(mark))return false;
 svxMatrix mat=identity();int ca=0,cb=0,n=0,*result=nullptr;
 int rc=p_cvxPartCopyTransform(base,&mat,&ca);if(!rc)rc=p_cvxPartCopyTransform(support,&mat,&cb);
 if(!rc)rc=p_cvxPartBool2(VX_BOOL_INTERSECT,1,&ca,1,&cb,&n,&result);
 bool good=rc==0&&n>=0&&(n==0||result);double overlap=0;
 if(good)for(int i=0;i<n;i++){double v=0;if(!verifiedVolume(result[i],v)){good=false;break;}overlap+=v;}
 if(result)p_cvxMemFree((void**)&result);
 if(p_cvxUndoRedoTo(1,mark)){failure("Blad cofniecia kontroli dociecia nosa.");return false;}
 return good&&overlap<=.1;
}
static bool nativeTrim(int&base,const Member&m,const CutFace&cut){
 double before=0;if(!verifiedVolume(base,before)){failure("FtSolidTrim: brak wiarygodnej objetosci bazy.");return false;}
 int label[256]={};if(!storeLabel(base,label))return false;
 Vec mid=vmul(vadd(m.a,m.b),.5);
 // Try the recorded command settings with both keep sides. Undo every rejected result.
 for(int extend=(strncmp(m.name,"NOS_GORA",8)==0?1:0);extend<=((cut.planar&&strncmp(m.name,"NOS_DOL",7)!=0)?1:0);extend++)for(int flip=0;flip<2;flip++){
  vxName mark={};if(p_cvxUndoRedoMarker(mark))return false;
  int data=0;vxName tpl="FtSolidTrim";bool ok=p_cvxDataInit(tpl,&data)==0&&data>0;
  if(ok){p_cvxDataDel(data,1);p_cvxDataDel(data,2);}
  svxData d={};d.isEntity=1;d.idEntity=base;if(ok)ok=p_cvxDataSet(data,1,&d)==0;
  for(int c=0;c<(cut.cutterCount?cut.cutterCount:1)&&ok;c++){d={};d.isEntity=1;d.idEntity=cut.cutterCount?cut.cutters[c]:cut.face;ok=p_cvxDataSet(data,2,&d)==0;}
  d={};d.isText=1;snprintf(d.Text,sizeof(d.Text),"DOC_%s",m.name);if(ok)ok=p_cvxDataSet(data,4,&d)==0;
  const int fields[]={3,5,7,8,10,11};const int values[]={flip,1,0,1,extend,0};
  for(int k=0;k<6&&ok;k++){d={};d.isNumber=1;d.NumType=VX_NUM;d.Num=values[k];ok=p_cvxDataSet(data,fields[k],&d)==0;}
  d={};d.isPoint=1;d.isDirection=1;d.Pnt={mid.x,mid.y,mid.z};d.Dir={cut.normal.x,cut.normal.y,cut.normal.z};if(ok)ok=p_cvxDataSet(data,20,&d)==0;
  int rc=-1;if(ok){rc=p_cvxCmdExec(data);data=0;ok=rc==0;}else if(data)p_cvxDataFree(data);
  int candidate=base;double after=0;svxBndBox b={};
  ok=ok&&refresh(candidate,label)&&verifiedVolume(candidate,after)&&before-after>fmax(1e-6,before*1e-9)&&after>before*.4&&readBounds(candidate,b)&&boxDistance(mid,b)<m.width&&completeCut(candidate,cut,m)&&noseSupportClear(candidate,m,cut);
  char row[320];snprintf(row,sizeof(row),"%s face=%d support=%s extend_try=%d flip=%d rc=%d V=%.12g -> %.12g accepted=%d\r\n",m.name,cut.face,plan.m[cut.support].name,extend,flip,rc,before,after,ok);
  if(strlen(cutReport)+strlen(row)<sizeof(cutReport))strcat(cutReport,row);
  if(ok){base=candidate;return refresh(base,label)&&shapeGeometry(base);}
  if(p_cvxUndoRedoTo(1,mark)){failure("FtSolidTrim: blad cofniecia odrzuconej proby.");return false;}
  if(!refresh(base,label)){failure("FtSolidTrim: utracono baze po cofnieciu.");return false;}
 }
 failure("FtSolidTrim nie dal potwierdzonego poprawnego dociecia.");return false;
}
static bool checkCollisions(){
 for(int i=0;i<plan.count;i++)for(int j=i+1;j<plan.count;j++){
  const Member&a=plan.m[i],&b=plan.m[j];
  bool pair=(a.kind==TUBE&&b.kind==TUBE)||(a.kind==TUBE&&b.kind==BLOCK&&b.hole)||(b.kind==TUBE&&a.kind==BLOCK&&a.hole);
  if(!pair)continue;
  if(!refresh(ids[i],shapeLabels[i])||!refresh(ids[j],shapeLabels[j])){failure("Utracono element przed kontrola kolizji.");return false;}
  svxBndBox x={},y={};if(!readBounds(ids[i],x)||!readBounds(ids[j],y)){failure("Nie mozna odczytac obwiedni kontroli kolizji.");return false;}
  if(fmin(x.X.max,y.X.max)-fmax(x.X.min,y.X.min)<.001||fmin(x.Y.max,y.Y.max)-fmax(x.Y.min,y.Y.min)<.001||fmin(x.Z.max,y.Z.max)-fmax(x.Z.min,y.Z.min)<.001)continue;
  vxName mark={};if(p_cvxUndoRedoMarker(mark))return false;
  svxMatrix mat=identity();int ca=0,cb=0,n=0,*result=nullptr;
  int rc=p_cvxPartCopyTransform(ids[i],&mat,&ca);if(!rc)rc=p_cvxPartCopyTransform(ids[j],&mat,&cb);
  if(!rc)rc=p_cvxPartBool2(VX_BOOL_INTERSECT,1,&ca,1,&cb,&n,&result);
  bool measured=rc==0&&n>=0&&(n==0||result);double overlap=0;
  if(measured)for(int k=0;k<n;k++){double v=0;if(!result||!verifiedVolume(result[k],v)){measured=false;break;}overlap+=v;}
  if(result)p_cvxMemFree((void**)&result);
  if(p_cvxUndoRedoTo(1,mark)){failure("Blad cofniecia kontroli kolizji.");return false;}
  char row[280];snprintf(row,sizeof(row),"KOLIZJA %s / %s rc=%d n=%d V=%.12g\r\n",a.name,b.name,rc,n,overlap);
  if(strlen(cutReport)+strlen(row)<sizeof(cutReport))strcat(cutReport,row);
  if(!measured||overlap>.1){failure(row);return false;}
 }
 return true;
}
static bool finishedLength(int id,const Member&m,double&out){
 Vec axis=unit(vsub(m.b,m.a));int n=0,*faces=nullptr;if(p_cvxPartInqShapeFaces(id,&n,&faces))return false;
 double lo=1e100,hi=-1e100;bool ok=true;
 for(int i=0;i<n&&ok;i++){
  int count=0;svxTriangle*tri=nullptr;if(p_cvxPartInqFaceFacets(faces[i],&count,&tri)||!tri||count<=0)ok=false;
  for(int j=0;j<count&&ok;j++)for(int k=0;k<3;k++){Vec p={tri[j].Pnt[k].x,tri[j].Pnt[k].y,tri[j].Pnt[k].z};double t=dot(p,axis);lo=fmin(lo,t);hi=fmax(hi,t);}
  if(tri)p_cvxMemFree((void**)&tri);
 }
 if(faces)p_cvxMemFree((void**)&faces);out=hi-lo;return ok&&isfinite(out)&&out>0;
}
static HMODULE assemblyModule=nullptr;
typedef int (*BuildAssembly)(int,const int*,const char (*)[256],const svxMatrix*,const int*);
static BuildAssembly assemblyBuild=nullptr;
static bool loadAssembly(){
 char path[MAX_PATH]={};GetModuleFileNameA(gModule,path,MAX_PATH);char*q=strrchr(path,'\\');if(!q){failure("Brak sciezki DLL generatora.");return false;}strcpy(q+1,"DSAssembly2019.dll");
 if(!assemblyModule)assemblyModule=LoadLibraryExA(path,nullptr,LOAD_WITH_ALTERED_SEARCH_PATH);
 if(!assemblyModule){failure("Nie mozna zaladowac DSAssembly2019.dll. Umiesc obie DLL w tym samym folderze.");return false;}
 typedef int(*VersionFn)();auto version=(VersionFn)GetProcAddress(assemblyModule,"DSAssemblyMakietaVersion");
 if(!version||version()!=34){failure("Zaladowano starsza DSAssembly. Zamknij ZW3D i podmien obie DLL z V35.");return false;}
 assemblyBuild=(BuildAssembly)GetProcAddress(assemblyModule,"DSAssemblyBuildPosed");
 if(!assemblyBuild){failure("Nieodpowiednia wersja DSAssembly2019.dll. Uzyj DLL dolaczonej do paczki V35.");return false;}return true;
}
static bool convertAssembly(){
 static char names[1800][256];static svxMatrix memberFrames[1800];static int kinds[1800];
 for(int i=0;i<plan.count;i++){
  const Member&m=plan.m[i];memberFrames[i]=frame(m);kinds[i]=(int)m.kind;double len=0;
  if(!refresh(ids[i],shapeLabels[i])||!finishedLength(ids[i],m,len)){failure("Nie mozna ustalic dlugosci do nazwy komponentu.");return false;}
  typedef int(*FormatName)(int,double,double,double,double,int,char*);
  auto formatName=(FormatName)GetProcAddress(assemblyModule,"DSAssemblyFormatName");
  if(!formatName||formatName((int)m.kind,m.width,m.depth,m.wall,len,m.hole,names[i])){failure("Nie mozna nazwac czesci przez DS Assembly.");return false;}
 }
 // Keep the verified finished geometry, not the construction/cutting history.
 // Separate explicit shape features avoid re-running failed trim attempts on regen.
 auto encapsulate=(decltype(&cvxPartEncapsulate))findApi("cvxPartEncapsulate");
 if(!encapsulate||encapsulate(2,0)){failure("Nie mozna utrwalic gotowych bryl przed konwersja.");return false;}
 for(int i=0;i<plan.count;i++)if(!refresh(ids[i],shapeLabels[i])||!shapeGeometry(ids[i])){failure("Utracono bryle przy utrwalaniu historii; konwersja przerwana.");return false;}
 if(assemblyBuild(plan.count,ids,names,memberFrames,kinds)){
  typedef const char*(*ErrorFn)();auto error=(ErrorFn)GetProcAddress(assemblyModule,"DSAssemblyMakietaError");failure(error?error():"Konwersja zlozenia nie powiodla sie.");return false;
 }
 if(!refreshDisplay(1))return false;
 char text[300];snprintf(text,sizeof(text),"Utworzono pelne zlozenie: %d komponentow.\nPodzial: %d pol, kat boczny %.2f stopni.\nNazwy zawieraja przekroj i gabaryt wzdluz osi po docieciu.\nZapisz plik ZW3D.",plan.count,plan.fields,plan.angle);MessageBoxA(nullptr,text,"DS Makieta V36 UI5 - zlozenie",MB_OK|MB_ICONINFORMATION);return true;
}
static bool build(){
 cutReport[0]=0;char err[256];if(!makePlan(cfg,plan,err)){failure(err);return false;}
 if(!emptyPart())return false;vxName mark={};
 if(p_cvxUndoRedoMarker(mark)){failure("Nie mozna zalozyc punktu Cofnij.");return false;}
 int axes[1800]={},axisCount=0;bool ok=true;int failed=-1;lastError[0]=0;memset(shapeLabels,0,sizeof(shapeLabels));
 for(int i=0;i<plan.count&&ok;i++){
  failed=i;const Member&m=plan.m[i];int id=0;
  if(m.kind==BLOCK){ok=m.hole?buildHolePlate(m,id):buildChamferedPlate(m,id);if(ok&&m.hole)ok=addHole(id);}
  else{
   svxPoint a={m.a.x,m.a.y,m.a.z},b={m.b.x,m.b.y,m.b.z};int axis=0;
   ok=p_cvxPartLine2pt(&a,&b,&axis)==0&&axis>0;
   if(ok){char name[32];snprintf(name,sizeof(name),"OS_%s",m.name);ok=p_cvxEntNameSet(axis,name)==0;}
   if(ok){axes[axisCount++]=axis;ok=createNativeMember(m,axis,id);}
  }
  if(ok)ok=shapeGeometry(id);ids[i]=id;
  if(ok&&!storeLabel(id,shapeLabels[i])){failure("Nie mozna zapisac etykiety bryly czlonu.");ok=false;}
 }
 // Native face trimming, one member and one end at a time.
 for(int i=0;i<plan.count&&ok;i++){
  failed=i;const Member&m=plan.m[i];
  bool mustCut=(m.kind==PROFILE&&m.hole)||(m.kind==TUBE&&(strncmp(m.name,"KRZYZULEC",9)==0||strncmp(m.name,"NOS_DOL",7)==0||strncmp(m.name,"ZASTRZAL",8)==0));
  if(mustCut){
   for(int end=0;end<(m.kind==PROFILE?1:2)&&ok;end++){
    CutFace cut;if(!chooseCutFace(m,end,cut)){failure("Nie znaleziono sciany podporowej do dociecia konca rury.");ok=false;break;}
    if(!refresh(ids[i],shapeLabels[i])){failure("Utracono baze przed FtSolidTrim.");ok=false;break;}
    ok=noseProfileFaces(m,cut)&&nativeTrim(ids[i],m,cut);
    if(ok){p_cvxEntNameSet(ids[i],m.name);ok=storeLabel(ids[i],shapeLabels[i]);}
   }
  }
  if(ok&&m.kind==PROFILE&&m.hole){ok=addHole(ids[i]);if(ok){p_cvxEntNameSet(ids[i],m.name);ok=storeLabel(ids[i],shapeLabels[i]);}}
 }
 if(ok){int count=0,*all=nullptr;int rc=p_cvxPartInqShapes(nullptr,nullptr,&count,&all);if(all)p_cvxMemFree((void**)&all);if(rc||count!=plan.count){failure("Liczba gotowych bryl nie zgadza sie z planem.");ok=false;}}
 if(ok)ok=checkCollisions();
 if(ok)ok=refreshDisplay(0);
 if(!ok)appendCutReport(lastError,0,0,0);
 if(!ok){char detail[512];snprintf(detail,sizeof(detail),"Element %s: %.350s",failed>=0?plan.m[failed].name:"?",lastError[0]?lastError:"API nie utworzylo elementu.");failure(detail);int rc=p_cvxUndoRedoTo(1,mark);if(rc)msg("Cofniecie nie powiodlo sie. Sprawdz model.");return false;}
 if(p_cvxEntBlank&&axisCount)p_cvxEntBlank(0,axisCount,axes);
 char result[512];snprintf(result,sizeof(result),"Utworzono %d elementow: natywne czlony DIN i fazowane blachy.\nDocinanie FtSolidTrim i otwor w belce nosa wykonano automatycznie.\nOtwor nominalny fi%.3f, opis %s; X=%.3f, Y=0, Z=%.3f.\nPodzial: %d pol; kat boczny: %.2f stopni.\nZapisz model ZW3D.",plan.count,cfg.holeD,cfg.fit,cfg.L,cfg.holeZ,plan.fields,plan.angle);
 return true;
}
// V36 UI2 keeps V35 geometry and uses the new native dimension preview.
#include "makieta_ui_v36.h"
extern "C" __declspec(dllexport) void DSMakieta(){
 if(!resolveApi()){MessageBoxA(nullptr,lastError,"DS Makieta - API",MB_OK|MB_ICONERROR);return;}
 while(true){int a=showWindow(cfg);if(a<=0){if(a<0)MessageBoxA(nullptr,lastError,"DS Makieta",MB_OK|MB_ICONERROR);return;}break;}
 if(!loadAssembly()){MessageBoxA(nullptr,lastError,"DS Makieta - DS Assembly",MB_OK|MB_ICONERROR);return;}
 if(!build()||!convertAssembly()){msg(lastError);MessageBoxA(nullptr,lastError,"DS Makieta - generowanie przerwane",MB_OK|MB_ICONERROR);}
}
extern "C" __declspec(dllexport) void DSMakietaUITest(){showWindow(cfg);}
// Read-only extraction from existing native features; no command execution.
extern "C" __declspec(dllexport) void DSMakietaCheck(){
 if(!resolveApi()||!p_cvxPartInqFtrList||!p_cvxPartInqFtrTemplate||!p_cvxPartInqFtrData||!p_cvxDataGet||!p_cvxDataFree){MessageBoxA(nullptr,"Brak funkcji odczytu danych operacji.","DS Makieta",MB_OK);return;}
 wchar_t path[1024]={};GetModuleFileNameW(gModule,path,900);wchar_t*slash=wcsrchr(path,L'\\');if(!slash)return;slash[1]=0;wcscat(path,L"DS_CZLONY_DIAGNOSTYKA.txt");
 HANDLE file=CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);if(file==INVALID_HANDLE_VALUE){MessageBoxA(nullptr,"Nie mozna zapisac diagnostyki obok DLL.","DS Makieta",MB_OK);return;}
 auto line=[&](const char*t){DWORD n;WriteFile(file,t,(DWORD)strlen(t),&n,nullptr);};
 int count=0,*features=nullptr;int rc=p_cvxPartInqFtrList(&count,&features);char row[1400];snprintf(row,sizeof(row),"List_rc=%d; operacje=%d\r\n",rc,count);line(row);
 if(rc==0&&features)for(int i=0;i<count;i++){
  vxName name={};if(p_cvxPartInqFtrTemplate(features[i],name))continue;
  snprintf(row,sizeof(row),"\r\nFEATURE %d TEMPLATE %s\r\n",features[i],name);line(row);
  if(!strstr(name,"Weld")&&!strstr(name,"weld")&&!strstr(name,"Hole")&&!strstr(name,"Cham")&&!strstr(name,"Trim"))continue;
  for(int mode=0;mode<=1;mode++){
   int data=0;rc=p_cvxPartInqFtrData(features[i],mode,&data);
   snprintf(row,sizeof(row),"DATA_MODE %d rc=%d id=%d\r\n",mode,rc,data);line(row);if(rc||data<=0)continue;
   for(int k=0;k<=255;k++){
    svxData first={};bool have=p_cvxDataGet(data,k,&first)==0;
    int cnt=0;svxData*items=nullptr;int lr=p_cvxDataGetList?p_cvxDataGetList(data,k,&cnt,&items):1;
    int opt=p_cvxDataGetOpt?p_cvxDataGetOpt(data,k):0;
    if(!have&&(lr||cnt<=0)&&opt<=0){if(items)p_cvxMemFree((void**)&items);continue;}
    snprintf(row,sizeof(row),"FIELD %d opt=%d list_rc=%d count=%d\r\n",k,opt,lr,cnt);line(row);
    int total=(lr==0&&cnt>0&&items)?cnt:(have?1:0);
    for(int j=0;j<total;j++){
     const svxData&d=(lr==0&&cnt>0&&items)?items[j]:first;
     snprintf(row,sizeof(row),"ITEM %d flags(pt=%d,ent=%d,num=%d,dir=%d,text=%d) ent=%d parent=%d num=%.12g point=(%.12g,%.12g,%.12g) text=%.255s\r\n",j,d.isPoint,d.isEntity,d.isNumber,d.isDirection,d.isText,d.idEntity,d.idParent,d.Num,d.Pnt.x,d.Pnt.y,d.Pnt.z,d.Text);line(row);
    }
    if(items)p_cvxMemFree((void**)&items);
   }p_cvxDataFree(data);
  }
 }
 if(features)p_cvxMemFree((void**)&features);CloseHandle(file);
 MessageBoxW(nullptr,path,L"Przeslij ten plik diagnostyczny",MB_OK);
}
extern "C" __declspec(dllexport) int DSMakieta2019Init(int,void*){
 if(!resolveApi()){MessageBoxA(nullptr,lastError,"DS Makieta - brak API",MB_OK|MB_ICONERROR);return 1;}
 if(p_cvxCmdFunc("DSMakieta",(void*)DSMakieta,0)||p_cvxCmdFunc("DSMakietaUITest",(void*)DSMakietaUITest,0)||p_cvxCmdFunc("DSMakietaCheck",(void*)DSMakietaCheck,0)){p_cvxCmdFuncUnload("DSMakieta");p_cvxCmdFuncUnload("DSMakietaUITest");p_cvxCmdFuncUnload("DSMakietaCheck");failure("Nie mozna zarejestrowac polecen.");return 1;}
 msg("DS Makieta 2019 V36 UI2 zaladowany. ~DSMakieta otwiera generator; ~DSMakietaUITest testuje okno.");return 0;
}
extern "C" __declspec(dllexport) int DSMakieta2019Exit(){if(p_cvxCmdFuncUnload){p_cvxCmdFuncUnload("DSMakieta");p_cvxCmdFuncUnload("DSMakietaUITest");p_cvxCmdFuncUnload("DSMakietaCheck");}return 0;}
BOOL WINAPI DllMain(HINSTANCE inst,DWORD reason,LPVOID){if(reason==DLL_PROCESS_ATTACH)gModule=inst;return TRUE;}
