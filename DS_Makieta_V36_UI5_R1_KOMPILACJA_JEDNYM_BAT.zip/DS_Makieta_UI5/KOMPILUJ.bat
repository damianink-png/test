@echo off
call "%~dp0KOMPILUJ_MAKIETE.bat"
