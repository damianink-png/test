import base64,json,re
import numpy as np
from dsac29.preview3d import create_preview
from dsac29.compare import Record
from test_optimization_10 import part

def scene(path):
    text=path.read_text(encoding='utf8')
    return json.loads(re.search(r'const scene=(.*);',text).group(1))

def test_both_revisions_colors_alpha_and_centered_coordinates(tmp_path):
    a=[part(0,(1e8,0,0)),part(1,(1e8,0,0))]
    b=[part(0,(1e8,40,0)),part(1,(1e8,0,0))]
    path=tmp_path/'view.html'
    info=create_preview(path,[Record(0,0,'MOVED',''),Record(1,1,'SAME','')],a,b,old_alpha=.25)
    chunks=scene(path)
    assert [c['status'] for c in chunks]==['MOVED_OLD','MOVED','SAME']
    assert [c['alpha'] for c in chunks]==[.25,1,1]
    assert info['elementy']==3 and not info['ograniczony']
    for c in chunks:
        points=np.frombuffer(base64.b64decode(c['data']),dtype='<f4')
        assert np.max(np.abs(points))<100
    text=path.read_text();assert 'src="http' not in text and 'fetch(' not in text

def test_limit_never_writes_partial_solid(tmp_path):
    a=[part(0),part(1)];path=tmp_path/'view.html'
    info=create_preview(path,[Record(None,i,'ADDED','') for i in range(2)],[],a,max_triangles=13)
    assert info['elementy']==1 and info['pominiete']==1 and info['trojkaty']==12
    assert len(base64.b64decode(scene(path)[0]['data']))==12*9*4

def test_worker_preview_flag_and_gui_option(tmp_path,monkeypatch):
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import QSettings
    from dsac29.gui46 import Window
    settings=QSettings(str(tmp_path/'prefs.ini'),QSettings.IniFormat)
    monkeypatch.setattr('dsac29.gui45.QSettings',lambda *a:settings)
    app=QApplication.instance() or QApplication([]);w=Window()
    try:
        assert w.preview_html.isChecked()
        assert 'PODGLAD_KOLOROW_3D.html' in w.compare_open
        w.preview_html.setChecked(False)
        assert str(settings.value('preview_html')).lower()=='false'
    finally:w.close()
