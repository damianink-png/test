import numpy as np
import pytest
from OCP.BRepPrimAPI import BRepPrimAPI_MakeBox
from dsac29.geometry import describe
from dsac29.alignment import _relocate
from dsac29.registration_gate import frame_support
from dsac29.compare import compare

def parts():return [describe(BRepPrimAPI_MakeBox(10+i,20,30).Shape(),str(i),str(i)) for i in range(4)]
def test_parametric_proof_precedes_boolean(monkeypatch):
 import dsac29.registration_gate as gate
 def forbidden(*args):raise AssertionError('Unnecessary Common')
 monkeypatch.setattr(gate,'equivalent_world',forbidden)
 s=frame_support(parts(),parts(),.01,verify_all=True)
 assert s['count']==4 and len(set(map(tuple,s['pairs'])))==4

def test_partial_reuse_keeps_real_changes():
 a=parts();b=parts();b[3]=describe(BRepPrimAPI_MakeBox(100,20,30).Shape(),'new','new')
 result=compare(a,b,.01,certified_pairs=[(0,0),(1,1),(2,2)],revision_only=True)
 assert sum(r.status=='SAME' for r in result)==3
 assert any(r.status=='ADDED' for r in result) and any(r.status=='REMOVED' for r in result)

@pytest.mark.parametrize('pairs',[[(0,0),(0,1)],[(0,0),(1,0)],[(5,0)]])
def test_invalid_map_rejected(pairs):
 with pytest.raises(ValueError):compare(parts(),parts(),.01,certified_pairs=pairs)

def test_wrong_frame_rejected():
 b=[_relocate(p,np.eye(3),np.array([50.,0,0])) for p in parts()]
 with pytest.raises(ValueError):compare(parts(),b,.01,certified_pairs=[(0,0)])

def test_changed_shape_not_certified():
 a=parts();b=parts();b[0]=describe(BRepPrimAPI_MakeBox(9,20,30).Shape(),'changed','changed')
 s=frame_support(a,b,.01,verify_all=True)
 assert s['count']==3 and (0,0) not in s['pairs']
