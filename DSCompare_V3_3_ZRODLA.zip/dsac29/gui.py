"""DS Compare V3.2 FAST — standalone dark UI for safe STEP B-Rep comparison.

Tkinter only. CAD model operations are NOT performed by the GUI, avoiding
re-entry into ZW3D's command / Windows message loops.
"""
from __future__ import annotations
import argparse
import csv
import json
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, colorchooser
from pathlib import Path
import traceback
import webbrowser
import re

from .cli import process
from .step_io import COLORS

BG = '#10141B'
SIDEBAR = '#151B24'
CARD = '#1B2430'
CARD_HOVER = '#243040'
INPUT = '#121923'
TEXT = '#F0F3F7'
MUTED = '#9BA8BA'
EDGE = '#344254'
ACCENT = '#E3A13B'
GREEN = '#2DA44E'
PURPLE = '#7465DC'
ORANGE = '#DA9554'

COLOR_ROLES = [
    ('SAME', 'Bez zmian', 'Zielony: zgodność geometrii oraz ustawienia'),
    ('ADDED', 'Nowe części', 'Kolor nowych komponentów w B'),
    ('CHANGED', 'Zmieniona geometria', 'Bryły o zmodyfikowanym kształcie'),
    ('MOVED', 'Zmiana położenia', 'Bryła ta sama, inne ustawienie'),
    ('REMOVED', 'Usunięte części', 'Kolor komponentów z modelu A'),
    ('UNCERTAIN', 'Do weryfikacji', 'Niepewne dopasowanie geometryczne'),
]

def _settings_path():
    root = Path(os.environ['APPDATA']) if os.name == 'nt' and os.environ.get('APPDATA') else Path.home() / '.config'
    return root / 'DSCompare' / 'settings.json'

def _valid_hex(value):
    return bool(re.fullmatch(r'#[0-9A-Fa-f]{6}', value))

def _to_triplet(value):
    color = value.lstrip('#')
    return tuple(round(int(color[x:x+2], 16)/255., 6) for x in (0, 2, 4))



def _rgb(color):
    return '#%02X%02X%02X' % tuple(round(max(0.0, min(1.0, x))*255) for x in color)


class GUI(tk.Tk):
    def __init__(self, a='', b='', output=None):
        if os.name == 'nt':
            try:
                import ctypes
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('DS.Szymczyk.DSCompare.V3')
            except (AttributeError, OSError):
                pass
        super().__init__()
        self.title('DS Compare  |  Geometry & Assembly Comparison  |  V3.3')
        self.geometry('1120x820')
        self.minsize(960, 735)
        self.configure(bg=BG)
        self.q = queue.Queue()
        self.cancel_requested = False
        self.running = False
        self.a = tk.StringVar(value=a)
        self.b = tk.StringVar(value=b)
        self.folder = tk.StringVar(value=str(output or Path.home() / 'Documents' / 'DSCompare' / 'Wyniki'))
        self.tolerance = tk.StringVar(value='0.01')
        self.density = tk.StringVar(value='7850')
        self.save_step = tk.BooleanVar(value=True)
        self.diff_step = tk.BooleanVar(value=True)
        self.worker = None
        self.open_report = tk.BooleanVar(value=True)
        self.status_text = tk.StringVar(value='Gotowy do porównania')
        self.last_output = None
        self.views = {}
        self.nav_btns = {}
        self.status_colors = {}
        self.palette_colors = dict(COLORS)
        self._load_settings()
        self._set_app_icon()
        self._style()
        self._build()
        self.show_view('compare')
        self.after(130, self.poll)
        self.protocol("WM_DELETE_WINDOW", self.close_app)

    def _set_app_icon(self):
        # Windows taskbar icon + icon embedded into EXE via PyInstaller --icon.
        root = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parents[1]))
        png = root / 'assets' / 'DSCompare.png'
        ico = root / 'assets' / 'DSCompare.ico'
        try:
            if png.is_file():
                self._icon_photo = tk.PhotoImage(file=str(png))
                self.iconphoto(True, self._icon_photo)
            if os.name == 'nt' and ico.is_file():
                self.iconbitmap(default=str(ico))
        except tk.TclError:
            pass

    def _load_settings(self):
        try:
            config = json.loads(_settings_path().read_text(encoding='utf-8'))
            for role, hex_value in config.get('colors', {}).items():
                if role in COLORS and isinstance(hex_value, str) and _valid_hex(hex_value):
                    self.palette_colors[role] = _to_triplet(hex_value)
            # Renamed parts must share the unchanged status color.
            self.palette_colors['RENAMED'] = self.palette_colors['SAME']
        except (FileNotFoundError, ValueError, OSError, TypeError, KeyError):
            pass

    def _save_settings(self):
        target = _settings_path()
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(json.dumps({'colors': {k: _rgb(v) for k,v in self.palette_colors.items()}},
                                         indent=2), encoding='utf-8')
        except OSError as exc:
            messagebox.showwarning('DS Compare', 'Nie zapisano ustawień: ' + str(exc))

    def _update_color_views(self):
        for key, button in self.status_colors.items():
            hex_value = _rgb(self.palette_colors[key])
            button.configure(bg=hex_value, activebackground=hex_value)
        for key, (sample, entry_var) in getattr(self, 'settings_colors', {}).items():
            hex_value = _rgb(self.palette_colors[key])
            sample.configure(bg=hex_value, activebackground=hex_value)
            entry_var.set(hex_value)
        for status in ('SAME', 'RENAMED', 'CHANGED', 'MOVED', 'ADDED', 'REMOVED', 'UNCERTAIN'):
            self.tree.tag_configure(status, foreground=_rgb(self.palette_colors[status]))
        for role, widget in getattr(self, 'summary_labels', {}).items():
            target = 'ADDED' if role == 'CHANGED' else role
            widget.configure(fg=_rgb(self.palette_colors[target]))

    def _apply_color(self, key, value):
        if not _valid_hex(value):
            messagebox.showerror('Kolor', 'Podaj kolor w formacie #RRGGBB, np. #2DA44E')
            return
        self.palette_colors[key] = _to_triplet(value)
        if key == 'SAME':
            self.palette_colors['RENAMED'] = self.palette_colors['SAME']
        self._update_color_views()
        self._save_settings()

    def _reset_colors(self):
        self.palette_colors = dict(COLORS)
        self._update_color_views()
        self._save_settings()

    def _style(self):
        st = ttk.Style(self)
        st.theme_use('clam')
        st.configure('DS.Treeview', background=INPUT, foreground=TEXT,
                     fieldbackground=INPUT, rowheight=31, borderwidth=0,
                     font=('Segoe UI', 10))
        st.configure('DS.Treeview.Heading', background=CARD_HOVER, foreground=TEXT,
                     font=('Segoe UI', 10, 'bold'), borderwidth=0, relief='flat')
        st.map('DS.Treeview', background=[('selected', '#41516B')], foreground=[('selected', TEXT)])
        st.configure('DS.Horizontal.TProgressbar', troughcolor=INPUT, background=ACCENT,
                     borderwidth=0, lightcolor=ACCENT, darkcolor=ACCENT)

    def _label(self, parent, text, size=10, color=TEXT, weight='normal', **kwargs):
        return tk.Label(parent, text=text, bg=kwargs.pop('bg', parent['bg']), fg=color,
                        font=('Segoe UI', size, weight), anchor=kwargs.pop('anchor', 'w'), **kwargs)

    def _button(self, parent, text, command, primary=False, width=None):
        bg = ACCENT if primary else CARD_HOVER
        fg = BG if primary else TEXT
        btn = tk.Button(parent, text=text, command=command, bg=bg, fg=fg,
                        activebackground='#EFB85D' if primary else '#36445B',
                        activeforeground=BG if primary else TEXT,
                        bd=0, relief='flat', padx=16, pady=9, cursor='hand2',
                        font=('Segoe UI', 10, 'bold' if primary else 'normal'),
                        highlightthickness=0, width=width)
        return btn

    def _entry(self, parent, variable):
        frame = tk.Frame(parent, bg=EDGE, padx=1, pady=1)
        entry = tk.Entry(frame, textvariable=variable, bg=INPUT, fg=TEXT,
                         insertbackground=TEXT, relief='flat', bd=0, highlightthickness=0,
                         font=('Segoe UI', 10))
        entry.pack(fill='x', expand=True, padx=9, pady=9)
        return frame

    def _card(self, parent, pad=18):
        container = tk.Frame(parent, bg=CARD, highlightbackground=EDGE,
                             highlightthickness=1, bd=0)
        inner = tk.Frame(container, bg=CARD)
        inner.pack(fill='both', expand=True, padx=pad, pady=pad)
        return container, inner

    def _build(self):
        self.left = tk.Frame(self, width=216, bg=SIDEBAR)
        self.left.pack(side='left', fill='y')
        self.left.pack_propagate(False)
        brand = tk.Frame(self.left, bg=SIDEBAR)
        brand.pack(fill='x', padx=21, pady=(25, 34))
        self._label(brand, 'DS', 26, ACCENT, 'bold', bg=SIDEBAR).pack(anchor='w')
        self._label(brand, 'COMPARE', 18, TEXT, 'bold', bg=SIDEBAR).pack(anchor='w')
        self._label(brand, 'GEOMETRY  /  B-REP', 8, MUTED, bg=SIDEBAR).pack(anchor='w', pady=(7, 0))
        for page, text in [('compare', '  Porównanie'), ('results', '  Wyniki'), ('settings', '  Ustawienia'), ('log', '  Dziennik')]:
            btn = tk.Button(self.left, text=text, anchor='w', command=lambda p=page: self.show_view(p),
                            bg=SIDEBAR, fg=MUTED, activebackground=CARD_HOVER,
                            activeforeground=TEXT, relief='flat', bd=0, cursor='hand2',
                            font=('Segoe UI', 11), padx=24, pady=14, highlightthickness=0)
            btn.pack(fill='x', pady=1)
            self.nav_btns[page] = btn
        tk.Frame(self.left, height=1, bg=EDGE).pack(fill='x', padx=20, pady=(28, 13))
        self._label(self.left, 'ZW3D 2019  •  STEP / STP', 9, MUTED,
                    bg=SIDEBAR).pack(anchor='w', padx=23)
        foot = tk.Frame(self.left, bg=SIDEBAR)
        foot.pack(side='bottom', fill='x', padx=20, pady=24)
        self._label(foot, 'DS COMPARE  V3.3', 9, ACCENT, 'bold', bg=SIDEBAR).pack(anchor='w')
        self._label(foot, 'Designed & developed by', 8, MUTED, bg=SIDEBAR).pack(anchor='w', pady=(11, 0))
        self._label(foot, 'Szymczyk Damian', 9, TEXT, bg=SIDEBAR).pack(anchor='w')

        area = tk.Frame(self, bg=BG)
        area.pack(side='left', fill='both', expand=True)
        head = tk.Frame(area, bg=BG)
        head.pack(fill='x', padx=27, pady=(21, 13))
        self._label(head, 'Geometry & Assembly Comparison', 18, TEXT, 'bold').pack(side='left')
        self._label(head, 'B-REP  •  V3.3', 9, ACCENT, 'bold').pack(side='right')
        tk.Frame(area, bg=EDGE, height=1).pack(fill='x', padx=27)
        viewhost = tk.Frame(area, bg=BG)
        viewhost.pack(fill='both', expand=True, padx=27, pady=18)
        for name in ('compare', 'results', 'settings', 'log'):
            frame = tk.Frame(viewhost, bg=BG)
            frame.place(relx=0, rely=0, relwidth=1, relheight=1)
            self.views[name] = frame
        self._build_compare(self.views['compare'])
        self._build_results(self.views['results'])
        self._build_settings(self.views['settings'])
        self._build_log(self.views['log'])
        self._update_color_views()

    def show_view(self, name):
        self.views[name].tkraise()
        for n, btn in self.nav_btns.items():
            btn.configure(bg=CARD_HOVER if n == name else SIDEBAR,
                          fg=ACCENT if n == name else MUTED)

    def _file_row(self, parent, title, sub, variable, directory=False):
        self._label(parent, title, 11, TEXT, 'bold').pack(anchor='w')
        self._label(parent, sub, 9, MUTED).pack(anchor='w', pady=(1, 7))
        row = tk.Frame(parent, bg=CARD)
        row.pack(fill='x', pady=(0, 12))
        ef = self._entry(row, variable)
        ef.pack(side='left', fill='x', expand=True)
        self._button(row, 'Wybierz', lambda: self._pick(variable, directory)).pack(side='left', padx=(10, 0))

    def _build_compare(self, host):
        self._label(host, 'Porównaj dwa modele', 14, TEXT, 'bold').pack(anchor='w')
        self._label(host, 'Dokładna analiza B-Rep poza procesem ZW3D — bez modyfikacji plików źródłowych.',
                    9, MUTED).pack(anchor='w', pady=(3, 13))
        card, body = self._card(host, 16)
        card.pack(fill='x')
        self._file_row(body, 'MODEL A  ·  WERSJA POPRZEDNIA', 'Plik STEP wyeksportowany z ZW3D', self.a)
        self._file_row(body, 'MODEL B  ·  WERSJA AKTUALNA', 'Plik STEP wyeksportowany z ZW3D', self.b)
        self._file_row(body, 'FOLDER WYNIKOWY', 'Raport, BOM A/B, różnice i kolorowy model STEP', self.folder, True)
        params = tk.Frame(body, bg=CARD)
        params.pack(fill='x')
        p1 = tk.Frame(params, bg=CARD)
        p1.pack(side='left', fill='x', expand=True, padx=(0, 12))
        self._label(p1, 'Tolerancja [mm]', 9, MUTED).pack(anchor='w', pady=(0, 5))
        self._entry(p1, self.tolerance).pack(fill='x')
        p2 = tk.Frame(params, bg=CARD)
        p2.pack(side='left', fill='x', expand=True)
        self._label(p2, 'Gęstość [kg/m³]', 9, MUTED).pack(anchor='w', pady=(0, 5))
        self._entry(p2, self.density).pack(fill='x')

        opts = tk.Frame(body, bg=CARD)
        opts.pack(fill='x', pady=(12, 0))
        for label, var in [('Kolorowy STEP (pełny model)', self.save_step), ('Tylko różnice B-Rep', self.diff_step), ('Otwórz raport', self.open_report)]:
            tk.Checkbutton(opts, text=label, variable=var, bg=CARD, fg=TEXT,
                           activebackground=CARD, activeforeground=TEXT,
                           selectcolor=SIDEBAR, highlightthickness=0,
                           font=('Segoe UI', 9)).pack(side='left', padx=(0, 24))

        legend = tk.Frame(host, bg=BG)
        legend.pack(fill='x', pady=(16, 12))
        self._label(legend, 'KOLORY PORÓWNANIA', 9, MUTED, 'bold').pack(anchor='w', pady=(0, 7))
        swatches = tk.Frame(legend, bg=BG)
        swatches.pack(fill='x')
        for key, desc in [('SAME', 'Bez zmian'), ('CHANGED', 'Zmienione'),
                          ('REMOVED', 'Usunięte'), ('UNCERTAIN', 'Do sprawdzenia')]:
            group = tk.Frame(swatches, bg=BG)
            group.pack(side='left', padx=(0, 17))
            btn = tk.Button(group, bg=_rgb(self.palette_colors[key]), activebackground=_rgb(self.palette_colors[key]),
                            width=2, height=1, relief='flat', bd=0,
                            command=lambda k=key: self._choose_color(k), cursor='hand2')
            btn.pack(side='left', padx=(0, 6))
            self.status_colors[key] = btn
            self._label(group, desc, 9, MUTED).pack(side='left')

        self._button(legend, 'Zmień kolory / zapamiętaj ustawienia   →',
                     lambda: self.show_view('settings')).pack(anchor='w', pady=(8, 0))

        actions = tk.Frame(host, bg=BG)
        actions.pack(fill='x', pady=(6, 7))
        self.run_button = self._button(actions, 'PORÓWNAJ B-REP', self.start, primary=True)
        self.run_button.pack(side='left')
        self.stop_button = self._button(actions, 'Anuluj', self.cancel)
        self.stop_button.pack(side='left', padx=8)
        self.stop_button.configure(state='disabled')
        self._button(actions, 'Otwórz wyniki', self.open_folder).pack(side='right')
        self.progress = ttk.Progressbar(host, mode='indeterminate', style='DS.Horizontal.TProgressbar')
        self.status_label = tk.Label(host, textvariable=self.status_text, bg=BG, fg=MUTED,
                                     anchor='w', font=('Segoe UI', 9))
        self.status_label.pack(fill='x', pady=(4,0))

    def _build_results(self, host):
        self._label(host, 'Wyniki porównania', 14, TEXT, 'bold').pack(anchor='w')
        self._label(host, 'Lista wykrytych zmian z raportu — wyniki są aktualizowane po zakończeniu analizy.',
                    9, MUTED).pack(anchor='w', pady=(3, 14))
        self.summary_frame = tk.Frame(host, bg=BG)
        self.summary_frame.pack(fill='x', pady=(0, 13))
        self.summary_labels = {}
        for key, title, color in [('SAME', 'BEZ ZMIAN', GREEN), ('CHANGED', 'NOWE / ZMIENIONE', PURPLE),
                                   ('REMOVED', 'USUNIĘTE', ORANGE), ('UNCERTAIN', 'NIEPEWNE', MUTED)]:
            card = tk.Frame(self.summary_frame, bg=CARD, highlightbackground=EDGE, highlightthickness=1)
            card.pack(side='left', expand=True, fill='x', padx=(0, 9))
            number = self._label(card, '—', 24, color, 'bold')
            number.pack(anchor='w', padx=14, pady=(10, 0))
            self._label(card, title, 8, MUTED).pack(anchor='w', padx=14, pady=(0, 12))
            self.summary_labels[key] = number
        filter_row = tk.Frame(host, bg=BG)
        filter_row.pack(fill='x', pady=(0, 9))
        self._label(filter_row, 'Filtruj wyniki:', 9, MUTED).pack(side='left', padx=(0, 9))
        self.search_results = tk.StringVar()
        self.search_results.trace_add('write', lambda *_: self._filter_results())
        self._entry(filter_row, self.search_results).pack(side='left', fill='x', expand=True)
        self.filter_status = tk.StringVar(value='Wszystkie')
        statuses = ('Wszystkie','Bez zmian','Zmieniona geometria','Przesunięte','Nowe','Usunięte','Niepewne')
        self.filter_box = ttk.Combobox(filter_row, textvariable=self.filter_status,
                                       values=statuses, state='readonly', width=21)
        self.filter_box.pack(side='left', padx=(10, 0))
        self.filter_box.bind('<<ComboboxSelected>>', lambda _: self._filter_results())
        self._all_result_rows = []
        frame = tk.Frame(host, bg=EDGE, padx=1, pady=1)
        frame.pack(fill='both', expand=True)
        cols = ('status', 'a', 'b', 'delta', 'note')
        tree = ttk.Treeview(frame, columns=cols, show='headings', style='DS.Treeview')
        for key, title, width in [('status', 'Status', 115), ('a', 'Nazwa A', 125),
                                  ('b', 'Nazwa B', 125), ('delta', 'Przes. [mm]', 100),
                                  ('note', 'Uwagi', 240)]:
            tree.heading(key, text=title)
            tree.column(key, width=width, stretch=(key == 'note'))
        bar = ttk.Scrollbar(frame, orient='vertical', command=tree.yview)
        hbar = ttk.Scrollbar(frame, orient='horizontal', command=tree.xview)
        tree.configure(yscrollcommand=bar.set, xscrollcommand=hbar.set)
        bar.pack(side='right', fill='y')
        hbar.pack(side='bottom', fill='x')
        tree.pack(fill='both', expand=True)
        for status in ('SAME','RENAMED','CHANGED','MOVED','ADDED','REMOVED','UNCERTAIN'):
            tree.tag_configure(status, foreground=_rgb(self.palette_colors[status]))
        self.tree = tree
        self.detail_var = tk.StringVar(value='Zaznacz wiersz, aby odczytać pełną nazwę i szczegóły zmiany.')
        self._label(host, 'SZCZEGÓŁY WYBRANEJ ZMIANY', 9, MUTED, 'bold').pack(anchor='w', pady=(10,3))
        tk.Label(host,textvariable=self.detail_var, bg=BG, fg=TEXT,
                 anchor='w', justify='left', wraplength=700,
                 font=('Segoe UI',9)).pack(fill='x')
        tree.bind('<<TreeviewSelect>>', self._show_detail)
        buttons = tk.Frame(host, bg=BG)
        buttons.pack(fill='x', pady=12)
        self._button(buttons, 'Raport HTML', self.open_report_file, primary=True).pack(side='left')
        self._button(buttons, 'Folder wynikowy', self.open_folder).pack(side='left', padx=8)
        self._button(buttons, 'Kolorowy STEP', self.open_step_file).pack(side='left')
        self._button(buttons, 'Tylko różnice', self.open_differences_file).pack(side='left',padx=8)

    def _build_log(self, host):
        self._label(host, 'Dziennik analizy', 14, TEXT, 'bold').pack(anchor='w')
        self._label(host, 'Szczegółowe informacje i błędy operacji geometrycznych.', 9, MUTED).pack(anchor='w', pady=(3, 12))
        self.log = tk.Text(host, bg=INPUT, fg=TEXT, font=('Consolas', 10),
                           insertbackground=TEXT, wrap='word', bd=0,
                           highlightthickness=1, highlightbackground=EDGE, padx=12, pady=12)
        self.log.pack(fill='both', expand=True)
        self._button(host, 'Wyczyść dziennik', lambda: self.log.delete('1.0', 'end')).pack(anchor='w', pady=12)

    def _pick(self, variable, isdir=False):
        path = filedialog.askdirectory() if isdir else filedialog.askopenfilename(
            filetypes=[('Modele STEP / STP', '*.step *.stp'), ('Wszystkie pliki', '*.*')])
        if path:
            variable.set(path)

    def _build_settings(self, host):
        self._label(host, 'Kolory modeli i raportów', 15, TEXT, 'bold').pack(anchor='w')
        self._label(host, 'Kliknij próbkę albo wpisz HEX. Zmiany są zapisywane automatycznie ',
                    9, MUTED).pack(anchor='w', pady=(3, 14))
        card, body = self._card(host, 19)
        card.pack(fill='x')
        self.settings_colors = {}
        for index, (role, title, desc) in enumerate(COLOR_ROLES):
            row = tk.Frame(body, bg=CARD)
            row.pack(fill='x', pady=6)
            sample = tk.Button(row, bg=_rgb(self.palette_colors[role]), relief='flat', bd=0,
                               width=3, height=1, cursor='hand2',
                               command=lambda k=role: self._choose_color(k))
            sample.pack(side='left', padx=(0, 14))
            words = tk.Frame(row, bg=CARD)
            words.pack(side='left', fill='x', expand=True)
            self._label(words, title, 10, TEXT, 'bold').pack(anchor='w')
            self._label(words, desc, 9, MUTED).pack(anchor='w')
            value = tk.StringVar(value=_rgb(self.palette_colors[role]))
            entry = tk.Entry(row, textvariable=value, bg=INPUT, fg=TEXT, width=11,
                             relief='flat', insertbackground=TEXT, justify='center',
                             font=('Consolas', 10))
            entry.pack(side='left', padx=(8, 7), ipady=6)
            entry.bind('<Return>', lambda event, k=role, v=value: self._apply_color(k,v.get()))
            self._button(row, 'Zapisz', lambda k=role,v=value: self._apply_color(k,v.get())).pack(side='left')
            self.settings_colors[role] = sample, value
        actions = tk.Frame(host, bg=BG)
        actions.pack(fill='x', pady=18)
        self._button(actions, 'Przywróć domyślne', self._reset_colors).pack(side='left')
        self._button(actions, 'Wróć do porównania', lambda: self.show_view('compare'),
                     primary=True).pack(side='right')
        self._label(host, 'Kolory obejmują pełny STEP, ROZNICE_BREP.step i raport HTML.\n'
                          'Kolory detali bez zmian i ze zmienioną nazwą są zawsze wspólne.',
                    9, MUTED).pack(anchor='w', pady=10)

    def _choose_color(self, key):
        picked = colorchooser.askcolor(color=_rgb(self.palette_colors[key]), title='DS Compare — kolor '+key)
        if picked and picked[1]:
            self._apply_color(key, picked[1].upper())

    def start(self):
        if self.running:
            return
        try:
            aa, bb = Path(self.a.get()), Path(self.b.get())
            for path in (aa, bb):
                if not path.is_file() or path.suffix.lower() not in ('.step', '.stp'):
                    raise ValueError('Wskaż dwa istniejące pliki STEP lub STP.')
            if aa.resolve() == bb.resolve():
                raise ValueError('Model A i B muszą być różnymi plikami.')
            tol = float(self.tolerance.get().replace(',', '.'))
            density = float(self.density.get().replace(',', '.'))
            if not (0 < tol <= 1): raise ValueError('Tolerancja musi wynosić >0 i ≤1 mm.')
            if not (0 < density <= 25000): raise ValueError('Gęstość poza zakresem (0, 25000] kg/m³.')
            out = Path(self.folder.get())
            if not str(out).strip(): raise ValueError('Wybierz folder wynikowy.')
            if out.resolve() in (aa.resolve(), bb.resolve()):
                raise ValueError('Niepoprawny folder wynikowy.')
        except Exception as exc:
            messagebox.showerror('Niepoprawne dane', str(exc))
            return
        self.running = True
        self.cancel_requested = False
        self.run_button.configure(state='disabled')
        self.stop_button.configure(state='normal')
        self.status_text.set('Trwa analiza geometrii B-Rep…')
        self.progress.pack(fill='x', pady=(3,2), before=self.status_label)
        self.progress.start(12)
        self.show_view('log')
        self.log.delete('1.0', 'end')
        colors = dict(self.palette_colors)
        args=[sys.executable]
        if not getattr(sys,'frozen',False):
            args += [str(Path(__file__).resolve().parents[1]/'DSCompareV3.py')]
        args += ['--dscompare-worker','--a',str(aa),'--b',str(bb),'--output',str(out),
                 '--tolerance',str(tol),'--density',str(density),
                 '--colors-json',json.dumps(colors)]
        if not self.save_step.get():args.append('--no-main-step')
        if not self.diff_step.get():args.append('--no-diff-step')
        try:
            self.worker=subprocess.Popen(args, stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                encoding='utf-8',errors='replace',text=True,bufsize=1,
                creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        except Exception as exc:
            self._finish()
            messagebox.showerror('DS Compare','Uruchomienie silnika nieudane: '+str(exc))
            return
        def follow(proc):
            done=None; fail=None
            try:
                for line in proc.stdout:
                    if line.startswith('DSCOMPARE_EVENT:'):
                        try:
                            event=json.loads(line[len('DSCOMPARE_EVENT:'):])
                            typ=event.get('type')
                            if typ=='log':self.q.put(('message',str(event.get('value',''))))
                            elif typ=='done':done=('done',event['folder'],event.get('error'))
                            elif typ=='error':fail=str(event.get('value'))
                        except Exception as exc:
                            self.q.put(('message','Komunikat silnika: '+str(exc)))
                    else:self.q.put(('message',line.rstrip()))
                ret=proc.wait()
                if self.cancel_requested:self.q.put(('cancelled',))
                elif ret==0 and done:self.q.put(done)
                else:self.q.put(('error',fail or f'Silnik zakończył działanie kodem {ret}.'))
            except Exception:self.q.put(('error',traceback.format_exc()))
        threading.Thread(target=follow,args=(self.worker,),daemon=True).start()

    def cancel(self):
        if not self.running:return
        self.cancel_requested=True
        self.q.put(('message','Zatrzymywanie niezależnego procesu B-Rep...'))
        if self.worker and self.worker.poll() is None:
            try:self.worker.terminate()
            except OSError:pass

    def close_app(self):
        if self.worker and self.worker.poll() is None:
            try:self.worker.terminate()
            except OSError:pass
        self.destroy()

    def _finish(self):
        self.running = False
        self.run_button.configure(state='normal')
        self.stop_button.configure(state='disabled')
        self.progress.stop()
        self.progress.pack_forget()

    def _show_detail(self, _event=None):
        selection = self.tree.selection()
        if not selection:return
        values = self.tree.item(selection[0], 'values')
        if not values:return
        self.detail_var.set(f'{values[0]} | A: {values[1] or "—"} | B: {values[2] or "—"}\n{values[4]}')

    def _load_results(self, folder):
        out = Path(folder)
        with (out / 'PODSUMOWANIE.json').open(encoding='utf-8') as inp:
            data = json.load(inp)
        counts = data.get('statuses', {})
        for key, widget in self.summary_labels.items():
            amount = counts.get(key, 0)
            if key == 'SAME': amount += counts.get('RENAMED', 0)
            if key == 'CHANGED': amount += counts.get('MOVED', 0) + counts.get('ADDED', 0)
            widget.configure(text=str(amount))
        self._all_result_rows = []
        with (out / 'ZMIANY.csv').open(encoding='utf-8-sig', newline='') as inp:
            for row in csv.DictReader(inp, delimiter=';'):
                state = row.get('Status', 'UNCERTAIN')
                short = {'SAME':'Bez zmian','RENAMED':'Nowa nazwa','MOVED':'Przesunięty',
                         'CHANGED':'Geometria','ADDED':'Nowy','REMOVED':'Usunięty',
                         'UNCERTAIN':'Niepewny'}.get(state, state)
                values = (short, row.get('Nazwa A', ''), row.get('Nazwa B', ''),
                          row.get('Przemieszczenie srodka [mm]', ''), row.get('Uwagi', ''))
                self._all_result_rows.append((values,state))
        self._filter_results()

    def _filter_results(self):
        tree = getattr(self, 'tree', None)
        if tree is None: return
        for item in tree.get_children(): tree.delete(item)
        needle = self.search_results.get().casefold().strip()
        selection = self.filter_status.get()
        allowed = {'Bez zmian': ('SAME','RENAMED'),
                   'Zmieniona geometria': ('CHANGED',),
                   'Przesunięte': ('MOVED',),
                   'Nowe': ('ADDED',), 'Usunięte': ('REMOVED',),
                   'Niepewne': ('UNCERTAIN',)}.get(selection)
        for values,state in self._all_result_rows:
            if allowed is not None and state not in allowed:continue
            if needle and needle not in ' '.join(values).casefold():continue
            tree.insert('', 'end', values=values, tags=(state,))

    def poll(self):
        try:
            while True:
                msg = self.q.get_nowait()
                if msg[0] == 'message':
                    self.log.insert('end', msg[1] + '\n')
                    self.log.see('end')
                    self.status_text.set(msg[1])
                elif msg[0] == 'done':
                    self._finish()
                    self.last_output = Path(msg[1])
                    self._load_results(self.last_output)
                    self.status_text.set('Porównanie zakończone')
                    self.show_view('results')
                    if self.open_report.get(): self.open_report_file()
                    if msg[2]: messagebox.showwarning('STEP — ostrzeżenie', str(msg[2]))
                elif msg[0] == 'cancelled':
                    self._finish()
                    self.status_text.set('Analiza anulowana')
                elif msg[0] == 'error':
                    self._finish()
                    self.status_text.set('Błąd analizy — sprawdź dziennik')
                    self.log.insert('end', msg[1] + '\n')
                    self.log.see('end')
                    self.show_view('log')
                    messagebox.showerror('Błąd analizy', msg[1][-1300:])
        except queue.Empty:
            pass
        self.after(130, self.poll)

    def _open_path(self, path):
        if not path or not Path(path).exists():
            messagebox.showinfo('DS Compare', 'Plik wynikowy nie został jeszcze utworzony.')
            return
        if os.name == 'nt': os.startfile(str(path))
        else: webbrowser.open(Path(path).as_uri())

    def open_folder(self):
        path = self.last_output or Path(self.folder.get())
        Path(path).mkdir(parents=True, exist_ok=True)
        self._open_path(path)

    def open_report_file(self):
        self._open_path(self.last_output / 'RAPORT.html' if self.last_output else None)

    def open_step_file(self):
        self._open_path(self.last_output / 'POROWNANIE_KOLORY.step' if self.last_output else None)

    def open_differences_file(self):
        self._open_path(self.last_output / 'ROZNICE_BREP.step' if self.last_output else None)


def _worker_main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--dscompare-worker',action='store_true')
    for k in ('a','b','output'):p.add_argument('--'+k,required=True)
    p.add_argument('--tolerance',type=float,default=0.01)
    p.add_argument('--density',type=float,default=7850.)
    p.add_argument('--colors-json',default='{}')
    p.add_argument('--no-main-step',action='store_true')
    p.add_argument('--no-diff-step',action='store_true')
    args=p.parse_args(argv)
    def emit(kind,**kwargs):
        print('DSCOMPARE_EVENT:'+json.dumps({'type':kind,**kwargs},ensure_ascii=True),flush=True)
    try:
        folder,rows,err=process(args.a,args.b,args.output,args.tolerance,args.density,
            not args.no_main_step,progress=lambda s:emit('log',value=s),
            colors=json.loads(args.colors_json),diff_step=not args.no_diff_step)
        emit('done',folder=str(folder),error=err)
        return 0
    except Exception:
        emit('error',value=traceback.format_exc());return 1


def main(argv=None):
    if '--dscompare-worker' in (sys.argv[1:] if argv is None else argv):
        return _worker_main(argv)
    p = argparse.ArgumentParser(description='DS Compare V3.2 FAST GUI')
    p.add_argument('--a', default='', help='Wstępnie wybrany model A STEP')
    p.add_argument('--b', default='', help='Wstępnie wybrany model B STEP')
    p.add_argument('--output', default=None, help='Folder wyników')
    opt = p.parse_args(argv)
    GUI(a=opt.a, b=opt.b, output=opt.output).mainloop()
    return 0


if __name__ == '__main__':
    sys.exit(main())
