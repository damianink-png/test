from __future__ import annotations
import csv,html,json
from pathlib import Path
from collections import defaultdict,Counter
from .step_io import export_colored_step, export_differences_step, COLORS
from .compare import Record

STATUS_PL={'SAME':'Bez zmian','RENAMED':'Bez zmian — zmieniona nazwa',
 'MOVED':'Zmiana położenia/obrotu','CHANGED':'Zmieniona geometria','ADDED':'Nowy',
 'REMOVED':'Usunięty','UNCERTAIN':'Wymaga weryfikacji'}

def _fmt(v):
    return '' if v is None else f'{v:.4f}'

def write_csv(path,headers,rows):
    with open(path,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f,delimiter=';');w.writerow(headers);w.writerows(rows)

def _bill(parts,density):
    # BOM by label and geometric approximate signature; geom aliases can be verified further.
    from .geometry import signature
    groups=defaultdict(list)
    for s in parts:
        groups[(s.name,signature(s))].append(s)
    rows=[]
    for (name,sig),items in sorted(groups.items(),key=lambda x:(x[0][0],str(x[0][1]))):
        # Signature is used as a BOM label/group; note large tolerance ambiguity.
        qty=len(items); v=items[0].volume; unit=v*1e-9*density
        rows.append((name,qty,round(v,4),round(unit,5),round(unit*qty,5),items[0].path))
    return rows

def produce(folder,a,b,records,density=7850.,generate_step=True,colors=None,
            diff_step=True,tolerance=0.01,progress=None):
    out=Path(folder);out.mkdir(parents=True,exist_ok=True)
    rows=[]
    for r in records:
        old=a[r.a_index] if r.a_index is not None else None
        new=b[r.b_index] if r.b_index is not None else None
        rows.append([STATUS_PL[r.status],r.status,old.name if old else '',new.name if new else '',
                     old.path if old else '',new.path if new else '',
                     _fmt(r.delta_x),_fmt(r.delta_y),_fmt(r.delta_z),_fmt(r.distance_mm),
                     _fmt(r.volume_delta_mm3),r.note])
    headers=['Status PL','Status','Nazwa A','Nazwa B','Pozycja A','Pozycja B',
             'Delta X [mm]','Delta Y [mm]','Delta Z [mm]','Przemieszczenie srodka [mm]',
             'Różnica objętości [mm3]','Uwagi']
    write_csv(out/'ZMIANY.csv',headers,rows)
    bom_a=_bill(a,density);bom_b=_bill(b,density)
    bh=['Nazwa','Ilość','Objętość 1 szt. [mm3]','Masa 1 szt. [kg]','Masa łącznie [kg]','Ścieżka']
    write_csv(out/'BOM_A.csv',bh,bom_a)
    write_csv(out/'BOM_B.csv',bh,bom_b)
    total_a=sum(s.volume*density*1e-9 for s in a)
    total_b=sum(s.volume*density*1e-9 for s in b)
    counts=Counter(x.status for x in records)
    palette={**COLORS,**(colors or {})}
    def hex_color(key):
        return '#' + ''.join(f'{round(min(1.,max(0.,c))*255):02x}' for c in palette[key])
    body=''.join('<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in row)+'</tr>' for row in rows)
    th=''.join('<th>'+html.escape(x)+'</th>' for x in headers)
    status=' '.join(f'{STATUS_PL[k]}: {v}' for k,v in sorted(counts.items()))
    htmltxt=f'''<!doctype html><html lang="pl"><head><meta charset="utf-8">
<title>DS Compare V3.3 — Geometry & Assembly Comparison</title>
<style>body{{font:14px system-ui,sans-serif;max-width:1600px;margin:32px auto;padding:0 18px;background:#101820;color:#e6edf4}}h1{{font-size:26px}}p{{line-height:1.55}}table{{border-collapse:collapse;width:100%;font-size:12px}}th,td{{border:1px solid #34465c;padding:7px;text-align:left;vertical-align:top}}th{{background:#29394b;position:sticky;top:0}}tr:nth-child(even){{background:#192638}}.panel{{background:#192638;border:1px solid #34465c;border-radius:10px;padding:18px;margin:16px 0}}.legend{{display:flex;gap:18px;flex-wrap:wrap}}.dot{{display:inline-block;width:13px;height:13px;border-radius:3px;margin-right:7px}}small{{color:#abbaca}}input{{padding:10px;width:100%;background:#24364b;color:white;border:1px solid #46607c;border-radius:5px;box-sizing:border-box}}</style></head><body>
<h1>DS Compare V3.3 — B-Rep STEP</h1><div class="panel"><p><b>Wynik:</b> {html.escape(status)}</p><p><b>Liczba brył:</b> A = {len(a)}, B = {len(b)}</p>
<p><b>Masa A:</b> {total_a:.3f} kg &nbsp; <b>Masa B:</b> {total_b:.3f} kg &nbsp; <b>Różnica:</b> {total_b-total_a:+.3f} kg</p>
<small>Przyjęta gęstość: {density:.1f} kg/m³ (jednakowa dla wszystkich brył), jednostka geometrii STEP: mm. Masa nie pochodzi z danych materiałowych ZW3D. BOM zawiera bryły, nie pełną strukturę natywnych złożeń.</small></div>
<div class="panel legend"><span><i class="dot" style="background:{hex_color("SAME")}"></i>Bez zmian / zmiana nazwy</span><span><i class="dot" style="background:{hex_color("CHANGED")}"></i>Nowe lub zmienione</span><span><i class="dot" style="background:{hex_color("REMOVED")}"></i>Usunięte</span><span><i class="dot" style="background:{hex_color("UNCERTAIN")}"></i>Niepewne</span></div>
<p><b>Uwaga:</b> prototyp testuje geometrię B-Rep za pomocą operacji Boolean, także po wyrównaniu sztywnym. Nie jest to porównanie historii operacji CAD ani bezpośredni odczyt pliku Z3. Niektóre symetryczne bryły i trudne modele STEP mogą wymagać ręcznej weryfikacji.</p>
<p>Pliki: ZMIANY.csv, BOM_A.csv, BOM_B.csv, POROWNANIE_KOLORY.step i ROZNICE_BREP.step (model pokazujący dokładnie dodany i usunięty materiał, jeśli eksport udany).</p>
<input id="search" placeholder="Filtruj zmiany: nazwa, status, uwagi" oninput="const q=this.value.toLowerCase();document.querySelectorAll('#table tbody tr').forEach(r=>r.style.display=r.innerText.toLowerCase().includes(q)?'':'none')">
<div style="overflow:auto;max-height:75vh"><table id="table"><thead><tr>{th}</tr></thead><tbody>{body}</tbody></table></div><footer style="margin-top:24px;color:#8c99ad;font-size:11px">Designed &amp; developed by Szymczyk Damian</footer></body></html>'''
    (out/'RAPORT.html').write_text(htmltxt,encoding='utf-8')
    err=None;details={'written':False,'solids':0,'changes':[],'errors':[]}
    if generate_step:
        try:
            if progress:progress('Eksport podstawowego kolorowego STEP...')
            export_colored_step(str(out/'POROWNANIE_KOLORY.step'),records,a,b,colors)
        except Exception as exc:
            err=str(exc)
            (out/'BŁĄD_EKSPORTU_STEP.txt').write_text(err,encoding='utf-8')
    if diff_step:
        try:
            if progress:progress('Tworzenie STEP z fragmentami dodanymi i usuniętymi...')
            details=export_differences_step(str(out/'ROZNICE_BREP.step'),records,a,b,tolerance,progress,colors=palette)
        except Exception as exc:
            details['errors'].append(str(exc))
    if details['changes']:
        write_csv(out/'DETAL_ROZNICE.csv',
            ['Nazwa A','Nazwa B','Usunięty materiał [mm3]','Dodany materiał [mm3]'],details['changes'])
    if details['errors']:
        (out/'UWAGI_ROZNICE_BREP.txt').write_text('\n'.join(details['errors']),encoding='utf-8')
    (out/'PODSUMOWANIE.json').write_text(json.dumps({'statuses':counts,'solids_A':len(a),'solids_B':len(b),
                        'colors_hex':{k:hex_color(k) for k in palette},'density_kg_m3':density,'mass_A_kg':total_a,'mass_B_kg':total_b,
                        'step_export_error':err,'diff_step':details},indent=2,ensure_ascii=False),encoding='utf-8')
    return out,err
