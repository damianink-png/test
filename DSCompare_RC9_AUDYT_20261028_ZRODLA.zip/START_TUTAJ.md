# DS Compare RC9 — ręczne wgranie i kompilacja

1. Rozpakuj ZIP. Wgraj do repozytorium folder `dscompare_rc9_manual` oraz
   `.github/workflows/dscompare-rc9-manual.yml`, zachowując ich ścieżki.
2. Przeczytaj `dscompare_rc9_manual/RAPORT_AUDYTU.md` i wyniki w `validation`.
3. W GitHub Actions wybierz **DS Compare RC9 manual audit** i **Run workflow**.
   Opcja `run_cad` włącza sześć dużych scenariuszy po poprawnej regresji i kompilacji.
4. Pobierz artefakt Windows x64; uruchamiaj EXE z całym towarzyszącym folderem.
   Osobny artefakt zawiera źródła; pozostałe — logi i wyniki testów.

Workflow sam nie uruchamia się przy push i nie anuluje poprzednich uruchomień.
Jeżeli nie widać go na liście Actions, plik workflow musi być obecny na domyślnej
gałęzi repozytorium. Nie trzeba ponownie nakładać starych patchy RC9.

Lokalnie na Windows x64, Python 3.11: w folderze `dscompare_rc9_manual` uruchom
`BUDUJ_WINDOWS.ps1`. Wynik: `dist/DSCompare/DSCompare.exe`.

To paczka źródeł, nie gotowy EXE. Duże testy Windows tej wersji nie zostały
uruchomione przez autora tej paczki. Historyczne README i verify_package.py
w źródłach odnoszą się do starszych wydań; aktualna procedura jest powyżej.
