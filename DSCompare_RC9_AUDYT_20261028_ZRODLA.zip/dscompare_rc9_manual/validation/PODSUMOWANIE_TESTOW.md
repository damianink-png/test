# Wyniki ponownych testów odtworzonej paczki

| Zestaw | PASS | Błędy | Pominięte | Czas zestawu |
|---|---:|---:|---:|---:|
| full-regressions | 209 | 0 | 0 | 377.78 s |
| integration | 60 | 0 | 1 | 8.37 s |

Zestawy częściowo się pokrywają. To testy źródeł na Linux, nie sześć dużych scenariuszy Windows EXE.
Test JavaScript podglądu i kontrola składni Python: PASS.
Brak porównywalnego benchmarku szybkości/RAM względem RC6.
