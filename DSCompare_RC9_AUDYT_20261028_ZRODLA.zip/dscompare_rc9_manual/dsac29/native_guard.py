"""Crash-contained OCCT rigid equality for large assemblies.

The parent NEVER turns native crashes, timeouts or malformed replies into SAME.
Only a positive verdict from the unmodified equivalent_rigid B-Rep routine
may be used as an equality proof. Each invocation uses its own process so an
Open CASCADE access violation cannot terminate the comparison coordinator.
"""
from __future__ import annotations
import json, os, subprocess, sys, tempfile, time
from pathlib import Path


_negative_saved=0

class NativeGeometryFailure(RuntimeError):
    """Geometry comparison incomplete; caller must fail the whole comparison."""


def _preserve_failure(root,operation):
    if os.getenv('DSCOMPARE_SAVE_FAILED_BREP','0')!='1':return
    try:
        import shutil
        from . import trace_r22 as trace
        if trace._path is None:return
        destination=trace._path.parent/'FAILED_BREP'/operation
        destination.mkdir(parents=True,exist_ok=True)
        # Stop after the first failure of each operation; preserve exact bytes.
        if (destination/'request.json').exists():return
        for file in Path(root).iterdir():
            if file.is_file():shutil.copy2(file,destination/file.name)
    except OSError:pass


def _load_brep(path):
    from OCP.BRepTools import BRepTools
    from OCP.TopoDS import TopoDS_Shape
    from OCP.BRep import BRep_Builder
    shape = TopoDS_Shape()
    with open(path, 'rb') as f:
        result = BRepTools.Read_s(shape, f, BRep_Builder())
    if result is False or shape.IsNull():
        raise ValueError('Nie można odczytać bryły B-Rep w odizolowanym procesie')
    return shape


def worker(request_path, result_path):
    """Dedicated EXE dispatch mode; no Qt and no export files are loaded."""
    req = json.loads(Path(request_path).read_text(encoding='utf-8'))
    from . import trace_r22 as trace
    trace.setup(Path(result_path).parent)
    from .geometry import describe, equivalent_rigid
    if req.get('operation') == 'material_regions':
        from .material_guard import worker as material_worker
        return material_worker(req,result_path)
    if req.get('operation') == 'world_session':
        from .native_session import serve
        return serve(req['directory'])
    def report(phase):
        Path(result_path).with_suffix('.phase').write_text(phase,encoding='utf-8')
    report('load_brep')
    a_shape = _load_brep(req['a'])
    b_shape = _load_brep(req['b'])
    if req.get('operation') == 'world_reexport':
        from .step_reexport_tolerance import reexport_equivalent_world
        from .brep_safety import is_valid,validated_copy
        original_invalid=not is_valid(a_shape) or not is_valid(b_shape)
        if original_invalid:
            report('validate_copy_repair')
            validated_copy(a_shape,float(req['tolerance']))
            validated_copy(b_shape,float(req['tolerance']))
        report('describe_shapes')
        a = describe(a_shape, 'A', 'native-guard/A')
        b = describe(b_shape, 'B', 'native-guard/B')
        matched = bool(reexport_equivalent_world(
            a, b, float(req['tolerance']),
            allow_boolean=(bool(req.get('allow_boolean', False)) and not original_invalid),
            _repair_boundary_only=original_invalid,progress=report))
        response = dict(ok=True, match=matched)
    elif req.get('operation') == 'common':
        from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
        from OCP.BRepTools import BRepTools
        from .material_deltas import operate, volume
        common = operate(BRepAlgoAPI_Common,a_shape,b_shape,float(req['tolerance']))
        with Path(req['common_shape']).open('wb') as handle:
            BRepTools.Write_s(common,handle)
        response = dict(ok=True, common_volume=float(volume(common)))
    else:
        a = describe(a_shape, 'A', 'native-guard/A')
        b = describe(b_shape, 'B', 'native-guard/B')
        match, r, t = equivalent_rigid(a,b,float(req['tolerance']))
        response = dict(ok=True, match=bool(match),
                        rotation=None if r is None else r.tolist(),
                        translation=None if t is None else t.tolist())
    target = Path(result_path)
    tmp = target.with_suffix('.partial')
    tmp.write_text(json.dumps(response),encoding='utf-8')
    tmp.replace(target)
    return 0


def guarded_rigid(a, b, tolerance, *, timeout_s=35, process_args=None):
    """Serialized independent B-Rep check with a hard per-call timeout.

    The OCC shape data is passed via binary .brep files, not Python pickles.
    A child can crash without changing the source parts or recording a match.
    """
    import numpy as np
    from OCP.BRepTools import BRepTools
    from . import trace_r22 as trace
    started=time.monotonic()
    with tempfile.TemporaryDirectory(prefix='dscompare_rigid_') as td:
        root=Path(td)
        for name,part in (('A',a),('B',b)):
            with (root/(name+'.brep')).open('wb') as f:
                BRepTools.Write_s(part.shape,f)
        request=root/'request.json'; reply=root/'reply.json'
        request.write_text(json.dumps({'a':str(root/'A.brep'), 'b':str(root/'B.brep'),
                                       'tolerance':float(tolerance)}),encoding='utf-8')
        argv=process_args or ([sys.executable,'--native-brep-compare'] if getattr(sys,'frozen',False) else [sys.executable,'-m','dsac29.native_guard'])
        trace.mark('native_guard','BEGIN',timeout_s=timeout_s)
        try:
            result=subprocess.run([*argv,str(request),str(reply)],timeout=timeout_s,
                                  stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,check=False)
        except subprocess.TimeoutExpired as exc:
            _preserve_failure(root,'rigid')
            trace.mark('native_guard','TIMEOUT',seconds=round(time.monotonic()-started,2))
            raise NativeGeometryFailure('Przekroczono limit odizolowanego testu B-Rep '+str(timeout_s)+' s; analiza niekompletna') from exc
        if result.returncode!=0 or not reply.exists():
            _preserve_failure(root,'rigid')
            trace.mark('native_guard','CRASH',exit_code=result.returncode)
            err=(result.stderr or b'')[-700:].decode('utf-8',errors='replace')
            raise NativeGeometryFailure(f'Proces B-Rep zakończył się błędem {result.returncode}; {err}')
        try:
            data=json.loads(reply.read_text(encoding='utf-8'))
            if not isinstance(data.get('match'),bool) or data.get('ok') is not True:
                raise ValueError('Nieprawidłowy wynik child B-Rep')
            r=None if data.get('rotation') is None else np.asarray(data['rotation'],float)
            t=None if data.get('translation') is None else np.asarray(data['translation'],float)
            if data['match'] and (r is None or r.shape!=(3,3) or t is None or t.shape!=(3,) or not np.isfinite(r).all() or not np.isfinite(t).all()):
                raise ValueError('Nieprawidłowa transformacja testu B-Rep')
        except (OSError,ValueError,TypeError,KeyError) as exc:
            raise NativeGeometryFailure('Wynik procesu geometrycznego uszkodzony — brak rozstrzygnięcia') from exc
        trace.mark('native_guard','END',seconds=round(time.monotonic()-started,2),match=data['match'])
        return data['match'],r,t


if __name__ == '__main__':
    if len(sys.argv)!=3:raise SystemExit(2)
    raise SystemExit(worker(sys.argv[1],sys.argv[2]))


def guarded_common(shape_a, shape_b, tolerance, *, timeout_s=35, process_args=None):
    """Boolean Common in an isolated native process; return validated B-Rep shape.

    Any failed or slow native operation aborts the comparison. Returning zero
    intersection when a worker crashed would conceal real material changes.
    """
    from OCP.BRepTools import BRepTools
    from . import trace_r22 as trace
    with tempfile.TemporaryDirectory(prefix='dscompare_common_') as td:
        root=Path(td)
        for name,shape in (('A',shape_a),('B',shape_b)):
            with (root/(name+'.brep')).open('wb') as output:
                BRepTools.Write_s(shape, output)
        common=root/'common.brep'
        req=root/'request.json'; reply=root/'reply.json'
        req.write_text(json.dumps(dict(operation='common',a=str(root/'A.brep'),
            b=str(root/'B.brep'),common_shape=str(common),tolerance=float(tolerance))),encoding='utf-8')
        argv=process_args or ([sys.executable,'--native-brep-compare'] if getattr(sys,'frozen',False) else [sys.executable,'-m','dsac29.native_guard'])
        trace.mark('native_common','BEGIN',timeout_s=timeout_s)
        try:
            proc=subprocess.run([*argv,str(req),str(reply)],timeout=timeout_s,
                                stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,check=False)
        except subprocess.TimeoutExpired as exc:
            _preserve_failure(root,'common')
            trace.mark('native_common','TIMEOUT',timeout_s=timeout_s)
            raise NativeGeometryFailure('Timeout odizolowanej operacji Common — wynik rewizji niekompletny') from exc
        if proc.returncode!=0 or not reply.exists() or not common.exists():
            _preserve_failure(root,'common')
            trace.mark('native_common','CRASH',exit_code=proc.returncode)
            raise NativeGeometryFailure('Odizolowany OCC Common zakończył się błędem '+str(proc.returncode)+' '+proc.stderr.decode('utf8',errors='replace')[-2000:])
        try:
            data=json.loads(reply.read_text(encoding='utf-8'))
            if data.get('ok') is not True or not isinstance(data.get('common_volume'),(int,float)):
                raise ValueError('Nieprawidłowa odpowiedź')
            import math
            if not math.isfinite(data['common_volume']) or data['common_volume']<0:
                raise ValueError('Invalid Common reply volume')
            result=_load_brep(common)
            from .material_deltas import volume
            if abs(volume(result)-float(data['common_volume']))>max(1.e-5,abs(data['common_volume'])*1.e-6):
                raise ValueError('Weryfikacja przekazanego kształtu Common nie powiodła się')
        except (ValueError,OSError,TypeError) as exc:
            raise NativeGeometryFailure('Nie udało się zweryfikować odizolowanego Common') from exc
        trace.mark('native_common','END',common_volume=data['common_volume'],native_operations=_worker_metrics(root))
        return result


def guarded_world_reexport(a, b, tolerance, *, timeout_s=35,
                           allow_boolean=False, process_args=None):
    """Subprocess-only B-Rep world equivalence proof for large STEP assemblies.

    A crash/timeout is always INCOMPLETE, never SAME, CHANGED or REMOVED.
    """
    from OCP.BRepTools import BRepTools
    from . import trace_r22 as trace
    if not 0 < float(tolerance) <= 1:
        raise ValueError('Invalid B-Rep tolerance')
    started = time.monotonic()
    with tempfile.TemporaryDirectory(prefix='dscompare_world_') as td:
        root = Path(td)
        for name, part in (('A', a), ('B', b)):
            with (root / (name + '.brep')).open('wb') as handle:
                BRepTools.Write_s(part.shape, handle)
        request = root / 'request.json'
        reply = root / 'reply.json'
        request.write_text(json.dumps({
            'operation': 'world_reexport',
            'a': str(root / 'A.brep'),
            'b': str(root / 'B.brep'),
            'tolerance': float(tolerance),
            'allow_boolean': bool(allow_boolean),
        }), encoding='utf-8')
        argv = process_args or (
            [sys.executable, '--native-brep-compare'] if getattr(sys, 'frozen', False)
            else [sys.executable, '-m', 'dsac29.native_guard'])
        trace.mark('native_world', 'BEGIN', timeout_s=timeout_s)
        try:
            from .native_session import current
            session = current() if process_args is None else None
            if session is not None:
                session.execute(request, reply, timeout_s)
                from types import SimpleNamespace
                proc = SimpleNamespace(returncode=0)
            else:
                proc = subprocess.run([*argv, str(request), str(reply)],
                    timeout=timeout_s, stdout=subprocess.DEVNULL,
                    stderr=subprocess.PIPE, check=False)
        except subprocess.TimeoutExpired as exc:
            trace.mark('native_world', 'TIMEOUT',
                       seconds=round(time.monotonic()-started, 2))
            raise NativeGeometryFailure(
                'Timeout odizolowanej weryfikacji STEP — analiza niekompletna; etap: '+
                (reply.with_suffix('.phase').read_text(encoding='utf-8') if reply.with_suffix('.phase').exists() else 'start procesu')) from exc
        except NativeGeometryFailure as exc:
            _preserve_failure(root,'world')
            phase=reply.with_suffix('.phase')
            detail=phase.read_text(encoding='utf-8') if phase.exists() else 'start procesu'
            raise NativeGeometryFailure(f'{exc}; etap: {detail}; A: {a.path}; B: {b.path}') from exc
        if proc.returncode != 0 or not reply.exists():
            trace.mark('native_world', 'CRASH', exit_code=proc.returncode)
            raise NativeGeometryFailure(
                'Awaria odizolowanej weryfikacji STEP: '+str(proc.returncode))
        try:
            data = json.loads(reply.read_text(encoding='utf-8'))
            if data.get('ok') is not True or type(data.get('match')) is not bool:
                raise ValueError('Invalid world equality response')
        except (ValueError, OSError, TypeError) as exc:
            raise NativeGeometryFailure(
                'Nieprawidłowy wynik weryfikacji STEP — analiza niekompletna') from exc
        trace.mark('native_world', 'END', match=data['match'],
                   seconds=round(time.monotonic()-started, 3))
        global _negative_saved
        if not data['match'] and os.getenv('DSCOMPARE_SAVE_FAILED_BREP','0')=='1' and _negative_saved<20:
            _negative_saved+=1
            _preserve_failure(root,f'world_negative_{_negative_saved:02d}')
        return data['match']

def _worker_metrics(root):
    try:
        entries=[json.loads(line) for line in (Path(root)/'_ETAPY_DIAGNOSTYKA.jsonl').read_text(encoding='utf8').splitlines()]
        return [entry for entry in entries if str(entry.get('stage','')).startswith('occt_') or entry.get('stage')=='brep_repair']
    except (OSError,ValueError):return []
